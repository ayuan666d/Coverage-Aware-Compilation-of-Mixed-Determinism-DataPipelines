"""Report vertical gaps in each column of a two-column PDF (float heights)."""
import sys
import pymupdf


def gaps(pdf_path, min_gap=40):
    doc = pymupdf.open(pdf_path)
    print(f"== {pdf_path}")
    for pno in range(len(doc)):
        page = doc[pno]
        H = page.rect.height
        for col, (xa, xb) in enumerate([(40, 300), (300, 570)]):
            ys = []
            for b in page.get_text("dict")["blocks"]:
                x0, y0, x1, y1 = b["bbox"]
                if y0 > H - 40 or y1 < 55:
                    continue
                if x0 < 100 and x1 > 450:
                    continue  # wide block
                if xa <= x0 < xb:
                    ys.append((y0, y1))
            ys.sort()
            if not ys:
                continue
            prev = 55.0
            for y0, y1 in ys:
                if y0 - prev > min_gap:
                    print(f"  p{pno+1:>2}c{col}  gap {prev:6.1f} -> {y0:6.1f}  ({y0-prev:5.1f}pt)")
                prev = max(prev, y1)


if __name__ == "__main__":
    for p in sys.argv[1:]:
        gaps(p)
