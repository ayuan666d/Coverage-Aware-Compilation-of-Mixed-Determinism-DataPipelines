"""E48b：BIRD 线上的 dense 上下文预算敏感性。

为什么单独一条线
----------------
论文的 +10.78（R@5@10k）是 BIRD 读数，而 BIRD 的目录与 Spider 线不同：
  base   = 876 spider 表 + 62 bird 表 = 951
  donors = base（E32_DONOR=fixed，与评估集解耦）= 938
  place  = 全部 176 库的真实表数
  extra  = legacy_tables(donors, 9049, place=place, seed=40)，同库派生 70%
这套构造由 e32_scale_forge.py 的 LEGACY + fixed 分支产生（见
D:\\vldb2027_e11\\e48_bird_base.log 首三行）。本脚本只复刻目录构造，
不跑 FORGE 特征、不跑 bm25/fuse，只把 dense 在 128 / 512 / 2048 三个预算下重编码。

校验
----
1) donors 必须是 938、extra 必须是 9049、"同库派生 70%"由 legacy_tables 自己打印；
2) seq=128 的读数必须复现 e48_bird_base.json 的 951 R@5=80.13、10k R@5=34.41。
   复现不了就说明目录或指标口径漂移，后续数字全部作废。

指标与 e43 一致：取 top-20，R@1 = top-1 命中金标比例，R@5 = top-5 覆盖金标比例
（多金标部分计分），另记 top1 / hit20。

用法：
  E48B_SEQS="128,2048" E48B_SIZES="951,4000,10000" python e48b_dense_bird.py
输出：D:\\vldb2027_e11\\e48b_dense_bird_longctx.json
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
import e28_scale as s28  # noqa: E402
from e40_legacy import legacy_tables  # noqa: E402

WORK = Path(r"D:\vldb2027_e11")
REPO = Path(__file__).resolve().parents[2]
CASES = Path(os.environ.get("E48B_CASES", str(REPO / "06_结果" / "e48_bird_dev_cases.json")))
OUT = Path(os.environ.get("E48B_OUT", str(WORK / "e48b_dense_bird_longctx.json")))
SEQS = [int(x) for x in os.environ.get("E48B_SEQS", "128,2048").split(",")]
SIZES = sorted(int(x) for x in os.environ.get("E48B_SIZES", "951,4000,10000").split(","))
CHUNK = int(os.environ.get("E48B_CHUNK", "64"))
BATCH = int(os.environ.get("E48B_BATCH", "0"))  # 0 = 按 token 预算自动取


def fid(db, name):
    return f"{str(db).lower()}::{str(name).lower()}"


def doc_text(t):
    parts = [f"{t['db']} :: {t['name']}"]
    cols, vals = [], []
    for c in t["columns"]:
        cols.append(c["name"])
        vals += [str(v) for v in (c.get("values") or [])[:12]]
    parts.append("columns: " + ", ".join(cols))
    if vals:
        parts.append("values: " + ", ".join(vals))
    return " | ".join(parts)


def ev(ranked, gold):
    return dict(R1=len(set(ranked[:1]) & gold) / len(gold),
                R5=len(set(ranked[:5]) & gold) / len(gold),
                top1=1.0 if ranked[0] in gold else 0.0,
                hit20=len(set(ranked[:20]) & gold) / len(gold))


def build_catalog():
    g.SPLIT_IDENT = True
    cache = json.load(open(WORK / "schema_cache.json", encoding="utf-8"))
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    test = [c for c in cases if c["split"] == "test"]

    tabs = []
    for db in cache["spider"]:
        tabs += s28.tables_of(cache, db, prefix=True)
    bird = []
    for db, s in cache["bird"].items():
        bird += [dict(t, db=db) for t in s["tables"]]

    # e48 的实际跑法（与 e43 的 donor 规则相同）：只从 Spider 侧排除 test 库，
    # BIRD 的 75 张表全部保留。注意 Spider 有一个与 BIRD 同名的库 'financial'（13 张表），
    # 所以 donors = 876 - 13 + 75 = 938。核对点：938，且 extra 变体
    # rename 2316 / denorm 2251 / agg 1827 / subset 2655 与 e48_bird_base.log 首行一致。
    test_dbs = {c["db_id"] for c in test}
    donors = [t for t in tabs if t["db"] not in test_dbs] + bird
    base = tabs + bird if max(SIZES) > len(tabs) else tabs
    n_real = len(base)
    place = {db: len(cache["spider"][db]["tables"]) for db in cache["spider"]}
    place.update({db: len(s["tables"]) for db, s in cache["bird"].items()})

    need = max(SIZES) - n_real
    extra = legacy_tables(donors, need, place=place,
                          seed=int(os.environ.get("LEGACY_SEED", "40"))) if need > 0 else []
    all_tabs = base + extra
    print(f"[catalog] N={len(all_tabs)} 真实={n_real} 干扰={len(extra)} "
          f"donors={len(donors)} 库={len(place)} 问题={len(test)}", flush=True)
    return all_tabs, n_real, test


def main():
    all_tabs, n_real, test = build_catalog()
    doc_ids = [fid(t["db"], t["name"]) for t in all_tabs]
    h = hashlib.sha1()
    for i, t in enumerate(all_tabs):
        h.update(f"{doc_ids[i]}|{len(t['columns'])}|".encode())
    doc_hash = h.hexdigest()[:16]
    print(f"[catalog] doc_hash={doc_hash}", flush=True)

    docs = [doc_text(t) for t in all_tabs]
    qs = [c["question"] for c in test]
    golds = [{fid(c["db_id"], x) for x in c["gold"]} for c in test]
    print(f"[gold] 平均金标 {np.mean([len(x) for x in golds]):.2f} 张", flush=True)

    from tokenizers import Tokenizer
    tk = Tokenizer.from_file(str(WORK / "models" / "Qwen3-Embedding-0.6B" / "tokenizer.json"))
    doc_len = np.array([len(e.ids) for e in tk.encode_batch(docs, add_special_tokens=False)])
    q_len = np.array([len(e.ids) for e in tk.encode_batch(qs, add_special_tokens=False)])
    print("[len] docs median %d p90 %d p99 %d max %d | queries median %d max %d"
          % (np.median(doc_len), np.percentile(doc_len, 90), np.percentile(doc_len, 99),
             doc_len.max(), np.median(q_len), q_len.max()), flush=True)

    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer(str(WORK / "models" / "Qwen3-Embedding-0.6B"), device="cuda")
    model.half()
    order = np.argsort(doc_len, kind="stable")
    res = json.load(open(OUT, encoding="utf-8")) if OUT.exists() else {}

    for seq in SEQS:
        model.max_seq_length = seq
        bs = BATCH or max(4, min(48, int(os.environ.get("E48B_TOKEN_BUDGET", "8192")) // seq))
        t0 = time.perf_counter()
        Q = model.encode(qs, batch_size=32, convert_to_numpy=True,
                         normalize_embeddings=True, prompt_name="query",
                         show_progress_bar=False).astype(np.float32)
        D = np.empty((len(docs), Q.shape[1]), dtype=np.float32)
        for c0 in range(0, len(order), CHUNK):
            idx = order[c0:c0 + CHUNK]
            E = model.encode([docs[i] for i in idx], batch_size=bs,
                             convert_to_numpy=True, normalize_embeddings=True,
                             show_progress_bar=False).astype(np.float32)
            D[idx] = E
        enc_s = time.perf_counter() - t0
        n_trunc = int((doc_len > seq).sum())
        print(f"[seq={seq}] batch={bs} 编码 {enc_s:.0f}s truncated {n_trunc}/{len(docs)} "
              f"({100.0*n_trunc/len(docs):.1f}%)", flush=True)

        S_all = Q @ D.T
        for n in SIZES:
            tag = "951" if n == 951 else f"{n // 1000}k-syn"
            sub_ids = [x.lower() for x in doc_ids[:n]]
            rows = []
            for qi, gold in enumerate(golds):
                order_q = np.argsort(-S_all[qi, :n])[:20]
                rows.append(ev([sub_ids[i] for i in order_q], gold))
            agg = {k: float(np.mean([r[k] for r in rows])) for k in ("R1", "R5", "top1", "hit20")}
            key = f"seq{seq}"
            res.setdefault(key, {})[tag] = dict(N=n, seq=seq, n_real=n_real,
                                                n_synth=n - n_real, doc_hash=doc_hash,
                                                truncated_docs=n_trunc,
                                                truncated_frac=n_trunc / len(docs),
                                                encode_s=enc_s, **agg)
            res.setdefault("_meta", {})["cases"] = str(CASES)
            res["_meta"].update({"doc_hash": doc_hash, "donors": 938,
                                 "model": "Qwen3-Embedding-0.6B", "dtype": "fp16"})
            json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            print(f"  [{key} {tag}] N={n:6d} R1 {agg['R1']*100:5.2f} R5 {agg['R5']*100:5.2f} "
                  f"top1 {agg['top1']*100:5.2f} hit20 {agg['hit20']*100:5.2f}", flush=True)
        del S_all, Q, D
        import gc
        gc.collect()
        import torch
        torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
