"""E12 addendum v2: the join-path witness experiment (typed computation, corrected).

Design (v2 fixes the v1 design flaw — the logic layer can only certify candidates
the probabilistic layer proposed):
  1. Anchor extraction: literal strings in the question (quoted / capitalized /
     acronyms / numerals).
  2. Scoping WITHOUT gold leakage: a global value->databases index (built once,
     cached) maps each anchor to the databases containing it; the logic layer's
     jurisdiction = the union of those databases. Candidates = the base pool
     (gp_ex top5) UNION every table of every jurisdiction database.
  3. Schema completion: declared FK edges + inclusion-dependency discovery over
     TRIMmed column value sets (ratio >= 0.9) — the declared graph is incomplete
     (792 declared vs ~16.5k data-evident edges); joins execute with TRIM
     normalization (raw values are dirty: ' AHD' vs 'AHD').
  4. A candidate earns a path witness when an executable non-empty join of 0..3
     hops binds an anchor to it. Rerank: base order + gamma * evidence; gamma
     tuned on 200 train questions (pools built identically from anchors).

Arms: base / +point (hop-0 only) / +path (hop 1-3) / +both.
Pre-registered predictions: gap-55 repairs concentrate in ambig+weak; semantic
stays unrepaired (no database-native witness exists for it).
"""
from __future__ import annotations

import json
import re
import sqlite3
from collections import defaultdict
from pathlib import Path

import numpy as np

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
SPIDER_DB = WORK / "spider" / "database"
CASES = REPO / "06_结果" / "e11_cases.json"
GP = REPO / "06_结果" / "e12_gp.json"
OUT = REPO / "06_结果" / "e12_joinpath.json"
IND_CACHE = WORK / "e12_ind_cache.json"
VAL_INDEX = WORK / "e12_value_index.json"

QUOTED = re.compile(r'"([^"]+)"|\'([^\']+)\'')
CAPSEQ = re.compile(r"\b([A-Z][a-zA-Z0-9]*(?:\s+[A-Z][a-zA-Z0-9]*)*)\b")
ACRO = re.compile(r"\b([A-Z]{2,}[0-9]*)\b")
NUM = re.compile(r"\b(\d{3,4})\b")

conns = {}
metas = {}


def open_db(db):
    if db not in conns:
        p = SPIDER_DB / db / f"{db}.sqlite"
        conns[db] = sqlite3.connect(f"file:{p}?mode=ro", uri=True) if p.exists() else None
    return conns[db]


class Meta:
    def __init__(self, db):
        self.ok = False
        self.con = None
        self.cols = {}
        self.real = {}
        con = open_db(db)
        if con is None:
            return
        self.con = con
        have = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
        self.real = {t.lower(): t for t in have}
        for tl, tr in self.real.items():
            cols = [(c[1], c[2]) for c in con.execute(f'PRAGMA table_info("{tr}")')]
            self.cols[tl] = [c for c, ty in cols
                             if ty and any(x in ty.lower() for x in ("text", "char", "varchar"))]
        self.ok = True

    def ground(self, tl, v):
        out = []
        if not self.ok or tl not in self.cols:
            return out
        tr = self.real[tl]
        for col in self.cols[tl]:
            try:
                if self.con.execute(
                        f'SELECT 1 FROM "{tr}" WHERE TRIM("{col}") = TRIM(?) COLLATE NOCASE LIMIT 1',
                        (v,)).fetchone():
                    out.append(col)
                elif len(v) >= 3 and v.isalpha() and self.con.execute(
                        f'SELECT 1 FROM "{tr}" WHERE "{col}" LIKE ? COLLATE NOCASE LIMIT 1',
                        (f"%{v}%",)).fetchone():
                    out.append(col)
            except sqlite3.Error:
                continue
        return out


def meta(db):
    if db not in metas:
        metas[db] = Meta(db)
    return metas[db]


def value_strings(q):
    out = []
    for m in QUOTED.finditer(q):
        v = (m.group(1) or m.group(2)).strip()
        if v:
            out.append(v)
    seen = set()
    for v in [m.group(1) for m in CAPSEQ.finditer(q)] + \
             [m.group(1) for m in ACRO.finditer(q)] + \
             [m.group(1) for m in NUM.finditer(q)]:
        if v.strip() and v.strip().lower() not in seen:
            seen.add(v.strip().lower())
            out.append(v.strip())
    return out


def main():
    cache = json.load(open(WORK / "schema_cache.json", encoding="utf-8"))["spider"]
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    gp = json.load(open(GP, encoding="utf-8"))
    gpx = {r["qid"]: r for r in gp["rows"]["gp_ex"]}
    ex = {r["qid"]: r for r in json.load(open(REPO / "06_结果" / "e12_exact.json", encoding="utf-8"))}
    qtext = {c["qid"]: c["question"] for c in cases}
    split = {c["qid"]: c["split"] for c in cases}
    db_of = {c["qid"]: c["db_id"] for c in cases}
    gold_of = {c["qid"]: {f"{c['db_id']}::{g.lower()}" for g in c["gold"]} for c in cases}
    qids = sorted(qtext, key=lambda q: int(q[2:]))

    # ---- schema completion: declared FK + inclusion dependencies ----
    adj = {}
    for db, s in cache.items():
        have = {t["name"].lower() for t in s["tables"]}
        a = defaultdict(list)
        for x, ca, y, cb in s.get("fks", []):
            if x.lower() in have and y.lower() in have and x.lower() != y.lower():
                a[x.lower()].append((y.lower(), ca, cb))
                a[y.lower()].append((x.lower(), cb, ca))
        adj[db] = a
    declared_total = sum(len(s.get("fks", [])) for s in cache.values())
    if IND_CACHE.exists():
        ind_data = json.load(open(IND_CACHE, encoding="utf-8"))
    else:
        ind_data = {}
        for db_i, s in cache.items():
            m = meta(db_i)
            if not m.ok:
                continue
            declared = {(x.lower(), ca.lower(), y.lower(), cb.lower())
                        for x, ca, y, cb in s.get("fks", [])}
            sets, types = {}, {}
            for tl, tr in m.real.items():
                for col, ty in [(c[1], c[2]) for c in m.con.execute(f'PRAGMA table_info("{tr}")')]:
                    tcl = (ty or "").lower()
                    k = ('num' if any(x in tcl for x in ('int', 'real', 'num', 'dec'))
                         else ('txt' if any(x in tcl for x in ('text', 'char', 'varchar')) else None))
                    if k is None:
                        continue
                    try:
                        vals = {str(v).strip().lower() for (v,) in m.con.execute(
                            f'SELECT DISTINCT TRIM("{col}") FROM "{tr}" LIMIT 50000') if v is not None}
                    except sqlite3.Error:
                        continue
                    vals.discard("")
                    if len(vals) >= 2:
                        sets[(tl, col)] = vals
                        types[(tl, col)] = k
            items = list(sets.items())
            inferred = []
            for i in range(len(items)):
                for j in range(len(items)):
                    if i == j:
                        continue
                    (t1, c1), s1 = items[i]
                    (t2, c2), s2 = items[j]
                    if t1 == t2 or types[(t1, c1)] != types[(t2, c2)]:
                        continue
                    if (t1.lower(), c1.lower(), t2.lower(), c2.lower()) in declared or \
                       (t2.lower(), c2.lower(), t1.lower(), c1.lower()) in declared:
                        continue
                    inter = len(s1 & s2)
                    if min(len(s1), len(s2)) >= 2 and inter / min(len(s1), len(s2)) >= 0.9:
                        inferred.append([t1, c1, t2, c2])
            ind_data[db_i] = inferred
            print(f"  IND {db_i}: {len(inferred)}", flush=True)
        json.dump(ind_data, open(IND_CACHE, "w", encoding="utf-8"))
    inferred_total = 0
    seen_ind = set()
    for db_i, inferred in ind_data.items():
        for edge in inferred:
            t1, c1, t2, c2 = edge[0], edge[1], edge[2], edge[3]
            key = (db_i, frozenset({(t1.lower(), c1.lower()), (t2.lower(), c2.lower())}))
            if key in seen_ind:
                continue
            seen_ind.add(key)
            inferred_total += 1
            adj[db_i][t1].append((t2, c1, c2))
            adj[db_i][t2].append((t1, c2, c1))
    print(f"schema completion: declared={declared_total}, inferred(undirected)="
          f"{inferred_total} (+{inferred_total / max(declared_total, 1):.0%})", flush=True)

    # ---- jurisdiction: value -> databases index (no gold leakage) ----
    if VAL_INDEX.exists():
        val_index = {k: set(v) for k, v in json.load(open(VAL_INDEX, encoding="utf-8")).items()}
        print("value index loaded", flush=True)
    else:
        val_index = defaultdict(set)
        for db_i in cache:
            m = meta(db_i)
            if not m.ok:
                continue
            for tl in m.cols:
                tr = m.real[tl]
                for col in m.cols[tl]:
                    try:
                        vs = [str(v).strip().lower() for (v,) in m.con.execute(
                            f'SELECT DISTINCT TRIM("{col}") FROM "{m.real[tl]}" LIMIT 20000')
                            if v is not None]
                    except sqlite3.Error:
                        continue
                    for v in vs:
                        if v:
                            val_index[v].add(db_i)
            print(f"  index {db_i}", flush=True)
        json.dump({k: sorted(v) for k, v in val_index.items()},
                  open(VAL_INDEX, "w", encoding="utf-8"))
    print(f"value index: {len(val_index)} values", flush=True)

    def jurisdiction(q):
        dbs = set()
        for v in value_strings(qtext[q]):
            dbs |= val_index.get(v.strip().strip("'\"").lower(), set())
        return dbs

    # ---- witnesses ----
    ground_cache = {}

    def ground_in_db(db, v):
        key = (db, v)
        if key in ground_cache:
            return ground_cache[key]
        m = meta(db)
        out = []
        if m.ok:
            for tl in m.cols:
                for col in m.ground(tl, v):
                    out.append((tl, col))
        ground_cache[key] = out
        return out

    def path_witness(db, anchor_tbl, anchor_col, v, target_tl, max_hops=3):
        con = meta(db).con
        if con is None:
            return False
        a = adj[db]
        start_real = meta(db).real.get(anchor_tbl, anchor_tbl)
        cond = f'TRIM(CAST(j0."{anchor_col}" AS TEXT)) = TRIM(?) COLLATE NOCASE'
        stack = [(anchor_tbl, anchor_col, {anchor_tbl}, 0,
                  [f'SELECT 1 FROM "{start_real}" AS j0'], [v])]
        while stack:
            t, _col, seen, hops, frm, params = stack.pop()
            if hops > 0 and t == target_tl:
                try:
                    if con.execute(" ".join(frm) + f" WHERE {cond} LIMIT 1", params).fetchone():
                        return True
                except sqlite3.Error:
                    pass
                continue
            if hops == max_hops:
                continue
            for (nb, ca, cb) in a.get(t, ()):
                if nb in seen:
                    continue
                jr = meta(db).real.get(nb, nb)
                frm2 = frm + [f'JOIN "{jr}" AS j{hops+1} '
                              f'ON TRIM(CAST(j{hops}."{ca}" AS TEXT)) = '
                              f'TRIM(CAST(j{hops+1}."{cb}" AS TEXT))']
                if nb == target_tl:
                    try:
                        if con.execute(" ".join(frm2) + f" WHERE {cond} LIMIT 1",
                                       params).fetchone():
                            return True
                    except sqlite3.Error:
                        pass
                stack.append((nb, _col, seen | {nb}, hops + 1, frm2, params))
        return False

    def evidence(db, vals, cand_tl, use_path):
        point, path = 0, 0
        m = meta(db)
        if not m.ok:
            return 0, 0
        for v in vals:
            v = v.strip().strip("'\"")
            if not v:
                continue
            if m.ground(cand_tl, v):
                point += 1
                continue
            if not use_path:
                continue
            hit = False
            for (tl, col) in ground_in_db(db, v):
                if tl == cand_tl:
                    continue
                if path_witness(db, tl, col, v, cand_tl):
                    hit = True
                    break
            if hit:
                path += 1
        return point, path

    def pool_for(q):
        """Test: gp_ex top5. Train: e12_exact pool (gold kept, base-disadvantaged)."""
        if split[q] == "test":
            return list(dict.fromkeys(gpx[q]["top5"]))
        return list(ex[q]["pool"])

    def expanded_pool(q):
        base = pool_for(q)
        jd = jurisdiction(q)
        extra = []
        for db in sorted(jd):
            m = meta(db)
            if not m.ok:
                continue
            for tl in m.cols:
                fid = f"{db}::{tl}"
                if fid not in base:
                    extra.append(fid)
        return base + extra[:80]

    def run_arm(qs, use_path, tag):
        pool_ev = {}
        for i, q in enumerate(qs):
            db = db_of[q]
            vals = value_strings(qtext[q])
            pool = expanded_pool(q)
            evs = {}
            for fid in pool:
                gdb, tl = fid.split("::", 1)
                if gdb != db:
                    evs[fid] = (0, 0)
                    continue
                evs[fid] = evidence(db, vals, tl, use_path)
            pool_ev[q] = (pool, evs)
            if (i + 1) % 50 == 0:
                print(f"  {tag} {i+1}/{len(qs)}", flush=True)
        return pool_ev

    def tune(pool_ev, qs, gamma_grid=(0.25, 0.5, 1, 2, 4, 8)):
        best, best_r = 0.5, -1
        for g in gamma_grid:
            tot = 0.0
            for q in qs:
                pool, evs = pool_ev[q]
                gold = gold_of[q]
                order = sorted(pool, key=lambda f: (-(evs[f][0] + g * evs[f][1]),
                                                    pool.index(f)))
                tot += sum(1.0 / len(gold) for f in order[:5] if f in gold)
            if tot / len(qs) > best_r:
                best_r, best = tot / len(qs), g
        return best, best_r

    def eval_arm(pool_ev, gamma):
        r1 = r5 = top1 = 0
        for q in test_q:
            pool, evs = pool_ev[q]
            gold = gold_of[q]
            order = sorted(pool, key=lambda f: (-(evs[f][0] + gamma * evs[f][1]),
                                                pool.index(f)))
            top1 += int(order[0] in gold)
            r5 += sum(1.0 / len(gold) for f in order[:5] if f in gold)
        n = len(test_q)
        return {"top1": round(top1 / n, 4), "r5": round(r5 / n, 4)}

    train_q = [q for q in qids if split[q] == "train"][:200]
    test_q = [q for q in qids if split[q] == "test"]

    print("train evidence (path arm)", flush=True)
    pe_tr = run_arm(train_q, True, "path/train")
    g_path, r_tr = tune(pe_tr, train_q)
    print(f"gamma(path)={g_path} train R@5={r_tr:.4f}", flush=True)

    print("test evidence (path arm)", flush=True)
    pe_te = run_arm(test_q, True, "path/test")
    print("test evidence (point arm)", flush=True)
    po_te = run_arm(test_q, False, "point/test")

    res = {"base": eval_arm(pe_te, 0.0),
           "point": eval_arm(po_te, g_path),
           "path": eval_arm(pe_te, g_path),
           "both": eval_arm({q: (pe_te[q][0],
                                 {f: (po_te[q][1][f][0], pe_te[q][1][f][1])
                                  for f in pe_te[q][1]})
                             for q in test_q}, g_path)}
    print("test:", json.dumps(res), flush=True)

    # gap-55 repair under the path arm
    verd = json.load(open(REPO / "06_结果" / "e12_verdict.json", encoding="utf-8"))
    classes = verd["classes"]
    gap = json.load(open(REPO / "06_结果" / "e12_gap42.json", encoding="utf-8"))["gap_qids"]
    repair = {}
    for q in gap:
        db = db_of[q]
        gold = gold_of[q]
        pool, evs = pe_te[q]
        gold_ev = evs.get(sorted(gold)[0], (0, 0))
        g1 = pool[0]
        g1_ev = evs.get(g1, (0, 0))
        order = sorted(pool, key=lambda f: (-(evs[f][0] + g_path * evs[f][1]), pool.index(f)))
        cls = classes[q]["class"]
        d = repair.setdefault(cls, {"n": 0, "gold_path_witness": 0, "top1_path_witness": 0,
                                    "repaired_to_top1": 0})
        d["n"] += 1
        d["gold_path_witness"] += int(gold_ev[1] > 0)
        d["top1_path_witness"] += int(g1_ev[1] > 0)
        d["repaired_to_top1"] += int(order[0] in gold)

    out = {"gamma_path": g_path, "train_r5_path": round(r_tr, 4), "test": res,
           "gap55_repair": repair,
           "note": "v2: jurisdiction = anchor-value databases (no gold leakage); "
                   "pool = gp_ex top5 + jurisdiction tables; IND-completed FK graph; "
                   "TRIM-normalized joins; gamma tuned on 200 train"}
    json.dump(out, open(OUT, "w", encoding="utf-8"), indent=1)
    print(json.dumps({k: v for k, v in out.items() if k != "note"}, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
