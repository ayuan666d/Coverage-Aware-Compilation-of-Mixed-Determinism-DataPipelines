"""E28：目录规模压力测试（876 → 10k）。

目的：回答审稿人“10k 表还行不行”。在 341 问冷启动协议不变的前提下，只扩充目录：
- 876：Spider 原生目录（基准）
- 951：+ BIRD 的 11 库 75 表（真实跨域扩充）
- 2k/4k/7k/10k：在真实表基础上生成干扰表（表名重组、列与值取自真实表），用于规模压力

被测方法全部零模型、零预训练、零额外标注：
- bm25：Catalog.bm25
- fuse：BM25 召回 top-30 后用逐 token PPR 图分数重排（与 e11_zerolabel 的排序器同构，不含证书层）

报告：R@1 / R@5 / top-1 / gold-in-top20、目录构建时间、单查询延迟。
"""
from __future__ import annotations

import json
import math
import random
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_run_spider import fks_of, tables_of  # noqa: E402

WORK = Path(r"D:\vldb2027_e11")
CASES = Path(r"E:\vldb2027_pipeline_safety\06_结果\e11_cases.json")
OUT = WORK / "e28_scale.json"
EPS = 1e-6


def ev(ranked, gold):
    return dict(
        R1=len(set(ranked[:1]) & gold) / len(gold),
        R5=len(set(ranked[:5]) & gold) / len(gold),
        top1=1.0 if ranked[0] in gold else 0.0,
        hit20=len(set(ranked[:20]) & gold) / len(gold),
    )


def synth_tables(base, need, seed=42):
    """干扰表：从 2–3 张不同真实表各取 2 列拼成新表，名字由不同来源的词根组合。

    不做单表复制：单表复制会在目录里制造金标的近似孪生，把规模测试变成重复项消歧，
    R@1 会假性崩塌，不能用来回答“10k 还行不行”。
    """
    rng = random.Random(seed)
    out = []
    for i in range(need):
        srcs = [base[rng.randrange(len(base))] for _ in range(3)]
        w1 = [w for w in srcs[0]["name"].lower().split("_") if w] or ["t"]
        w2 = [w for w in srcs[2]["name"].lower().split("_") if w] or ["x"]
        name = f"{w1[rng.randrange(len(w1))]}_{w2[rng.randrange(len(w2))]}_{i}"
        cols = []
        for src in srcs:
            picked = rng.sample(src["columns"], min(2, len(src["columns"])))
            for c in picked:
                vals = [str(v) for v in (c.get("values") or [])[:2]]
                cols.append({"name": c["name"], "values": vals})
        out.append({"db": f"synth{i // 40:05d}", "name": name, "columns": cols[:5]})
    return out


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(WORK / "schema_cache.json", encoding="utf-8"))
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    test = [c for c in cases if c["split"] == "test"]
    test_dbs = {c["db_id"] for c in test}

    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    n_spider = len(tabs)

    bird = []
    for db, s in cache["bird"].items():
        bird += [dict(t, db=db) for t in s["tables"]]

    plans = [(n_spider, "spider", tabs),
             (n_spider + len(bird), "spider+bird", tabs + bird),
             (2000, "2k-syn", tabs + bird), (4000, "4k-syn", tabs + bird),
             (7000, "7k-syn", tabs + bird), (10000, "10k-syn", tabs + bird)]
    plans = [(n, tag, base) for n, tag, base in plans if n >= n_spider]
    if len(sys.argv) > 1:
        keep = {int(x) for x in sys.argv[1].split(",")}
        plans = [(n, tag, base) for n, tag, base in plans if n in keep]

    res = {}
    if OUT.exists():
        res = json.load(open(OUT, encoding="utf-8"))
    donors = [t for t in tabs if t["db"] not in test_dbs] + bird
    for n_target, tag, base in plans:
        need = max(0, n_target - len(base))
        extra = synth_tables(donors, need) if need else []
        all_tabs = base + extra
        t0 = time.perf_counter()
        cat = g.Catalog(all_tabs, fks, coquery=None, prefix_db=True)
        build_s = time.perf_counter() - t0
        N = len(cat.tables)

        qsets = [set(g.toks(c["question"])) for c in test]
        toks = sorted({w for qs in qsets for w in qs if ("token", w) in cat.idx})
        t1 = time.perf_counter()
        tok = {}
        for w in toks:
            x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
            s = cat.table_scores(x)
            mx = float(s.max())
            tok[w] = s / mx if mx > 0 else s
        tok_s = time.perf_counter() - t1
        idf = {w: math.log(1 + (N - cat.token_df.get(w, 0) + 0.5) /
                           (cat.token_df.get(w, 0) + 0.5)) for w in tok}

        t2 = time.perf_counter()
        rows = []
        for c, qs in zip(test, qsets):
            gold = {f"{c['db_id']}::{t}".lower() for t in c["gold"]}
            b = g.bm25(cat, qs)
            b_order = np.argsort(-b)
            b_rank = [cat.table_ids[i].lower() for i in b_order]
            ws = [w for w in qs if w in tok]
            if ws:
                M = np.stack([tok[w] for w in ws])
                iw = np.array([idf[w] for w in ws])[:, None]
                graph = np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
            else:
                graph = np.zeros(N, dtype=np.float32)
            top = b_order[:30]
            mixed = b.copy()
            basev = float(b[top[-1]])
            for k, idx in enumerate(top[np.argsort(-graph[top])]):
                mixed[idx] = basev + (30 - k) * 1e-6
            order = np.argsort(-mixed)
            fused = [cat.table_ids[i].lower() for i in order]
            rows.append({"bm25": ev(b_rank, gold), "fuse": ev(fused, gold)})
        query_s = (time.perf_counter() - t2) / len(test)

        agg = {m: {k: float(np.mean([r[m][k] for r in rows])) for k in
                  ("R1", "R5", "top1", "hit20")} for m in ("bm25", "fuse")}
        res[tag] = dict(n=N, build_s=build_s, tok_s=tok_s,
                        query_ms=query_s * 1000, **agg)
        print(f"{tag:12s} N={N:6d} build={build_s:6.1f}s tok={tok_s:5.1f}s "
              f"q={query_s*1000:6.2f}ms | bm25 R@1={agg['bm25']['R1']*100:5.2f} "
              f"R@5={agg['bm25']['R5']*100:5.2f} | fuse R@1={agg['fuse']['R1']*100:5.2f} "
              f"R@5={agg['fuse']['R5']*100:5.2f} hit20={agg['fuse']['hit20']*100:5.2f}",
              flush=True)
        json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        del cat
        import gc
        gc.collect()


if __name__ == "__main__":
    main()
