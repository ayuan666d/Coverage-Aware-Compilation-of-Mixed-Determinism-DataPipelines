"""E11-COST3: the number 2.9 was missing -- what a dense query encode actually costs.

The graph side was already measured (build 0.22 s, BM25 p50 0.96 ms, fuse+rerank p50 0.38
ms, 0 model calls per query).  The claim "the operators are cheap" is only honest next to
the reference's real serving cost, which is a 0.6B forward pass per query -- not the 0.3 ms
dot product that was reported before.

The GPU on this machine is held by the parallel line's job (7.8 / 8.2 GiB), so this runs on
CPU with fp32.  A CPU number is an UPPER bound on GPU latency, never a lower bound, so the
only claim it supports is "the reference pays a model forward per query and we pay none";
the speed factor stays unmeasured until the card is free.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[2]
CASES = REPO / "06_结果" / "e11_cases.json"
MODEL = Path("D:/vldb2027_e11/models/Qwen3-Embedding-0.6B")
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
OUT = REPO / "06_结果" / "e11_cost3.json"


def pct(v):
    v = np.asarray(v, dtype=np.float64)
    return {"p50": round(float(np.percentile(v, 50)), 1),
            "p95": round(float(np.percentile(v, 95)), 1),
            "mean": round(float(v.mean()), 1), "n": int(v.size)}


def main():
    import torch
    torch.set_num_threads(8)
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    queries = [str(c["question"]) for c in test]
    cache = json.load(open(CACHE, encoding="utf-8"))
    docs = []
    for db, s in cache["spider"].items():
        for t in s["tables"]:
            cols = ", ".join(c["name"] for c in t["columns"])
            vals = ", ".join(str(v) for c in t["columns"] for v in c.get("values", [])[:6])
            docs.append(f"table {t['name']}; columns: {cols}; values: {vals}")

    dev = "cpu"
    out = {"device": dev, "threads": torch.get_num_threads(), "dtype": "float32",
           "n_queries": len(queries), "n_docs": len(docs),
           "note_gpu": "GPU held by the parallel line (7.8/8.2 GiB); CPU latency is an "
                       "upper bound on GPU latency, so no speed factor is claimed."}
    t0 = time.perf_counter()
    from sentence_transformers import SentenceTransformer
    m = SentenceTransformer(str(MODEL), device=dev)
    out["load_s"] = round(time.perf_counter() - t0, 2)

    single = []
    for q in queries:
        t1 = time.perf_counter()
        m.encode([q], normalize_embeddings=True)
        single.append((time.perf_counter() - t1) * 1000)
    out["query_encode_ms_single"] = pct(single)

    t1 = time.perf_counter()
    embs = m.encode(queries, batch_size=32, normalize_embeddings=True,
                    show_progress_bar=False)
    dt = time.perf_counter() - t1
    out["query_encode_ms_batched"] = {"total_s": round(dt, 2),
                                      "per_query_ms": round(1000 * dt / len(queries), 1)}

    t1 = time.perf_counter()
    m.encode(docs[:200], batch_size=32, normalize_embeddings=True, show_progress_bar=False)
    dt200 = time.perf_counter() - t1
    out["index_encode_s_projected"] = round(dt200 * len(docs) / 200, 1)
    out["index_encode_ms_per_doc"] = round(1000 * dt200 / 200, 1)
    out["embedding_dim"] = int(np.asarray(embs).shape[1])
    del m
    json.dump(out, open(OUT, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print(json.dumps(out, indent=1, ensure_ascii=False))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
