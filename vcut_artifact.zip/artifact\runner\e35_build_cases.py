"""E35：扩大评估集（B 线）——把 Spider train 的 7000 问补进问句池。

动机
    既有评估集 341 问 / 6 库（`e11_cases.json`），单问粒度 0.2933 pt。所有小于
    0.3 pt 的差距（含「真实表内 R@5 是否过 90」）都在单问翻转量级内，不足以支撑
    结论。本地 schema 侧有 166 库 / 876 表，但 dev.json 的 1034 问只覆盖 20 库
    ——**缺的是问句，不是库**。

协议（与 e11_data.py 逐条对齐，不引入新规则）
    1. 库划分沿用 e11_data.py 的 `random.Random(0)` + `shuffle` + 80/20 切分，
       即 132 train 库 / 34 test 库，与 `e11_cases.json` 的 `spider_test_dbs`
       完全相同（本脚本会断言校验这一点）。
    2. split 只由 db_id 决定，同一库的所有问句必在同一侧 → 不存在问句级泄漏。
    3. gold 由 `parse_gold_tables(sql)` + `canon_gold(schema, ...)` 得到，与旧集
       同函数同参数。
    4. 只保留 db_id 在 schema_cache 中有 schema 的问句。

与旧集的唯一差异
    **只多了一个问句来源**（`train_spider.json`）。目录侧（876/951 表）不变，
    因此新旧读数的差异纯粹来自评估集，不来自目录或特征变化。

    ⚠ 但测试集与编译集同时变大，编译集从 693 涨到约 6.3k，**这意味着新读数
    不能与旧读数（61.00/91.69、60.12/93.60）直接比较**，必须在新协议下重跑
    876 点作为新起点。

产出
    06_结果/e35_cases.json        与 e11_cases.json 同结构，可直接替换读取
    D:/vldb2027_e11/e35_cases_meta.json   规模与质量统计
"""

from __future__ import annotations

import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e11_data import canon_gold, parse_gold_tables  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
SQL = REPO / "04_数据" / "external" / "sql"
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
OUT = REPO / "06_结果" / "e35_cases.json"
META = WORK / "e35_cases_meta.json"


def main() -> None:
    cache = json.load(open(CACHE, encoding="utf-8"))
    schema = cache["spider"]

    # ---- 1. 复现 e11_data.py 的分库协议 ----
    dbs = sorted(schema)
    rnd = random.Random(0)
    rnd.shuffle(dbs)
    cut = int(len(dbs) * 0.8)
    train_dbs, test_dbs = set(dbs[:cut]), set(dbs[cut:])

    old = json.load(open(REPO / "06_结果" / "e11_cases.json", encoding="utf-8"))
    assert set(old["spider_test_dbs"]) == test_dbs, "分库协议未能复现，停止"
    print(f"库 {len(dbs)}：train {len(train_dbs)} / test {len(test_dbs)}（与旧集一致）")

    # ---- 2. 合并问句池 ----
    dev = json.load(open(SQL / "dev.json", encoding="utf-8"))
    train = json.load(open(SQL / "train_spider.json", encoding="utf-8"))

    cases: list[dict] = []
    stats = {"dev": {"raw": len(dev), "no_schema": 0, "gold_empty": 0, "kept": 0},
             "train_spider": {"raw": len(train), "no_schema": 0, "gold_empty": 0, "kept": 0}}

    for tag, rows in (("dev", dev), ("train_spider", train)):
        for i, c in enumerate(rows):
            db = c["db_id"]
            if db not in schema:
                stats[tag]["no_schema"] += 1
                continue
            gt = canon_gold(schema[db]["tables"], parse_gold_tables(c["query"]))
            if not gt:
                stats[tag]["gold_empty"] += 1
                continue
            cases.append({
                "qid": f"sp{i}" if tag == "dev" else f"tr{i}",
                "db_id": db,
                "question": c["question"],
                "sql": c["query"],
                "gold": gt,
                "split": "train" if db in train_dbs else "test",
                "src": tag,
            })
            stats[tag]["kept"] += 1

    # ---- 3. 一致性检查 ----
    tr = [c for c in cases if c["split"] == "train"]
    te = [c for c in cases if c["split"] == "test"]

    qids = [c["qid"] for c in cases]
    assert len(qids) == len(set(qids)), "qid 冲突"
    # split 只由 db 决定：同库不得跨侧
    db_side: dict[str, str] = {}
    for c in cases:
        if db_side.setdefault(c["db_id"], c["split"]) != c["split"]:
            raise AssertionError(f"{c['db_id']} 跨 split，存在泄漏")

    # 与旧集在 dev 侧的重合度（用于确认旧读数的偏差方向）
    old_test_q = {json.loads(json.dumps(c))["qid"] for c in old["spider"] if c["split"] == "test"}

    meta = {
        "n_db_total": len(dbs), "n_db_train": len(train_dbs), "n_db_test": len(test_dbs),
        "per_source": stats,
        "n_cases": len(cases),
        "n_train": len(tr), "n_train_db": len({c["db_id"] for c in tr}),
        "n_test": len(te), "n_test_db": len({c["db_id"] for c in te}),
        "granularity_pt": 100.0 / len(te),
        "granularity_old_pt": 100.0 / max(len(old_test_q), 1),
        "gold_mean": round(sum(len(c["gold"]) for c in te) / max(len(te), 1), 3),
        "old_test_n": len(old_test_q),
        "split_reproduced": True,
    }

    # ---- 4. 落盘 ----
    out = {
        "bird": old["bird"],  # BIRD 控制集原样带出，确保读取方无感
        "spider": cases,
        "spider_train_dbs": sorted(train_dbs),
        "spider_test_dbs": sorted(test_dbs),
        "spider_missing_dbs": old.get("spider_missing_dbs", []),
    }
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(meta, open(META, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    print(f"\n问句池合并：{len(cases)} 条（dev {stats['dev']['kept']} + "
          f"train_spider {stats['train_spider']['kept']}）")
    print(f"  gold 解析失败：dev {stats['dev']['gold_empty']} / "
          f"train {stats['train_spider']['gold_empty']}")
    print(f"  train {len(tr)} 问 / {meta['n_train_db']} 库")
    print(f"  test  {len(te)} 问 / {meta['n_test_db']} 库"
          f"  ← 旧集 {len(old_test_q)} 问 / 6 库")
    print(f"  单问粒度 {meta['granularity_pt']:.4f} pt"
          f"（旧 {meta['granularity_old_pt']:.4f} pt，精确 {meta['granularity_old_pt']/meta['granularity_pt']:.1f}×）")
    print(f"  test gold 均数 {meta['gold_mean']}")
    print(f"\n→ {OUT}\n→ {META}")


if __name__ == "__main__":
    main()
