# -*- coding: utf-8 -*-
"""The two failure directions of the paper, on a synthetic graph.

E1a and E1b run against a proprietary permit-platform checkout, so a reviewer
cannot execute them. These tests rebuild the same two graphs with the shipped
generator and assert that the dominator check errs in both directions while the
cut criterion over effective verdicts stays correct.
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from generator.synth import Pipe, Rule, Table  # noqa: E402
from runner.e1 import judge_cut, judge_dominance, v_eff_all  # noqa: E402

INPUTS = [{"ftype": f, "flevel": l}
          for f in ("hot", "confined", "high")
          for l in ("sp", "1st", "2nd")]


def table(covered: int, fallback: str = "reject") -> Table:
    rules = [Rule(rid=f"r{i}", when=frozenset(t.items()), verdict="reject")
             for i, t in enumerate(INPUTS[:covered])]
    return Table(rules=rules, fallback=fallback)


def branching() -> Pipe:
    """Two branches, one verdict each, merging at the sink: safe, no dominator."""
    return Pipe(
        nodes={"entry": "src", "v1": "rule", "v2": "rule", "sink": "sink"},
        edges=[("entry", "v1"), ("v1", "sink"),
               ("entry", "v2"), ("v2", "sink")],
        tables={"v1": table(9), "v2": table(9)},
        input_space=INPUTS,
    )


def falling_through(covered: int = 6) -> Pipe:
    """One verdict, six of nine inputs covered, the rest fall through to pass."""
    return Pipe(
        nodes={"entry": "src", "vA": "rule", "sink": "sink"},
        edges=[("entry", "vA"), ("vA", "sink")],
        tables={"vA": table(covered, fallback="pass")},
        input_space=INPUTS,
    )


class TestE1aFalseAlarm(unittest.TestCase):
    """E1a: the check rejects a pipeline that is safe."""

    def test_graph_is_safe_under_the_effective_cut(self):
        p = branching()
        self.assertEqual(judge_cut(p, v_eff_all(p)), {"sink": True})

    def test_dominance_rejects_it(self):
        p = branching()
        self.assertEqual(judge_dominance(p), {"sink": False})


class TestE1bFalseRelease(unittest.TestCase):
    """E1b: the check accepts a pipeline that releases an unjudged third."""

    def test_dominance_accepts_it(self):
        p = falling_through()
        self.assertEqual(judge_dominance(p), {"sink": True})

    def test_no_verdict_is_effective_for_all_inputs(self):
        self.assertEqual(v_eff_all(falling_through()), frozenset())

    def test_effective_cut_rejects_it(self):
        p = falling_through()
        self.assertEqual(judge_cut(p, v_eff_all(p)), {"sink": False})

    def test_full_coverage_closes_the_hole(self):
        p = falling_through(covered=9)
        self.assertEqual(judge_cut(p, v_eff_all(p)), {"sink": True})


if __name__ == "__main__":
    unittest.main()
