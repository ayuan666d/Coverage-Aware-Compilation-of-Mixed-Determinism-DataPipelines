"""E9b: fair local-model schema linking with columns and sample values.

E7v gave the local 4B model only table names.  The explicit graph (E9) sees
columns and sampled values, so this rerun gives the model the same information
before comparing recall.
"""
from __future__ import annotations

import json
import re
import sqlite3
import sys
import time
import urllib.request
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
BIRD = REPO / "04_数据" / "external" / "bird"
GOLD = BIRD / "mini_dev_sqlite_2025.json"
DB_ROOT = BIRD / "minidev" / "MINIDEV" / "dev_databases"
E9 = REPO / "06_结果" / "e9_band_bird.json"
OUT = REPO / "06_结果" / "e9b_local_full.json"
HOST = "http://127.0.0.1:11434/api/chat"


def schema_text(db: Path) -> str:
    con = sqlite3.connect(db)
    cur = con.cursor()
    tables = [r[0] for r in cur.execute(
        "select name from sqlite_master where type='table' and name not like 'sqlite_%'")]
    lines = []
    for t in tables:
        cs = [r[1] for r in cur.execute(f'pragma table_info("{t}")')]
        samples = []
        for c in cs[:6]:
            try:
                vals = [str(r[0]) for r in cur.execute(
                    f'select distinct "{c}" from "{t}" where "{c}" is not null limit 3')]
            except Exception:
                vals = []
            if vals:
                samples.append(f"{c}: " + ", ".join(vals))
        lines.append(f"TABLE {t} (" + ", ".join(cs) + ")")
        if samples:
            lines.append("  samples: " + "; ".join(samples))
    con.close()
    return "\n".join(lines)


def gold_tables(sql: str) -> set[str]:
    return set(re.findall(r"(?:from|join)\s+[\"`]?([A-Za-z_][A-Za-z0-9_]*)", sql, re.I))


def ask(db_id: str, question: str, schema: str) -> set[str]:
    prompt = (f"Database {db_id} schema:\n{schema}\n\nQuestion: {question}\n"
              "Which tables are needed? Return JSON {\"tables\": [names]} with at most 6 "
              "exact table names. No explanation.")
    body = json.dumps({"model": "qwen3:4b",
                       "messages": [{"role": "user", "content": prompt}],
                       "stream": False, "think": False, "format": "json",
                       "options": {"temperature": 0, "num_predict": 150,
                                   "num_ctx": 8192}}).encode()
    req = urllib.request.Request(HOST, data=body, headers={"Content-Type": "application/json"},
                                 method="POST")
    with urllib.request.urlopen(req, timeout=120) as r:
        d = json.loads(r.read())
    try:
        return set(json.loads(d["message"]["content"]).get("tables") or [])
    except Exception:
        return set()


def main():
    cases = json.load(open(GOLD, encoding="utf-8"))[:100]
    rows = []
    t0 = time.perf_counter()
    for i, c in enumerate(cases, 1):
        db = DB_ROOT / c["db_id"] / f"{c['db_id']}.sqlite"
        sch = schema_text(db)
        gt = gold_tables(c["SQL"])
        try:
            got = ask(c["db_id"], c["question"], sch)
        except Exception:
            got = set()
        rows.append({"question_id": c["question_id"], "db_id": c["db_id"],
                     "gold": sorted(gt), "got": sorted(got),
                     "recall": round(len(gt & got) / max(1, len(gt)), 4)})
        if i % 20 == 0:
            print(f"{i}/100 {time.perf_counter()-t0:.0f}s", flush=True)
    summary = {"n": len(rows),
               "mean_recall": round(sum(r["recall"] for r in rows) / len(rows), 4),
               "exact": sum(1 for r in rows if r["recall"] == 1),
               "zero": sum(1 for r in rows if r["recall"] == 0)}
    json.dump({"summary": summary, "rows": rows}, open(OUT, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
