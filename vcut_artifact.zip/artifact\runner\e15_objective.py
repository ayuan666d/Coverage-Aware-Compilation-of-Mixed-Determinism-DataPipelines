"""E15: the same covariance ratio, three closed-form objectives.

E13/E14 use ordinary ridge (average squared error over 607k pairs, 1043
positives).  That objective buys recall@5 but loses recall@1.  Two other
closed forms target separation instead of average error:

  balanced ridge : weight positives by N_neg/N_pos (class-balanced least squares)
  Fisher         : w = (Cov_all + lam I)^-1 (mu_pos - mu_neg)   (LDA direction)

All three use the same 12-primitive features and 90-term second-order space as
E14.  One variable: the objective.
"""
from __future__ import annotations

import json
import sys

import numpy as np

sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码\runner")
import e14_db_anchor as e14  # noqa: E402

OUT = e14.REPO / "06_结果" / "e15_objective.json"


def fit_ridge(F, y, lam):
    A = F.T @ F + lam * np.eye(F.shape[1], dtype=np.float32)
    b = F.T @ y
    return np.linalg.solve(A.astype(np.float64), b.astype(np.float64)).astype(np.float32)


def fit_balanced(F, y, lam):
    npos = float((y > 0.5).sum())
    nneg = float(len(y) - npos)
    wts = np.where(y > 0.5, nneg / max(npos, 1.0), 1.0).astype(np.float32)
    FW = F * wts[:, None]
    A = FW.T @ F + lam * np.eye(F.shape[1], dtype=np.float32)
    b = FW.T @ y
    return np.linalg.solve(A.astype(np.float64), b.astype(np.float64)).astype(np.float32)


def fit_fisher(F, y, lam):
    mu = F.mean(0)
    C = F.T @ F / len(y) - np.outer(mu, mu)
    mu_p = F[y > 0.5].mean(0)
    mu_n = F[y <= 0.5].mean(0)
    return np.linalg.solve((C + lam * np.eye(F.shape[1])).astype(np.float64),
                           (mu_p - mu_n).astype(np.float64)).astype(np.float32)


def main():
    meta = e14.load()
    print("building features…", flush=True)
    Ft = meta["build_F"](meta["train_q"])
    mu = Ft.reshape(-1, Ft.shape[-1]).mean(0)
    sd = Ft.reshape(-1, Ft.shape[-1]).std(0) + 1e-9
    Fn = ((Ft - mu) / sd).reshape(-1, Ft.shape[-1])
    Y = np.zeros((len(meta["train_q"]), meta["D"]), dtype=np.float32)
    for qi, q in enumerate(meta["train_q"]):
        for f in meta["gold_all"][q]:
            j = meta["didx"].get(f)
            if j is not None:
                Y[qi, j] = 1.0
    y = Y.reshape(-1)

    Fte1 = ((meta["build_F"](meta["test_q"]) - mu) / sd).reshape(len(meta["test_q"]), meta["D"], -1)

    idx = [(i, j) for i in range(12) for j in range(i, 12)]
    Fn2 = np.concatenate([Fn, e14.quad(Fn, idx)], axis=1)
    Fte2 = np.concatenate([Fte1.reshape(-1, 12), e14.quad(Fte1.reshape(-1, 12), idx)], axis=1).reshape(
        len(meta["test_q"]), meta["D"], -1)
    print("first:", Fn.shape, "second:", Fn2.shape, flush=True)

    out = {}
    configs = [("first", Fn, Fte1), ("second", Fn2, Fte2)]
    for name, F, Fte in configs:
        for obj, fn, lams in [("ridge", fit_ridge, (1.0, 10.0)),
                              ("balanced", fit_balanced, (1.0, 10.0)),
                              ("fisher", fit_fisher, (0.1, 1.0, 10.0))]:
            for lam in lams:
                w = fn(F, y, lam)
                s, rows = e14.evaluate(meta, Fte, w)
                key = f"{name}/{obj}/{lam}"
                out[key] = {"test": s, "weights": w.tolist(), "rows": rows}
                print(key, json.dumps(s), flush=True)

    json.dump({"runs": {k: {"test": v["test"], "weights": v["weights"]} for k, v in out.items()},
               "rows": {k: v["rows"] for k, v in out.items()},
               "reference": {"e13_cf2_ridge_r1": 0.4819, "e13_cf2_ridge_r5": 0.8568,
                             "e14_cf2_ridge_r1": 0.4863, "e14_cf2_ridge_r5": 0.8622,
                             "ga_gp_ex_r1": 0.5122, "ga_gp_ex_r5": 0.8216,
                             "dense_zero_r1": 0.586, "dense_zero_r5": 0.8793}},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
