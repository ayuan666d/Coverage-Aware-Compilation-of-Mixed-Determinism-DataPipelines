"""E11-DIAG: why does the explicit relational graph lose to a 0.6B embedding?

Not a scoreboard — a mechanism study on the Spider merged catalog (876 tables,
341 test questions).  Three candidate causes, each with its own measurement:

  C1 coverage  — the graph can only diffuse from query tokens that exist in the
                 catalog.  If a question needs a word the schema does not contain
                 (synonym / world knowledge), no operator can recover it.
  C2 hub       — a row-normalised graph gives the token "name" (in half the
                 catalogue) the same seed mass as the token "corolla" (in one
                 table).  BM25 suppresses hubs with idf; the plain graph does not.
  C3 repair    — if C2 is the cause, idf-weighting the token edges should close
                 the gap.  If it does not, the loss is a property of the model,
                 not of the implementation.
"""
from __future__ import annotations

import json
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_run_spider import band_fn, coquery_map, fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
OUT = REPO / "06_结果" / "e11_diag.json"

DF_BUCKETS = [(0, 0, "no_bridge"), (1, 1, "df=1"), (2, 5, "df 2-5"),
              (6, 20, "df 6-20"), (21, 100, "df 21-100"), (101, 10 ** 9, "df>100")]


def bucket(df: int) -> str:
    for lo, hi, name in DF_BUCKETS:
        if lo <= df <= hi:
            return name
    return "df>100"


def doc_tokens(t: dict) -> set[str]:
    return set(g.table_doc(t))


def rrf(s1: np.ndarray, s2: np.ndarray, k: int = 60) -> np.ndarray:
    out = np.zeros(len(s1), dtype=np.float32)
    for rk, idx in enumerate(np.argsort(-s1), 1):
        out[idx] += 1.0 / (k + rk)
    for rk, idx in enumerate(np.argsort(-s2), 1):
        out[idx] += 1.0 / (k + rk)
    return out


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    if args.limit:
        test = test[:args.limit]
    out_path = OUT if not args.limit else OUT.with_name("e11_diag_smoke.json")

    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    coq = coquery_map([c for c in data["spider"] if c["split"] == "train"], prefix=True)

    t0 = time.time()
    cat = g.Catalog(tabs, fks, coquery=coq, prefix_db=True)
    cat_idf = g.Catalog(tabs, fks, coquery=coq, prefix_db=True, idf_edges=True)
    print(f"catalogs built in {time.time()-t0:.1f}s  nodes={len(cat.idx)}", flush=True)

    bf, bands = band_fn(test)

    z = np.load(EMB, allow_pickle=True)
    ids, Dm, qids, Qm = list(z["ids"]), z["D"].astype(np.float32), list(z["qids"]), z["Q"].astype(np.float32)
    assert ids == cat.table_ids, "embedding id order does not match catalog"
    qpos = {q: i for i, q in enumerate(qids)}

    rows = []
    for n, c in enumerate(test):
        q = toks(c["question"])
        gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
        bw = bf(q)
        s_bm = g.bm25(cat, q)
        s_ppr = g.single_ppr(cat, q, band_weight=bw)
        s_typed = g.fuse(cat, q, band_weight=bw)
        s_ppr_idf = g.single_ppr(cat_idf, q, band_weight=bw)
        s_typed_idf = g.fuse(cat_idf, q, band_weight=bw)
        qv = Qm[qpos[c["qid"]]]
        s_dense = Dm @ qv
        scores = {"bm25": s_bm, "ppr_band": s_ppr, "typed_band": s_typed,
                  "ppr_idf": s_ppr_idf, "typed_idf": s_typed_idf, "dense": s_dense,
                  "rrf_bm_graph": rrf(s_bm, s_typed), "rrf_graph_dense": rrf(s_typed, s_dense)}

        rec = {"qid": c["qid"], "db": c["db_id"], "gold": sorted(gold),
               "n_qtok": len(q)}

        # ---- C1 coverage: OOV of query tokens w.r.t. the catalogue vocabulary
        oov = [w for w in set(q) if ("token", w) not in cat.idx]
        rec["oov_frac"] = round(len(oov) / max(1, len(set(q))), 3)
        rec["oov"] = oov[:12]

        # ---- bridge: query tokens present in the gold table's own document
        gtdocs = [doc_tokens(cat.tables[cat.table_pos[t]]) for t in gold if t in cat.table_pos]
        gunion = set().union(*gtdocs) if gtdocs else set()
        bridge = sorted(set(q) & gunion)
        rec["bridge"] = bridge
        rec["bridge_df"] = [cat.token_df.get(w, 0) for w in bridge]
        rec["max_bridge_df"] = max(rec["bridge_df"], default=0)
        rec["min_bridge_df"] = min(rec["bridge_df"], default=0)
        rec["bridge_bucket"] = bucket(rec["min_bridge_df"])

        for name, s in scores.items():
            r = g.rank(s, cat)
            m = g.metrics(r, gold)
            rec[f"{name}_r1"] = round(m["recall@1"], 4)
            rec[f"{name}_r5"] = round(m["recall@5"], 4)
            rec[f"{name}_hit1"] = float(r[0] in gold)
            rec[f"{name}_rank"] = next((i for i, t in enumerate(r, 1) if t in gold), 999)

        # ---- C2 hub: which tokens carried the graph's top-1 choice
        top1 = g.rank(s_ppr, cat)[0]
        rec["graph_top1"] = top1
        if top1 in cat.table_pos:
            ttoks = doc_tokens(cat.tables[cat.table_pos[top1]])
            mt = sorted(set(q) & ttoks)
            rec["graph_top1_shared"] = len(mt)
            rec["graph_top1_df"] = [cat.token_df.get(w, 0) for w in mt]
            rec["graph_top1_max_df"] = max(rec["graph_top1_df"], default=0)
            rec["graph_top1_mean_df"] = round(float(np.mean(rec["graph_top1_df"])), 1) if mt else 0
        # same for the gold table, and for bm25's pick
        bm_top1 = g.rank(s_bm, cat)[0]
        if bm_top1 in cat.table_pos:
            mt = sorted(set(q) & doc_tokens(cat.tables[cat.table_pos[bm_top1]]))
            rec["bm25_top1_shared"] = len(mt)
            rec["bm25_top1_mean_df"] = round(float(np.mean([cat.token_df.get(w, 0) for w in mt])), 1) if mt else 0
        gt = [cat.token_df.get(w, 0) for w in bridge]
        rec["gold_shared"] = len(bridge)
        rec["gold_mean_df"] = round(float(np.mean(gt)), 1) if gt else 0
        # does the graph's winner out-match the gold table on raw overlap?
        rec["graph_beats_gold_on_count"] = float(rec.get("graph_top1_shared", 0) > rec["gold_shared"])
        rows.append(rec)
        if (n + 1) % 40 == 0:
            print(f"{n+1}/{len(test)} {time.time()-t0:.0f}s", flush=True)

    # ---------------- aggregation ----------------
    def sel_rows(sel):
        return [r for r in rows if sel(r)]

    def agg(sel):
        s = sel_rows(sel)
        if not s:
            return {"n": 0}
        mean = lambda k: round(float(np.mean([r[k] for r in s])), 4)  # noqa: E731
        return {"n": len(s), "bm25_r5": mean("bm25_r5"), "graph_r5": mean("ppr_band_r5"),
                "typed_r5": mean("typed_band_r5"), "dense_r5": mean("dense_r5"),
                "graph_r1": mean("ppr_band_r1"), "bm25_r1": mean("bm25_r1"),
                "dense_r1": mean("dense_r1"), "oov_frac": mean("oov_frac")}

    no_bridge = lambda r: not r["bridge"]  # noqa: E731
    has_bridge = lambda r: bool(r["bridge"])  # noqa: E731

    by_bucket = {b[2]: agg(lambda r, b=b: r["bridge_bucket"] == b[2])
                 for b in DF_BUCKETS}
    c1 = {"no_bridge": agg(no_bridge), "has_bridge": agg(has_bridge)}
    # who recovers a no-bridge question?
    nb = sel_rows(no_bridge)
    c1["no_bridge_dense_hit5"] = sum(1 for r in nb if r["dense_r5"] > 0)
    c1["no_bridge_graph_hit5"] = sum(1 for r in nb if r["ppr_band_r5"] > 0)
    c1["no_bridge_bm25_hit5"] = sum(1 for r in nb if r["bm25_r5"] > 0)
    c1["oov_frac_has_bridge"] = round(float(np.mean([r["oov_frac"] for r in rows if has_bridge(r)])), 3)
    c1["oov_frac_no_bridge"] = round(float(np.mean([r["oov_frac"] for r in nb])), 3) if nb else None

    # C2 hub dilution
    hb = sel_rows(has_bridge)
    c2 = {
        "mean_df_gold_bridge": round(float(np.mean([r["min_bridge_df"] for r in hb])), 1),
        "mean_df_graph_top1_match": round(float(np.mean([r.get("graph_top1_mean_df", 0) for r in hb])), 1),
        "mean_df_bm25_top1_match": round(float(np.mean([r.get("bm25_top1_mean_df", 0) for r in hb])), 1),
        "graph_top1_outmatches_gold": round(float(np.mean([r["graph_beats_gold_on_count"] for r in hb])), 3),
        "graph_wrong_when_bridge": sum(1 for r in hb if r["ppr_band_hit1"] == 0),
        "graph_wrong_and_bm25_right": sum(1 for r in hb if r["ppr_band_hit1"] == 0 and r["bm25_hit1"] == 1),
        "graph_right_and_bm25_wrong": sum(1 for r in hb if r["ppr_band_hit1"] == 1 and r["bm25_hit1"] == 0),
    }
    # split failures by whether the graph's answer contains the query at all
    c2["graph_top1_zero_overlap"] = sum(1 for r in hb if r.get("graph_top1_shared", 0) == 0)

    # C3 repair: idf-weighted token edges
    c3 = {"ppr_band_r5": round(float(np.mean([r["ppr_band_r5"] for r in rows])), 4),
          "ppr_idf_r5": round(float(np.mean([r["ppr_idf_r5"] for r in rows])), 4),
          "typed_band_r5": round(float(np.mean([r["typed_band_r5"] for r in rows])), 4),
          "typed_idf_r5": round(float(np.mean([r["typed_idf_r5"] for r in rows])), 4),
          "ppr_band_r1": round(float(np.mean([r["ppr_band_r1"] for r in rows])), 4),
          "ppr_idf_r1": round(float(np.mean([r["ppr_idf_r1"] for r in rows])), 4),
          "typed_band_r1": round(float(np.mean([r["typed_band_r1"] for r in rows])), 4),
          "typed_idf_r1": round(float(np.mean([r["typed_idf_r1"] for r in rows])), 4),
          "bm25_r5": round(float(np.mean([r["bm25_r5"] for r in rows])), 4),
          "dense_r5": round(float(np.mean([r["dense_r5"] for r in rows])), 4)}
    c3["bridge_only"] = {}
    for b in DF_BUCKETS:
        s = [r for r in rows if r["bridge_bucket"] == b[2]]
        if not s:
            continue
        c3["bridge_only"][b[2]] = {
            "n": len(s),
            "graph": round(float(np.mean([r["ppr_band_r5"] for r in s])), 4),
            "graph_idf": round(float(np.mean([r["ppr_idf_r5"] for r in s])), 4),
            "typed": round(float(np.mean([r["typed_band_r5"] for r in s])), 4),
            "typed_idf": round(float(np.mean([r["typed_idf_r5"] for r in s])), 4),
            "bm25": round(float(np.mean([r["bm25_r5"] for r in s])), 4),
            "dense": round(float(np.mean([r["dense_r5"] for r in s])), 4)}

    # C4 hybrid: does the graph add anything on top of the two it already loses to?
    c4 = {m: {"r5": round(float(np.mean([r[f"{m}_r5"] for r in rows])), 4),
              "r1": round(float(np.mean([r[f"{m}_r1"] for r in rows])), 4)}
          for m in ("bm25", "ppr_band", "typed_band", "ppr_idf", "typed_idf",
                    "dense", "rrf_bm_graph", "rrf_graph_dense")}
    nbh = sel_rows(no_bridge)
    c4["hybrid_recovers_no_bridge"] = {
        "n": len(nbh),
        "bm25_hit5": sum(1 for r in nbh if r["bm25_r5"] > 0),
        "rrf_bm_graph_hit5": sum(1 for r in nbh if r["rrf_bm_graph_r5"] > 0),
        "rrf_graph_dense_hit5": sum(1 for r in nbh if r["rrf_graph_dense_r5"] > 0),
        "dense_hit5": sum(1 for r in nbh if r["dense_r5"] > 0)}

    out = {"n": len(rows), "n_tables": len(cat.tables), "nodes": len(cat.idx),
           "bands": bands,
           "C1_coverage": c1,
           "C2_hub": c2,
           "C3_idf_repair": c3,
           "C4_hybrid": c4,
           "by_bridge_bucket": by_bucket,
           "overall": agg(lambda r: True),
           "rows": rows}
    json.dump(out, open(out_path, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=2))
    print("wrote", out_path)


if __name__ == "__main__":
    main()
