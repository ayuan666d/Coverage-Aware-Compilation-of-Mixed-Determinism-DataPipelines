# -*- coding: utf-8 -*-
"""E1 合成器 —— 管线图 × 决策表变异

图因子（实验方案 §3）：节点数 / 出口数 / 源数 / 拓扑形状
表因子：失效率 p_miss（可控），通过"精确覆盖输入子集"实现

关键设计：eff(t) ⟺ t ∈ covered。失效率由此**精确可控**，
不依赖随机游走或启发式。
"""

from __future__ import annotations

import itertools
import random
from dataclasses import dataclass, field
from typing import Dict, FrozenSet, List, Sequence, Set, Tuple

ENTRY = "__entry__"
VERDICT_KINDS = frozenset({"rule", "gate"})
SINK_KINDS = frozenset({"sink"})


# ══════════════════════════════════════════════════════════════
# 决策表
# ══════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class Rule:
    rid: str
    when: FrozenSet[Tuple[str, str]]      # (字段, 值) 的合取
    verdict: str


CONSERVATIVE_VERDICTS = frozenset({"reject", "review"})


@dataclass
class Table:
    rules: List[Rule]
    # 兜底方向：pass = 未命中就放行（假安全的来源）；reject/review = 保守兜底（仍算判过）
    fallback: str = "pass"

    def hit(self, t: Dict[str, str]) -> str | None:
        """返回第一条命中的规则 id；无命中返回 None（= H=∅，走兜底）。"""
        for r in self.rules:
            if all(t.get(f) == v for f, v in r.when):
                return r.rid
        return None

    def decide(self, t: Dict[str, str]) -> Tuple[str, str | None]:
        """返回 (V, H 中的规则 id)。无命中时返回 (fallback, None)。"""
        rid = self.hit(t)
        if rid is None:
            return self.fallback, None
        for r in self.rules:
            if r.rid == rid:
                return r.verdict, rid
        return self.fallback, None

    def judged(self, t: Dict[str, str]) -> bool:
        """v0.3 定义 5：命中规则，或落到保守兜底。"""
        v, rid = self.decide(t)
        return rid is not None or v in CONSERVATIVE_VERDICTS

    def eff(self, t: Dict[str, str]) -> bool:
        """逐输入诊断版（v0.3 的 eff(v,t)）。"""
        return self.judged(t)

    def eff_all(self, input_space: List[Dict[str, str]]) -> bool:
        """v0.3 定义 6：全称有效——所有输入都判过。"""
        return all(self.judged(t) for t in input_space)


def make_table(
    input_space: List[Dict[str, str]],
    cover_ratio: float,
    rng: random.Random,
    fallback: str = "pass",
) -> Tuple[Table, FrozenSet[Tuple[str, ...]]]:
    """构造一张恰好覆盖 cover_ratio 比例输入的决策表。

    每条被覆盖的输入生成一条**精确匹配**规则（when = 该输入全部字段值）。
    覆盖的输入命中规则（verdict=reject）；未覆盖的走 fallback。

    返回 (表, 被覆盖输入的指纹集合)。
    """
    k = round(len(input_space) * cover_ratio)
    covered = rng.sample(input_space, k) if k else []
    rules = [
        Rule(rid=f"r{i}", when=frozenset(v.items()), verdict="reject")
        for i, v in enumerate(covered)
    ]
    fingerprints = frozenset(tuple(sorted(v.items())) for v in covered)
    return Table(rules=rules, fallback=fallback), fingerprints


# ══════════════════════════════════════════════════════════════
# 管线图
# ══════════════════════════════════════════════════════════════


@dataclass
class Pipe:
    nodes: Dict[str, str]                       # id → kind
    edges: List[Tuple[str, str]]
    tables: Dict[str, Table] = field(default_factory=dict)   # 判决节点 → 表
    input_space: List[Dict[str, str]] = field(default_factory=list)

    def sources(self) -> List[str]:
        has_in = {b for _, b in self.edges}
        return sorted(n for n in self.nodes if n not in has_in)

    def sinks(self) -> List[str]:
        return sorted(n for n, k in self.nodes.items() if k in SINK_KINDS)

    def verdicts(self) -> List[str]:
        return sorted(n for n, k in self.nodes.items() if k in VERDICT_KINDS)

    def succ(self) -> Dict[str, List[str]]:
        s = {n: [] for n in self.nodes}
        for a, b in self.edges:
            s[a].append(b)
        return s

    def pred(self) -> Dict[str, List[str]]:
        p = {n: [] for n in self.nodes}
        for a, b in self.edges:
            p[b].append(a)
        return p


def _input_space(domains: Dict[str, List[str]]) -> List[Dict[str, str]]:
    keys = list(domains)
    return [dict(zip(keys, vals)) for vals in itertools.product(*(domains[k] for k in keys))]


def synth(
    shape: str,                 # line / fork_join / branch_verdict
    n_nodes: int,               # 目标规模（近似；最后用 pad 补到精确值）
    n_sinks: int,
    n_sources: int,
    p_miss: float,              # 决策表失效率
    rng: random.Random,
    fallback: str = "pass",     # pass = 未命中放行；reject/review = 保守兜底
) -> Pipe:
    """按形状合成一条管线。形状是 E1 的核心因子。"""
    domains = {"ftype": ["hot", "confined", "high"], "flevel": ["sp", "1st", "2nd"]}
    input_space = _input_space(domains)
    table, _ = make_table(input_space, 1.0 - p_miss, rng, fallback=fallback)

    nodes: Dict[str, str] = {}
    edges: List[Tuple[str, str]] = []
    tables: Dict[str, Table] = {}

    def add(nid: str, kind: str, table: Table | None = None) -> str:
        nodes[nid] = kind
        if table is not None:
            tables[nid] = table
        return nid

    n_map = max(1, (n_nodes - n_sources - n_sinks - 2) // 2)

    if shape == "line":
        chain = [add("src0", "source")]
        for i in range(n_map):
            chain.append(add(f"map{i}", "map"))
        mid = add("model0", "model")
        chain.append(mid)
        v = add("verdict0", "rule", table)
        chain.append(v)
        for a, b in zip(chain, chain[1:]):
            edges.append((a, b))
        # v0.3 修正：多出口时从最后一个判决节点并行分出，不再把 sink 串成链
        last = chain[-1]
        for si in range(n_sinks):
            sk = add(f"sink{si}", "sink")
            edges.append((last, sk))

    elif shape == "fork_join":
        heads = [add(f"src{i}", "source") for i in range(n_sources)]
        pre = add("map_pre", "map")
        mdl = add("model0", "model")
        post = add("map_post", "map")
        for h in heads:
            edges.append((h, pre))
        edges += [(pre, mdl), (mdl, post)]
        # 填充节点数：在 heads[0] 与 pre 之间插一条 map 链
        if n_map > 1:
            edges.remove((heads[0], pre))
            prev = heads[0]
            for i in range(n_map - 1):
                m = add(f"map{i}", "map")
                edges.append((prev, m))
                prev = m
            edges.append((prev, pre))
        for si in range(n_sinks):
            v = add(f"verdict{si}", "rule", table)
            sk = add(f"sink{si}", "sink")
            edges += [(post, v), (v, sk)]

    elif shape == "branch_verdict":
        # 定理 1' 的形状：多支路各带判决，全部汇到每个出口
        heads = [add(f"src{i}", "source") for i in range(n_sources)]
        pre = add("map_pre", "map")
        mdl = add("model0", "model")
        post = add("map_post", "map")
        for h in heads:
            edges.append((h, pre))
        edges += [(pre, mdl), (mdl, post)]
        if n_map > 1:
            edges.remove((heads[0], pre))
            prev = heads[0]
            for i in range(n_map - 1):
                m = add(f"map{i}", "map")
                edges.append((prev, m))
                prev = m
            edges.append((prev, pre))
        n_branch = max(2, n_sinks)
        branch_last = []
        for bi in range(n_branch):
            v = add(f"verdict{bi}", "rule", table)
            branch_last.append(v)
            edges.append((post, v))
        for si in range(n_sinks):
            sk = add(f"sink{si}", "sink")
            for v in branch_last:
                edges.append((v, sk))
    else:
        raise ValueError(f"未知形状 {shape}")

    # v0.3：把实际节点数补到目标规模（只在非 sink 边上串 map，保持路径/割结构）
    pad_i = 0
    while len(nodes) < n_nodes:
        cand = [(a, b) for a, b in edges
                if not a.startswith("sink") and not b.startswith("sink")]
        if not cand:
            break
        a, b = cand[0]
        mid = f"pad{pad_i}"
        pad_i += 1
        nodes[mid] = "map"
        edges.remove((a, b))
        edges.append((a, mid))
        edges.append((mid, b))

    return Pipe(nodes=nodes, edges=edges, tables=tables, input_space=input_space)
