"""List figure/table vertical extents in a two-column PDF to budget page space."""
import sys
import pymupdf


def scan(pdf_path):
    doc = pymupdf.open(pdf_path)
    print(f"== {pdf_path}")
    for pno in range(len(doc)):
        page = doc[pno]
        d = page.get_text("dict")
        # images
        for b in d["blocks"]:
            if b.get("type") == 1:
                x0, y0, x1, y1 = b["bbox"]
                print(f"  p{pno+1:>2} IMG  h={y1-y0:6.1f}pt  y=[{y0:.0f},{y1:.0f}]  w={x1-x0:.0f}")
        # captions
        for b in d["blocks"]:
            if b.get("type") != 0:
                continue
            for ln in b["lines"]:
                t = "".join(s["text"] for s in ln["spans"]).strip()
                if t.startswith("Figure ") or t.startswith("Table "):
                    print(f"  p{pno+1:>2} CAP  y={ln['bbox'][1]:6.1f}  {t[:60]}")
                    break


if __name__ == "__main__":
    for p in sys.argv[1:]:
        scan(p)
