# -*- coding: utf-8 -*-
"""A10: Guardrails AI (real package) as a baseline on the 772-receipt workload.

Guard.for_pydantic validates the receipt schema: required total/subtotal, integer
amounts, optional components, list of item prices. It does not check arithmetic.
Readings: automation, false pass, precision, against the A8 schema-rule rung.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from pydantic import BaseModel
from typing import List, Optional

from guardrails import Guard

RAW = Path(r"E:\vldb2027_pipeline_safety\06_结果\e7_receipts.json")
OUT = Path(r"E:\vldb2027_pipeline_safety\06_结果\a10_guardrails.json")


class Receipt(BaseModel):
    total: int
    subtotal: int
    tax: Optional[int] = None
    service: Optional[int] = None
    discount: Optional[int] = None
    items: List[int] = []


def main():
    guard = Guard.for_pydantic(Receipt)
    rows = json.loads(RAW.read_text(encoding="utf-8"))["rows"]
    out_rows = []
    errors = 0
    for r in rows:
        g = (r.get("gold") or {}).get("total")
        if g is None:
            continue
        m = r.get("model") or {}
        payload = {
            "total": m.get("total"),
            "subtotal": m.get("subtotal"),
            "tax": m.get("tax"),
            "service": m.get("service"),
            "discount": m.get("discount"),
            "items": [x for x in (m.get("items") or []) if x is not None],
        }
        try:
            res = guard.validate(json.dumps(payload))
            passed = bool(getattr(res, "validation_passed", True))
        except Exception as e:  # noqa: BLE001
            passed = False
            errors += 1
        out_rows.append({
            "file": r["file"], "passed": passed,
            "correct": r.get("total_correct"),
            "model_total": m.get("total"), "gold": g,
        })
    n = len(out_rows)
    acc = [x for x in out_rows if x["passed"]]
    fp = sum(1 for x in acc if x["correct"] is False)
    out = {
        "n": n, "guard": "guardrails-ai 0.11.0 / Guard.for_pydantic",
        "errors": errors,
        "accept": len(acc), "automation": round(len(acc) / n, 4),
        "false_pass": fp, "false_pass_rate": round(fp / n, 4),
        "precision": round((len(acc) - fp) / len(acc), 4) if acc else None,
    }
    OUT.write_text(json.dumps({"summary": out, "rows": out_rows}, ensure_ascii=False, indent=1),
                   encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
