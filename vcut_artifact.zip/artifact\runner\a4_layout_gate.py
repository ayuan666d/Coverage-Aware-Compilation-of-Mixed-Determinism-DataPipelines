# -*- coding: utf-8 -*-
"""A4: does the independent layout witness close the x10 hole?

Join the a3 clean model outputs with the E7 layout-reader totals (e7l), then
compare four gate policies under the scale-forgery attack:

  C   closure only            (E7 arithmetic judge: accept/fill)
  B   agreement only          (layout total == model total)
  C∧B conjunction             (both must hold)
  C∨B union                   (E7's headline union)

Clean vs x10 (model output multiplied by 10; the printed document is untouched).
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

RUN = Path(r"E:\vldb2027_pipeline_safety\05_代码\runner")
sys.path.insert(0, str(RUN))
spec = importlib.util.spec_from_file_location("e7", str(RUN / "e7_receipts.py"))
e7 = importlib.util.module_from_spec(spec)
sys.modules["e7"] = e7
spec.loader.exec_module(e7)

spec2 = importlib.util.spec_from_file_location("e7k", str(RUN / "e7k_independent_witness.py"))
e7k = importlib.util.module_from_spec(spec2)
sys.modules["e7k"] = e7k
spec2.loader.exec_module(e7k)

A3 = Path(r"E:\vldb2027_pipeline_safety\06_结果\a3_injection.json")
LAY = Path(r"E:\vldb2027_pipeline_safety\06_结果\e7l_layout_witness.json")
OUT = Path(r"E:\vldb2027_pipeline_safety\06_结果\a4_layout_gate.json")


def scaled(m, k):
    d = dict(m)
    d["items"] = list(m.get("items") or [])
    for key in ("total", "subtotal", "tax", "service", "discount"):
        d[key] = None if m.get(key) is None else int(m[key] * k)
    d["items"] = [None if x is None else int(x * k) for x in d["items"]]
    return d


def evaluate(rows, scale):
    out = {}
    for policy in ("C", "B", "C_and_B", "C_or_B"):
        acc_rows = []
        for r in rows:
            m = scaled(r["model"], scale)
            t = m.get("total")
            j = e7.judge(m, {"total": r["gold"], "subtotal": None}, r["text"])
            c = j["verdict"] in ("accept", "fill")
            b = (t is not None and r["layout"] is not None and e7k.match(t, r["layout"]) is True)
            ok = (c if policy == "C" else b if policy == "B"
                  else (c and b) if policy == "C_and_B" else (c or b))
            if ok:
                acc_rows.append((t is not None and e7k.match(t, r["gold"]) is True))
        fp = sum(1 for good in acc_rows if not good)
        out[policy] = {
            "accept": len(acc_rows),
            "accept_rate": round(len(acc_rows) / len(rows), 4),
            "false_pass": fp,
            "false_pass_rate": round(fp / len(rows), 4),
            "precision": round((len(acc_rows) - fp) / len(acc_rows), 4) if acc_rows else None,
        }
    return out


def main():
    a3 = json.loads(A3.read_text(encoding="utf-8"))
    lay = {r["file"]: r for r in json.loads(LAY.read_text(encoding="utf-8"))["rows"]}
    rows = []
    for r in a3["rows"]:
        if r["cond"] != "clean" or r["model"].get("total") is None:
            continue
        f = r["file"]
        if f not in lay:
            continue
        L = lay[f]
        rows.append({
            "file": f, "model": r["model"], "gold": r["gold_total"],
            "text": r["text"],
            "layout": L["ocr"]["total"],
            "layout_correct": L.get("ocr_correct"),
        })
    n = len(rows)
    out = {"n": n,
           "layout_available": sum(1 for r in rows if r["layout"] is not None),
           "layout_accuracy": round(sum(1 for r in rows if r["layout_correct"] is True)
                                    / max(1, sum(1 for r in rows if r["layout_correct"] is not None)), 4),
           "clean": evaluate(rows, 1), "x10": evaluate(rows, 10)}
    print("n", n, "layoutavail", out["layout_available"], "layout_acc", out["layout_accuracy"])
    for k in out:
        if k in ("clean", "x10"):
            print(k, json.dumps(out[k], ensure_ascii=False))
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print("wrote", OUT)


if __name__ == "__main__":
    main()
