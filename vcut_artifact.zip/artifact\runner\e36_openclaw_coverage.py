"""E36: OpenClaw static coverage census — real framework, first cut.

Scan D:/dev/openclaw/src/agents/tools/*.ts (excluding tests), classify each
tool as high-risk (exec/write/send/publish/delete/spawn/command) and as
guarded (guard/approval/permission/allowlist/denylist/confirm), and report the
coverage: how many high-risk tools carry any guard at all.

This is the first real-framework instance of the census: the criterion is
"does a verdict guard actually cover every high-risk sink", not "does a guard
node exist somewhere".
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

TOOLS = Path(r"D:\dev\openclaw\src\agents\tools")
HOOKS = Path(r"D:\dev\openclaw\src\agents\agent-hooks")
OUT = Path(r"E:\vldb2027_pipeline_safety\06_结果\e36_openclaw_coverage.json")

HIGH = re.compile(r"exec|shell|write|edit|send|publish|delete|spawn|kill|command|upload", re.I)
GUARD = re.compile(r"guard|approval|permission|allowlist|denylist|confirm|requireApproval|policy", re.I)


def main():
    files = [p for p in TOOLS.glob("*.ts") if ".test." not in p.name]
    rows = []
    for p in files:
        txt = p.read_text(encoding="utf-8", errors="ignore")
        name = p.stem
        high = bool(HIGH.search(name))
        guard = bool(GUARD.search(txt))
        rows.append({"tool": name, "high_risk": high, "guarded": guard,
                     "loc": len(txt)})

    high = [r for r in rows if r["high_risk"]]
    high_guarded = [r for r in high if r["guarded"]]
    high_unguarded = [r for r in high if not r["guarded"]]
    guarded_any = [r for r in rows if r["guarded"]]

    hooks = []
    if HOOKS.exists():
        hooks = [p.name for p in HOOKS.glob("*.ts") if ".test." not in p.name]

    out = {
        "tools_total": len(rows),
        "tools_guarded_any": len(guarded_any),
        "high_risk_tools": len(high),
        "high_risk_guarded": len(high_guarded),
        "high_risk_unguarded": len(high_unguarded),
        "coverage_rate": round(len(high_guarded) / max(len(high), 1), 4),
        "high_risk_unguarded_list": [r["tool"] for r in high_unguarded],
        "hook_files": hooks,
    }
    print(json.dumps(out, ensure_ascii=False, indent=1), flush=True)
    json.dump({"summary": out, "rows": rows},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
