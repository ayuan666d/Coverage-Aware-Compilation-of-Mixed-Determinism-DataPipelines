"""E11-SPLIT-SMALL: does the identifier-split + geometric-mean reading transfer
to the two small-schema settings that carry the main tables of the report?

Same four operators, run per database (BIRD 11 dbs / Spider known 34 dbs), under
both tokenisers, with the dense reference computed on the same candidate sets.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
OUT = REPO / "06_结果" / "e11_split_small_spider.json"
EPS = 1e-6
METHODS = ("bm25", "ppr_band", "typed_band", "sum_norm", "geom", "dense")


def per_token(cat, qs, alpha=0.85, iters=20):
    out = {}
    for w in sorted({w for q in qs for w in q}):
        if ("token", w) not in cat.idx:
            continue
        x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, alpha, iters)
        s = cat.table_scores(x)
        mx = float(s.max())
        out[w] = s / mx if mx > 0 else s
    return out


def fuse(tok, q, mode, n):
    ws = [w for w in set(q) if w in tok]
    if not ws:
        return np.zeros(n, dtype=np.float32)
    M = np.stack([tok[w] for w in ws])
    return M.sum(axis=0) if mode == "sum_norm" else np.exp(np.log(M + EPS).mean(axis=0))


def band_for(cases):
    qdf = Counter()
    for c in cases:
        qdf.update(set(toks(c["question"])))
    vals = sorted(qdf.values())
    hi = float(np.quantile(vals, 0.80)) if vals else 1.0

    def f(q):
        return {x: (0.15 if qdf[x] >= hi else 1.0) for x in q}
    return f


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", choices=["bird", "known"], required=True)
    args = ap.parse_args()
    cache = json.load(open(CACHE, encoding="utf-8"))
    allc = json.load(open(CASES, encoding="utf-8"))
    if args.kind == "bird":
        cases_all = allc["bird"]
        dbs = cache["bird"]
        emb = Path("D:/vldb2027_e11/e11_emb_bird.npz")
    else:
        cases_all = [c for c in allc["spider"] if c["split"] == "test"]
        dbs = cache["spider"]
        emb = Path("D:/vldb2027_e11/e11_emb_spider.npz")
    z = np.load(emb, allow_pickle=True)
    ids = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}
    by_db_pos = {}
    for i, t in enumerate(ids):
        by_db_pos.setdefault(t.split("::")[0], []).append(i)

    res = {}
    for flag in (False, True):
        g.SPLIT_IDENT = flag
        t0 = time.time()
        rows = []
        by = {}
        for c in cases_all:
            by.setdefault(c["db_id"], []).append(c)
        for db, cs in sorted(by.items()):
            if db not in dbs:
                continue
            tables = [dict(t, db=db) for t in dbs[db]["tables"]]
            cat = g.Catalog(tables, dbs[db]["fks"], prefix_db=False)
            bf = band_for(cs)
            tk = per_token(cat, [toks(c["question"]) for c in cs])
            cand = by_db_pos.get(db, [])
            for c in cs:
                q = toks(c["question"])
                gold_names = set(c["gold"])
                gold_ns = {f"{db}::{t}" for t in c["gold"]}
                bw = bf(q)
                sc = {"bm25": g.bm25(cat, q), "ppr_band": g.single_ppr(cat, q, band_weight=bw),
                      "typed_band": g.fuse(cat, q, band_weight=bw),
                      "sum_norm": fuse(tk, q, "sum_norm", len(cat.tables)),
                      "geom": fuse(tk, q, "geom", len(cat.tables))}
                rec = {"qid": c["qid"], "db": db, "n_tables": len(cat.tables), "gold": sorted(gold_names)}
                gt = set()
                for t in gold_names:
                    if t in cat.table_pos:
                        gt |= set(g.table_doc(cat.tables[cat.table_pos[t]]))
                bt = set(q) & gt
                rec["bridge_min_df"] = min([cat.token_df.get(w, 0) for w in bt], default=0)
                for name, s in sc.items():
                    r = g.rank(s, cat)
                    m = g.metrics(r, gold_names)
                    rec[f"{name}_r1"] = round(m["recall@1"], 4)
                    rec[f"{name}_r5"] = round(m["recall@5"], 4)
                    rec[f"{name}_mrr"] = round(m["mrr"], 4)
                if cand:
                    sim = Dm[cand] @ Qm[qpos[c["qid"]]]
                    rk = [ids[cand[j]] for j in np.argsort(-sim)]
                    m = g.metrics(rk, gold_ns)
                    rec["dense_r1"] = round(m["recall@1"], 4)
                    rec["dense_r5"] = round(m["recall@5"], 4)
                    rec["dense_mrr"] = round(m["mrr"], 4)
                rows.append(rec)
        mean = lambda k: round(float(np.mean([r[k] for r in rows if k in r])), 4)  # noqa: E731
        res["split" if flag else "underscore"] = {
            "n": len(rows), "secs": round(time.time() - t0, 1),
            **{f"{m}_r1": mean(f"{m}_r1") for m in METHODS},
            **{f"{m}_r5": mean(f"{m}_r5") for m in METHODS},
            **{f"{m}_mrr": mean(f"{m}_mrr") for m in METHODS},
            "no_bridge": sum(1 for r in rows if r["bridge_min_df"] == 0)}
        res[("split" if flag else "underscore") + "_rows"] = rows
        print(json.dumps({k: v for k, v in res[("split" if flag else "underscore")].items()}, indent=2), flush=True)

    out = {"kind": args.kind, **{k: v for k, v in res.items() if not k.endswith("_rows")},
           "rows": res["split_rows"]}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
