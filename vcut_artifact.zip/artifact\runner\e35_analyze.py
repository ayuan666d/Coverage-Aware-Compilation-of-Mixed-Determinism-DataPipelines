"""E35 归因：从逐问明细拆解评估集效应。

读 `e36_scale_forge_big_<tag>_perq.jsonl`，输出三张表：
    1. 按问句来源（dev / train_spider）分组
    2. 按库分组（只报 R@5 最低的 12 个，定位失效库）
    3. 按 gold 表数分组（多表题是否系统性更难）

用法：
    python e35_analyze.py                 # 默认分析 951 与 10k-syn
    python e35_analyze.py 4k-syn 10k-syn
"""

from __future__ import annotations

import json
import os
import sys
from collections import defaultdict
from pathlib import Path

WORK = Path("D:/vldb2027_e11")
# 产物前缀：默认读自划 33 库口径（e36）；官方 dev20 口径用 E35_STEM=e37_scale_dev20
STEM = os.environ.get("E35_STEM", "e36_scale_forge_big")


def load(tag: str) -> list[dict]:
    p = WORK / f"{STEM}_{tag}_perq.jsonl"
    if not p.exists():
        return []
    return [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]


def agg(rows: list[dict]) -> dict:
    n = max(len(rows), 1)
    return {"n": len(rows),
            "R1": sum(r["R1"] for r in rows) / n * 100,
            "R5": sum(r["R5"] for r in rows) / n * 100,
            "hit20": sum(r["hit20"] for r in rows) / n * 100,
            "synth5": sum(r["synth5"] for r in rows) / n}


def main() -> None:
    tags = sys.argv[1:] or ["951", "10k-syn"]
    for tag in tags:
        rows = load(tag)
        if not rows:
            print(f"[{tag}] 无逐问明细，跳过")
            continue
        print(f"\n{'='*78}\n[{tag}] 共 {len(rows)} 问\n{'='*78}")

        print("\n-- 按问句来源 --")
        print("| 来源 | 问数 | R@1 | R@5 | hit@20 | 合成进top5 |")
        print("|---|---|---|---|---|---|")
        by_src: dict[str, list[dict]] = defaultdict(list)
        for r in rows:
            by_src[r["src"]].append(r)
        for src, sub in sorted(by_src.items()):
            a = agg(sub)
            print(f"| {src} | {a['n']} | {a['R1']:.2f} | {a['R5']:.2f} | "
                  f"{a['hit20']:.2f} | {a['synth5']:.2f} |")
        a = agg(rows)
        print(f"| **全部** | {a['n']} | {a['R1']:.2f} | {a['R5']:.2f} | "
              f"{a['hit20']:.2f} | {a['synth5']:.2f} |")

        print("\n-- 按库（R@5 最低 12 个）--")
        print("| 库 | 问数 | R@1 | R@5 |")
        print("|---|---|---|---|")
        by_db: dict[str, list[dict]] = defaultdict(list)
        for r in rows:
            by_db[r["db"]].append(r)
        ranked = sorted(((agg(v), k) for k, v in by_db.items()), key=lambda x: x[0]["R5"])
        for a, db in ranked[:12]:
            print(f"| {db} | {a['n']} | {a['R1']:.2f} | {a['R5']:.2f} |")
        print(f"（共 {len(by_db)} 个库）")

        print("\n-- 按 gold 表数 --")
        print("| gold 数 | 问数 | R@1 | R@5 |")
        print("|---|---|---|---|")
        by_g: dict[int, list[dict]] = defaultdict(list)
        for r in rows:
            by_g[min(r["n_gold"], 3)].append(r)
        for g in sorted(by_g):
            a = agg(by_g[g])
            label = f"{g}" if g < 3 else "3+"
            print(f"| {label} | {a['n']} | {a['R1']:.2f} | {a['R5']:.2f} |")


if __name__ == "__main__":
    main()
