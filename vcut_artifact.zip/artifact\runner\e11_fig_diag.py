"""E11 diagnostic figure: where the retrieval loss actually lives.

Panel A -- audit by where the evidence sits (real SQLite opened per question).
Panel B -- R@5 against the document frequency of the rarest anchor the query
found, before and after the two zero-training fixes.
"""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
OUT = R / "E11_diag.png"
BM25, GRAPH, DENSE, NEW = "#7f7f7f", "#1f77b4", "#d62728", "#2ca02c"


def main():
    ev = json.load(open(R / "e11_evidence.json", encoding="utf-8"))["by_class"]
    spl = json.load(open(R / "e11_split.json", encoding="utf-8"))
    sp = {r["qid"]: r for r in spl["split_ident_rows"]}
    dg = {r["qid"]: r for r in json.load(open(R / "e11_diag.json", encoding="utf-8"))["rows"]}
    rt = {r["qid"]: r for r in json.load(open(R / "e11_route.json", encoding="utf-8"))["rows"]}

    fig, ax = plt.subplots(1, 2, figsize=(13.4, 5.0))

    # ---------- panel A: evidence audit ----------
    order = ["exact", "compound", "fullvalue", "none"]
    lab = {"exact": "whole identifier\nappears in the question\n(242 q)",
           "compound": "only a PART of a\ncompound identifier\n(90 q)",
           "fullvalue": "only in real cell values,\nnot in the sample\n(8 q)",
           "none": "nothing anywhere\nin the database\n(1 q)"}
    x = np.arange(len(order))
    for i, (name, key, col) in enumerate([("BM25", "bm25_r5", BM25),
                                          ("relational graph", "graph_r5", GRAPH),
                                          ("dense 0.6B", "dense_r5", DENSE)]):
        ys = [ev[k][key] * 100 for k in order]
        ax[0].bar(x + (i - 1) * 0.26, ys, 0.24, color=col, label=name, zorder=3)
        for xi, y in zip(x + (i - 1) * 0.26, ys):
            ax[0].annotate(f"{y:.0f}", (xi, y), textcoords="offset points", xytext=(0, 3),
                           ha="center", fontsize=8.5, zorder=4)
    ax[0].axvspan(0.5, 1.5, color="#ffbf00", alpha=0.18, zorder=0)
    ax[0].text(1.0, 46, "54% of the whole gap:\nthe word IS in the schema,\nour tokeniser read it\nas one word",
               ha="center", fontsize=8.5, color="#333333")
    ax[0].set_xticks(x)
    ax[0].set_xticklabels([lab[k] for k in order], fontsize=8.5)
    ax[0].set_ylabel("R@5 (%)")
    ax[0].set_ylim(0, 112)
    ax[0].set_title("A  Where the evidence actually sits\n876-table catalogue, 341 questions, old tokeniser",
                    fontsize=10.5, loc="left")
    ax[0].legend(fontsize=8.5, frameon=False, ncol=3, loc="upper center",
                 bbox_to_anchor=(0.5, -0.20))
    ax[0].grid(axis="y", alpha=0.25, zorder=0)

    # ---------- panel B: anchor-frequency curve ----------
    def buck(x0):
        return 0 if x0 == 0 else (1 if x0 == 1 else (5 if x0 <= 5 else (20 if x0 <= 20 else 21)))

    bins = [0, 1, 5, 20, 21]
    names = ["0\n(no anchor)", "1", "2-5", "6-20", ">20"]
    counts = defaultdict(int)
    acc = defaultdict(lambda: defaultdict(list))
    for q, r in sp.items():
        b = buck(r["bridge_min_df"])
        counts[b] += 1
        acc[b]["graph_old"].append(dg[q]["typed_band_r5"])
        acc[b]["bm25_new"].append(r["bm25_r5"])
        acc[b]["rerank_new"].append(rt[q]["rerank30_r5"])
        acc[b]["dense"].append(r["dense_r5"])
    styles = [("graph_old", "-s", GRAPH, "graph, old tokeniser (as reported)", (-15, -4)),
              ("bm25_new", ":^", BM25, "BM25, identifiers split", (14, -4)),
              ("rerank_new", "-o", NEW, "graph, split + per-token fusion + rerank", (0, 8)),
              ("dense", "--o", DENSE, "dense 0.6B (not affected by our tokeniser)", (-4, 8))]
    xs = np.arange(len(bins))
    seen_zero = set()
    for k, st, col, labk, off in styles:
        ys = [float(np.mean(acc[b][k])) * 100 if acc[b][k] else np.nan for b in bins]
        ax[1].plot(xs, ys, st, color=col, label=labk, lw=1.7, ms=5.5)
        for xi, y in zip(xs, ys):
            if y != y:
                continue
            if y < 1.0:                      # several series collapse to 0; label once
                if xi in seen_zero:
                    continue
                seen_zero.add(xi)
                off = (0, 8)
            ax[1].annotate(f"{y:.0f}", (xi, y), textcoords="offset points",
                           xytext=off, ha="center", fontsize=8, color=col)
    ax[1].axvspan(0.5, 1.5, color=NEW, alpha=0.10, zorder=0)
    ax[1].text(1.0, 12, "here the graph beats\ndense (93 vs 88)", ha="center", fontsize=8.5, color="#1a5c1a")
    ax[1].set_xticks(xs)
    ax[1].set_xticklabels([f"{n}\nn={counts[b]}" for n, b in zip(names, bins)], fontsize=8.5)
    ax[1].set_xlabel("document frequency of the rarest catalogue anchor")
    ax[1].set_ylabel("R@5 (%)")
    ax[1].set_ylim(0, 112)
    ax[1].set_title("B  After two zero-training fixes: overall 47.5% -> 76.4% (dense 87.9%)\n"
                    "the loss is now only where the anchor is absent or a hub",
                    fontsize=10.5, loc="left")
    ax[1].legend(fontsize=8, frameon=False, loc="upper center", ncol=2,
                 bbox_to_anchor=(0.5, -0.24))
    ax[1].grid(alpha=0.25, zorder=0)

    fig.tight_layout()
    fig.savefig(OUT, dpi=170)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
