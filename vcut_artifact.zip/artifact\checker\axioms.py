# -*- coding: utf-8 -*-
"""三个命题的 A/B 双实现对拍

A 组：穷举。走路径枚举 / 子集枚举，**不调用 graphutil 的任何函数**。
B 组：算法。走可达性 / 最大流。

两组的唯一共同输入是 (节点集, 边集, V_eff)。若两者结论不一致，
说明定义有歧义或某一侧实现有 bug —— 这正是 E0 要抓的东西。

覆盖：
    V1  定理 1   割集判据          A: 路径枚举  vs  B: 可达性
    V2  命题 1   坏路径节点集      A: 路径并集  vs  B: 交集刻画
    V3  定理 2   最小修复规模      A: 子集枚举  vs  B: Menger 最大流
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass
from typing import Dict, FrozenSet, List, Sequence, Set, Tuple

from . import graphutil as GU

ENTRY = "__entry__"


@dataclass(frozen=True)
class Case:
    """一个待验证的小图实例。"""

    nodes: Tuple[str, ...]
    edges: Tuple[Tuple[str, str], ...]
    sinks: Tuple[str, ...]
    v_eff: FrozenSet[str]            # 已知有效的判决节点；E0 只验图论，不验 eff

    def succ(self) -> Dict[str, List[str]]:
        s: Dict[str, List[str]] = {n: [] for n in self.nodes}
        for a, b in self.edges:
            s[a].append(b)
        return s

    def pred(self) -> Dict[str, List[str]]:
        p: Dict[str, List[str]] = {n: [] for n in self.nodes}
        for a, b in self.edges:
            p[b].append(a)
        return p

    def sources(self) -> List[str]:
        has_in = {b for _, b in self.edges}
        return sorted(n for n in self.nodes if n not in has_in)


# ══════════════════════════════════════════════════════════════
# A 组：穷举
# ══════════════════════════════════════════════════════════════


def _a_all_paths(case: Case) -> List[List[str]]:
    """A 组自带的路径枚举。刻意不用 graphutil.enumerate_paths。"""
    succ = case.succ()
    out: List[List[str]] = []
    stack = [(s, (s,)) for s in case.sources()]
    while stack:
        node, path = stack.pop()
        if node in case.sinks:
            out.append(list(path))
            continue
        for nxt in succ[node]:
            if nxt in path:
                continue
            stack.append((nxt, path + (nxt,)))
    return out


def v1_by_enumeration(case: Case) -> Tuple[bool, List[List[str]]]:
    """对每个出口：所有 entry→sink 路径都与 V_eff 相交。"""
    bad_all: List[List[str]] = []
    for s in case.sinks:
        paths = [p for p in _a_all_paths(case) if p[-1] == s]
        for p in paths:
            if not (set(p) & case.v_eff):
                bad_all.append(p)
    return (len(bad_all) == 0), bad_all


def v2_by_path_union(case: Case) -> Dict[str, Set[str]]:
    """每个出口：所有坏路径经过的节点并集。"""
    out: Dict[str, Set[str]] = {}
    for s in case.sinks:
        acc: Set[str] = set()
        for p in _a_all_paths(case):
            if p[-1] == s and not (set(p) & case.v_eff):
                acc.update(p)
        out[s] = acc
    return out


def v3_by_subset_enum(case: Case) -> Dict[str, int | None]:
    """每个出口：枚举所有候选修复集，取使 V_eff∪X 成割的最小 |X|。

    候选 = 节点去掉 V_eff、去掉出口、**去掉源**。
    源不可被割（割掉源没有工程意义），汇同理。返回 None 表示在内部无解。
    """
    out: Dict[str, int | None] = {}
    srcs = set(case.sources())
    candidates_all = [n for n in case.nodes if n not in case.v_eff and n not in srcs]
    for s in case.sinks:
        cands = [n for n in candidates_all if n != s]
        best: int | None = None
        for k in range(0, len(cands) + 1):
            found = False
            for combo in itertools.combinations(cands, k):
                blocked = set(case.v_eff) | set(combo)
                if not _a_reaches_any(case, s, blocked):
                    best = k
                    found = True
                    break
            if found:
                break
        out[s] = best
    return out


def _a_reaches_any(case: Case, target: str, blocked: Set[str]) -> bool:
    """A 组自带的可达性（BFS），与 graphutil.reachable_set 不同实现。"""
    succ = case.succ()
    seen = set()
    q = []
    for s in case.sources():
        if s not in blocked:
            if s == target:
                return True
            seen.add(s)
            q.append(s)
    while q:
        n = q.pop(0)
        for k in succ[n]:
            if k in blocked or k in seen:
                continue
            if k == target:
                return True
            seen.add(k)
            q.append(k)
    return False


# ══════════════════════════════════════════════════════════════
# B 组：算法
# ══════════════════════════════════════════════════════════════


def v1_by_reachability(case: Case) -> Tuple[bool, Dict[str, bool], Dict[str, List[str] | None]]:
    succ = case.succ()
    per: Dict[str, bool] = {}
    witness: Dict[str, List[str] | None] = {}
    srcs = case.sources()
    for s in case.sinks:
        off = None
        for src in srcs:
            off = GU.find_offender_path([src], s, succ, case.v_eff)
            if off:
                break
        per[s] = off is None
        witness[s] = off
    return all(per.values()), per, witness


def v2_by_intersection(case: Case) -> Dict[str, Set[str]]:
    """坏路径节点集 = { n : n 从 entry 可达 且 n 可达 sink }，均在 G\\V_eff 中。"""
    succ, pred = case.succ(), case.pred()
    blocked = set(case.v_eff)
    out: Dict[str, Set[str]] = {}
    for s in case.sinks:
        fwd: Set[str] = set()
        for src in case.sources():
            fwd |= GU.reachable_set(src, succ, frozenset(blocked))
        bwd = GU.coreachable_set(s, pred, frozenset(blocked))
        out[s] = fwd & bwd
    return out


def v3_by_menger(case: Case) -> Dict[str, int | None]:
    """多源 → 单汇 一次求整体最小内部顶点割。INF 视为内部无解（None）。"""
    succ = case.succ()
    per: Dict[str, int | None] = {}
    for s in case.sinks:
        k = GU.max_vertex_disjoint_paths_multi(
            case.sources(), s, case.nodes, succ, case.v_eff
        )
        per[s] = None if k >= GU.INF else k
    return per


# ── v0.3：边割版本（在边上串判决）────────────────────────────


def _a_reaches_any_with_edges(
    case: Case, target: str, blocked_nodes: Set[str],
    blocked_edges: Set[Tuple[str, str]],
) -> bool:
    """A 组自带的 BFS：跳过 blocked 节点和 blocked 边。与 graphutil 不同实现。"""
    succ = case.succ()
    seen = set()
    q = []
    for s in case.sources():
        if s not in blocked_nodes:
            if s == target:
                return True
            seen.add(s)
            q.append(s)
    while q:
        n = q.pop(0)
        for k in succ[n]:
            if k in blocked_nodes or (n, k) in blocked_edges or k in seen:
                continue
            if k == target:
                return True
            seen.add(k)
            q.append(k)
    return False


def v3_edge_by_enum(
    case: Case, max_k: int = 6, max_edges: int = 18,
) -> Dict[str, int | None]:
    """枚举边子集求最小边割。图太大时返回 None 表示“未验证”，由调用方区分。"""
    succ = case.succ()
    cands = [(a, b) for a, b in case.edges
             if a not in case.v_eff and b not in case.v_eff]
    per: Dict[str, int | None] = {}
    if len(cands) > max_edges:
        for s in case.sinks:
            per[s] = None
        return per
    for s in case.sinks:
        best: int | None = None
        for k in range(0, min(max_k, len(cands)) + 1):
            found = False
            for combo in itertools.combinations(cands, k):
                if not _a_reaches_any_with_edges(
                    case, s, set(case.v_eff), set(combo)
                ):
                    best = k
                    found = True
                    break
            if found:
                break
        if best is None:
            # 超过 max_k 才可能切掉：交给 Menger，不在这里判错
            best = None
        per[s] = best
    return per


def v3_edge_by_menger(case: Case) -> Dict[str, int | None]:
    succ = case.succ()
    per: Dict[str, int | None] = {}
    for s in case.sinks:
        k = GU.max_edge_disjoint_paths_multi(
            case.sources(), s, case.nodes, succ, case.v_eff
        )
        per[s] = None if k >= GU.INF else k
    return per


def min_edge_cut(case: Case) -> Dict[str, List[Tuple[str, str]]]:
    succ = case.succ()
    return {
        s: GU.min_edge_cut_multi(
            case.sources(), s, case.nodes, succ, case.v_eff
        )
        for s in case.sinks
    }


# ══════════════════════════════════════════════════════════════
# 对拍
# ══════════════════════════════════════════════════════════════


@dataclass
class Issue:
    kind: str
    detail: str


def edge_check_applicable(
    case: Case, max_edges: int = 18, max_k: int = 6,
) -> bool:
    """边割枚举的适用范围：边数不太多，且 Menger 值不超过枚举上限。"""
    cands = [(a, b) for a, b in case.edges
             if a not in case.v_eff and b not in case.v_eff]
    if len(cands) > max_edges:
        return False
    b = v3_edge_by_menger(case)
    return all(v is not None and v <= max_k for v in b.values())


def verify(case: Case, check_edge: bool = True) -> List[Issue]:
    issues: List[Issue] = []

    # V1
    a_safe, bad_paths = v1_by_enumeration(case)
    b_safe, b_per, b_witness = v1_by_reachability(case)
    if a_safe != b_safe:
        issues.append(Issue(
            "V1",
            f"定理1不一致: 枚举={a_safe} 可达={b_safe}  "
            f"坏路径样例={bad_paths[:1]}  可达见证={b_witness}",
        ))

    # V2
    a_nodes = v2_by_path_union(case)
    b_nodes = v2_by_intersection(case)
    for s in case.sinks:
        if a_nodes[s] != b_nodes[s]:
            issues.append(Issue(
                "V2",
                f"命题1不一致 出口{s}: 路径并集={sorted(a_nodes[s])} "
                f"交集刻画={sorted(b_nodes[s])}  差={sorted(a_nodes[s] ^ b_nodes[s])}",
            ))

    # V3（v0.2 顶点位置模型，保留作对照）
    a_k = v3_by_subset_enum(case)
    b_k = v3_by_menger(case)
    for s in case.sinks:
        if a_k[s] != b_k[s]:
            issues.append(Issue(
                "V3",
                f"定理2(顶点)不一致 出口{s}: 子集枚举={a_k[s]} Menger={b_k[s]}",
            ))

    # V4（v0.3 边插入模型）
    if check_edge and edge_check_applicable(case):
        a_e = v3_edge_by_enum(case)
        b_e = v3_edge_by_menger(case)
        for s in case.sinks:
            if a_e[s] != b_e[s]:
                issues.append(Issue(
                    "V4",
                    f"定理2(边割)不一致 出口{s}: 边子集枚举={a_e[s]} Menger={b_e[s]}",
                ))

    return issues
