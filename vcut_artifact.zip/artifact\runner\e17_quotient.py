"""E17: quotient granularity — merge primitives by semantic relation type.

Hypothesis: second-order estimation fails on BIRD because the 9 primitives are
9 representations of ~1 semantic relation (cond ~1e10).  Quotient by the
representation group: fixed grouping rules merge same-relation primitives, so
the second order is estimated on a low-dimensional quotient that is identical
across databases.

  G1 (coarse, 3 dims): lexical = mean(overlap, idf, stem, bm25, name, col, val),
                       typed, db
  G2 (medium, 7 dims): overlap = mean(raw, idf, stem), bm25, name, col, val,
                       typed, db
  G3 (fine, 9 dims):   identity (no quotient)

Train on Spider with each quotient, transfer the weight vector to BIRD.
Abllation: first order in every quotient (control for the merge itself).
"""
from __future__ import annotations

import json
import sys

import numpy as np

sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码\runner")
import e14_db_anchor as e14  # noqa: E402
import e16_transfer as e16  # noqa: E402
from e15_objective import fit_fisher  # noqa: E402

OUT = e14.REPO / "06_结果" / "e17_quotient.json"
KEEP = e16.KEEP  # [0,1,2,3,6,7,8,9,11] -> 9 positions


def qmat(kind):
    if kind == "G1":
        M = np.zeros((9, 3))
        M[[0, 1, 2, 3, 4, 5, 6], 0] = 1.0 / 7.0
        M[7, 1] = 1.0
        M[8, 2] = 1.0
    elif kind == "G2":
        M = np.zeros((9, 7))
        M[[0, 1, 2], 0] = 1.0 / 3.0
        M[3, 1] = 1.0
        M[4, 2] = 1.0
        M[5, 3] = 1.0
        M[6, 4] = 1.0
        M[7, 5] = 1.0
        M[8, 6] = 1.0
    else:
        M = np.eye(9)
    return M


def second_idx(d):
    return [(i, j) for i in range(d) for j in range(i, d)]


def fit_all(F, y, kind):
    M = qmat(kind)
    Q = F @ M
    mu = Q.mean(0)
    sd = Q.std(0) + 1e-9
    Qz = (Q - mu) / sd
    idx = second_idx(Q.shape[1])
    Q2 = np.concatenate([Qz, e14.quad(Qz, idx)], axis=1)
    w1 = fit_fisher(Qz, y, 0.1)
    w2 = fit_fisher(Q2, y, 0.1)
    return M, mu, sd, idx, w1, w2


def main():
    meta = e14.load()
    print("building Spider features…", flush=True)
    Ft = meta["build_F"](meta["train_q"])[:, :, KEEP]
    Y = np.zeros((len(meta["train_q"]), meta["D"]), dtype=np.float32)
    for qi, q in enumerate(meta["train_q"]):
        for f in meta["gold_all"][q]:
            j = meta["didx"].get(f)
            if j is not None:
                Y[qi, j] = 1.0
    y = Y.reshape(-1)
    Xt = Ft.reshape(-1, 9)

    cache = json.load(open(e14.CACHE, encoding="utf-8"))["bird"]
    cases = json.load(open(e14.CASES, encoding="utf-8"))["bird"]
    by_db = {}
    for c in cases:
        by_db.setdefault(c["db_id"], []).append(c)

    out = {}
    for kind in ("G1", "G2", "G3"):
        print("=== quotient", kind, "===", flush=True)
        M, mu, sd, idx, w1, w2 = fit_all(Xt, y, kind)
        d = M.shape[1]
        # Spider test (same quotient)
        Fte = ((meta["build_F"](meta["test_q"])[:, :, KEEP].reshape(len(meta["test_q"]), meta["D"], 9)
                @ M) - mu) / sd
        s1 = e14.evaluate(meta, Fte, w1)[0]
        s2 = e14.evaluate(meta, np.concatenate(
            [Fte.reshape(-1, d), e14.quad(Fte.reshape(-1, d), idx)], axis=1).reshape(
            len(meta["test_q"]), meta["D"], -1), w2)[0]
        print("Spider", kind, "d=", d, "first", json.dumps(s1), "second", json.dumps(s2), flush=True)

        # BIRD transfer
        rows = []
        for db, cs in sorted(by_db.items()):
            F9, doc_ids = e16.build_bird_db(cache[db], cs)
            Q = F9.reshape(-1, 9) @ M
            mu_b = Q.mean(0)
            sd_b = Q.std(0) + 1e-9
            Qz = (Q - mu_b) / sd_b
            Qz2 = np.concatenate([Qz, e14.quad(Qz, idx)], axis=1)
            for qi, c in enumerate(cs):
                gold = {g.lower() for g in c["gold"]}
                for name, w, Z in [("first", w1, Qz), ("second", w2, Qz2)]:
                    sc = Z.reshape(len(cs), len(doc_ids), -1)[qi] @ w
                    order = np.argsort(-sc)[:5]
                    top = [doc_ids[i] for i in order]
                    r, m = e14.metrics_top(top, gold)
                    rows.append({"qid": c["qid"], "db": db, "kind": kind,
                                 "method": name, "recall@1": r[1], "recall@3": r[3],
                                 "recall@5": r[5], "mrr": m})
        agg = {}
        for name in ("first", "second"):
            sub = [r for r in rows if r["method"] == name]
            agg[name] = {k: round(sum(r[k] for r in sub) / len(sub), 4)
                         for k in ("recall@1", "recall@3", "recall@5", "mrr")}
        out[kind] = {"dims": d, "spider": {"first": s1, "second": s2},
                     "bird": agg, "rows": rows}
        print("BIRD", kind, json.dumps(agg), flush=True)

    json.dump({"quotients": {k: {kk: vv for kk, vv in v.items() if kk != "rows"}
                             for k, v in out.items()},
               "rows": {k: v["rows"] for k, v in out.items()},
               "reference": {"bird_bm25_r5": 0.8628, "bird_ppr_r5": 0.9133,
                             "bird_transfer_first_9_r5": 0.9362,
                             "bird_transfer_second_9_r5": 0.6868}},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
