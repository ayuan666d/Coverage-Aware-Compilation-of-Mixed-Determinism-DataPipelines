"""E18: larger sample — official Spider train (7000 q, 140 dbs) -> dev (1034 q, 20 dbs).

Same 876-table catalog, same 11 primitives (exact-value removed: train has no
exact index).  First / second / third order closed forms, all Fisher (lam .1),
accumulated in chunks so the 363-dim third-order space never materializes whole.

Reference: E12 split 693/341 (14/6 dbs inside dev) first/second order.
"""
from __future__ import annotations

import json
import math
import re
import sys
import zipfile
from collections import Counter

import numpy as np

sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码\runner")
import e14_db_anchor as e14  # noqa: E402

ZIP = r"D:\vldb2027_e11\spider_data.zip"
OUT = e14.REPO / "06_结果" / "e18_large.json"
CHUNK = 120
LAM = 0.1

GOLD = re.compile(r"(?:[`\"\[]?[A-Za-z_][A-Za-z0-9_]*[`\"\]]?)")


def parse_gold(sql):
    ident = r"(?:[`\"\[]?[A-Za-z_][A-Za-z0-9_]*[`\"\]]?)"
    pat = re.compile(rf"\b(?:from|join)\s+({ident}(?:\s*\.\s*{ident})?)", re.I)
    out = set()
    for m in pat.finditer(sql):
        parts = re.split(r"\s*\.\s*", m.group(1))
        name = parts[-1].strip("`\"[] ")
        if name and name.lower() not in {"select", "where", "group", "order", "limit", "with"}:
            out.add(name.lower())
    return out


def load_cases():
    z = zipfile.ZipFile(ZIP)
    out = []
    for i, x in enumerate(json.loads(z.read("spider_data/train_spider.json").decode("utf-8"))):
        out.append({"qid": f"tr{i}", "db_id": x["db_id"], "question": x["question"],
                    "gold": sorted(parse_gold(x["query"]))})
    for i, x in enumerate(json.loads(z.read("spider_data/dev.json").decode("utf-8"))):
        out.append({"qid": f"dv{i}", "db_id": x["db_id"], "question": x["question"],
                    "gold": sorted(parse_gold(x["query"]))})
    return out


def load_docs():
    cache = json.load(open(e14.CACHE, encoding="utf-8"))["spider"]
    z = np.load(e14.NPZ, allow_pickle=True)
    doc_ids = [str(x) for x in z["doc_ids"]]
    didx = {f: i for i, f in enumerate(doc_ids)}
    D = len(doc_ids)
    doc_wn = z["doc_word"] / np.maximum(np.linalg.norm(z["doc_word"], axis=1, keepdims=True), 1e-9)
    doc_gn = z["doc_gram"] / np.maximum(np.linalg.norm(z["doc_gram"], axis=1, keepdims=True), 1e-9)

    name_t, col_t, val_t, all_t, stem_t, db_t = {}, {}, {}, {}, {}, {}
    for db, s in cache.items():
        dbname = re.sub(r"\d+$", "", db)
        for t in s["tables"]:
            fid = f"{db}::{t['name'].lower()}"
            nm = e14.wtoks(t["name"])
            cl, vl = [], []
            for c in t["columns"]:
                cl += e14.wtoks(c["name"])
                for v in (c.get("values") or [])[:12]:
                    vl += e14.wtoks(str(v))
            name_t[fid], col_t[fid], val_t[fid] = set(nm), set(cl), set(vl)
            all_t[fid] = set(nm) | set(cl) | set(vl)
            stem_t[fid] = {e14.stem4(x) for x in all_t[fid] if len(x) >= 4}
            db_t[fid] = set(e14.wtoks(dbname))

    df = Counter()
    for ts in all_t.values():
        df.update(ts)
    Dn = D
    idf = {t: math.log(1 + (Dn - df[t] + 0.5) / (df[t] + 0.5)) for t in df}
    tf = np.zeros((D, len(df)), dtype=np.float32)
    tidx = {t: i for i, t in enumerate(sorted(df))}
    for j, f in enumerate(doc_ids):
        for t in all_t[f]:
            tf[j, tidx[t]] = 1.0
    dlr = tf.sum(axis=1)

    wv_vocab = {t: i for i, t in enumerate(z["word_vocab"])}
    gr_vocab = {t: i for i, t in enumerate(z["gram_vocab"])}
    term_w, term_g = z["term_word"], z["term_gram"]

    def q_latent(tokens, vocab, term):
        vs = [term[vocab[t]] for t in set(tokens) if t in vocab]
        if not vs:
            return None
        v = np.mean(vs, axis=0)
        return v / max(np.linalg.norm(v), 1e-9)

    def build_F(qs):
        nf = 11
        F = np.zeros((len(qs), D, nf), dtype=np.float32)
        for qi, q in enumerate(qs):
            qt = e14.wtoks(q["question"])
            qset = set(qt)
            qstem = {e14.stem4(w) for w in qt if len(w) >= 4}
            wv = q_latent(qt, wv_vocab, term_w)
            gv = q_latent([g for w in qt for g in e14.ngrams(w)], gr_vocab, term_g)
            if wv is not None:
                F[qi, :, 4] = doc_wn @ wv
            if gv is not None:
                F[qi, :, 5] = doc_gn @ gv
            s = np.zeros(D, dtype=np.float32)
            for t, qc in Counter(qt).items():
                if t not in tidx:
                    continue
                col = tf[:, tidx[t]]
                s += qc * idf[t] * (col * 2.2) / (col + 1.2 * (0.25 + 0.75 * dlr / (dlr.mean() + 1e-9)))
            F[qi, :, 3] = s
            for j, f in enumerate(doc_ids):
                inter = qset & all_t[f]
                F[qi, j, 0] = len(inter)
                F[qi, j, 1] = sum(idf.get(t, 0.0) for t in inter)
                F[qi, j, 2] = len(qstem & stem_t[f])
                F[qi, j, 6] = len(qset & name_t[f])
                F[qi, j, 7] = len(qset & col_t[f])
                F[qi, j, 8] = len(qset & val_t[f])
                F[qi, j, 10] = len(qset & db_t[f])
        F[:, :, 9] = np.log1p(F[:, :, 6]) * np.log1p(F[:, :, 7]) * np.log1p(F[:, :, 8])
        return F

    return dict(doc_ids=doc_ids, didx=didx, D=D, build_F=build_F)


def idx2(d):
    return [(i, j) for i in range(d) for j in range(i, d)]


def idx3(d):
    return [(i, j, k) for i in range(d) for j in range(i, d) for k in range(j, d)]


def expand(X, I2, I3):
    P2 = np.empty((X.shape[0], len(I2)), dtype=np.float32)
    for k, (i, j) in enumerate(I2):
        P2[:, k] = X[:, i] * X[:, j]
    P3 = np.empty((X.shape[0], len(I3)), dtype=np.float32)
    for k, (i, j, l) in enumerate(I3):
        P3[:, k] = X[:, i] * X[:, j] * X[:, l]
    return P2, P3


def main():
    cases = load_cases()
    docs = load_docs()
    qtext = {c["qid"]: c["question"] for c in cases}
    gold_all = {c["qid"]: {f"{c['db_id']}::{g}" for g in c["gold"]} for c in cases}
    train = [c for c in cases if c["qid"].startswith("tr")]
    test = [c for c in cases if c["qid"].startswith("dv")]
    print("train q", len(train), "test q", len(test), "catalog", docs["D"], flush=True)

    mu = None
    sd = None
    stats = {"n": 0, "A": None, "sx": None, "sxp": None, "np": 0}
    I2, I3 = idx2(11), idx3(11)
    dim = 11 + len(I2) + len(I3)
    print("dims: first 11, second", len(I2), "third", len(I3), "total", dim, flush=True)

    # pass 1: first-order stats for standardization
    for s0 in range(0, len(train), CHUNK):
        F = docs["build_F"](train[s0:s0 + CHUNK])
        flat = F.reshape(-1, 11)
        if stats["sx"] is None:
            stats["A"] = np.zeros(dim, dtype=np.float64)
            stats["sx"] = np.zeros(dim, dtype=np.float64)
            stats["sxp"] = np.zeros(dim, dtype=np.float64)
        if mu is None:
            mu, sd = flat.mean(0), flat.std(0) + 1e-9
    print("mu/sd from first chunk", flush=True)

    stats = {"n": 0, "A": np.zeros((dim, dim), dtype=np.float64),
             "sx": np.zeros(dim, dtype=np.float64),
             "sxp": np.zeros(dim, dtype=np.float64), "np": 0}
    for s0 in range(0, len(train), CHUNK):
        batch = train[s0:s0 + CHUNK]
        F = docs["build_F"](batch)
        Z = ((F - mu) / sd).reshape(-1, 11)
        P2, P3 = expand(Z, I2, I3)
        X = np.concatenate([Z, P2, P3], axis=1)
        y = np.zeros((len(batch), docs["D"], 1), dtype=np.float32)
        for qi, c in enumerate(batch):
            for g in gold_all[c["qid"]]:
                j = docs["didx"].get(g)
                if j is not None:
                    y[qi, j, 0] = 1.0
        yy = y.reshape(-1)
        stats["A"] += X.T @ X
        stats["sx"] += X.sum(0)
        stats["n"] += len(yy)
        pos = yy > 0.5
        stats["np"] += int(pos.sum())
        stats["sxp"] += X[pos].sum(0)
        if (s0 // CHUNK) % 10 == 0:
            print("train chunk", s0, "/", len(train), flush=True)

    n = stats["n"]
    w_by_arm = {}
    for arm, k in [("first", 11), ("second", 11 + len(I2)), ("third", dim)]:
        A_k = stats["A"][:k, :k]
        sx_k = stats["sx"][:k]
        sxp_k = stats["sxp"][:k]
        mean_k = sx_k / n
        Cov_k = A_k / n - np.outer(mean_k, mean_k)
        mu_p_k = sxp_k / max(stats["np"], 1)
        mu_n_k = (sx_k - sxp_k) / max(n - stats["np"], 1)
        w_k = np.linalg.solve((Cov_k + LAM * np.eye(k)).astype(np.float64),
                              (mu_p_k - mu_n_k).astype(np.float64)).astype(np.float32)
        w_by_arm[arm] = w_k
        print(arm, "solved k=", k, "positives", stats["np"], "of", n,
              "w_norm", float(np.linalg.norm(w_k)), flush=True)

    rows = []
    for s0 in range(0, len(test), 80):
        batch = test[s0:s0 + 80]
        F = docs["build_F"](batch)
        Z = ((F - mu) / sd).reshape(-1, 11)
        P2, P3 = expand(Z, I2, I3)
        X = np.concatenate([Z, P2, P3], axis=1)
        for qi, c in enumerate(batch):
            gold = gold_all[c["qid"]]
            for arm, k in [("first", 11), ("second", 11 + len(I2)), ("third", dim)]:
                sc = X.reshape(len(batch), docs["D"], -1)[qi][:, :k] @ w_by_arm[arm]
                order = np.argsort(-sc)[:5]
                top = [docs["doc_ids"][i] for i in order]
                r, m = e14.metrics_top(top, gold)
                rows.append({"qid": c["qid"], "db": c["db_id"], "arm": arm,
                             "recall@1": r[1], "recall@3": r[3], "recall@5": r[5], "mrr": m})
        if (s0 // 80) % 5 == 0:
            print("test chunk", s0, "/", len(test), flush=True)

    out = {}
    for arm in ("first", "second", "third"):
        sub = [r for r in rows if r["arm"] == arm]
        out[arm] = {k: round(sum(r[k] for r in sub) / len(sub), 4)
                    for k in ("recall@1", "recall@3", "recall@5", "mrr")}
        print(arm, json.dumps(out[arm]), flush=True)

    json.dump({"setup": {"train_q": len(train), "test_q": len(test),
                         "catalog": docs["D"], "dim": dim,
                         "second_terms": len(I2), "third_terms": len(I3)},
               "metrics": out,
               "weights_len": {k: int(len(v)) for k, v in w_by_arm.items()},
               "reference": {"e12_split_693_341_second_r5": 0.8622,
                             "e12_split_693_341_first_r5": 0.7805}},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
