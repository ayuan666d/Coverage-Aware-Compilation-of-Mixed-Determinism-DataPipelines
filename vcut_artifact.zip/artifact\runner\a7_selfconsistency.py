# -*- coding: utf-8 -*-
"""A7: k=3 self-consistency baseline (LOTUS-style sampling verification).

200 CORD receipts, 3 samples each at temperature 0.7 (600 calls). Policies compared
on the same receipts and the same outputs:

  P1  k=1 closure                 (single sample, arithmetic closure)
  P2  k=1 closure + layout agree  (our guard at one call)
  P3  k=3 majority only           (sampling verification, no database check)
  P4  k=3 majority + closure
  P5  k=3 majority + closure + layout agree   (ours at three calls)

Readings: automation, false pass, precision. Key from DEEPSEEK_API_KEY.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import sys
import time
import urllib.error
import urllib.request
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

RUN = Path(r"E:\vldb2027_pipeline_safety\05_代码\runner")
sys.path.insert(0, str(RUN))


def load(name, fname):
    spec = importlib.util.spec_from_file_location(name, str(RUN / fname))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


e7 = load("e7", "e7_receipts.py")
e7k = load("e7k", "e7k_independent_witness.py")

DATA = Path(r"E:\vldb2027_pipeline_safety\04_数据\external\cord\train.parquet")
LAY = Path(r"E:\vldb2027_pipeline_safety\06_结果\a5_layout_v2.json")
OUT = Path(r"E:\vldb2027_pipeline_safety\06_结果\a7_selfconsistency.json")


def call(key, text, model, temperature, timeout=90):
    body = json.dumps({
        "model": model,
        "messages": [{"role": "system", "content": e7.SYSTEM},
                     {"role": "user", "content": "OCR tokens:\n" + text +
                      "\n\nReturn the JSON object now."}],
        "temperature": temperature,
        "max_tokens": 1200,
        "response_format": {"type": "json_object"},
    }, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        "https://api.deepseek.com/chat/completions", data=body,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        method="POST")
    last = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = json.loads(r.read().decode("utf-8"))
            return {"raw": (data.get("choices") or [{}])[0].get("message", {}).get("content", "")}
        except urllib.error.HTTPError as e:
            last = f"HTTP {e.code}"
            if e.code not in (408, 409, 429, 500, 502, 503, 504):
                break
        except Exception as e:  # noqa: BLE001
            last = f"{type(e).__name__}: {e}"
        time.sleep(1.5 * (attempt + 1))
    return {"raw": "", "error": last}


def majority(vals):
    vals = [v for v in vals if v is not None]
    if not vals:
        return None, 0
    v, c = Counter(vals).most_common(1)[0]
    return v, c


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--k", type=int, default=3)
    ap.add_argument("--workers", type=int, default=10)
    ap.add_argument("--temp", type=float, default=0.7)
    ap.add_argument("--model", default="deepseek-chat")
    ap.add_argument("--key-env", default="DEEPSEEK_API_KEY")
    a = ap.parse_args()
    key = os.environ.get(a.key_env)
    if not key:
        print(f"missing env {a.key_env}", file=sys.stderr)
        sys.exit(2)

    import pandas as pd
    df = pd.read_parquet(DATA).sample(n=a.n, random_state=11)
    lay = {r["file"]: r["total"] for r in
           json.loads(LAY.read_text(encoding="utf-8"))["rows"]}

    items = []
    for _, r in df.iterrows():
        items.append({"file": r["file_name"], "text": e7.tokens_text(r["ocr_text"]),
                      "gold": e7.gold_of(r["ocr_kie"]).get("total")})

    jobs = [(i, s) for i in range(len(items)) for s in range(a.k)]
    raws = [{} for _ in jobs]
    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=a.workers) as ex:
        fut = {ex.submit(call, key, items[i]["text"], a.model, a.temp): n
               for n, (i, s) in enumerate(jobs)}
        done = 0
        for f in as_completed(fut):
            raws[fut[f]] = f.result()
            done += 1
            if done % 100 == 0:
                print(f"{done}/{len(jobs)} calls, {time.perf_counter()-t0:.0f}s", flush=True)

    rows = []
    for i, it in enumerate(items):
        outs = []
        for s in range(a.k):
            m = e7.parse_model(raws[i * a.k + s].get("raw", ""))
            outs.append(m)
        vals = [m.get("total") for m in outs]
        maj, cnt = majority(vals)
        # representative output for closure: the first one carrying the majority value
        rep = next((m for m in outs if m.get("total") == maj), outs[0])
        j = e7.judge(rep, {"total": it["gold"], "subtotal": None}, it["text"])
        j1 = e7.judge(outs[0], {"total": it["gold"], "subtotal": None}, it["text"])
        B = lay.get(it["file"])
        rows.append({
            "file": it["file"], "gold": it["gold"], "totals": vals,
            "majority": maj, "votes": cnt,
            "first": vals[0],
            "first_closure": j1["verdict"] in ("accept", "fill"),
            "majority_closure": j["verdict"] in ("accept", "fill"),
            "layout": B,
            "first_agree_B": vals[0] is not None and B is not None and e7k.match(vals[0], B) is True,
            "maj_agree_B": maj is not None and B is not None and e7k.match(maj, B) is True,
            "errors": sum(1 for s in range(a.k) if raws[i * a.k + s].get("error")),
        })

    def ok(v, g):
        return v is not None and e7k.match(v, g) is True

    policies = {
        "P1_k1_closure": lambda r: (r["first"], r["first_closure"]),
        "P2_k1_closure_B": lambda r: (r["first"], r["first_closure"] and r["first_agree_B"]),
        "P3_k3_majority": lambda r: (r["majority"], r["votes"] >= 2),
        "P4_k3_majority_closure": lambda r: (r["majority"], r["votes"] >= 2 and r["majority_closure"]),
        "P5_k3_majority_closure_B": lambda r: (r["majority"], r["votes"] >= 2 and r["majority_closure"] and r["maj_agree_B"]),
    }
    out = {"n": len(rows), "k": a.k, "temp": a.temp, "calls": len(jobs),
           "api_errors": sum(r["errors"] for r in rows),
           "policies": {}}
    for name, fn in policies.items():
        acc = []
        for r in rows:
            v, okp = fn(r)
            if okp:
                acc.append(ok(v, r["gold"]))
        fp = sum(1 for g in acc if not g)
        out["policies"][name] = {
            "accept": len(acc), "automation": round(len(acc) / len(rows), 4),
            "false_pass": fp, "false_pass_rate": round(fp / len(rows), 4),
            "precision": round((len(acc) - fp) / len(acc), 4) if acc else None}
    out["vote_distribution"] = dict(Counter(r["votes"] for r in rows))
    out["rows"] = rows
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, ensure_ascii=False, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
