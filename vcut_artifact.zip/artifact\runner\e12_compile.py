"""E12 leg 1: compile the database into retrieval matrices (no training).

Database-native artifacts only: table/column names, sampled values, FK edges.
Two fixed-structure spaces are compiled:
  - word space:  PPMI-weighted term-doc matrix over table documents
  - ngram space: PPMI-weighted char 3-5 gram matrix (word-form robustness)
Both are factorised by truncated SVD (closed form; the "fixed math structure").

Self-contained: imports nothing from e11_* (that file is being edited in
parallel).  Tokenizer/STOP mirrors e11_data for comparability.
"""
from __future__ import annotations

import json
import re
import sys
from collections import Counter
from pathlib import Path

import numpy as np

WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
OUT_NPZ = WORK / "e12_spectral.npz"
OUT_META = WORK / "e12_spectral_meta.json"

STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us list show give find return
number names name""".split())

WORD = re.compile(r"[a-z0-9]+")


def wtoks(s):
    return [t for t in WORD.findall(s.lower()) if t not in STOP]


def ngrams(word, ns=(3, 4, 5)):
    w = f"<{word}>"
    out = set()
    for n in ns:
        if len(w) >= n:
            out |= {w[i:i + n] for i in range(len(w) - n + 1)}
    return out


def randomized_svd(A, k, oversample=16, iters=4, seed=0):
    """Halko-style randomized SVD of a dense (m x n) matrix, returns U(k),S(k),Vt(k)."""
    rng = np.random.default_rng(seed)
    m, n = A.shape
    Q = min(k + oversample, min(m, n))
    Omega = rng.standard_normal((n, Q)).astype(np.float32)
    Y = A @ Omega
    Y -= Y.mean(axis=0, keepdims=True)
    for _ in range(iters):
        Y = A @ (A.T @ Y)
        Y -= Y.mean(axis=0, keepdims=True)
    Qu, _ = np.linalg.qr(Y.astype(np.float64))
    B = Qu.T @ A                      # Q x n
    Ub, S, Vt = np.linalg.svd(B, full_matrices=False)
    U = Qu @ Ub[:, :k]
    return U[:, :k].astype(np.float32), S[:k].astype(np.float32), Vt[:k, :].astype(np.float32)


def ppmi_weight(counts_td, docs_len, df, alpha=0.75):
    """Shifted PPMI on a dense term-doc count matrix (V x D given transposed)."""
    total = counts_td.sum()
    p_t = counts_td.sum(axis=1, keepdims=True) / total          # V x 1
    p_d = (docs_len[np.newaxis, :] ** alpha)
    p_d = p_d / p_d.sum()
    expected = p_t @ p_d * total
    pmi = np.log((counts_td * total) / np.maximum(expected, 1e-12) / np.log(2.0))
    return np.maximum(pmi, 0.0).astype(np.float32)


def build_space(items, name, min_df=2, k=256):
    """items: list of (doc_idx, field_weight, tokens) -> PPMI-SVD space."""
    per_doc = {}
    for d, w, toks in items:
        tw = per_doc.setdefault(d, {})
        for t in set(toks):
            tw[t] = tw.get(t, 0.0) + w
    df = Counter()
    for tw in per_doc.values():
        for t in tw:
            df[t] += 1
    vocab = sorted(t for t, c in df.items() if c >= min_df)
    vidx = {t: i for i, t in enumerate(vocab)}
    D = max(per_doc) + 1
    C = np.zeros((len(vocab), D), dtype=np.float32)
    dlen = np.zeros(D, dtype=np.float64)
    for d, tw in per_doc.items():
        for t, w in tw.items():
            i = vidx.get(t)
            if i is not None:
                C[i, d] = w
        dlen[d] = sum(tw.values())
    M = ppmi_weight(C, dlen, df)
    # factorise M^T (D x V): doc vectors = U, term vectors = V
    U, S, Vt = randomized_svd(M.T, k, seed=abs(hash(name)) % 2**31)
    return {"vocab": vocab, "vidx": vidx, "doc_vec": U, "term_vec": (Vt.T * S).astype(np.float32),
            "dim": int(k), "n_terms": len(vocab)}


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))["spider"]
    docs, doc_ids, doc_db = [], [], []
    word_items, gram_items = [], []
    meta_cols = {}
    for db, s in sorted(cache.items()):
        for t in s["tables"]:
            d = len(docs)
            fid = f"{db}::{t['name'].lower()}"
            doc_ids.append(fid)
            doc_db.append(db)
            name_t = wtoks(t["name"])
            col_t, val_t = [], []
            for c in t["columns"]:
                col_t += wtoks(c["name"])
                for v in (c.get("values") or [])[:12]:
                    val_t += wtoks(str(v))
            docs.append({"name": name_t, "col": col_t, "val": val_t})
            # name weighted 2x, columns 1x, values 1x
            word_items.append((d, 2.0, name_t))
            word_items.append((d, 1.0, col_t))
            word_items.append((d, 1.0, val_t))
            gset = set()
            for w in name_t + col_t + val_t:
                if len(w) >= 4:
                    gset |= ngrams(w)
            gram_items.append((d, 1.0, sorted(gset)))
            meta_cols[fid] = [c["name"] for c in t["columns"]]

    sp_w = build_space(word_items, "word", min_df=1, k=256)
    sp_g = build_space(gram_items, "ngram", min_df=3, k=256)
    np.savez_compressed(
        OUT_NPZ,
        doc_ids=np.array(doc_ids),
        doc_word=sp_w["doc_vec"], term_word=sp_w["term_vec"],
        word_vocab=np.array(sp_w["vocab"]),
        doc_gram=sp_g["doc_vec"], term_gram=sp_g["term_vec"],
        gram_vocab=np.array(sp_g["vocab"]),
    )
    json.dump({"n_docs": len(doc_ids), "dim_word": sp_w["dim"], "dim_gram": sp_g["dim"],
               "vocab_word": sp_w["n_terms"], "vocab_gram": sp_g["n_terms"],
               "cols": meta_cols},
              open(OUT_META, "w", encoding="utf-8"))
    print(f"docs={len(doc_ids)} wordV={sp_w['n_terms']} gramV={sp_g['n_terms']} "
          f"k={sp_w['dim']}/{sp_g['dim']}")
    print("wrote", OUT_NPZ)


if __name__ == "__main__":
    main()
