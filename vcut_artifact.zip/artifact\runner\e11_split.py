"""E11-SPLIT: the repair experiment that follows from the evidence audit.

e11_evidence.py says 90/341 questions (26%) have their only lexical evidence
inside a compound identifier: the column is contestant_name / AirportName /
airportcode, the user says "contestant", "name", "airport".  Under the original
tokeniser [a-z0-9_]+ the whole identifier is one vocabulary item, so BM25 and
the graph score the gold table exactly 0 -- not "worse", zero.  Dense gets 87 of
those 90 because its subword tokenizer already knows the parts.

This script switches the identifier tokeniser on and re-runs the same four
operators on the same 876-table catalogue with the same split, plus the two
per-token fusions that e11_and.py found (normalised sum, geometric mean).
BM25 gets the same tokeniser: the comparison is operator-vs-operator under one
vocabulary, not "we fixed only our own method".
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_run_spider import band_fn, coquery_map, fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
DIAG = REPO / "06_结果" / "e11_diag.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
OUT = REPO / "06_结果" / "e11_split.json"
EPS = 1e-6
METHODS = ("bm25", "ppr_band", "typed_band", "sum_norm", "geom")


def per_token_cache(cat, queries, alpha=0.85, iters=20):
    out = {}
    t0 = time.time()
    for k, w in enumerate(sorted({w for q in queries for w in q})):
        if ("token", w) not in cat.idx:
            continue
        x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, alpha, iters)
        s = cat.table_scores(x)
        mx = float(s.max())
        out[w] = s / mx if mx > 0 else s
        if (k + 1) % 200 == 0:
            print(f"  per-token PPR {k+1} {time.time()-t0:.0f}s", flush=True)
    return out


def fuse_tokens(tok: dict, q: list[str], mode: str, n: int) -> np.ndarray:
    ws = [w for w in set(q) if w in tok]
    if not ws:
        return np.zeros(n, dtype=np.float32)
    M = np.stack([tok[w] for w in ws])
    return M.sum(axis=0) if mode == "sum_norm" else np.exp(np.log(M + EPS).mean(axis=0))


def evaluate(cat, cases, gold_fn, tok, bf):
    rows = []
    for c in cases:
        q = toks(c["question"])
        gold = set(gold_fn(c))
        bw = bf(q)
        s = {"bm25": g.bm25(cat, q), "ppr_band": g.single_ppr(cat, q, band_weight=bw),
             "typed_band": g.fuse(cat, q, band_weight=bw),
             "sum_norm": fuse_tokens(tok, q, "sum_norm", len(cat.tables)),
             "geom": fuse_tokens(tok, q, "geom", len(cat.tables))}
        rec = {"qid": c["qid"], "gold": sorted(gold)}
        # evidence class under the current tokeniser
        gt = set()
        for t in gold:
            if t in cat.table_pos:
                gt |= set(g.table_doc(cat.tables[cat.table_pos[t]]))
        bt = sorted(set(q) & gt)
        rec["bridge"] = bt
        rec["bridge_min_df"] = min([cat.token_df.get(w, 0) for w in bt], default=0)
        for name, sc in s.items():
            r = g.rank(sc, cat)
            m = g.metrics(r, gold)
            rec[f"{name}_r1"] = round(m["recall@1"], 4)
            rec[f"{name}_r5"] = round(m["recall@5"], 4)
            rec[f"{name}_mrr"] = round(m["mrr"], 4)
            rec[f"{name}_hit1"] = float(r[0] in gold)
        rows.append(rec)
    return rows


def summarise(rows, names):
    s = [r for r in rows if all(f"{m}_r5" in r for m in names)]
    out = {"n": len(s)}
    for m in names:
        out[m] = {"r1": round(float(np.mean([r[f"{m}_r1"] for r in s])), 4),
                  "r5": round(float(np.mean([r[f"{m}_r5"] for r in s])), 4),
                  "mrr": round(float(np.mean([r[f"{m}_mrr"] for r in s])), 4)}
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["merged", "known"], default="merged")
    args = ap.parse_args()
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    dg = {r["qid"]: r for r in json.load(open(DIAG, encoding="utf-8"))["rows"]}
    z = np.load(EMB, allow_pickle=True)
    dense_ids = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}

    res = {}
    for flag in (False, True):
        g.SPLIT_IDENT = flag
        print(f"== SPLIT_IDENT={flag}", flush=True)
        if args.mode == "merged":
            tabs, fks = [], []
            for db in cache["spider"]:
                tabs += tables_of(cache, db, prefix=True)
                fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
            coq = coquery_map([c for c in data["spider"] if c["split"] == "train"], prefix=True)
            cat = g.Catalog(tabs, fks, coquery=coq, prefix_db=True)
            bf, _ = band_fn(test)
            gold_fn = lambda c: [f"{c['db_id']}::{t}" for t in c["gold"]]  # noqa: E731
            cases = test
        else:
            by = {}
            for c in test:
                by.setdefault(c["db_id"], []).append(c)
            cat = None
            rows = []
            for db, cs in by.items():
                if db not in cache["spider"]:
                    continue
                tabs = tables_of(cache, db, prefix=False)
                cat = g.Catalog(tabs, fks_of(cache, db, tabs, prefix=False), prefix_db=False)
                bf, _ = band_fn(cs)
                q0 = [toks(c["question"]) for c in cs]
                tk = per_token_cache(cat, q0)
                rows += evaluate(cat, cs, lambda c: c["gold"], tk, bf)
            res["known" if not flag else "known_split"] = summarise(rows, METHODS)
            res["_known_rows_" + str(flag)] = rows
            continue
        q0 = [toks(c["question"]) for c in cases]
        t0 = time.time()
        tk = per_token_cache(cat, q0)
        print(f"  catalog nodes={len(cat.idx)} vocab-in-query={len(tk)} {time.time()-t0:.0f}s", flush=True)
        rows = evaluate(cat, cases, gold_fn, tk, bf)
        # dense reference on the identical tokeniser-independent documents
        for r, c in zip(rows, cases):
            if args.mode == "merged":
                gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
                s = Dm @ Qm[qpos[c["qid"]]]
                rk = [dense_ids[i] for i in np.argsort(-s)]
                m = g.metrics(rk, gold)
                r["dense_r1"] = round(m["recall@1"], 4)
                r["dense_r5"] = round(m["recall@5"], 4)
                r["dense_mrr"] = round(m["mrr"], 4)
        key = "keep_underscore" if not flag else "split_ident"
        res[key] = summarise(rows, list(METHODS) + ["dense"])
        res[key + "_rows"] = rows
        res[key + "_evidence"] = Counter(("exact" if r["bridge"] else "none") for r in rows)
        res[key + "_bridge_df"] = Counter(
            ("0" if r["bridge_min_df"] == 0 else ("1" if r["bridge_min_df"] == 1 else
             ("2-5" if r["bridge_min_df"] <= 5 else ("6-20" if r["bridge_min_df"] <= 20 else ">20"))))
            for r in rows)
        print(json.dumps(res[key], indent=2), flush=True)

    out = {"mode": args.mode, "n": len(test)}
    for k, v in res.items():
        out[k] = {kk: (str(vv) if isinstance(vv, Counter) else vv) for kk, vv in v.items()} \
            if isinstance(v, dict) and not k.endswith("_rows") else v
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, default=str)
    print(json.dumps({k: v for k, v in out.items() if not k.endswith("_rows")}, indent=2, default=str))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
