"""E7q: format-only baselines for the receipt checker.

A reviewer's first alternative is "just validate the JSON schema".  This script
measures what schema validation alone buys: parsing, required fields, and
grounding each number in the OCR text, with no arithmetic or witness.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e7_receipts import grounded, ocr_digits  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
SRC = REPO / "06_结果" / "e7_receipts.json"
OUT = REPO / "06_结果" / "e7q_format_baseline.json"


def metrics(rows, pred, name):
    acc = [r for r in rows if pred(r)]
    known = [r for r in acc if r["model_total_correct"] is not None]
    fp = sum(1 for r in known if r["model_total_correct"] is False)
    return {"name": name, "accept": len(acc), "automation": round(len(acc) / len(rows), 4),
            "false_pass": fp, "false_pass_rate": round(fp / len(rows), 4),
            "precision": round((len(known) - fp) / len(known), 4) if known else None}


def main():
    rows = json.load(open(SRC, encoding="utf-8"))["rows"]
    for r in rows:
        m = r["model"] or {}
        d = ocr_digits(r["text"])
        r["_fields"] = all(m.get(k) is not None for k in ("total", "subtotal", "tax"))
        r["_items"] = bool(m.get("items"))
        r["_grounded"] = all(grounded(m.get(k), d) for k in ("total", "subtotal", "tax"))
        r["_parse"] = bool(m.get("total") is not None)

    policies = [
        metrics(rows, lambda r: r["_parse"], "JSON parses + numeric total"),
        metrics(rows, lambda r: r["_parse"] and r["_grounded"], "total/number grounded in OCR"),
        metrics(rows, lambda r: r["_fields"], "schema: total+subtotal+tax"),
        metrics(rows, lambda r: r["_fields"] and r["_items"], "schema + non-empty items"),
        metrics(rows, lambda r: r["_fields"] and r["_items"] and r["_grounded"],
                "schema + items + all grounded"),
    ]
    summary = {"n": len(rows), "policies": policies}
    json.dump(summary, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
