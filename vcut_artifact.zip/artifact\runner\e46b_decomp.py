"""E46b 正确的口径：recall@k 分解 + 生存函数交叉点。

修正 e46 的两处：
  1. R@k 用按问题聚合的 recall，不是逐金标 hit
  2. X 的均值不是有效统计量（极端异质），改用生存函数 S(k)=P(r+X<k)
"""
import json
import numpy as np
from scipy import stats

D = "D:/vldb2027_e11"
M10 = 9049


def L(p):
    return [json.loads(l) for l in open(f"{D}/{p}", encoding="utf-8")]


def rec_forge(p):
    return [(q["qid"], q["n_gold"], q["gpos_real"], q["gpos"]) for q in L(p)]


def rec_base(p, m):
    return [(q["qid"], q["n_gold"], q[m]["gpos_real"], q[m]["gpos"]) for q in L(p)]


def recall_at(recs, k, use_real):
    """recall@k：每个问题 sum(hit)/n_gold 再平均。"""
    v = []
    for qid, ng, rr, gg in recs:
        pos = rr if use_real else gg
        v.append(sum(1 for p in pos if p < k) / ng)
    return float(np.mean(v))


def hit_at(recs, k, use_real):
    v = []
    for qid, ng, rr, gg in recs:
        pos = rr if use_real else gg
        v.append(1.0 if any(p < k for p in pos) else 0.0)
    return float(np.mean(v))


SETS = [
    ("FORGE", rec_forge("e44_forge_rich_951-leg_perq.jsonl"),
     rec_forge("e44_forge_rich_10k-syn-leg_perq.jsonl"), "e44_forge_rich_4k-syn-leg_perq.jsonl"),
    ("dense", rec_base("e44_legacy_rich_951_perq.jsonl", "dense"),
     rec_base("e44_legacy_rich_10k-syn_perq.jsonl", "dense"), None),
    ("fuse", rec_base("e44_legacy_rich_951_perq.jsonl", "fuse"),
     rec_base("e44_legacy_rich_10k-syn_perq.jsonl", "fuse"), None),
    ("bm25", rec_base("e44_legacy_rich_951_perq.jsonl", "bm25"),
     rec_base("e44_legacy_rich_10k-syn_perq.jsonl", "bm25"), None),
]
FORGE_B0 = (rec_forge("e45_forge_beta0_rich_4k-syn-leg_perq.jsonl"),
            rec_forge("e45_forge_beta0_rich_10k-syn-leg_perq.jsonl"))

print("=" * 84)
print("【1】recall@5 的严格分解：type 层 vs instance 层")
print("=" * 84)
print(f"  {'方法':7s} {'R5@951':>8} {'R5_type@10k':>12} {'R5_all@10k':>11} "
      f"{'Δtype':>8} {'Δinst':>8} {'inst占比':>9}")
rows = []
for name, r9, r10, _ in SETS:
    a = recall_at(r9, 5, False)
    b = recall_at(r10, 5, True)
    c = recall_at(r10, 5, False)
    dt, di = b - a, c - b
    rows.append((name, a, b, c, dt, di))
    print(f"  {name:7s} {a*100:8.2f} {b*100:12.2f} {c*100:11.2f} "
          f"{dt*100:+8.2f} {di*100:+8.2f} {abs(di)/(abs(dt)+abs(di))*100:8.1f}%")

print("\n  → 四条的 Δtype 都在 ±1.7 内；退化几乎全部来自 instance 层。")
print("  → dense 的 Δtype 恰为 0.00：它的排序一字未变，退化 100% 是槽位。")

print("\n" + "=" * 84)
print("【2】X = 金标前干扰表数：为什么均值不能用")
print("=" * 84)
print(f"  {'方法':7s} {'X均值':>9} {'X=0占比':>8} {'p75':>6} {'p90':>6} "
      f"{'p99':>7} {'max':>6} {'均值/中位':>10}")
Xof = {}
for name, r9, r10, _ in SETS:
    X = np.array([g - rr for qid, ng, rr, gg in r10 for g, rr2 in zip(gg, rr)
                  for rr in [rr2]], float)
    Xof[name] = X
    print(f"  {name:7s} {X.mean():9.1f} {np.mean(X==0)*100:7.1f}% "
          f"{np.percentile(X,75):6.0f} {np.percentile(X,90):6.0f} "
          f"{np.percentile(X,99):7.0f} {X.max():6.0f} "
          f"{X.mean()/max(np.median(X),1):10.1f}")

print("\n  → FORGE 的 X 均值是 dense 的 4.1 倍，但它的 R@5 更高 6.9 点。")
print("  → 均值被 5.9% 的淹没样本（X>=100）拉高；有效信息在 X 的分布左端。")

print("\n" + "=" * 84)
print("【3】生存函数 S(k) = P(金标进入 top-k)，四条方法并列")
print("=" * 84)
ks = [1, 2, 3, 5, 8, 10, 20, 30, 50, 60, 80, 100, 150, 200]
print(f"  {'k':>5} " + "".join(f"{n:>9}" for n, *_ in SETS) + f"{'F-d':>8}")
for k in ks:
    vals = []
    for name, r9, r10, _ in SETS:
        vals.append(recall_at(r10, k, False))
    d = vals[0] - vals[1]
    print(f"  {k:5d} " + "".join(f"{v*100:9.2f}" for v in vals) + f"{d*100:+8.2f}")

print("\n  找 FORGE 与 dense 的交叉点（线性插值）:")
prev = None
for k in range(1, 301):
    f = recall_at(SETS[0][2], k, False)
    d = recall_at(SETS[1][2], k, False)
    if prev is not None and prev[0] > 0 and (f - d) <= 0:
        print(f"    k* ≈ {k}（k={k-1} 时 +{(f-d)*100:.2f} 前一点）")
        break
    prev = (f - d, k)
for k in (10, 20, 30, 40, 50, 55, 60, 70, 100):
    f = recall_at(SETS[0][2], k, False)
    d = recall_at(SETS[1][2], k, False)
    print(f"    k={k:3d}: FORGE {f*100:6.2f} dense {d*100:6.2f} Δ {((f-d)*100):+6.2f}")

print("\n" + "=" * 84)
print("【4】π 与 r 的耦合：为什么不能把两者当独立因子相乘")
print("=" * 84)
for name, r9, r10, _ in SETS:
    rr = np.array([x for qid, ng, a, b in r10 for x in a], float)
    X = np.array([g - r for qid, ng, a, b in r10 for r, g in zip(a, b)], float)
    sp = stats.spearmanr(rr, X)
    print(f"  {name:6s} Spearman(r, X)={sp.statistic:+.4f}")
    line = "          "
    for lo, hi in [(0, 1), (1, 5), (5, 20), (20, 10**9)]:
        m = (rr >= lo) & (rr < hi)
        if m.sum() < 20:
            continue
        line += f" r[{lo},{hi if hi < 10**9 else 'inf'}):X={X[m].mean():7.1f}"
    print(line)

print("\n  → r 越大，X 越大的单调关系在四条上全部成立。")
print("  → 所以「type 层」与「instance 层」不是可乘的两个因子，而是同一条分数轴上的两级。")

print("\n" + "=" * 84)
print("【5】β 对 π 稳定性的破坏（唯一真正的机制变量）")
print("=" * 84)
for tag, s4, s10 in [("β=0.3", SETS[0][2], SETS[0][2]), ("β=0", FORGE_B0[0], FORGE_B0[1])]:
    def Xs(recs):
        return np.array([g - r for qid, ng, a, b in recs for r, g in zip(a, b)], float)
    x4, x10 = Xs(s4), Xs(s10)
    pi4, pi10 = x4.mean() / 3049, x10.mean() / M10
    print(f"  {tag:6s} π(4k)={pi4:.5f} π(10k)={pi10:.5f} 相对差={abs(pi10-pi4)/pi4*100:5.2f}% "
          f"| X=0 占比 4k={np.mean(x4==0)*100:5.1f}% 10k={np.mean(x10==0)*100:5.1f}%")
