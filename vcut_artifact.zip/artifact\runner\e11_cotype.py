"""E11-COTYPE: turn the co-typing law into a rule, and price it.

2.14 killed the free-standing certificate: "the query words are written in the answer"
certifies a decision made from those words, and says nothing about a decision made from
character fragments or a searched graph score.  The law (third appearance: key collapse
sec 5, execution evidence 2.11) is that a witness must be of the same type as the
proposition it attests.

So the method has to say WHICH evidence a ranker reads and certify against that one.
This script builds the same chance correction on four catalogue-side evidence types and
prices all four on every arm that has per-question answers:

  word  -- query words occurring anywhere in the table document (names + sample values)
  name  -- only in identifiers: table name + column names        (what a lexical ranker reads)
  value -- only inside sample values                              (what an entity matcher reads)
  col   -- the best single column of that table                   (what our column arm reads)

Each type has its own null: its own document frequencies, its own multiplicity (876 tables,
or 4 503 columns for col).  alpha = 0.05 everywhere, unchanged.

Pre-registered, decided BEFORE looking at any false-pass count, by how each arm is built --
not by which number looks best:
  * E11 column arm and BM25/dense-free lexical arms  -> name
  * our table arm (diffusion over names+values)      -> word
  * char n-gram / PPMI-word arms                     -> word   (they still read identifier text)
  * GP / GP+exact / tree arms                        -> value  (their primitives test value hits)
  * fine-tuned 0.6B and dense                        -> none   (no catalogue-side evidence is
    co-typed with a trained embedding; the law predicts every certificate is invalid for them)
Claim under test: the a-priori assignment gives 0 false passes on every arm it covers, while
a single certificate applied to all arms does not.
"""
from __future__ import annotations

import json
import math
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_surprise import chance_tail  # noqa: E402
from e11_col import col_index  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
CASES = R / "e11_cases.json"
SURP2 = R / "e11_surprise2.json"
OUT = R / "e11_cotype.json"
ALPHA = 0.05
TYPES = ("word", "name", "value", "col")

# a-priori assignment: what the arm reads, fixed by its construction (docstring)
ASSIGN = {"E11_column": "col", "E11_table": "word",
          "E12_bm25": "name", "E12_word": "name", "E12_gram": "word",
          "E12_fused": "word", "E12_gp": "value", "E12_gp_ex": "value",
          "E12_tree": "value", "E12_ft0.6B": None, "dense_0.6B": None}


def docs_by_type(cat):
    """Four corpora: table-level word/name/value docs and the column-level docs."""
    tab_all, tab_name, tab_val, col_name, col_val = [], [], [], [], []
    for t in cat.tables:
        a, n, v = [], [], []
        nt = toks(t["name"])
        a += nt
        n += nt
        for c in t["columns"]:
            cn = toks(c["name"])
            a += cn
            n += cn
            col_name.append(cn)
            cv = []
            for val in c.get("values", [])[:6]:
                tv = toks(val)[:3]
                a += tv
                v += tv
                cv += tv
            col_val.append(cv)
        tab_all.append(a)
        tab_name.append(n)
        tab_val.append(v)
    col_docs = [cn + cv for cn, cv in zip(col_name, col_val)]
    return {"word": tab_all, "name": tab_name, "value": tab_val, "col": col_docs}


def incidence(docs):
    inc = {}
    for j, d in enumerate(docs):
        for w in set(d):
            v = inc.get(w)
            if v is None:
                v = inc[w] = np.zeros(len(docs), dtype=bool)
            v[j] = True
    return inc


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    tabs = []
    for db, s in cache["spider"].items():
        tabs += [dict(t, db=db) for t in s["tables"]]
    cat = g.Catalog(tabs, [], prefix_db=True)
    lowmap = {tid.lower(): i for i, tid in enumerate(cat.table_ids)}

    def pos_of(tid):
        return cat.table_pos.get(tid, lowmap.get(str(tid).lower()))
    N = len(cat.tables)
    corpora = docs_by_type(cat)
    incs = {k: incidence(d) for k, d in corpora.items()}
    dfs = {k: Counter() for k in corpora}
    for k, d in corpora.items():
        for j, doc in enumerate(d):
            dfs[k].update({w: 1 for w in set(doc)})
    # column -> owning table, for the col statistic
    colnodes, cdocs, starts, ends = col_index(cat)
    col_of_table = [(int(s), int(e)) for s, e in zip(starts, ends)]
    print(f"corpora sizes: " + ", ".join(f"{k}={len(v)}" for k, v in corpora.items()),
          flush=True)

    surp = json.load(open(SURP2, encoding="utf-8"))
    arm_top1 = {}
    arm_r5 = {}
    for r in surp["rows"]:
        arm_top1.setdefault(r["arm"], {})[r["qid"]] = r["top1"]
        arm_r5.setdefault(r["arm"], {})[r["qid"]] = r["r5"]

    t0 = time.time()
    per_q = {}
    for c in test:
        q = set(toks(c["question"]))
        # identifiers carry arbitrary case in the source schema (VOTES vs votes); every
        # comparison below is case-folded, both sides.
        gold = {f"{c['db_id']}::{t}".lower() for t in c["gold"]}
        stat_vec, curves = {}, {}
        for k in ("word", "name", "value"):
            inc = incs[k]
            s = np.zeros(N, dtype=np.float32)
            qd = []
            for w in q:
                v = inc.get(w)
                if v is None:
                    continue
                s += v
                qd.append(dfs[k].get(w, 0))
            stat_vec[k] = s
            M = N if k != "col" else len(corpora["col"])
            curves[k] = [chance_tail(qd, M, x)[1] for x in range(0, len(q) + 2)]
        # col statistic: best single column inside each table, null over all columns
        inc = incs["col"]
        qcols = [(w, inc[w], dfs["col"].get(w, 0)) for w in q if w in inc]
        s = np.zeros(N, dtype=np.float32)
        if qcols:
            per_col = np.zeros(len(corpora["col"]), dtype=np.int32)
            for _, v, _ in qcols:
                per_col += v.astype(np.int32)
            for i, (a, b) in enumerate(col_of_table):
                s[i] = per_col[a:b].max() if b > a else 0
        stat_vec["col"] = s
        qd = [d for _, _, d in qcols]
        curves["col"] = [chance_tail(qd, len(corpora["col"]), x)[1] for x in range(0, len(q) + 2)]
        per_q[c["qid"]] = {"gold": gold, "vec": stat_vec, "curve": curves}
    print(f"statistics + nulls for {len(per_q)} questions in {time.time()-t0:.0f}s", flush=True)

    res = {"alpha": ALPHA, "assignment": ASSIGN, "arms": {}, "matrix": {}, "layers": {}}
    LAYERS = ("word", "col", "word&col", "word&col&name", "word&name")
    for arm, tops in arm_top1.items():
        n_acc = Counter()
        fp = Counter()
        cov_r5 = Counter()
        lay_acc, lay_fp, lay_drop_ok = Counter(), Counter(), Counter()
        lay_r5 = Counter()
        for qid, t1 in tops.items():
            st = per_q.get(qid)
            pos = pos_of(t1) if st is not None else None
            if pos is None:
                continue
            correct = str(t1).lower() in st["gold"]
            for k in TYPES:
                s = int(st["vec"][k][pos])
                p = st["curve"][k][min(s, len(st["curve"][k]) - 1)]
                if p <= ALPHA:
                    n_acc[k] += 1
                    cov_r5[k] += arm_r5[arm].get(qid, 0.0)
                    if not correct:
                        fp[k] += 1
        for qid, t1 in tops.items():
            st = per_q.get(qid)
            if st is None:
                continue
            pos = pos_of(t1)
            if pos is None:
                continue
            ok = t1.lower() in st["gold"]
            pv = {}
            for k in TYPES:
                s_ = int(st["vec"][k][pos])
                pv[k] = st["curve"][k][min(s_, len(st["curve"][k]) - 1)] <= ALPHA
            for tag in LAYERS:
                keep = all(pv[t] for t in tag.split("&"))
                if keep:
                    lay_acc[tag] += 1
                    lay_r5[tag] += arm_r5[arm].get(qid, 0.0)
                    if not ok:
                        lay_fp[tag] += 1
                elif not ok:
                    pass
                else:
                    lay_drop_ok[tag] += 1
        n_tot = len([q for q in tops if q in per_q])
        res["layers"][arm] = {tag: {"n": n_tot, "accepted": lay_acc[tag],
                                    "false_pass": lay_fp[tag],
                                    "precision": round(1 - lay_fp[tag] / lay_acc[tag], 4) if lay_acc[tag] else None,
                                    "cov": round(lay_acc[tag] / max(1, n_tot), 4),
                                    "acc_r5": round(lay_r5[tag] / lay_acc[tag], 4) if lay_acc[tag] else None,
                                    "dropped_correct": lay_drop_ok[tag]} for tag in LAYERS}
        res["matrix"][arm] = {
            k: {"n": n_tot, "cov": round(n_acc[k] / max(1, n_tot), 4), "accepted": n_acc[k],
                "false_pass": fp[k],
                "precision": round(1 - fp[k] / n_acc[k], 4) if n_acc[k] else None,
                "acc_r5": round(cov_r5[k] / n_acc[k], 4) if n_acc[k] else None}
            for k in TYPES}
        pick = ASSIGN.get(arm)
        res["arms"][arm] = {"assigned_certificate": pick,
                            "assigned": res["matrix"][arm].get(pick) if pick else "none: law says no catalogue-side certificate applies",
                            "word": res["matrix"][arm]["word"]}

    diagonal_fp = sum(res["matrix"][a][ASSIGN[a]]["false_pass"] for a in ASSIGN if ASSIGN[a])
    diagonal_cov = sum(res["matrix"][a][ASSIGN[a]]["accepted"] for a in ASSIGN if ASSIGN[a])
    word_only_fp = sum(res["matrix"][a]["word"]["false_pass"] for a in ASSIGN)
    word_only_acc = sum(res["matrix"][a]["word"]["accepted"] for a in ASSIGN)
    covered = [a for a in ASSIGN if ASSIGN[a]]
    clean = [a for a in covered if res["matrix"][a][ASSIGN[a]]["false_pass"] == 0]
    res["summary"] = {
        "arms": len(ASSIGN), "arms_with_certificate": len(covered),
        "apriori_assignment_false_passes_pooled": diagonal_fp,
        "apriori_assignment_accepted_pooled": diagonal_cov,
        "arms_with_zero_false_pass": clean,
        "single_word_certificate_false_passes_pooled": word_only_fp,
        "single_word_certificate_accepted_pooled": word_only_acc}
    pooled = {}
    for tag in LAYERS:
        a = sum(res["layers"][arm][tag]["accepted"] for arm in res["layers"])
        f = sum(res["layers"][arm][tag]["false_pass"] for arm in res["layers"])
        pooled[tag] = {"accepted": a, "false_pass": f,
                       "precision": round(1 - f / a, 4) if a else None,
                       "arms_with_zero_fp": sum(1 for arm in res["layers"]
                                                if res["layers"][arm][tag]["false_pass"] == 0)}
    res["pooled_layers"] = pooled
    json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps(pooled, indent=1, ensure_ascii=False))
    for tag in LAYERS:
        print("%-14s " % tag, " ".join("%s:%d/%dfp" % (a.split('_')[-1], res["layers"][a][tag]["accepted"],
              res["layers"][a][tag]["false_pass"]) for a in res["layers"]))
    print(json.dumps(res["matrix"], indent=1, ensure_ascii=False))
    print(json.dumps(res["summary"], indent=1, ensure_ascii=False))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
