# -*- coding: utf-8 -*-
"""E2 —— 级联降级与重写收益（管线骨架）

状态：**管线可用，真实数据/API 未接。** 默认 `--mock` 只做冒烟；
mock 数字不能写进论文，报告里会显式标注。

配置：
    C0  全量贵模型 + 判决表在模型后（现状）
    C1  便宜模型 k=3 采样 → 一致性阈值 → 贵模型
    C2  C1 + R1：pre 表先判，命中终局则不调模型
    C3  C2 + R3（未实现，占位）

指标：
    cost_units / calls / 每文档成本
    字段抽取准确率（宏平均；F1 等真实数据接入后再加）
    判决准确率、假放行率（pred pass & true reject）、误拒率
    A1：高置信区间上 cheap vs exp 的字段准确率差 + bootstrap CI

数据 schema（documents.jsonl）：
    {"id": "...", "pre": {...}, "post_true": {...}, "text": "...", "true_verdict": "pass|reject|review"}
    pre/post_true 的字段必须覆盖决策表；true_verdict 缺省时由表在真值上算出。

用法：
    python runner/e2.py --mock --n 100
    python runner/e2.py --docs 04_数据/permits/documents.jsonl --pilot
    python runner/e2.py --mock --mock-a1 fails
"""

from __future__ import annotations

import argparse
import json
import os
import random
import sys
import threading
import time
import urllib.error
import urllib.request
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

HERE = Path(__file__).resolve().parent.parent
REPO = HERE
sys.path.insert(0, str(HERE))

from checker.decision_table import (  # noqa: E402
    Decision,
    DecisionTable,
    load_table,
)

TABLE_PATH = REPO / "04_数据" / "gb30871" / "decision_table_v0.2.yaml"
OUT_JSON = REPO / "06_结果" / "e2_mock.json"
OUT_MD = REPO / "06_结果" / "E2_报告.md"
OUT_API_JSON = REPO / "06_结果" / "e2_api.json"
OUT_API_MD = REPO / "06_结果" / "E2_API_报告.md"

CHEAP_COST = 1
EXP_COST = 10
THETA = 0.9
K = 3          # 仅 vote 模式：同一文档采样三次做一致性
CASCADE = "conf"  # "conf" = 一次调用看模型自报置信度；"vote" = 三次采样一致性


# ── 数据 ──────────────────────────────────────────────────────

_WORK = {"hot": "动火", "confined": "受限空间", "blind": "盲板抽堵",
         "lifting": "吊装", "electric": "临时用电", "excavation": "动土",
         "road": "断路", "height": "高处"}
_FIRE = {"special": "特级", "first": "一级", "second": "二级", "none": "无"}
_APPROVAL = {"team": "班组", "department": "部门", "company": "公司"}


def render_text(doc: dict) -> str:
    """把结构化真值渲染成一段中文作业票文本（仅用于 API 联调，不是真实语料）。"""
    pre, post = doc["pre"], doc["post_true"]
    return "\n".join([
        f"作业票编号：{doc.get('id', '')}",
        f"作业类型：{_WORK.get(pre['work_type'], pre['work_type'])}",
        f"动火等级：{_FIRE.get(pre['fire_level'], pre['fire_level'])}",
        f"有效期：{pre['valid_hours']} 小时",
        f"审批级别：{_APPROVAL.get(pre['approval_level'], pre['approval_level'])}",
        f"安全措施：{'已落实' if post['measures_done'] else '未落实'}",
        f"可燃气体检测：{post['lel']}% LEL",
        f"氧含量：{post['o2']}%",
        f"设备隔离：{'已隔离' if post['isolated'] else '未隔离'}",
        f"现场清理：{'已清理' if post['cleanup'] else '未清理'}",
    ])


def gen_docs(n: int, rng: random.Random, table: DecisionTable) -> List[dict]:
    """合成的作业票分布（只用于冒烟；不是 CUAD/真实分布）。"""
    docs = []
    for i in range(n):
        work_type = rng.choice(["hot", "confined", "blind", "lifting",
                                "electric", "excavation", "road", "height"])
        hot = work_type == "hot"
        pre = {
            "work_type": work_type,
            "fire_level": rng.choice(["special", "first", "second"]) if hot else "none",
            "valid_hours": rng.choice([4, 6, 8, 12, 24, 48, 72, 96]),
            "approval_level": rng.choice(["team", "department", "company"]),
            "multi_permit": rng.random() < 0.2,
            "multi_permits_ok": rng.random() < 0.9,
            "approver_authorized": rng.random() < 0.9,
            "guardian_certified": rng.random() < 0.9,
            "gas_before_approval": rng.random() < 0.9,
        }
        post = {
            "measures_done": rng.random() < 0.82,
            "lel": rng.choice([5, 10, 15, 20, 25, 30, 40]),
            "o2": rng.choice([17, 19.0, 19.5, 21, 23.0, 23.5, 24]),
            "isolated": rng.random() < 0.85,
            "cleanup": rng.random() < 0.85,
        }
        d = table.evaluate({**pre, **post})
        docs.append({
            "id": f"p{i:04d}",
            "pre": pre,
            "post_true": post,
            "true_verdict": d.verdict,
            "text": render_text({"id": f"p{i:04d}", "pre": pre,
                                 "post_true": post}),
        })
    return docs


def load_docs(path: str | Path, table: DecisionTable) -> List[dict]:
    docs = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        d = json.loads(line)
        d.setdefault("true_verdict",
                     table.evaluate({**d["pre"], **d["post_true"]}).verdict)
        docs.append(d)
    return docs


# ── 抽取器 ────────────────────────────────────────────────────


@dataclass
class Extraction:
    values: Dict[str, Any]
    conf: Dict[str, float]
    prompt_tokens: int = 0
    completion_tokens: int = 0

    @property
    def min_conf(self) -> float:
        return min(self.conf.values()) if self.conf else 1.0

    @property
    def cost_units(self) -> int:
        """API 模式下是 token 数；mock 模式下由 MockExtractor 写入固定成本。"""
        return self.prompt_tokens + self.completion_tokens


def _wrong(field: str, true: Any) -> Any:
    if isinstance(true, bool):
        return not true
    if field == "lel":
        return 30 if true <= 25 else 5
    if field == "o2":
        return 17 if 19.5 <= true <= 23.5 else 21
    return true


class MockExtractor:
    def __init__(self, name: str, accuracy: float, wrong_conf: float,
                 rng: random.Random, cost: int, doc_error_rate: float = 0.0):
        self.name = name
        self.accuracy = accuracy
        self.wrong_conf = wrong_conf
        self.rng = rng
        self.cost = cost
        # “自信地错”：按文档整份错，三次采样一致且高置信（A1 失败的那种模型）
        self.doc_error_rate = doc_error_rate
        self._doc_bad: Dict[str, bool] = {}

    def _is_bad_doc(self, doc: dict) -> bool:
        """同一文档的三次采样共享同一个错误状态，避免抽样把整份错打散。"""
        did = str(doc.get("id", id(doc)))
        if did not in self._doc_bad:
            self._doc_bad[did] = self.rng.random() < self.doc_error_rate
        return self._doc_bad[did]

    def extract(self, doc: dict, fields: Sequence[str]) -> Extraction:
        vals, confs = {}, {}
        doc_bad = self._is_bad_doc(doc)
        for f in fields:
            true = doc["post_true"][f]
            if doc_bad:
                vals[f], confs[f] = _wrong(f, true), max(self.wrong_conf, 0.95)
            elif self.rng.random() < self.accuracy:
                vals[f], confs[f] = true, 0.95
            else:
                vals[f], confs[f] = _wrong(f, true), self.wrong_conf
        return Extraction(vals, confs, 0, self.cost)


# ── 真实 API 抽取器（OpenAI-compatible / DeepSeek） ───────────

FIELD_SPECS = {
    "measures_done": "boolean; true if the safety measures are stated as implemented",
    "lel": "number; combustible gas reading in %LEL (e.g. 10 for 10% LEL)",
    "o2": "number; oxygen percentage (e.g. 21 for 21%)",
    "isolated": "boolean; true if energy/equipment isolation is stated as done",
    "cleanup": "boolean; true if site cleanup is stated as done",
}

_SYSTEM = (
    "You extract structured fields from a Chinese permit document. "
    "Return exactly one JSON object and nothing else. The object maps every "
    "requested field to {\"value\": ..., \"confidence\": 0..1}. Use null and "
    "confidence 0 when the document does not state the field. Do not guess. "
    "Booleans must be JSON true/false; numbers must be JSON numbers."
)


def _coerce(field: str, raw: Any) -> Any:
    if raw is None:
        return None
    if field in ("measures_done", "isolated", "cleanup"):
        if isinstance(raw, bool):
            return raw
        s = str(raw).strip().lower()
        if s in ("true", "yes", "1", "是", "已落实", "已隔离", "已清理"):
            return True
        if s in ("false", "no", "0", "否", "未落实", "未隔离", "未清理"):
            return False
        if "未" in s or s.startswith("否") or s.startswith("no"):
            return False
        if "已" in s or s.startswith("是") or s.startswith("yes"):
            return True
        return None
    # number fields
    if isinstance(raw, (int, float)):
        return raw
    import re
    m = re.search(r"-?\d+(?:\.\d+)?", str(raw))
    return float(m.group(0)) if m else None


def parse_extraction(content: str, fields: Sequence[str]) -> Extraction:
    text = (content or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        if "\n" in text:
            text = text.split("\n", 1)[1]
    lo, hi = text.find("{"), text.rfind("}")
    if lo >= 0 and hi > lo:
        text = text[lo:hi + 1]
    obj = json.loads(text)
    vals, confs = {}, {}
    for f in fields:
        item = obj.get(f)
        if isinstance(item, dict):
            raw, c = item.get("value"), item.get("confidence", 0.5)
        else:
            raw, c = item, 0.5
        v = _coerce(f, raw)
        vals[f] = v
        try:
            c = float(c)
        except (TypeError, ValueError):
            c = 0.5
        confs[f] = 0.0 if v is None else max(0.0, min(1.0, c))
    return Extraction(vals, confs)


class APIExtractor:
    """OpenAI-compatible chat-completions extractor (stdlib only)."""

    def __init__(self, name: str, model: str, api_key: str,
                 base_url: str = "https://api.deepseek.com",
                 timeout: int = 90, max_tokens: int = 768,
                 retries: int = 3):
        if not api_key:
            raise ValueError("missing API key")
        self.name = name
        self.model = model
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_tokens = max_tokens
        self.retries = retries
        self.calls = 0
        self._lock = threading.Lock()

    def _payload(self, doc: dict, fields: Sequence[str]) -> dict:
        spec = "\n".join(f"- {f}: {FIELD_SPECS.get(f, 'value')}" for f in fields)
        user = (
            f"Fields to extract:\n{spec}\n\n"
            f"Document:\n{doc.get('text', '')}\n\n"
            "Return the JSON object now."
        )
        return {
            "model": self.model,
            "messages": [{"role": "system", "content": _SYSTEM},
                         {"role": "user", "content": user}],
            "temperature": 0,
            "max_tokens": self.max_tokens,
        }

    def extract(self, doc: dict, fields: Sequence[str]) -> Extraction:
        url = self.base_url + "/chat/completions"
        body = json.dumps(self._payload(doc, fields), ensure_ascii=False).encode("utf-8")
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        last = None
        for attempt in range(self.retries):
            req = urllib.request.Request(url, data=body, headers=headers, method="POST")
            try:
                with self._lock:
                    self.calls += 1
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                usage = data.get("usage") or {}
                content = (data.get("choices") or [{}])[0].get("message", {}).get("content", "")
                ext = parse_extraction(content, fields)
                ext.prompt_tokens = int(usage.get("prompt_tokens") or 0)
                ext.completion_tokens = int(usage.get("completion_tokens") or 0)
                return ext
            except urllib.error.HTTPError as e:
                detail = e.read().decode("utf-8", "replace")[:300]
                last = RuntimeError(f"HTTP {e.code}: {detail}")
                if e.code not in (408, 409, 429, 500, 502, 503, 504):
                    raise last
            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, ValueError) as e:
                last = e
            time.sleep(1.5 * (attempt + 1))
        raise RuntimeError(f"API extract failed after {self.retries} attempts: {last}")


# ── 级联 ──────────────────────────────────────────────────────


@dataclass
class DocResult:
    doc_id: str
    mode: str
    verdict: str
    true_verdict: str
    calls: int
    cost: int
    extracted: bool
    field_correct: int
    field_total: int
    low_conf_review: bool
    skipped_pre: bool


def _field_correct(ext: Extraction, true_post: dict) -> Tuple[int, int]:
    n = len(true_post)
    c = sum(1 for f, v in true_post.items() if ext.values.get(f) == v)
    return c, n


def run_doc(doc: dict, table: DecisionTable, mode: str,
            cheap_samples: Sequence[Extraction],
            exp_ext: Extraction, cascade: str = CASCADE) -> DocResult:
    true_verdict = doc["true_verdict"]

    # C2/C3：pre 表先判
    if mode in ("C2", "C3"):
        pre = table.pre_decision(doc["pre"])
        if pre is not None:
            return DocResult(doc["id"], mode, pre.verdict, true_verdict,
                             0, 0, False, 0, 0, False, True)

    fields = table.post_fields

    if mode == "C0":
        ext = exp_ext
        calls, cost = 1, exp_ext.cost_units
    elif cascade == "conf":
        # R2 的本来形式：一次调用，模型自报置信度；低于阈值才升级。
        cheap = cheap_samples[0]
        calls, cost = 1, cheap.cost_units
        if cheap.min_conf >= THETA:
            ext = cheap
        else:
            ext = exp_ext
            calls += 1
            cost += exp_ext.cost_units
    else:
        samples = cheap_samples
        calls, cost = K, sum(s.cost_units for s in samples)
        agree = all(
            len({s.values[f] for s in samples}) == 1
            and samples[0].values[f] is not None
            for f in fields
        )
        if agree:
            ext = samples[0]
        else:
            ext = exp_ext
            calls += 1
            cost += exp_ext.cost_units

    fields_all = {**doc["pre"], **ext.values}
    d = table.evaluate(fields_all)
    low_conf = ext.min_conf < THETA
    # C0 是“现状”：不做低置信复核；C1/C2 用 review 把低置信输出截住。
    if low_conf and mode != "C0":
        d = Decision("review", None, "low_conf")
    c, n = _field_correct(ext, doc["post_true"])
    return DocResult(doc["id"], mode, d.verdict, true_verdict,
                     calls, cost, True, c, n, low_conf, False)


def summarize(results: List[DocResult], docs: List[dict]) -> dict:
    n = len(results)
    calls = sum(r.calls for r in results)
    cost = sum(r.cost for r in results)
    correct = sum(r.field_correct for r in results)
    total = sum(r.field_total for r in results)
    v_ok = sum(1 for r in results if r.verdict == r.true_verdict)
    true_reject = [r for r in results if r.true_verdict == "reject"]
    true_pass = [r for r in results if r.true_verdict == "pass"]
    false_pass = sum(1 for r in true_reject if r.verdict == "pass")
    false_reject = sum(1 for r in true_pass if r.verdict == "reject")
    return {
        "docs": n,
        "calls": calls,
        "cost_units": cost,
        "cost_per_doc": round(cost / n, 3) if n else None,
        "extracted_docs": sum(1 for r in results if r.extracted),
        "skipped_pre": sum(1 for r in results if r.skipped_pre),
        "field_acc": round(correct / total, 4) if total else None,
        "verdict_acc": round(v_ok / n, 4) if n else None,
        "false_pass": false_pass,
        "false_pass_rate": round(false_pass / len(true_reject), 4) if true_reject else None,
        "false_reject": false_reject,
        "false_reject_rate": round(false_reject / len(true_pass), 4) if true_pass else None,
        "low_conf_reviews": sum(1 for r in results if r.low_conf_review),
    }


# ── A1 ────────────────────────────────────────────────────────


def _acc(exts: List[Tuple[Extraction, dict]]) -> float:
    if not exts:
        return 0.0
    c = sum(_field_correct(e, t)[0] for e, t in exts)
    n = sum(_field_correct(e, t)[1] for e, t in exts)
    return c / n if n else 0.0


def a1_test(docs: List[dict], table: DecisionTable,
            cheap_samples_by_id: Dict[str, List[Extraction]],
            exp_by_id: Dict[str, Extraction],
            rng: random.Random, boots: int = 500,
            cascade: str = CASCADE) -> dict:
    """高置信区间上，cheap vs exp 的字段准确率差。

    conf 模式：高置信 = 一次 cheap 调用的 min_conf ≥ θ；
    vote 模式：高置信 = 三次采样在所有字段上一致且非空。
    """
    high: List[Tuple[Extraction, Extraction, dict]] = []
    low: List[Tuple[Extraction, Extraction, dict]] = []
    for doc in docs:
        samples = cheap_samples_by_id[doc["id"]]
        if cascade == "conf":
            is_high = samples[0].min_conf >= THETA
        else:
            is_high = all(
                len({s.values[f] for s in samples}) == 1
                and samples[0].values[f] is not None
                for f in table.post_fields
            )
        exp_ext = exp_by_id[doc["id"]]
        (high if is_high else low).append((samples[0], exp_ext, doc))

    def diff(group):
        ce = [(c, d["post_true"]) for c, _, d in group]
        ee = [(e, d["post_true"]) for _, e, d in group]
        return _acc(ce) - _acc(ee)

    out = {}
    for name, group in (("high", high), ("low", low)):
        if not group:
            out[name] = {"n": 0}
            continue
        point = diff(group)
        idx = list(range(len(group)))
        vals = []
        for _ in range(boots):
            sample = [group[rng.choice(idx)] for _ in idx]
            vals.append(diff(sample))
        vals.sort()
        lo = vals[int(0.025 * len(vals))]
        hi = vals[int(0.975 * len(vals)) - 1]
        out[name] = {
            "n": len(group),
            "cheap_acc": round(_acc([(c, d["post_true"]) for c, _, d in group]), 4),
            "exp_acc": round(_acc([(e, d["post_true"]) for _, e, d in group]), 4),
            "diff_cheap_minus_exp": round(point, 4),
            "ci95": [round(lo, 4), round(hi, 4)],
        }
    return out


# ── 主流程 ────────────────────────────────────────────────────


def run(docs: List[dict], table: DecisionTable, mock_a1: str,
        cheap=None, exp=None, include_fails: bool = True,
        workers: int = 1, cascade: str = CASCADE) -> dict:
    """跑 C0/C1/C2 + A1。cheap/exp 未给时用 mock；给了 APIExtractor 就是真调用。

    cascade="conf"：R2 的一次调用 + 自报置信度（默认，API 用这个）；
    cascade="vote"：三次采样一致性（mock 老口径/消融）。
    workers > 1 时按文档并行；同一文档内的多次采样仍顺序。
    """
    if cheap is None:
        cheap = MockExtractor("cheap", 0.92, 0.55, random.Random(20261030),
                              CHEAP_COST, doc_error_rate=0.02)
    if exp is None:
        exp = MockExtractor("exp", 0.97, 0.85, random.Random(20261031),
                            EXP_COST, doc_error_rate=0.02)
    if mock_a1 == "fails" and isinstance(cheap, MockExtractor):
        # A1 失败的那种模型：整份错、高置信
        cheap.accuracy = 0.85
        cheap.doc_error_rate = 0.25
        cheap.wrong_conf = 0.95

    n_samples = 1 if cascade == "conf" else K

    def build_one(d, c, e):
        samples = [c.extract(d, table.post_fields) for _ in range(n_samples)]
        return d["id"], samples, e.extract(d, table.post_fields)

    def build_caches(c, e):
        cs, es = {}, {}
        if workers > 1:
            from concurrent.futures import ThreadPoolExecutor
            with ThreadPoolExecutor(max_workers=workers) as pool:
                for did, samples, exp_ext in pool.map(
                        lambda d: build_one(d, c, e), docs):
                    cs[did], es[did] = samples, exp_ext
            return cs, es
        for d in docs:
            did, samples, exp_ext = build_one(d, c, e)
            cs[did], es[did] = samples, exp_ext
        return cs, es

    t0 = time.time()
    cheap_samples, exp_cache = build_caches(cheap, exp)

    modes = ["C0", "C1", "C2"]
    per_mode = {}
    for mode in modes:
        results = [
            run_doc(d, table, mode, cheap_samples[d["id"]], exp_cache[d["id"]],
                    cascade=cascade)
            for d in docs
        ]
        per_mode[mode] = summarize(results, docs)

    # C0 作为成本基线
    base_cost = per_mode["C0"]["cost_per_doc"] or 0
    for mode in modes:
        cpd = per_mode[mode]["cost_per_doc"] or 0
        per_mode[mode]["saving_vs_C0"] = (
            round(1 - cpd / base_cost, 4) if base_cost else None
        )

    result = {
        "schema": "e2-api-v0.1" if not isinstance(cheap, MockExtractor) else "e2-mock-v0.1",
        "status": (
            "REAL API + SYNTHETIC/PLACEHOLDER TEXT — 不是论文证据，除非 docs 是真实语料"
            if not isinstance(cheap, MockExtractor)
            else "MOCK ONLY — 不是真实 API/数据结果，不可写进论文"
        ),
        "table": str(TABLE_PATH),
        "n_docs": len(docs),
        "theta": THETA, "k": K, "cascade": cascade,
        "cost_unit": "tokens" if not isinstance(cheap, MockExtractor) else "units",
        "cheap_cost": getattr(cheap, "cost", None),
        "exp_cost": getattr(exp, "cost", None),
        "model_cheap": getattr(cheap, "model", None) or "mock-cheap",
        "model_exp": getattr(exp, "model", None) or "mock-exp",
        "elapsed_s": round(time.time() - t0, 2),
        "per_mode": per_mode,
        "a1": a1_test(docs, table, cheap_samples, exp_cache,
                      random.Random(20261034), cascade=cascade),
        "a1_fails": {},
        "a1_mock_setting": mock_a1 if isinstance(cheap, MockExtractor) else "real-api",
    }

    if include_fails and isinstance(cheap, MockExtractor):
        cheap_f = MockExtractor("cheap_fails", 0.85, 0.95,
                                random.Random(20261032), CHEAP_COST,
                                doc_error_rate=0.25)
        exp_f = MockExtractor("exp_fails", 0.97, 0.85,
                              random.Random(20261033), EXP_COST,
                              doc_error_rate=0.02)
        cs_f, es_f = build_caches(cheap_f, exp_f)
        result["a1_fails"] = a1_test(docs, table, cs_f, es_f,
                                     random.Random(20261035), cascade=cascade)
    return result


def write_report(result: dict, out_md: Path | None = None) -> None:
    out_md = Path(out_md) if out_md is not None else OUT_MD
    is_mock = str(result.get("schema", "")).startswith("e2-mock")
    unit = result.get("cost_unit", "units")
    cost_label = "成本/文档" if is_mock else "token/文档"
    lines = [
        "# E2 报告：级联降级与重写收益（" + ("Mock 冒烟" if is_mock else "真实 API 联调") + "）",
        "",
        f"> **状态：{result.get('status', '')}**",
        "",
        "## 一、已完成",
        "",
        "- GB 30871 的 P1–P8 / Q1–Q5 已编码成可执行决策表（`04_数据/gb30871/decision_table_v0.2.yaml`），"
        "含 `fallback` 与 `certified_default`；单测覆盖 pre/post/缺失/兜底。",
        "- E2 管线：C0 / C1（cheap k=3 一致性）/ C2（R1 pre 先判）；C3 未实现。",
        f"- 指标：调用数、{cost_label}、字段准确率、判决准确率、假放行/误拒、A1 分组 bootstrap。",
        "",
        ("## 二、Mock 冒烟（不可引用）" if is_mock else
         "## 二、真实 API 结果（合成/占位文本，不可引用）"),
        "",
        f"| 配置 | 调用 | {cost_label}（{unit}） | 字段准确率 | 判决准确率 | 假放行 | 误拒 | {'相对 C0 省' if is_mock else '相对 C0 token 变化'} |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for mode, v in result["per_mode"].items():
        lines.append(
            f"| {mode} | {v['calls']} | {v['cost_per_doc']} | {v['field_acc']} "
            f"| {v['verdict_acc']} | {v['false_pass']} | {v['false_reject']} "
            f"| {v['saving_vs_C0'] if v['saving_vs_C0'] is not None else '—'} |"
        )
    c0 = result["per_mode"].get("C0", {})
    c1 = result["per_mode"].get("C1", {})
    c2 = result["per_mode"].get("C2", {})
    lines += [
        "",
        *(["> token 不是成本：跨模型比较必须乘各自单价；本表只验证调用/解析/统计管线。"]
          if not is_mock else []),
        "",
        "**三个设计教训（先读）：**",
        "",
        f"1. **C1 不一定省。** {cost_label} C1={c1.get('cost_per_doc')} vs C0={c0.get('cost_per_doc')}；"
        + ("3 次采样一致性不够高时，级联会倒亏。便宜模型的“可用率”必须先测。"
           if is_mock else
           "这里只比 token；是否省钱还要乘各自的单价，token 多不等于钱多。"),
        f"2. **C2 的收益来自 pre 表。** {c2.get('skipped_pre', 0)}/{result['n_docs']} 份被 pre 判掉，"
        f"{'相对 C0 省' if is_mock else '相对 C0 的 token 变化为'} {c2.get('saving_vs_C0')}。"
        "这是 `T_pre` 的真实否决率，不是条件计数。",
        f"3. **review 把假放行从 C0 的 {c0.get('false_pass')} 降到 C1/C2 的 "
        f"{c1.get('false_pass')}/{c2.get('false_pass')}。** 代价是低置信复核次数；"
        "C0 的假放行就是“现状不做覆盖检查”的风险形态。",
        "",
        "> 口径提醒：`verdict_acc` 把 `review` 当成非 pass/reject 的错误（除非真值也是 review），"
        "所以 C1/C2 的判决准确率会被复核拉低；**安全结论看假放行列，不看这一列**。",
        "",
        "## 三、A1（高置信区间 cheap vs exp）",
        "",
        f"主设定：`{result.get('a1_mock_setting')}`；模型：cheap=`{result.get('model_cheap')}`，"
        f"exp=`{result.get('model_exp')}`；耗时 {result.get('elapsed_s')} s。",
        "",
        "**主表**",
        "",
        "| 组 | n | cheap acc | exp acc | diff | 95% CI |",
        "|---|---|---|---|---|---|",
    ]
    for k in ("high", "low"):
        v = result.get("a1", {}).get(k, {})
        if v.get("n", 0) == 0:
            lines.append(f"| {k} | 0 | — | — | — | — |")
            continue
        lines.append(
            f"| {k} | {v['n']} | {v['cheap_acc']} | {v['exp_acc']} "
            f"| {v['diff_cheap_minus_exp']} | {v['ci95']} |"
        )
    lines.append("")

    af = result.get("a1_fails", {}).get("high", {})
    if result.get("a1_fails"):
        lines += [
            "**对照（`--mock-a1 fails`：自信地错）**",
            "",
            "| 组 | n | cheap acc | exp acc | diff | 95% CI |",
            "|---|---|---|---|---|---|",
        ]
        for k in ("high", "low"):
            v = result["a1_fails"].get(k, {})
            if v.get("n", 0) == 0:
                lines.append(f"| {k} | 0 | — | — | — | — |")
                continue
            lines.append(
                f"| {k} | {v['n']} | {v['cheap_acc']} | {v['exp_acc']} "
                f"| {v['diff_cheap_minus_exp']} | {v['ci95']} |"
            )
        lines.append("")
        af_ci = af.get("ci95") or [None, None]
        lines += [
            "**读法**：高置信组 diff 的 CI 下限 > -0.02 才可声明“不弱于”；"
            "低置信组应显著为负（便宜模型被拦下）。对照分支证明 **A1 检验有牙**："
            f"high 组 n={af.get('n', 0)}、diff={af.get('diff_cheap_minus_exp')}、"
            f"CI 上界 {af_ci[1]}；若上界 < -0.02，检验会停。这里全是 mock 的管线自检，"
            "真实结论必须用 API 在同一批文档上跑。",
        ]
    else:
        lines += [
            "**读法**：高置信组 diff 的 CI 下限 > -0.02 才可声明“不弱于”；"
            "低置信组应显著为负（便宜模型被拦下）。这一轮是真实 API 调用，但文档是"
            "合成/占位文本，**不能当论文证据**；对照分支为省调用未跑。",
        ]
    lines += [
        "",
        "## 四、规则表状态（必须先核）",
        "",
        "- 表来自公开条文片段，**不是 GB 30871 全文**；P1/P2/Q2 的条号与阈值仍是推断"
        "（Q2 有 25% LEL / 10% LEL 两个版本，本表取 25%）。",
        "- `certified_default: true` 是“违规规则对声明域穷尽”的**责任声明**，不是语法证明。"
        "完整条文核对前只能当待证；一旦发现规则洞，必须设 `false`，否则默认 pass 会把未判输入当合规。",
        "- 表里 P3 给非动火作业加了 72h 上限（上限待核）；不适用的字段用 `none` 填，缺失字段一律 review。",
        "",
        "## 五、还没接的",
        "",
    ]
    if is_mock:
        lines += [
            "- **数据**：CUAD 未下载；原生作业票 JSONL 未提供。当前 mock 是合成分布；"
            "`04_数据/permits/sample_documents.jsonl` 只是接口样例。",
            "- **模型**：所有“便宜/贵模型”都是按准确率抽样的模拟器。",
            "- **C3**：R3 复核归并未实现。",
            "- **token**：mock 只记调用数/成本单元，没有真实 token。",
        ]
    else:
        lines += [
            "- **数据**：这一轮用的是 `gen_docs` 渲染的合成中文作业票文本，不是真实语料；"
            "CUAD 与原生作业票 JSONL 仍未接入。",
            "- **C3**：R3 复核归并未实现。",
            "- **成本**：只记 token，不含供应商计价；跨模型比较需乘各自单价。",
        ]
    lines += [
        "",
        "## 六、下一步",
        "",
        "1. 把 CUAD 或原生作业票转成 `documents.jsonl`（schema 见 `04_数据/permits/README.md`）。",
        "2. `APIExtractor` 已实现；用 `--api --docs <path>` 替换 `--mock`。",
        "3. 先跑 100 份 pilot，只看 **A1 高置信组**；不成立就停，不跑全量。",
        "",
        f"> 产物：`{out_md.as_posix()}`。",
    ]
    out_md.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mock", action="store_true", help="用合成数据/模拟器（默认）")
    ap.add_argument("--api", action="store_true", help="用真实 OpenAI-compatible API")
    ap.add_argument("--docs", default=None, help="documents.jsonl 路径")
    ap.add_argument("--n", type=int, default=100)
    ap.add_argument("--pilot", action="store_true")
    ap.add_argument("--mock-a1", choices=["holds", "fails"], default="holds")
    ap.add_argument("--cascade", choices=["conf", "vote"], default=CASCADE,
                    help="conf=一次调用+自报置信度；vote=三次采样一致性")
    ap.add_argument("--model-cheap", default="deepseek-flash")
    ap.add_argument("--model-exp", default="deepseek-v4-pro")
    ap.add_argument("--base-url", default="https://api.deepseek.com")
    ap.add_argument("--api-key-env", default="DEEPSEEK_API_KEY")
    ap.add_argument("--timeout", type=int, default=120)
    ap.add_argument("--max-tokens", type=int, default=8192)
    ap.add_argument("--workers", type=int, default=4,
                    help="API 模式下按文档并行的线程数（1 = 串行）")
    ap.add_argument("--out-json", default=None)
    ap.add_argument("--out-md", default=None)
    args = ap.parse_args()

    table = load_table(TABLE_PATH)
    if args.docs:
        docs = load_docs(args.docs, table)
        if args.pilot:
            docs = docs[:100]
        source = str(args.docs)
    else:
        n = 30 if args.pilot else args.n
        docs = gen_docs(n, random.Random(20261030), table)
        source = "synthetic"

    if args.api:
        key = os.environ.get(args.api_key_env, "")
        if not key:
            print(f"缺少环境变量 {args.api_key_env}", file=sys.stderr)
            return 2
        cheap = APIExtractor("cheap", args.model_cheap, key,
                             base_url=args.base_url, timeout=args.timeout,
                             max_tokens=args.max_tokens)
        exp = APIExtractor("exp", args.model_exp, key,
                           base_url=args.base_url, timeout=args.timeout,
                           max_tokens=args.max_tokens)
        result = run(docs, table, args.mock_a1, cheap=cheap, exp=exp,
                     include_fails=False, workers=max(1, args.workers),
                     cascade=args.cascade)
        result["source"] = source
        result["api_calls"] = cheap.calls + exp.calls
        out_json = Path(args.out_json) if args.out_json else OUT_API_JSON
        out_md = Path(args.out_md) if args.out_md else OUT_API_MD
    else:
        result = run(docs, table, args.mock_a1, cascade=args.cascade)
        result["source"] = "mock" if not args.docs else str(args.docs)
        out_json = Path(args.out_json) if args.out_json else OUT_JSON
        out_md = Path(args.out_md) if args.out_md else OUT_MD

    out_json.write_text(json.dumps(result, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    write_report(result, out_md=out_md)
    print(json.dumps({
        "source": result["source"],
        "n_docs": result["n_docs"],
        "api_calls": result.get("api_calls"),
        "per_mode": result["per_mode"],
        "a1": result["a1"],
    }, ensure_ascii=False, indent=2))
    print(f"\n已写入 {out_json} 和 {out_md}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
