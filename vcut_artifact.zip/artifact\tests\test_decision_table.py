# -*- coding: utf-8 -*-
"""GB 30871 决策表骨架的最小单测。"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from checker.decision_table import DecisionTable, load_table  # noqa: E402

TABLE = Path(__file__).resolve().parents[1] / "04_数据" / "gb30871" / "decision_table_v0.2.yaml"


def base() -> dict:
    return dict(
        work_type="confined", fire_level="none", valid_hours=6,
        approval_level="department", multi_permit=False, multi_permits_ok=True,
        approver_authorized=True, guardian_certified=True, gas_before_approval=True,
        measures_done=True, lel=10, o2=21, isolated=True, cleanup=True,
    )


class TestGBTable(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.t = load_table(TABLE)

    def test_counts(self):
        self.assertEqual(self.t.t_pre, 8)
        self.assertEqual(self.t.t_post, 5)

    def test_compliant_passes_and_is_judged(self):
        d = self.t.evaluate(base())
        self.assertEqual(d.verdict, "pass")
        self.assertTrue(d.judged)          # certified default
        self.assertEqual(d.phase, "fallback")

    def test_q2_rejects_on_lel(self):
        f = base(); f["lel"] = 30
        d = self.t.evaluate(f)
        self.assertEqual((d.verdict, d.rule_id, d.phase), ("reject", "Q2", "post"))

    def test_q3_rejects_on_o2(self):
        f = base(); f["o2"] = 24
        d = self.t.evaluate(f)
        self.assertEqual((d.verdict, d.rule_id), ("reject", "Q3"))

    def test_p1_rejects_unknown_type(self):
        f = base(); f["work_type"] = "bad"
        d = self.t.evaluate(f)
        self.assertEqual((d.verdict, d.rule_id, d.phase), ("reject", "P1", "pre"))

    def test_p3_non_hot_validity(self):
        f = base(); f["valid_hours"] = 100
        d = self.t.evaluate(f)
        self.assertEqual((d.verdict, d.rule_id), ("reject", "P3"))

    def test_missing_field_reviews(self):
        f = base(); f.pop("o2")
        d = self.t.evaluate(f)
        self.assertEqual((d.verdict, d.phase), ("review", "missing"))
        self.assertEqual(d.missing, ("o2",))

    def test_pre_decision_returns_none_for_compliant(self):
        self.assertIsNone(self.t.pre_decision(base()))

    def test_uncertified_pass_fallback_is_not_judged(self):
        t = DecisionTable(
            pre=list(self.t.pre), post=list(self.t.post),
            fallback="pass", certified_default=False,
        )
        d = t.evaluate(base())
        self.assertEqual(d.verdict, "pass")
        self.assertFalse(d.judged)


if __name__ == "__main__":
    unittest.main()
