"""E7o: does a witness vocabulary learned on 800 receipts transfer to the
held-out CORD test split?

Labels are selected only on the train split (a token that fires on >=8 receipts
and matches the gold total on >=90% of them).  The frozen vocabulary is then
applied, with bounding boxes, to the 100 unseen receipts.  This separates
"witness synthesis" from "witness overfitting": the test half never contributes
to the vocabulary.
"""
from __future__ import annotations

import json
import re
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e7k_independent_witness import match, num  # noqa: E402
from e7l_layout_witness import parse_box  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
TRAIN_RAW = REPO / "06_结果" / "e7_receipts.json"
TEST_DATA = REPO / "04_数据" / "external" / "cord" / "test_adapted.parquet"
TEST_RAW = REPO / "06_结果" / "e7n_test_qwen3.json"
OUT = REPO / "06_结果" / "e7o_label_transfer.json"


def norm(t: str) -> str:
    return re.sub(r"[^a-z ]", "", str(t).lower()).strip()


def labels_of(text):
    toks = [t.strip() for t in text.split("|")]
    out = defaultdict(list)
    for i, t in enumerate(toks):
        lab = norm(t)
        if not lab or len(lab) < 2 or len(lab) > 20:
            continue
        for j in range(max(0, i - 5), min(len(toks), i + 6)):
            if j == i:
                continue
            v = num(toks[j])
            if v is not None and v >= 100:
                out[lab].append(v)
    return out


def select_labels(train_rows):
    stat = defaultdict(lambda: [0, 0])
    for r in train_rows:
        for lab, vals in labels_of(r["text"]).items():
            stat[lab][0] += 1
            if any(match(v, r["gold"]["total"]) for v in vals):
                stat[lab][1] += 1
    return {lab for lab, (n, m) in stat.items() if n >= 8 and m / n >= 0.9}


def read_labels(tokens, labels):
    if not tokens:
        return None
    tol = max(8.0, statistics.median(t["h"] for t in tokens) * 0.8)
    cands = []
    for i, t in enumerate(tokens):
        if norm(t["text"]) not in labels:
            continue
        same = [u for u in tokens if u is not t and abs(u["y"] - t["y"]) <= tol]
        amounts = [(u["x"], v) for u in same
                   for v in [num(u["text"])] if v is not None and v >= 100]
        if not amounts:
            continue
        right = [(x, v) for x, v in amounts if x >= t["x"] - 2]
        v = min(right, key=lambda p: p[0])[1] if right else max(amounts, key=lambda p: p[0])[1]
        cands.append((t["x"], v))
    return max(cands, key=lambda p: p[0])[1] if cands else None


def main():
    train = json.load(open(TRAIN_RAW, encoding="utf-8"))["rows"]
    labels = select_labels(train)
    test = {r["file"]: r for r in json.load(open(TEST_RAW, encoding="utf-8"))["rows"]}
    df = pd.read_parquet(TEST_DATA)

    rows = []
    for _, r in df.iterrows():
        f = r["file_name"]
        if f not in test:
            continue
        toks = parse_box(r["ocr_box"])
        v = read_labels(toks, labels)
        t = test[f]
        gold = t["gold"]["total"]
        rows.append({
            "file": f, "witness": v, "gold": gold,
            "model": t["model"].get("total"),
            "witness_correct": match(v, gold), "model_correct": t["model_total_correct"],
            "agree": match(v, t["model"].get("total")) is True,
            "self": t["verdict"] in ("accept", "fill"),
        })

    n = len(rows)

    def m(pred, name):
        acc = [r for r in rows if pred(r)]
        known = [r for r in acc if r["model_correct"] is not None]
        fp = sum(1 for r in known if r["model_correct"] is False)
        return {"name": name, "accept": len(acc), "automation": round(len(acc) / n, 4),
                "false_pass": fp, "false_pass_rate": round(fp / n, 4),
                "precision": round((len(known) - fp) / len(known), 4) if known else None}

    wknown = [r for r in rows if r["witness_correct"] is not None]
    summary = {
        "n": n, "labels": sorted(labels),
        "witness_found": sum(1 for r in rows if r["witness"] is not None),
        "witness_accuracy": round(sum(1 for r in wknown if r["witness_correct"]) / max(1, len(wknown)), 4),
        "policies": [
            m(lambda r: r["self"], "self-consistency"),
            m(lambda r: r["agree"], "witness agree"),
            m(lambda r: r["self"] and r["agree"], "self AND witness"),
            m(lambda r: r["self"] or r["agree"], "self OR witness"),
        ],
    }
    json.dump({"summary": summary, "rows": rows}, open(OUT, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
