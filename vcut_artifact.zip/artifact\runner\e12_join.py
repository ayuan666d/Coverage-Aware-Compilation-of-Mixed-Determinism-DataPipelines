"""E12-JOIN: put the two lines on one attribution table and one certificate.

The parallel E12 line (fixed structure = PPMI+SVD, searched structure = GA over
DB-native primitives, gradient = fine-tuned 0.6B) reports a 164-question failure
attribution with mechanism classes.  My E11 arm (identifier split + per-token idf
geometric fusion + BM25-recall-then-graph-rerank) has never been scored on those
classes, and the support certificate has never been tried on top of their stronger
base ranker.  This script does both, read-only on their JSONs.

Two questions it answers:
  1. Of the 164 questions where dense is right and the old E11 graph is wrong,
     how many does each arm fix, per mechanism class?
  2. Does the free support certificate (>=3 query words actually present in the
     answer's own document) still select a subset where the DB-native arm beats
     dense on top-1, when the arm is gp_ex instead of my graph?
"""
from __future__ import annotations

import json
import math
import re
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_run_spider import coquery_map, fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
EMB = WORK / "e11_emb_spider.npz"
OUT = R / "e12_join.json"
EPS = 1e-6
WORD = re.compile(r"[a-z0-9]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us""".split())
CLASSES = ("weak", "form", "trap", "ambig", "semantic")


def wtoks(s):
    return [t for t in WORD.findall(str(s).lower()) if t not in STOP]


def main():
    ver = json.load(open(R / "e12_verdict.json", encoding="utf-8"))
    cls = ver["classes"]
    gp = json.load(open(R / "e12_gp.json", encoding="utf-8"))["rows"]
    spec = json.load(open(R / "e12_spectral.json", encoding="utf-8"))["rows"]
    dense = {r["qid"]: r for r in json.load(open(WORK / "e11_dense_spider.json", encoding="utf-8"))["rows"]}
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(R / "e11_cases.json", encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    train = [c for c in data["spider"] if c["split"] == "train"]

    # ---------- rebuild my arm ----------
    g.SPLIT_IDENT = True
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    cat = g.Catalog(tabs, fks, coquery=coquery_map(train, prefix=True), prefix_db=True)
    N = len(cat.tables)
    z = np.load(EMB, allow_pickle=True)
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}
    t0 = time.time()
    tok = {}
    for w in sorted({w for c in test for w in g.toks(c["question"])}):
        if ("token", w) not in cat.idx:
            continue
        x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
        s = cat.table_scores(x)
        mx = float(s.max())
        tok[w] = s / mx if mx > 0 else s
    idf = {w: math.log(1 + (N - cat.token_df.get(w, 0) + 0.5) / (cat.token_df.get(w, 0) + 0.5))
           for w in tok}
    print(f"my arm rebuilt in {time.time()-t0:.0f}s", flush=True)

    # shared document vocabulary for the support count, per table id (lowercased)
    doc_low = {}
    for t in cat.tables:
        s = set(wtoks(t["name"]))
        for c in t["columns"]:
            s |= set(wtoks(c["name"]))
            for v in (c.get("values") or [])[:12]:
                s |= set(wtoks(v))
        doc_low[t["tid"].lower()] = s

    qtext = {c["qid"]: c["question"] for c in data["spider"]}
    test_ids = {c["qid"] for c in test}

    mine = {}
    for c in test:
        q = g.toks(c["question"])
        gold = {f"{c['db_id']}::{t}".lower() for t in c["gold"]}
        ws = [w for w in set(q) if w in tok]
        if ws:
            M = np.stack([tok[w] for w in ws])
            iw = np.array([idf[w] for w in ws])[:, None]
            graph = np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
        else:
            graph = np.zeros(N, dtype=np.float32)
        b = g.bm25(cat, q)
        top = np.argsort(-b)[:30]
        mixed = b.copy()
        base = float(b[top[-1]])
        for i, idx in enumerate(top[np.argsort(-graph[top])]):
            mixed[idx] = base + (30 - i) * 1e-6
        ranked = [cat.table_ids[i].lower() for i in np.argsort(-mixed)]
        m = g.metrics(ranked, gold)
        mine[c["qid"]] = {"top1": ranked[0], "r1": m["recall@1"], "r5": m["recall@5"],
                          "hit1": float(ranked[0] in gold), "q": set(q)}

    # ---------- arms on a common footing ----------
    arms = {}

    def add_from_rows(name, rows, pick=None):
        d = {}
        for r in rows:
            if r["qid"] not in test_ids:
                continue
            sub = r[pick] if pick else r
            top1 = str(sub["top5"][0]).lower()
            d[r["qid"]] = {"top1": top1, "r1": sub["recall@1"], "r5": sub["recall@5"],
                           "hit1": float(top1 in {x.lower() for x in r["gold"]}),
                           "q": set(wtoks(qtext[r["qid"]]))}
        arms[name] = d

    add_from_rows("gp", gp["gp"])
    add_from_rows("gp_ex", gp["gp_ex"])
    for nm in ("bm25", "word", "gram", "fused"):
        add_from_rows("e12_" + nm, spec, nm)
    arms["e11_graph_mine"] = mine
    arms["dense"] = {qid: {"top1": str(r["top5"][0]).lower(), "r1": r["recall@1"], "r5": r["recall@5"],
                           "hit1": float(str(r["top5"][0]).lower() in {x.lower() for x in r["gold"]}),
                           "q": set(wtoks(qtext[qid]))}
                     for qid, r in dense.items() if qid in test_ids}

    def support(arm, qid):
        a = arms[arm][qid]
        d = doc_low.get(a["top1"], set())
        return len(a["q"] & d)

    # 1. class-wise fixes over the 164
    fixes = {}
    for arm in arms:
        per = {k: [0, 0] for k in CLASSES}
        for qid, info in cls.items():
            c = info["class"]
            per[c][1] += 1
            if arm == "dense":
                ok = bool(info.get("dense_top1")) and info["dense_top1"].lower() in \
                    {x.lower() for x in dense[qid]["gold"]}
            else:
                ok = arms[arm][qid]["hit1"] > 0
            if ok:
                per[c][0] += 1
        fixes[arm] = {"class_fixes": {k: f"{v[0]}/{v[1]}" for k, v in per.items()},
                      "fixed_164": sum(v[0] for v in per.values()),
                      "top1_hit_all": round(float(np.mean([arms[arm][q]["hit1"] for q in dense])), 4)}

    # 2. certificate on top of each arm: accept k>=3, else dense
    cert = {}
    for arm in ("e11_graph_mine", "gp", "gp_ex", "e12_fused", "e12_gram", "e12_bm25"):
        acc = [q for q in dense if support(arm, q) >= 3]
        cov = len(acc) / len(dense)
        acc_r1 = float(np.mean([arms[arm][q]["r1"] for q in acc])) if acc else None
        acc_d1 = float(np.mean([arms["dense"][q]["r1"] for q in acc])) if acc else None
        acc_r5 = float(np.mean([arms[arm][q]["r5"] for q in acc])) if acc else None
        acc_d5 = float(np.mean([arms["dense"][q]["r5"] for q in acc])) if acc else None
        hyb_r1 = (sum(arms[arm][q]["r1"] for q in acc)
                  + sum(arms["dense"][q]["r1"] for q in dense if q not in set(acc))) / len(dense)
        hyb_r5 = (sum(arms[arm][q]["r5"] for q in acc)
                  + sum(arms["dense"][q]["r5"] for q in dense if q not in set(acc))) / len(dense)
        cert[arm] = {"accept_cov": round(cov, 4),
                     "accepted_arm_r1": round(acc_r1, 4) if acc_r1 else None,
                     "accepted_dense_r1": round(acc_d1, 4) if acc_d1 else None,
                     "accepted_arm_r5": round(acc_r5, 4) if acc_r5 else None,
                     "accepted_dense_r5": round(acc_d5, 4) if acc_d5 else None,
                     "hybrid_r1": round(hyb_r1, 4), "hybrid_r5": round(hyb_r5, 4),
                     "call_frac": round(1 - cov, 4)}

    out = {"n_test": len(dense), "n164": len(cls), "class_sizes": dict(Counter(v["class"] for v in cls.values())),
           "attribution": fixes, "certificate_on_arm": cert,
           "dense_only": {"r1": round(float(np.mean([arms["dense"][q]["r1"] for q in dense])), 4),
                          "r5": round(float(np.mean([arms["dense"][q]["r5"] for q in dense])), 4),
                          "top1_hit": arms["dense"] and round(float(np.mean([arms["dense"][q]["hit1"] for q in dense])), 4)}}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(out, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
