"""E11 figures: scale curve, certificate frontier, role separation."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"


def curve(cur):
    xs = [c["coverage"] * 100 for c in cur if c["precision"] is not None]
    ys = [c["precision"] * 100 for c in cur if c["precision"] is not None]
    return xs, ys


def main():
    scale = json.load(open(R / "e11_scale.json", encoding="utf-8"))
    cert = json.load(open(R / "e11_spider_known_dense_cert.json", encoding="utf-8"))
    sim = json.load(open(R / "e11_sim.json", encoding="utf-8"))
    cord = json.load(open(R / "e11_cord_role.json", encoding="utf-8"))

    fig, ax = plt.subplots(1, 3, figsize=(13.6, 4.2))
    runs = [r for r in scale["runs"] if r["n_q"] > 0]
    ns = [r["N"] for r in runs]
    styles = {"dense": ("-o", "dense embedding (Qwen3-0.6B)"),
              "ppr_band": ("--s", "relational graph (selected on held-in data)"),
              "bm25": (":d", "BM25")}
    for k, (st, lab) in styles.items():
        ys = [r["metrics"].get(k, {}).get("recall@5", float("nan")) * 100 for r in runs]
        ax[0].plot(ns, ys, st, label=lab)
        for x, y in zip(ns, ys):
            if y == y:
                ax[0].annotate(f"{y:.0f}", (x, y), textcoords="offset points",
                               xytext=(0, 6), fontsize=7)
    ax[0].set_xscale("log")
    ax[0].set_xticks(ns)
    ax[0].set_xticklabels([str(n) for n in ns])
    ax[0].set_xlabel("tables in the catalog")
    ax[0].set_ylabel("recall@5 (%)")
    ax[0].set_title("A. retrieval vs schema size (Spider)")
    ax[0].legend(fontsize=7, loc="lower left")
    ax[0].grid(alpha=0.3)

    d = cert["methods"]["dense"]
    xs, ys = curve(d["score"])
    ax[1].plot(xs, ys, "-o", label="cosine threshold")
    xs, ys = curve(d["key_exact"])
    ax[1].plot(xs, ys, "--s", label="path certificate (unique key)")
    dp = cert["methods"]["dense_plus_typed"]
    xs, ys = curve(dp["key_exact"])
    ax[1].plot(xs, ys, "-.^", label="certificate on dense+graph")
    ax[1].axhline(95, color="grey", lw=0.8)
    ax[1].set_xlabel("accepted queries (% of 341)")
    ax[1].set_ylabel("precision (%)")
    ax[1].set_title("B. what the graph can certify (known DB)")
    ax[1].legend(fontsize=7, loc="lower left")
    ax[1].grid(alpha=0.3)

    rr = sim["rho_sweep"]
    rhos = [x["rho"] for x in rr]
    ax[2].plot(rhos, [x["untyped"] * 100 for x in rr], "-o", label="one undirected operator")
    ax[2].plot(rhos, [x["typed_theme"] * 100 for x in rr], "--s", label="relation selected (right)")
    ax[2].plot(rhos, [x["typed_role"] * 100 for x in rr], ":^", label="relation selected (wrong)")
    ax[2].set_xlabel("agreement of the two partitions $\\rho$")
    ax[2].set_ylabel("answer accuracy (%)")
    ax[2].set_title(f"C. role vs proximity (sim; CORD {cord['all']['single_all_acc']*100:.1f}$\\to${cord['all']['typed_all_acc']*100:.1f}%)")
    ax[2].legend(fontsize=7, loc="lower right")
    ax[2].grid(alpha=0.3)

    fig.tight_layout()
    fig.savefig(R / "E11_zoom.png", dpi=150)
    print("wrote", R / "E11_zoom.png")


if __name__ == "__main__":
    main()
