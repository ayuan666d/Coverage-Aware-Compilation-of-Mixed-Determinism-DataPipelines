"""E11-GENERIC: press the two things the hand-written arm has never been tested on.

The structure is fixed by hand (split identifiers -> per-token PPR -> per-token best
COLUMN -> idf geometric conjunction -> BM25 top-30 recall). Two assumptions inside it were
never priced:

  (A) constants.  The recall stage is K=30 and the diffusion damping is alpha=0.85.  Neither
      was swept on the column arm.  (alpha=0.85 has a parameter-free rival, alpha=lambda_2,
      which tied per-database tuning in sec 6 -- that was tested on the old table-level arm.)
  (B) naming.  Everything the arm reads is human-readable English identifiers.  Real lakes
      carry C1/COL_A/pinyin/abbreviations.  So: rebuild the catalogue with identifiers
      replaced by an injective map onto opaque tokens (x0001, x0002, ...) -- structure is
      preserved, English morphology is destroyed -- and separately with the sample values
      removed, and with both.  The arm, its BM25 control, and both certificate layers are
      re-read in every world.

Pre-registered readings, written before running:
  * generality of constants is CLAIMED if the K sweep and the alpha sweep move test R@5 by
    <= 2.0 points in the clean world; otherwise the claim becomes "K and alpha are
    catalogue-size dependent" and must be stated as parameters with a default.
  * naming dependence is MEASURED, not assumed away: the arm's fall under opaque names is
    the honest price of the design, and the certificate is expected to go SILENT rather than
    wrong.  Silent-but-honest is acceptable; wrong is not.
  * dense is reported once, in the clean world. It cannot be re-encoded on this machine
    (GPU held by another line), so no dense number is shown for the corrupted worlds --
    quoting the clean number there would compare our arm's new world to the model's old one.
"""
from __future__ import annotations

import json
import math
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np
from scipy import sparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_surprise import chance_tail  # noqa: E402
from e11_col import col_index, gm, seg_top12  # noqa: E402
from e11_run_spider import fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
CASES = R / "e11_cases.json"
EMB = WORK / "e11_emb_spider.npz"
OUT = R / "e11_generic.json"
EPS, ITERS = 1e-6, 20
ALPHA = 0.05
KS = (10, 20, 30, 50, 100, 876)
WORLDS = ("clean", "opaque_names", "no_values", "both")


def opaque(tables, fks, ret_map=False):
    """Injective rename of every identifier onto an opaque token.

    Table names map the same way across databases (as a real anonymisation would), column
    names per database, and the foreign-key graph is remapped along with them: English
    morphology is destroyed, structure is preserved."""
    tmap, cmap = {}, {}
    out = []
    for t in tables:
        tt = dict(t)
        if t["name"] not in tmap:
            tmap[t["name"]] = f"x{len(tmap):05d}"
        tt["name"] = tmap[t["name"]]
        cols = []
        for c in t["columns"]:
            cc = dict(c)
            key = f"{t['db']}#{c['name']}"
            if key not in cmap:
                cmap[key] = f"c{len(cmap):05d}"
            cc["name"] = cmap[key]
            cols.append(cc)
        tt["columns"] = cols
        out.append(tt)
    nfks = []
    for a, ca, b, cb in fks:
        da, ta = a.split("::", 1)
        db2, tb = b.split("::", 1)
        nfks.append([f"{da}::{tmap.get(ta, ta)}", cmap.get(f"{da}#{ca}", ca),
                     f"{db2}::{tmap.get(tb, tb)}", cmap.get(f"{db2}#{cb}", cb)])
    return (out, nfks, tmap) if ret_map else (out, nfks)


def strip_values(tables):
    out = []
    for t in tables:
        tt = dict(t)
        tt["columns"] = [dict(c, values=[]) for c in t["columns"]]
        out.append(tt)
    return out


def make_tables(kind, world):  # returns (tables, fks, table-name map for gold remapping)
    cache = json.load(open(CACHE, encoding="utf-8"))
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    tmap = {}
    if world in ("opaque_names", "both"):
        tabs, fks, tmap = opaque(tabs, fks, ret_map=True)
        # gold ids are scored against the RENAMED catalogue, so they go through the same map
    if world in ("no_values", "both"):
        tabs = strip_values(tabs)
    return tabs, fks, tmap


def lambda2(cat):
    A = cat.union
    A = (A + A.T) * 0.5
    d = np.asarray(A.sum(axis=1)).ravel()
    d[d <= 0] = 1.0
    Dm = sparse.diags(1.0 / np.sqrt(d))
    S = (Dm @ A @ Dm).tocsr()
    try:
        from scipy.sparse.linalg import eigsh
        w = eigsh(S, k=3, which="LA", return_eigenvectors=False)
        w = np.sort(np.real(w))[::-1]
        return float(w[1]) if w.size > 1 else 0.85
    except Exception:
        return 0.85


def run_world(cat, cases, alphas, ks, N, tmap=None):
    tmap = tmap or {}
    colnodes, cdocs, starts, ends = col_index(cat)
    docs = [g.table_doc(t) for t in cat.tables]
    inc_word, inc_name = {}, {}
    for j, d in enumerate(docs):
        for w in set(d):
            inc_word.setdefault(w, np.zeros(N))[j] = 1.0
    for j, t in enumerate(cat.tables):
        names = set(toks(t["name"]))
        for c in t["columns"]:
            names |= set(toks(c["name"]))
        for w in names:
            inc_name.setdefault(w, np.zeros(N))[j] = 1.0
    def idf_of(w):
        d = cat.token_df.get(w, 0)
        return math.log(1 + (N - d + 0.5) / (d + 0.5))
    res = {}
    for a in alphas:
        tok_tab, tok_col = {}, {}
        for w in sorted({w for c in cases for w in toks(c["question"])}):
            k = ("token", w)
            if k not in cat.idx:
                continue
            x = g.ppr(cat.union, {cat.idx[k]: 1.0}, a, ITERS)
            st = cat.table_scores(x)
            mx = float(st.max())
            if mx <= 0:
                continue
            tok_tab[w] = (st / mx).astype(np.float32)
            cv = np.asarray(x)[colnodes].astype(np.float32)
            cmx = float(cv.max())
            tok_col[w] = cv / cmx if cmx > 0 else cv
        per_q = {}
        for c in cases:
            q = toks(c["question"])
            gold = {f"{c['db_id']}::{tmap.get(t, t)}" for t in c["gold"]}
            ws = sorted({w for w in q if w in tok_tab})
            b = g.bm25(cat, q)
            sc = np.zeros(N, dtype=np.float32)
            if ws:
                iw = np.array([idf_of(w) for w in ws], dtype=np.float32)[:, None]
                Tt = np.maximum.reduceat(np.stack([tok_col[w] for w in ws]), starts, axis=1)
                sc = gm(Tt, iw)
            cs = np.zeros(N)
            cs_name = np.zeros(N)
            for w in set(q):
                if w in inc_word:
                    cs += inc_word[w]
                if w in inc_name:
                    cs_name += inc_name[w]
            per_q[c["qid"]] = {"q": set(q), "gold": gold, "b": b, "sc": sc, "cs": cs,
                               "cs_name": cs_name,
                               "dfs_word": [cat.token_df.get(w, 0) for w in set(q) if w in inc_word],
                               "dfs_name": [cat.token_df.get(w, 0) for w in set(q) if w in inc_name]}
        for K in ks:
            rows = []
            for c in cases:
                st = per_q[c["qid"]]
                b, sc = st["b"], st["sc"]
                Kc = min(K, N)
                top = np.argsort(-b)[:Kc]
                base = float(b[top[-1]])
                mixed = b.copy()
                for i, idx in enumerate(top[np.argsort(-sc[top])]):
                    mixed[idx] = base + (Kc - i) * 1e-6
                r = g.rank(mixed, cat)
                m = g.metrics(r, st["gold"])
                t1 = r[0]
                pos = cat.table_pos[t1]
                s_word = int(st["cs"][pos])
                pw = chance_tail(st["dfs_word"], N, s_word)[1] if st["dfs_word"] else 1.0
                s_name = int(st["cs_name"][pos])
                pn = chance_tail(st["dfs_name"], N, s_name)[1] if st["dfs_name"] else 1.0
                rb = g.rank(b, cat)
                mb = g.metrics(rb, st["gold"])
                rows.append({"r1": m["recall@1"], "r5": m["recall@5"],
                             "bm25_r5": mb["recall@5"], "bm25_r1": mb["recall@1"],
                             "cert_w": pw <= ALPHA, "cert_n": pn <= ALPHA,
                             "correct": bool(t1 in st["gold"]), "n_anchor": len(st["dfs_word"])})
            f = lambda k: round(float(np.mean([x[k] for x in rows])), 4)  # noqa: E731
            acc_w = [x for x in rows if x["cert_w"]]
            acc_wn = [x for x in rows if x["cert_w"] and x["cert_n"]]
            res[f"a{a}_K{K}"] = {
                "r1": f("r1"), "r5": f("r5"), "bm25_r5": f("bm25_r5"),
                "cert_word_acc": len(acc_w),
                "cert_word_fp": sum(1 for x in acc_w if not x["correct"]),
                "cert_wn_acc": len(acc_wn),
                "cert_wn_fp": sum(1 for x in acc_wn if not x["correct"]),
                "no_anchor_share": round(float(np.mean([x["n_anchor"] == 0 for x in rows])), 4)}
    return res


def main():
    g.SPLIT_IDENT = True
    data = json.load(open(CASES, encoding="utf-8"))
    cases = [c for c in data["spider"] if c["split"] == "test"]
    z = np.load(EMB, allow_pickle=True)
    ids = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}
    out = {"worlds": {}, "dense_clean": None, "lambda2": None}
    t0 = time.perf_counter()
    for world in WORLDS:
        tabs, fks, tmap = make_tables(None, world)
        cat = g.Catalog(tabs, fks, coquery=None, prefix_db=True)
        N = len(cat.tables)
        if world == "clean":
            lam = lambda2(cat)
            out["lambda2"] = round(lam, 4)
            alphas = [0.85, 0.80, 0.90, round(lam, 3)]
            ks = list(KS)
            r5 = []
            r1 = []
            for c in cases:
                if c["qid"] not in qpos:
                    continue
                gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
                order = [ids[i] for i in np.argsort(-(Dm @ Qm[qpos[c["qid"]]]))]
                m = g.metrics(order, gold)
                r5.append(m["recall@5"]); r1.append(m["recall@1"])
            out["dense_clean"] = {"r1": round(float(np.mean(r1)), 4),
                                  "r5": round(float(np.mean(r5)), 4)}
        else:
            alphas, ks = [0.85], [30]
        out["worlds"][world] = run_world(cat, cases, alphas, ks, N, tmap=tmap)
        print(f"{world}: {len(out['worlds'][world])} cells in {time.time()-t0:.0f}s", flush=True)
    clean = out["worlds"]["clean"]
    k_span = max(v["r5"] for k, v in clean.items() if k.startswith("a0.85_K")) - \
             min(v["r5"] for k, v in clean.items() if k.startswith("a0.85_K"))
    a_span = max(v["r5"] for k, v in clean.items() if k.endswith("_K30")) - \
             min(v["r5"] for k, v in clean.items() if k.endswith("_K30"))
    out["verdict_constants"] = {
        "K_sweep_r5_span": round(k_span, 4), "alpha_sweep_r5_span": round(a_span, 4),
        "claim_holds": bool(k_span <= 0.02 and a_span <= 0.02)}
    out["verdict_naming"] = {
        w: {"r5": out["worlds"][w]["a0.85_K30"]["r5"],
            "bm25_r5": out["worlds"][w]["a0.85_K30"]["bm25_r5"],
            "no_anchor_share": out["worlds"][w]["a0.85_K30"]["no_anchor_share"],
            "cert_wn_acc": out["worlds"][w]["a0.85_K30"]["cert_wn_acc"],
            "cert_wn_fp": out["worlds"][w]["a0.85_K30"]["cert_wn_fp"]}
        for w in WORLDS}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in out.items() if k != "worlds"}, indent=1, ensure_ascii=False))
    print("clean grid:")
    for k, v in clean.items():
        print("  %-14s r1=%.4f r5=%.4f bm25=%.4f cert_word=%d/%d fp  cert_wn=%d/%d fp  noanchor=%.2f"
              % (k, v["r1"], v["r5"], v["bm25_r5"], v["cert_word_acc"], v["cert_word_fp"],
                 v["cert_wn_acc"], v["cert_wn_fp"], v["no_anchor_share"]))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
