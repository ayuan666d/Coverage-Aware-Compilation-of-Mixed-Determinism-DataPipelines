"""E12 scale curve: does the DB-native GA scorer's edge over BM25 grow with
catalog size?  Same protocol as e11_scale.py (uniform N-table samples, score
questions whose gold is fully inside the catalog, REPS repeats), but the GA is
RE-TRAINED on each cell's own train questions (the approach is allowed its
tiny fitting budget at every scale).  Baselines rebuilt per cell: BM25,
spectral fused (PPMI-SVD rebuilt, fusion weights retuned on cell train), and
frozen dense rows (embeddings are catalog-independent).

The N=876 cell is not rerun here -- e12_gp/e12_spectral/e11_spider_dense
already hold per-876 numbers; cite them in the report.
"""
from __future__ import annotations

import json
import math
import random
import re
from collections import Counter
from pathlib import Path

import numpy as np

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
CASES = REPO / "06_结果" / "e11_cases.json"
CACHE = WORK / "schema_cache.json"
EMB = WORK / "e11_emb_spider.npz"
OUT = REPO / "06_结果" / "e12_scale.json"

SIZES = [100, 300]
REPS = 3
WORD = re.compile(r"[a-z0-9]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us list show give find return
number names name""".split())


def wtoks(s):
    return [t for t in WORD.findall(s.lower()) if t not in STOP]


def ngrams(w, ns=(3, 4, 5)):
    pad = f"<{w}>"
    return {pad[i:i + n] for n in ns for i in range(len(pad) - n + 1)} if len(pad) >= 3 else set()


def stem4(w):
    return w[:4] if len(w) >= 4 else w


def randomized_svd(A, k, oversample=16, iters=4, seed=0):
    rng = np.random.default_rng(seed)
    m, n = A.shape
    Q = min(k + oversample, min(m, n))
    Omega = rng.standard_normal((n, Q)).astype(np.float32)
    Y = A @ Omega
    Y -= Y.mean(axis=0, keepdims=True)
    for _ in range(iters):
        Y = A @ (A.T @ Y)
        Y -= Y.mean(axis=0, keepdims=True)
    Qu, _ = np.linalg.qr(Y.astype(np.float64))
    B = Qu.T @ A
    Ub, S, Vt = np.linalg.svd(B, full_matrices=False)
    U = Qu @ Ub[:, :k]
    return U[:, :k].astype(np.float32), S[:k].astype(np.float32), Vt[:k, :].astype(np.float32)


def build_svd_space(doc_tokens, k, seed):
    """doc_tokens: list of token lists -> (doc_vec, term_vec, vocab) via PPMI-SVD."""
    per_doc = [set(t) for t in doc_tokens]
    df = Counter()
    for ts in per_doc:
        df.update(ts)
    vocab = sorted(df)
    vidx = {t: i for i, t in enumerate(vocab)}
    Dn = len(doc_tokens)
    C = np.zeros((len(vocab), Dn), dtype=np.float32)
    for j, ts in enumerate(per_doc):
        for t in ts:
            C[vidx[t], j] = 1.0
    dlen = np.array([len(ts) for ts in per_doc], dtype=np.float64)
    total = C.sum()
    p_t = C.sum(axis=1, keepdims=True) / total
    p_d = dlen[np.newaxis, :] ** 0.75
    p_d = p_d / p_d.sum()
    pmi = np.log((C * total) / np.maximum(p_t @ p_d * total, 1e-12) / math.log(2))
    M = np.maximum(pmi, 0.0).astype(np.float32)
    U, S, Vt = randomized_svd(M.T, k, seed=seed)
    return U, (Vt.T * S).astype(np.float32), vocab


def metrics_top(top_ids, gold_set):
    r = {1: 0.0, 5: 0.0}
    mrr = 0.0
    for i, d in enumerate(top_ids[:5]):
        if d in gold_set:
            mrr = max(mrr, 1.0 / (i + 1))
            for k in r:
                if i < k:
                    r[k] += 1.0 / len(gold_set)
    return r, mrr


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))["spider"]
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    all_tables, all_fks = [], []
    for db, s in cache.items():
        for t in s["tables"]:
            all_tables.append(dict(t, db=db, fid=f"{db}::{t['name'].lower()}"))
        have = {t["name"].lower() for t in s["tables"]}
        for a, ca, b, cb in s.get("fks", []):
            if a.lower() in have and b.lower() in have:
                all_fks.append((f"{db}::{a.lower()}", f"{db}::{b.lower()}"))
    z = np.load(EMB, allow_pickle=True)
    eids = [str(x).lower() for x in z["ids"]]
    E = z["D"].astype(np.float32)
    epos = {f: i for i, f in enumerate(eids)}

    def doc_tokens(tbl):
        ts = list(wtoks(tbl["name"])) * 2
        for c in tbl["columns"]:
            ts += wtoks(c["name"])
            for v in (c.get("values") or [])[:12]:
                ts += wtoks(str(v))
        return ts

    results = []
    for N in SIZES:
        acc = {m: [] for m in ("bm25", "spectral", "gp", "dense")}
        n_q = 0
        for rep in range(REPS):
            rnd = random.Random(7000 + N * 10 + rep)
            sample = all_tables if N >= len(all_tables) else rnd.sample(all_tables, N)
            have = {t["fid"] for t in sample}
            fks = [(a, b) for a, b in all_fks if a in have and b in have]
            doc_toks = [doc_tokens(t) for t in sample]
            fid2j = {t["fid"]: j for j, t in enumerate(sample)}
            Dn = len(sample)
            # per-catalog df/idf
            df = Counter()
            for ts in doc_toks:
                df.update(set(ts))
            Ntot = Dn
            idf = {t: math.log(1 + (Ntot - df[t] + 0.5) / (df[t] + 0.5)) for t in df}
            tf = np.zeros((Dn, len(df)), dtype=np.float32)
            tidx = {t: i for i, t in enumerate(sorted(df))}
            for j, ts in enumerate(doc_toks):
                for t, c in Counter(ts).items():
                    tf[j, tidx[t]] = c
            dlr = tf.sum(axis=1)
            # spectral rebuild (word+gram)
            gram_toks = [sorted({g for w in ts if len(w) >= 4 for g in ngrams(w)}) for ts in doc_toks]
            k = 128
            Uw, Tw, vw = build_svd_space(doc_toks, k, seed=N + rep)
            Ug, Tg, vg = build_svd_space(gram_toks, k, seed=N + rep + 77)
            vwi = {t: i for i, t in enumerate(vw)}
            vgi = {t: i for i, t in enumerate(vg)}
            Uwn = Uw / np.maximum(np.linalg.norm(Uw, axis=1, keepdims=True), 1e-9)
            Ugn = Ug / np.maximum(np.linalg.norm(Ug, axis=1, keepdims=True), 1e-9)
            # questions kept
            tr = [c for c in cases if c["split"] == "train" and
                  all(f"{c['db_id']}::{g.lower()}" in have for g in c["gold"])]
            te = [c for c in cases if c["split"] == "test" and
                  all(f"{c['db_id']}::{g.lower()}" in have for g in c["gold"])]
            if not te or len(tr) < 30:
                continue
            n_q += len(te)

            def lat_vec(tokens, vocab_i, T):
                vs = [T[vocab_i[t]] for t in set(tokens) if t in vocab_i]
                if not vs:
                    return None
                v = np.mean(vs, axis=0)
                return v / max(np.linalg.norm(v), 1e-9)

            def features(qs):
                F = np.zeros((len(qs), Dn, 10), dtype=np.float32)
                for qi, c in enumerate(qs):
                    qt = wtoks(c["question"])
                    qset, qstem = set(qt), {stem4(w) for w in qt if len(w) >= 4}
                    wv = lat_vec(qt, vwi, Tw)
                    gv = lat_vec([g for w in qt for g in ngrams(w)], vgi, Tg)
                    if wv is not None:
                        F[qi, :, 4] = Uwn @ wv
                    if gv is not None:
                        F[qi, :, 5] = Ugn @ gv
                    s = np.zeros(Dn, dtype=np.float32)
                    for t, qc in Counter(qt).items():
                        if t not in tidx:
                            continue
                        col = tf[:, tidx[t]]
                        s += qc * idf[t] * (col * 2.2) / (col + 1.2 * (0.25 + 0.75 * dlr / (dlr.mean() + 1e-9)))
                    F[qi, :, 3] = s
                    for j, ts in enumerate(doc_toks):
                        dset = set(ts)
                        inter = qset & dset
                        F[qi, j, 0] = len(inter)
                        F[qi, j, 1] = sum(idf.get(t, 0.0) for t in inter)
                        F[qi, j, 2] = len(qstem & {stem4(x) for x in dset if len(x) >= 4})
                        # typed fields
                        nm = set(wtoks(sample[j]["name"]))
                        cl = set(wtoks(" ".join(c2["name"] for c2 in sample[j]["columns"])))
                        vl = set(wtoks(" ".join(str(v) for c2 in sample[j]["columns"]
                                                for v in (c2.get("values") or [])[:12])))
                        F[qi, j, 6] = len(qset & nm)
                        F[qi, j, 7] = len(qset & cl)
                        F[qi, j, 8] = len(qset & vl)
                    F[:, :, 9] = 0
                F[:, :, 9] = np.log1p(F[:, :, 6]) * np.log1p(F[:, :, 7]) * np.log1p(F[:, :, 8])
                return F

            Ft = features(tr)
            mu = Ft.reshape(-1, Ft.shape[-1]).mean(0)
            sd = Ft.reshape(-1, Ft.shape[-1]).std(0) + 1e-9
            Fn = (Ft - mu) / sd
            gold_tr = [{f"{c['db_id']}::{g.lower()}" for g in c["gold"]} for c in tr]

            def fitness_batch(W, chunk=120):
                P = W.shape[0]
                out = np.zeros(P)
                for s0 in range(0, len(tr), chunk):
                    e = min(s0 + chunk, len(tr))
                    sc = Fn[s0:e] @ W.T
                    for p in range(P):
                        part = np.argpartition(-sc[:, :, p], 8, axis=1)[:, :8]
                        for qi in range(e - s0):
                            loc = part[qi]
                            order = loc[np.argsort(-sc[qi, loc, p])]
                            g = gold_tr[s0 + qi]
                            r5 = 0.0
                            for di in order[:5]:
                                if sample[di]["fid"] in g:
                                    r5 += 1.0 / len(g)
                            out[p] += r5
                return out / len(tr)

            rng = np.random.default_rng(7)
            P, G = 80, 60
            pop = rng.uniform(-0.5, 1.5, (P, 10))
            for gen in range(G):
                fit = fitness_batch(pop)
                elite = pop[np.argsort(-fit)[:2]].copy()
                new = [elite[0], elite[1]]
                while len(new) < P:
                    i, j = rng.integers(0, P, 2)
                    a, b = (pop[i], pop[j]) if fit[i] >= fit[j] else (pop[j], pop[i])
                    lam = rng.uniform(-0.25, 1.25, 10)
                    child = a + lam * (b - a)
                    child += (rng.random(10) < 0.25) * rng.normal(0, 0.2, 10)
                    new.append(np.clip(child, -3, 3))
                pop = np.array(new)
            fit = fitness_batch(pop)
            w_best = pop[int(np.argmax(fit))]

            # spectral fusion retune on cell train
            best, best_r = (0.25, 1.0), -1
            for a4 in range(5):
                for b4 in range(5):
                    if a4 + b4 == 0:
                        continue
                    a, b = a4 / 4, b4 / 4
                    tot = 0.0
                    for qi, c in enumerate(tr):
                        qt = wtoks(c["question"])
                        wv = lat_vec(qt, vwi, Tw)
                        gv = lat_vec([g for w in qt for g in ngrams(w)], vgi, Tg)
                        s = np.zeros(Dn, dtype=np.float32)
                        if wv is not None and a > 0:
                            s += a * (Uwn @ wv)
                        if gv is not None and b > 0:
                            s += b * (Ugn @ gv)
                        order = np.argsort(-s)[:5]
                        g = gold_tr[qi]
                        for di in order:
                            if sample[di]["fid"] in g:
                                tot += 1.0 / len(g)
                    if tot / len(tr) > best_r:
                        best_r, best = tot / len(tr), (a, b)
            a_f, b_f = best

            Fte = (features(te) - mu) / sd
            for qi, c in enumerate(te):
                qt = wtoks(c["question"])
                gold = {f"{c['db_id']}::{g.lower()}" for g in c["gold"]}
                qset = set(qt)
                # bm25
                s = np.zeros(Dn, dtype=np.float32)
                for t, qc in Counter(qt).items():
                    if t not in tidx:
                        continue
                    col = tf[:, tidx[t]]
                    s += qc * idf[t] * (col * 2.2) / (col + 1.2 * (0.25 + 0.75 * dlr / (dlr.mean() + 1e-9)))
                r, m = metrics_top([sample[j]["fid"] for j in np.argsort(-s)[:5]], gold)
                acc["bm25"].append((r, m))
                # spectral fused
                wv = lat_vec(qt, vwi, Tw)
                gv = lat_vec([g for w in qt for g in ngrams(w)], vgi, Tg)
                s2 = np.zeros(Dn, dtype=np.float32)
                if wv is not None and a_f > 0:
                    s2 += a_f * (Uwn @ wv)
                if gv is not None and b_f > 0:
                    s2 += b_f * (Ugn @ gv)
                r, m = metrics_top([sample[j]["fid"] for j in np.argsort(-s2)[:5]], gold)
                acc["spectral"].append((r, m))
                # gp
                sc = Fte[qi] @ w_best
                r, m = metrics_top([sample[j]["fid"] for j in np.argsort(-sc)[:5]], gold)
                acc["gp"].append((r, m))
                # dense (frozen rows)
                cand = [epos[t["fid"]] for t in sample if t["fid"] in epos]
                qv = z["Q"][list(map(str, z["qids"])).index(c["qid"])].astype(np.float32)
                sim = E[cand] @ qv
                r, m = metrics_top([eids[cand[j]] for j in np.argsort(-sim)[:5]], gold)
                acc["dense"].append((r, m))
        row = {"N": N, "n_q": n_q}
        for mname, lst in acc.items():
            if lst:
                row[mname] = {"r5": round(float(np.mean([a[0][5] for a in lst])), 4),
                              "top1": round(float(np.mean([a[1] for a in lst])), 4)}
        results.append(row)
        print(json.dumps(row), flush=True)
    json.dump({"sizes": SIZES, "reps": REPS, "runs": results,
               "note": "GA retrained per cell (pop80/gen60); spectral rebuilt+retuned per cell; dense frozen; N=876 cell cited from e12_gp/e12_spectral/e11_spider_dense"},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
