"""E16: forward transfer — Spider-learned covariance weights applied to BIRD.

Train: 12-primitive Spider features, second-order closed form (Fisher, lam .1).
Transfer: the same weight vector applied to BIRD's 11 databases / 500 questions.
Only the 9 primitives that need no Spider-specific resource are used
(drop word-latent, gram-latent, exact-value index):
  0 raw overlap, 1 idf overlap, 2 stem4, 3 bm25, 6 name, 7 column, 8 value,
  9 typed product, 11 db-name.

Feature standardization inside BIRD is per-database (cold-start statistics),
so the only object crossing datasets is the weight vector.
"""
from __future__ import annotations

import json
import math
import sys
from collections import Counter

import numpy as np

sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码\runner")
import e14_db_anchor as e14  # noqa: E402
from e15_objective import fit_fisher, fit_ridge  # noqa: E402

OUT = e14.REPO / "06_结果" / "e16_transfer.json"
KEEP = [0, 1, 2, 3, 6, 7, 8, 9, 11]


def build_bird_db(cache_db, cases):
    tables = cache_db["tables"]
    doc_ids = [t["name"].lower() for t in tables]
    name_t, col_t, val_t, all_t, stem_t = {}, {}, {}, {}, {}
    for t in tables:
        fid = t["name"].lower()
        nm = e14.wtoks(t["name"])
        cl, vl = [], []
        for c in t["columns"]:
            cl += e14.wtoks(c["name"])
            for v in (c.get("values") or [])[:12]:
                vl += e14.wtoks(str(v))
        name_t[fid] = set(nm)
        col_t[fid] = set(cl)
        val_t[fid] = set(vl)
        all_t[fid] = set(nm) | set(cl) | set(vl)
        stem_t[fid] = {e14.stem4(x) for x in all_t[fid] if len(x) >= 4}
    D = len(doc_ids)
    df = Counter()
    for ts in all_t.values():
        df.update(ts)
    idf = {t: math.log(1 + (D - df[t] + 0.5) / (df[t] + 0.5)) for t in df}
    tf = np.zeros((D, len(df)), dtype=np.float32)
    tidx = {t: i for i, t in enumerate(sorted(df))}
    for j, f in enumerate(doc_ids):
        for t in all_t[f]:
            tf[j, tidx[t]] = 1.0
    dlr = tf.sum(axis=1)

    F = np.zeros((len(cases), D, 9), dtype=np.float32)
    for qi, c in enumerate(cases):
        qt = e14.wtoks(c["question"])
        qset = set(qt)
        qstem = {e14.stem4(w) for w in qt if len(w) >= 4}
        s = np.zeros(D, dtype=np.float32)
        for t, qc in Counter(qt).items():
            if t not in tidx:
                continue
            col = tf[:, tidx[t]]
            s += qc * idf[t] * (col * 2.2) / (col + 1.2 * (0.25 + 0.75 * dlr / (dlr.mean() + 1e-9)))
        F[qi, :, 0] = 0
        F[qi, :, 1] = 0
        F[qi, :, 2] = 0
        F[qi, :, 3] = s
        for j, f in enumerate(doc_ids):
            inter = qset & all_t[f]
            F[qi, j, 0] = len(inter)
            F[qi, j, 1] = sum(idf.get(t, 0.0) for t in inter)
            F[qi, j, 2] = len(qstem & stem_t[f])
            F[qi, j, 4] = len(qset & name_t[f])
            F[qi, j, 5] = len(qset & col_t[f])
            F[qi, j, 6] = len(qset & val_t[f])
        F[qi, :, 7] = np.log1p(F[qi, :, 4]) * np.log1p(F[qi, :, 5]) * np.log1p(F[qi, :, 6])
        F[qi, :, 8] = 0
    return F, doc_ids


def main():
    meta = e14.load()
    print("building Spider train features…", flush=True)
    Ft = meta["build_F"](meta["train_q"])[:, :, KEEP]
    mu = Ft.reshape(-1, 9).mean(0)
    sd = Ft.reshape(-1, 9).std(0) + 1e-9
    Fn = ((Ft - mu) / sd).reshape(-1, 9)
    Y = np.zeros((len(meta["train_q"]), meta["D"]), dtype=np.float32)
    for qi, q in enumerate(meta["train_q"]):
        for f in meta["gold_all"][q]:
            j = meta["didx"].get(f)
            if j is not None:
                Y[qi, j] = 1.0
    y = Y.reshape(-1)
    idx = [(i, j) for i in range(9) for j in range(i, 9)]
    Fn2 = np.concatenate([Fn, e14.quad(Fn, idx)], axis=1)
    w1 = fit_fisher(Fn, y, 0.1)
    w2 = fit_fisher(Fn2, y, 0.1)
    print("Spider train pairs:", Fn.shape, "second:", Fn2.shape, flush=True)
    print("Spider 9-prim first:", json.dumps(
        e14.evaluate(meta, ((meta["build_F"](meta["test_q"])[:, :, KEEP] - mu) / sd).reshape(-1, 9)
                     .reshape(len(meta["test_q"]), meta["D"], -1), w1)[0]), flush=True)
    print("Spider 9-prim second:", json.dumps(
        e14.evaluate(meta, np.concatenate(
            [((meta["build_F"](meta["test_q"])[:, :, KEEP] - mu) / sd).reshape(-1, 9),
             e14.quad(((meta["build_F"](meta["test_q"])[:, :, KEEP] - mu) / sd).reshape(-1, 9), idx)],
            axis=1).reshape(len(meta["test_q"]), meta["D"], -1), w2)[0]), flush=True)

    cache = json.load(open(e14.CACHE, encoding="utf-8"))["bird"]
    cases = json.load(open(e14.CASES, encoding="utf-8"))["bird"]
    by_db = {}
    for c in cases:
        by_db.setdefault(c["db_id"], []).append(c)

    rows = []
    for db, cs in sorted(by_db.items()):
        F, doc_ids = build_bird_db(cache[db], cs)
        mu_b = F.reshape(-1, 9).mean(0)
        sd_b = F.reshape(-1, 9).std(0) + 1e-9
        Fz = ((F - mu_b) / sd_b).reshape(-1, 9)
        Fz2 = np.concatenate([Fz, e14.quad(Fz, idx)], axis=1)
        for qi, c in enumerate(cs):
            gold = {g.lower() for g in c["gold"]}
            for name, w, Z in [("transfer_first", w1, Fz), ("transfer_second", w2, Fz2)]:
                sc = Z.reshape(len(cs), len(doc_ids), -1)[qi] @ w
                order = np.argsort(-sc)[:5]
                top = [doc_ids[i] for i in order]
                r, m = e14.metrics_top(top, gold)
                rows.append({"qid": c["qid"], "db": db, "gold": sorted(gold),
                             "method": name, "top5": top,
                             "recall@1": r[1], "recall@3": r[3], "recall@5": r[5], "mrr": m})

    out = {}
    for name in ("transfer_first", "transfer_second"):
        sub = [r for r in rows if r["method"] == name]
        out[name] = {k: round(sum(r[k] for r in sub) / len(sub), 4)
                     for k in ("recall@1", "recall@3", "recall@5", "mrr")}
        print(name, json.dumps(out[name]), flush=True)

    json.dump({"spider_train": {"first_9": Fn.shape[1], "second_9": Fn2.shape[1]},
               "bird": out,
               "bird_reference": {"bm25_r1": 0.3963, "bm25_r5": 0.8628,
                                  "ppr_r1": 0.4273, "ppr_r5": 0.9133,
                                  "typed_r1": 0.4247, "typed_r5": 0.9127},
               "weights": {"first": w1.tolist(), "second": w2.tolist()},
               "rows": rows},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
