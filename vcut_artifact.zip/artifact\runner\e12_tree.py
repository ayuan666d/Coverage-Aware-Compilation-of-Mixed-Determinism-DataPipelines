"""E12 addendum 2: tree-form GP over the primitive DSL — is 82.2% the ceiling
of the SEARCH or of the LINEAR SCORING FAMILY?

Same features as e12_gp (plus one FK-sibling primitive motivated by the weak
residue dissection), same train/test split, same fitness (train R@5), same
GA budget class.  The only change: the scoring function is an expression TREE
(+ - * protected/ max min | abs log1p sqrt over z-normalised features) instead
of a weight vector.  If tree-GP lands at the same test R@5 as linear-GA, the
82.2% is the search ceiling; if it is clearly higher, the linear family was
the binding constraint.
"""
from __future__ import annotations

import json
import math
import random
import re
from collections import Counter
from pathlib import Path

import numpy as np

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
CASES = REPO / "06_结果" / "e11_cases.json"
CACHE = WORK / "schema_cache.json"
NPZ = WORK / "e12_spectral.npz"
EXACT = REPO / "06_结果" / "e12_exact.json"
OUT = REPO / "06_结果" / "e12_tree.json"

WORD = re.compile(r"[a-z0-9]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us list show give find return
number names name""".split())

FEATS = ["ov_raw", "ov_idf", "stem", "bm25", "cos_word", "cos_gram",
         "name_hit", "col_hit", "val_hit", "typed", "fk_sib"]


def wtoks(s):
    return [t for t in WORD.findall(s.lower()) if t not in STOP]


def ngrams(w, ns=(3, 4, 5)):
    pad = f"<{w}>"
    return {pad[i:i + n] for n in ns for i in range(len(pad) - n + 1)} if len(pad) >= 3 else set()


def stem4(w):
    return w[:4] if len(w) >= 4 else w


def metrics_top(top_ids, gold_set):
    r = {1: 0.0, 3: 0.0, 5: 0.0}
    mrr = 0.0
    for i, d in enumerate(top_ids[:5]):
        if d in gold_set:
            mrr = max(mrr, 1.0 / (i + 1))
            for k in r:
                if i < k:
                    r[k] += 1.0 / len(gold_set)
    return r, mrr


# ---------- tree machinery ----------

BIN = ("add", "sub", "mul", "pdiv", "max", "min")
UN = ("abs", "log1p", "sqrt0")


def tree_eval(t, F):
    op = t[0]
    if op == "feat":
        return F[:, :, t[1]]
    if op == "const":
        return np.full(F.shape[:2], t[1], dtype=np.float32)
    if op in BIN:
        a, b = tree_eval(t[2], F), tree_eval(t[3], F)
        if op == "add":
            return a + b
        if op == "sub":
            return a - b
        if op == "mul":
            return a * b
        if op == "pdiv":
            return a / (np.abs(b) + 1e-6)
        if op == "max":
            return np.maximum(a, b)
        return np.minimum(a, b)
    a = tree_eval(t[2], F)
    if op == "abs":
        return np.abs(a)
    if op == "log1p":
        return np.log1p(np.maximum(a, 0.0))
    return np.sqrt(np.maximum(a, 0.0))


def tree_nodes(t):
    if t[0] in ("feat", "const"):
        return 1
    if t[0] in BIN:
        return 1 + tree_nodes(t[2]) + tree_nodes(t[3])
    return 1 + tree_nodes(t[2])


def tree_depth(t):
    if t[0] in ("feat", "const"):
        return 1
    if t[0] in BIN:
        return 1 + max(tree_depth(t[2]), tree_depth(t[3]))
    return 1 + tree_depth(t[2])


def rand_tree(rng, depth, leaf_p=0.4):
    if depth <= 1 or rng.random() < leaf_p:
        if rng.random() < 0.75:
            return ("feat", rng.randrange(len(FEATS)))
        return ("const", round(rng.choice([0.0, 0.5, 1.0, -1.0]), 2))
    if rng.random() < 0.7:
        op = rng.choice(BIN)
        return (op, None, rand_tree(rng, depth - 1, leaf_p), rand_tree(rng, depth - 1, leaf_p))
    op = rng.choice(UN)
    return (op, None, rand_tree(rng, depth - 1, leaf_p))


def pick_subtree(t, rng):
    nodes = []

    def walk(x, path):
        nodes.append((path, x))
        if x[0] in BIN:
            walk(x[2], path + (2,))
            walk(x[3], path + (3,))
        elif x[0] in UN:
            walk(x[2], path + (2,))
    walk(t, ())
    path, _ = nodes[rng.randrange(len(nodes))]
    return path


def replace_at(t, path, new):
    if not path:
        return new
    i, *rest = path
    if t[0] in BIN:
        ch = list(t)
        ch[i] = replace_at(t[i], rest, new)
        return tuple(ch)
    ch = list(t)
    ch[i] = replace_at(t[i], rest, new)
    return tuple(ch)


def subtree(t, path):
    for i in path:
        t = t[i]
    return t


def crossover(a, b, rng):
    pa, pb = pick_subtree(a, rng), pick_subtree(b, rng)
    child = replace_at(a, pa, subtree(b, pb))
    return child if tree_nodes(child) <= 15 and tree_depth(child) <= 4 else a


def mutate(a, rng):
    pa = pick_subtree(a, rng)
    child = replace_at(a, pa, rand_tree(rng, rng.choice([1, 2, 3])))
    return child if tree_nodes(child) <= 15 and tree_depth(child) <= 4 else a


# ---------- features (same as e12_gp + fk_sib) ----------

def main():
    z = np.load(NPZ, allow_pickle=True)
    doc_ids = [str(x) for x in z["doc_ids"]]
    didx = {f: i for i, f in enumerate(doc_ids)}
    D = len(doc_ids)
    doc_wn = z["doc_word"] / np.maximum(np.linalg.norm(z["doc_word"], axis=1, keepdims=True), 1e-9)
    doc_gn = z["doc_gram"] / np.maximum(np.linalg.norm(z["doc_gram"], axis=1, keepdims=True), 1e-9)

    cache = json.load(open(CACHE, encoding="utf-8"))["spider"]
    name_t, col_t, val_t, all_t, stem_t, nbr = {}, {}, {}, {}, {}, {}
    for db, s in cache.items():
        have = {t["name"].lower() for t in s["tables"]}
        for t in s["tables"]:
            fid = f"{db}::{t['name'].lower()}"
            nm = list(wtoks(t["name"]))
            cl, vl = [], []
            for c in t["columns"]:
                cl += wtoks(c["name"])
                for v in (c.get("values") or [])[:12]:
                    vl += wtoks(str(v))
            name_t[fid], col_t[fid], val_t[fid] = set(nm), set(cl), set(vl)
            all_t[fid] = set(nm) | set(cl) | set(vl)
            stem_t[fid] = {stem4(x) for x in all_t[fid] if len(x) >= 4}
        for a, ca, b, cb in s.get("fks", []):
            if a.lower() in have and b.lower() in have:
                nbr.setdefault(f"{db}::{a.lower()}", set()).add(f"{db}::{b.lower()}")
                nbr.setdefault(f"{db}::{b.lower()}", set()).add(f"{db}::{a.lower()}")
    df = Counter()
    for ts in all_t.values():
        df.update(ts)
    N = D
    idf = {t: math.log(1 + (N - df[t] + 0.5) / (df[t] + 0.5)) for t in df}
    tf = np.zeros((D, len(df)), dtype=np.float32)
    tidx = {t: i for i, t in enumerate(sorted(df))}
    for j, f in enumerate(doc_ids):
        for t in all_t[f]:
            tf[j, tidx[t]] = 1.0
    dlr = tf.sum(axis=1)

    exact = {r["qid"]: r for r in json.load(open(EXACT, encoding="utf-8"))}
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    gold_all = {c["qid"]: {f"{c['db_id']}::{g.lower()}" for g in c["gold"]} for c in cases}
    qtext = {c["qid"]: c["question"] for c in cases}
    split = {c["qid"]: c["split"] for c in cases}
    qids = sorted(qtext, key=lambda q: int(q[2:]))
    train_q = [q for q in qids if split[q] == "train"]
    test_q = [q for q in qids if split[q] == "test"]

    wv_vocab = {t: i for i, t in enumerate(z["word_vocab"])}
    gr_vocab = {t: i for i, t in enumerate(z["gram_vocab"])}
    term_w, term_g = z["term_word"], z["term_gram"]

    def q_latent(tokens, vocab, term):
        vs = [term[vocab[t]] for t in set(tokens) if t in vocab]
        if not vs:
            return None
        v = np.mean(vs, axis=0)
        return v / max(np.linalg.norm(v), 1e-9)

    def build_F(qs):
        F = np.zeros((len(qs), D, len(FEATS)), dtype=np.float32)
        for qi, q in enumerate(qs):
            qt = wtoks(qtext[q])
            qset = set(qt)
            qstem = {stem4(w) for w in qt if len(w) >= 4}
            wv = q_latent(qt, wv_vocab, term_w)
            gv = q_latent([g for w in qt for g in ngrams(w)], gr_vocab, term_g)
            if wv is not None:
                F[qi, :, 4] = doc_wn @ wv
            if gv is not None:
                F[qi, :, 5] = doc_gn @ gv
            s = np.zeros(D, dtype=np.float32)
            for t, qc in Counter(qt).items():
                if t not in tidx:
                    continue
                col = tf[:, tidx[t]]
                s += qc * idf[t] * (col * 2.2) / (col + 1.2 * (0.25 + 0.75 * dlr / (dlr.mean() + 1e-9)))
            F[qi, :, 3] = s
            for j, f in enumerate(doc_ids):
                inter = qset & all_t[f]
                F[qi, j, 0] = len(inter)
                F[qi, j, 1] = sum(idf.get(t, 0.0) for t in inter)
                F[qi, j, 2] = len(qstem & stem_t[f])
                F[qi, j, 6] = len(qset & name_t[f])
                F[qi, j, 7] = len(qset & col_t[f])
                F[qi, j, 8] = len(qset & val_t[f])
                fk = 0.0
                for u in nbr.get(f, ()):
                    if u != f and u in all_t:
                        fk += sum(idf.get(t, 0.0) for t in (qset & all_t[u]))
                F[qi, j, 10] = fk
            F[:, :, 9] = 0
        F[:, :, 9] = np.log1p(F[:, :, 6]) * np.log1p(F[:, :, 7]) * np.log1p(F[:, :, 8])
        return F

    print("building features (train)…", flush=True)
    Ft = build_F(train_q)
    mu = Ft.reshape(-1, Ft.shape[-1]).mean(0)
    sd = Ft.reshape(-1, Ft.shape[-1]).std(0) + 1e-9
    Fn = (Ft - mu) / sd
    del Ft
    gold_tr = [gold_all[q] for q in train_q]

    def fitness(trees, chunk=120):
        out = []
        for t in trees:
            total = 0.0
            for s0 in range(0, len(train_q), chunk):
                e = min(s0 + chunk, len(train_q))
                sc = np.clip(tree_eval(t, Fn[s0:e]), -50, 50)
                for qi in range(e - s0):
                    part = np.argpartition(-sc[qi], 8)[:8]
                    order = part[np.argsort(-sc[qi][part])]
                    g = gold_tr[s0 + qi]
                    r5 = 0.0
                    for di in order[:5]:
                        if doc_ids[di] in g:
                            r5 += 1.0 / len(g)
                    total += r5
            out.append(total / len(train_q))
        return np.array(out)

    rng = random.Random(11)
    P, G = 40, 30
    pop = [rand_tree(rng, rng.choice([2, 3])) for _ in range(P)]
    hist = []
    for gen in range(G):
        fit = fitness(pop)
        hist.append(round(float(fit.max()), 4))
        idx = np.argsort(-fit)
        new = [pop[idx[0]], pop[idx[1]]]
        while len(new) < P:
            i, j = rng.sample(range(P), 2)
            a, b = (pop[i], pop[j]) if fit[i] >= fit[j] else (pop[j], pop[i])
            child = crossover(a, b, rng) if rng.random() < 0.9 else mutate(a, rng)
            if rng.random() < 0.25:
                child = mutate(child, rng)
            new.append(child)
        pop = new
        if (gen + 1) % 5 == 0:
            print(f"  gen {gen+1}: best train R@5={fit.max():.4f}", flush=True)
    fit = fitness(pop)
    best = pop[int(np.argmax(fit))]
    print("train best R@5:", round(float(fit.max()), 4))
    print("best tree:", best)

    print("building features (test)…", flush=True)
    Fte = (build_F(test_q) - mu) / sd
    rows = []
    for qi, q in enumerate(test_q):
        sc = np.clip(tree_eval(best, Fte[qi:qi + 1]), -50, 50)[0]
        order = np.argsort(-sc)[:5]
        top = [doc_ids[i] for i in order]
        r, m = metrics_top(top, gold_all[q])
        rows.append({"qid": q, "db": next(c["db_id"] for c in cases if c["qid"] == q),
                     "gold": sorted(gold_all[q]), "top5": top,
                     "recall@1": r[1], "recall@3": r[3], "recall@5": r[5], "mrr": m})
    n = len(rows)
    summ = {k: round(sum(x[k] for x in rows) / n, 4) for k in ("recall@1", "recall@3", "recall@5", "mrr")}
    print("tree-gp test:", json.dumps(summ))
    json.dump({"tree": str(best), "train_curve": hist, "test_metrics": summ, "rows": rows},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
