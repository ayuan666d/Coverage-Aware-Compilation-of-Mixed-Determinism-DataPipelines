"""E11-LAYERS-SMALL: the layered certificate outside the 876-table lake.

2.15's zero-false-pass layer (word AND identifier-only support, both chance-corrected,
alpha=0.05) was priced on one corpus.  This runs the same two layers per database on BIRD
and on the Spider known-DB setting, on our column-level arm, with the null rebuilt from
each catalogue's own document frequencies (so the correction is scale-local, as it must be).

Pre-registered: same alpha, same construction, no retuning; report accepted / false passes
for word, name and word&name in each setting.  The interesting quantity is the DIRECTION of
change: in a 5-table schema identifiers are shared by almost everything, so chance is high
and the layer should go quiet -- if it instead stamps everything, the construction is wrong.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_surprise import chance_tail  # noqa: E402
from e11_col import col_index, gm  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
WORK = Path("D:/vldb2027_e11")
OUT = R / "e11_layers_small.json"
ALPHA = 0.05
EPS, ALPHA_PPR, ITERS, TOPK = 1e-6, 0.85, 20, 30


def corpora(cat):
    """Table docs (names+values), identifier-only docs, and column docs."""
    tab_all, tab_name, col_docs = [], [], []
    for t in cat.tables:
        a, n = [], []
        nt = toks(t["name"])
        a += nt
        n += nt
        for c in t["columns"]:
            cn = toks(c["name"])
            a += cn
            n += cn
            cv = []
            for v in c.get("values", [])[:6]:
                tv = toks(v)[:3]
                a += tv
                cv += tv
            col_docs.append(cn + cv)
        tab_all.append(a)
        tab_name.append(n)
    return {"word": tab_all, "name": tab_name, "col": col_docs}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", choices=["bird", "known"], required=True)
    args = ap.parse_args()
    g.SPLIT_IDENT = True
    cache = json.load(open(WORK / "schema_cache.json", encoding="utf-8"))
    allc = json.load(open(R / "e11_cases.json", encoding="utf-8"))
    if args.kind == "bird":
        cases_all, dbs = allc["bird"], cache["bird"]
        emb = WORK / "e11_emb_bird.npz"
    else:
        cases_all = [c for c in allc["spider"] if c["split"] == "test"]
        dbs = cache["spider"]
        emb = WORK / "e11_emb_spider.npz"
    z = np.load(emb, allow_pickle=True)
    ids = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}
    cand_by_db = {}
    for i, t in enumerate(ids):
        cand_by_db.setdefault(t.split("::")[0], []).append(i)

    rows = []
    t0 = time.time()
    for db, s in sorted(dbs.items()):
        cs = [c for c in cases_all if c["db_id"] == db]
        if not cs:
            continue
        tabs = [dict(t, db=db) for t in s["tables"]]
        cat = g.Catalog(tabs, s["fks"], prefix_db=False)
        N = len(cat.tables)
        corp = corpora(cat)
        colnodes, cdocs, starts, ends = col_index(cat)
        tok_tab, tok_col, idf_of = {}, {}, {}
        for w in sorted({w for c in cs for w in toks(c["question"])}):
            k = ("token", w)
            if k not in cat.idx:
                continue
            x = g.ppr(cat.union, {cat.idx[k]: 1.0}, ALPHA_PPR, ITERS)
            st = cat.table_scores(x)
            mx = float(st.max())
            if mx <= 0:
                continue
            tok_tab[w] = (st / mx).astype(np.float32)
            idf_of[w] = math.log(1 + (N - cat.token_df.get(w, 0) + 0.5)
                                 / (cat.token_df.get(w, 0) + 0.5))
            cv = np.asarray(x)[colnodes].astype(np.float32)
            cmx = float(cv.max())
            tok_col[w] = cv / cmx if cmx > 0 else cv
        inc = {}
        for typ, docs in corp.items():
            d = {}
            for j, doc in enumerate(docs):
                for w in set(doc):
                    v = d.get(w)
                    if v is None:
                        v = d[w] = np.zeros(len(docs), dtype=np.float32)
                    v[j] += 1.0
            inc[typ] = d
        dfs = {typ: {w: sum(1 for doc in corp[typ] if w in set(doc)) for w in d}
               for typ, d in inc.items()}
        for c in cs:
            q = set(toks(c["question"]))
            gold = set(c["gold"])
            ws = sorted({w for w in q if w in tok_tab})
            b = g.bm25(cat, q)
            top = np.argsort(-b)[:min(TOPK, N)]
            base = float(b[top[-1]])
            if ws:
                iw = np.array([idf_of[w] for w in ws], dtype=np.float32)[:, None]
                Tt = np.maximum.reduceat(np.stack([tok_col[w] for w in ws]), starts, axis=1)
                sc = gm(Tt, iw)
            else:
                sc = np.zeros(N, dtype=np.float32)
            mixed = b.copy()
            for i, idx in enumerate(top[np.argsort(-sc[top])]):
                mixed[idx] = base + (len(top) - i) * 1e-6
            r = g.rank(mixed, cat)
            t1 = r[0]
            pos = cat.table_pos[t1]
            m = g.metrics(r, gold)
            rec = {"qid": c["qid"], "db": db, "n_tables": N, "top1": t1,
                   "correct": bool(t1 in gold), "r1": round(m["recall@1"], 4),
                   "r5": round(m["recall@5"], 4), "n_cols": len(corp["col"])}
            for typ in ("word", "name", "col"):
                d = inc[typ]
                cnt = np.zeros(len(corp[typ]), dtype=np.float32)
                ql = []
                for w in q:
                    v = d.get(w)
                    if v is None:
                        continue
                    cnt += v
                    ql.append(dfs[typ].get(w, 0))
                M = len(corp[typ])
                obs = cnt[pos] if typ != "col" else cnt[starts[pos]:ends[pos]].max() if ends[pos] > starts[pos] else 0.0
                tail, padj = chance_tail(ql, M, int(obs))
                rec[typ] = {"support": float(obs), "p_beyond": round(padj, 5),
                            "pass": bool(padj <= ALPHA)}
            if c["qid"] in qpos:
                cand = cand_by_db.get(db, [])
                sim = Dm[cand] @ Qm[qpos[c["qid"]]]
                order = [ids[cand[i]].split("::", 1)[1] for i in np.argsort(-sim)]
                md = g.metrics(order, gold)
                rec["dense"] = {"r1": round(md["recall@1"], 4), "r5": round(md["recall@5"], 4)}
            rows.append(rec)
        print(f"{db}: {len(cs)} q / {N} tables ({time.time()-t0:.0f}s)", flush=True)

    def rate(pred):
        acc = [r for r in rows if pred(r)]
        fp = sum(1 for r in acc if not r["correct"])
        return {"accepted": len(acc), "false_pass": fp,
                "precision": round(1 - fp / len(acc), 4) if acc else None,
                "cov": round(len(acc) / len(rows), 4)}

    out = {"kind": args.kind, "n": len(rows), "alpha": ALPHA,
           "mean_tables": round(float(np.mean([r["n_tables"] for r in rows])), 2),
           "arm_top1_acc": round(float(np.mean([r["correct"] for r in rows])), 4),
           "word": rate(lambda r: r["word"]["pass"]),
           "name": rate(lambda r: r["name"]["pass"]),
           "col": rate(lambda r: r["col"]["pass"]),
           "word_and_name": rate(lambda r: r["word"]["pass"] and r["name"]["pass"]),
           "word_and_col": rate(lambda r: r["word"]["pass"] and r["col"]["pass"]),
           "rows": rows}
    op = Path(str(OUT).replace(".json", f"_{args.kind}.json"))
    json.dump(out, open(op, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=1, ensure_ascii=False))
    print("wrote", op)


if __name__ == "__main__":
    main()
