"""E12 leg 6: gradient learning arm — fine-tune the 0.6B embedding on the SAME
693 train-database questions the GA used (matched supervision), Multiple-
NegativesRankingLoss, then evaluate on the merged test split.

Doc text is built exactly like the E11 dense protocol (table name + columns +
sampled values), so the only change vs the zero-shot dense baseline is the
gradient step.  Completes the pre-registered triple:
fixed structure (spectral) vs searched structure (GA) vs gradient learning.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
MODEL = WORK / "models" / "Qwen3-Embedding-0.6B"
CASES = REPO / "06_结果" / "e11_cases.json"
CACHE = WORK / "schema_cache.json"
OUT = REPO / "06_结果" / "e12_ft.json"


def doc_text(db, t):
    parts = [f"{db} :: {t['name']}"]
    cols, vals = [], []
    for c in t["columns"]:
        cols.append(c["name"])
        vals += [str(v) for v in (c.get("values") or [])[:12]]
    parts.append("columns: " + ", ".join(cols))
    if vals:
        parts.append("values: " + ", ".join(vals))
    return " | ".join(parts)


def main():
    import torch
    from sentence_transformers import SentenceTransformer, InputExample, losses
    from torch.utils.data import DataLoader

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    print("device:", dev, flush=True)

    cache = json.load(open(CACHE, encoding="utf-8"))["spider"]
    docs, doc_ids = [], []
    for db, s in sorted(cache.items()):
        for t in s["tables"]:
            doc_ids.append(f"{db}::{t['name'].lower()}")
            docs.append(doc_text(db, t))

    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    gold = {c["qid"]: {f"{c['db_id']}::{g.lower()}" for g in c["gold"]} for c in cases}
    qtext = {c["qid"]: c["question"] for c in cases}
    train_q = [c["qid"] for c in cases if c["split"] == "train"]
    test_q = [c["qid"] for c in cases if c["split"] == "test"]
    dmap = {f: i for i, f in enumerate(doc_ids)}

    model = SentenceTransformer(str(MODEL), device=dev)
    model.max_seq_length = 128

    pairs = []
    for q in train_q:
        for g in gold[q]:
            if g in dmap:
                pairs.append(InputExample(texts=[qtext[q], docs[dmap[g]]]))
    print(f"train pairs: {len(pairs)}", flush=True)
    loader = DataLoader(pairs, shuffle=True, batch_size=16)
    loss = losses.MultipleNegativesRankingLoss(model)
    model.fit(train_objectives=[(loader, loss)], epochs=3, warmup_steps=20,
              show_progress_bar=False, optimizer_params={"lr": 2e-5})
    print("fine-tune done", flush=True)

    Ddoc = model.encode(docs, batch_size=32, convert_to_numpy=True,
                        normalize_embeddings=True, show_progress_bar=False)
    Dq = model.encode([qtext[q] for q in test_q], batch_size=32, convert_to_numpy=True,
                      normalize_embeddings=True, show_progress_bar=False,
                      prompt_name="query")
    S = Dq @ Ddoc.T
    rows = []
    for qi, q in enumerate(test_q):
        order = np.argsort(-S[qi])[:5]
        top = [doc_ids[i] for i in order]
        g = gold[q]
        r = {1: 0.0, 3: 0.0, 5: 0.0}
        mrr = 0.0
        for i, t in enumerate(top):
            if t in g:
                mrr = max(mrr, 1 / (i + 1))
                for k in r:
                    if i < k:
                        r[k] += 1 / len(g)
        rows.append({"qid": q, "db": next(c["db_id"] for c in cases if c["qid"] == q),
                     "gold": sorted(g), "top5": top,
                     "recall@1": r[1], "recall@3": r[3], "recall@5": r[5], "mrr": mrr})
    n = len(rows)
    summ = {k: round(sum(x[k] for x in rows) / n, 4) for k in ("recall@1", "recall@3", "recall@5", "mrr")}
    print("ft test:", json.dumps(summ))
    json.dump({"device": dev, "pairs": len(pairs), "epochs": 3, "test_metrics": summ, "rows": rows},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
