"""E7p: re-judge the stored DeepSeek outputs with the current checker.

The model calls are the expensive part and are already stored.  Re-running the
deterministic checker offline keeps code and reported numbers in sync without
spending API budget.
"""
from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e7_receipts as e7  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
SRC = REPO / "06_结果" / "e7_receipts_raw.json"
OUT = REPO / "06_结果" / "e7_receipts.json"


def main():
    rows = json.load(open(SRC, encoding="utf-8"))["rows"]
    for r in rows:
        j = e7.judge(r["model"], r["gold"], r["text"])
        r.update(j)
    n = len(rows)
    verdicts = Counter(r["verdict"] for r in rows)
    known = [r for r in rows if r["model_total_correct"] is not None]
    acc = sum(r["model_total_correct"] for r in known) / max(1, len(known))
    accepted = [r for r in rows if r["verdict"] in ("accept", "fill")]
    fp = sum(1 for r in accepted if r["total_correct"] is False)
    fills = [r for r in rows if r["verdict"] == "fill"]
    summary = {
        "n": n, "verdicts": dict(verdicts),
        "model_total_accuracy": round(acc, 4),
        "final_total_accuracy": round(
            sum(r["total_correct"] for r in rows if r["total_correct"] is not None)
            / max(1, sum(1 for r in rows if r["total_correct"] is not None)), 4),
        "accepted": len(accepted), "automation": round(len(accepted) / n, 4),
        "false_pass": fp, "false_pass_rate": round(fp / n, 4),
        "accepted_precision": round((len(accepted) - fp) / len(accepted), 4) if accepted else None,
        "wrong_model_total": sum(1 for r in rows if r["model_total_correct"] is False),
        "caught_wrong_total": sum(1 for r in rows if r["verdict"] == "reject"
                                  and r["model_total_correct"] is False),
        "fill_count": len(fills),
        "fill_correct": sum(1 for r in fills if r["total_correct"]),
        "fill_precision": round(sum(1 for r in fills if r["total_correct"]) / len(fills), 4) if fills else None,
        "closure_accept": verdicts.get("accept", 0),
        "usage_tokens": sum((r["usage"] or {}).get("total_tokens", 0) for r in rows),
        "errors": sum(1 for r in rows if r.get("error")),
    }
    json.dump({"summary": summary, "rows": rows}, open(OUT, "w", encoding="utf-8"),
              ensure_ascii=False)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
