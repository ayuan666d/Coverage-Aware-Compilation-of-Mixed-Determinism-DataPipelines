"""E7b: execution consensus as a deterministic verdict.

Thirteen real model outputs per question are executed against the real
database.  The verdict node sees only *result equivalence classes* (it never
sees the gold query): if every successful execution agrees, the answer is
accepted; otherwise it is sent to review.  This measures whether redundancy
can substitute for the semantic certificate that structural checks cannot
provide.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e7_sql_pilot as e7  # noqa: E402

REPO = e7.REPO
OUT = REPO / "06_结果" / "e7b_consensus.json"


def sig(res: e7.ExecResult) -> str | None:
    if not res.ok:
        return None
    rows = e7.canon_rows(res.rows)
    h = hashlib.sha1()
    for row in sorted(rows):
        h.update(repr(row).encode())
        h.update(b"\x00")
    return f"{len(rows)}:{h.hexdigest()[:16]}"


def run_question(case: dict, preds: dict[str, dict[int, str]], timeout: float):
    gold = e7.execute(case["db_path"], case["SQL"], timeout=timeout)
    gold_sig = sig(gold)
    per_model = {}
    for model, p in preds.items():
        if case["idx"] not in p:
            continue
        sql = e7.first_statement(p[case["idx"]])
        res = e7.execute(case["db_path"], sql, timeout=timeout)
        per_model[model] = {
            "sql": sql,
            "ok": res.ok,
            "err": res.err,
            "sig": sig(res),
            "n_rows": len(res.rows),
            "ms": round(res.ms, 3),
        }
    return {
        "idx": case["idx"],
        "qid": case["question_id"],
        "db": case["db_id"],
        "difficulty": case["difficulty"],
        "question": case["question"],
        "gold_sql": case["SQL"],
        "gold_sig": gold_sig,
        "gold_ok": gold.ok,
        "models": per_model,
    }


def summarize(groups: list[dict], model_votes: dict[str, float] | None = None) -> dict:
    """groups: per-question dicts with `votes` (model->sig) and `gold_sig`."""
    results = {}
    for alpha in (1.0, 0.8, 0.6, 0.5):
        for kmin in (2, 3, 5):
            n = accepted = correct = 0
            false_pass = 0
            correct_review = 0
            wrong_review = 0
            for g in groups:
                votes = g["votes"]
                n_ok = len(votes)
                n += 1
                if n_ok < kmin:
                    if g["gold_sig"] is not None:
                        correct_review += 1
                    continue
                counts = Counter(votes.values())
                top_sig, top_n = counts.most_common(1)[0]
                # alpha=1.0 means unanimous
                if alpha == 1.0:
                    ok = len(counts) == 1
                else:
                    ok = top_n >= max(kmin, int(alpha * n_ok + 0.999999))
                if not ok:
                    if top_sig == g["gold_sig"]:
                        correct_review += 1
                    else:
                        wrong_review += 1
                    continue
                accepted += 1
                if top_sig == g["gold_sig"]:
                    correct += 1
                else:
                    false_pass += 1
            results[f"a{alpha}_k{kmin}"] = {
                "n": n,
                "accept": accepted,
                "automation": round(accepted / n, 4) if n else 0,
                "precision": round(correct / accepted, 4) if accepted else None,
                "false_pass": false_pass,
                "false_pass_rate": round(false_pass / n, 4) if n else 0,
                "correct_review": correct_review,
                "wrong_review": wrong_review,
            }
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--timeout", type=float, default=8.0)
    args = ap.parse_args()

    cases = e7.load_cases(args.limit)
    preds = {}
    for p in sorted(e7.PRED_DIR.glob("*.json")) + sorted(e7.PRED_TA.glob("*.json")):
        preds[e7.model_name(p)] = e7.load_preds(p)
    print(f"cases={len(cases)} models={len(preds)}", flush=True)

    rows = []
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(run_question, c, preds, args.timeout): c for c in cases}
        for i, fut in enumerate(as_completed(futs), 1):
            rows.append(fut.result())
            if i % 100 == 0:
                print(f"{i}/{len(cases)}", flush=True)
    rows.sort(key=lambda r: r["idx"])

    # Only keep questions whose gold executed
    rows = [r for r in rows if r["gold_ok"]]
    groups = []
    for r in rows:
        votes = {m: v["sig"] for m, v in r["models"].items() if v["ok"] and v["sig"]}
        groups.append({"votes": votes, "gold_sig": r["gold_sig"]})

    # also evaluate subsets: zero-shot only, CoT only, top-5 by single-model acc
    e7_summary = None
    p = REPO / "06_结果" / "e7_sql_pilot.json"
    if p.exists():
        e7_summary = json.load(p.open(encoding="utf-8"))["summary"]
    top_models = sorted(e7_summary, key=lambda m: -e7_summary[m]["exec_acc"])[:5] if e7_summary else []

    def subset(names):
        gs = []
        for r in rows:
            votes = {m: v["sig"] for m, v in r["models"].items()
                     if m in names and v["ok"] and v["sig"]}
            gs.append({"votes": votes, "gold_sig": r["gold_sig"]})
        return gs

    out = {
        "n": len(rows),
        "models": sorted(preds),
        "all": summarize(groups),
        "top5": summarize(subset(top_models)),
        "top3": summarize(subset(top_models[:3])),
        "cot": summarize(subset([m for m in preds if m.endswith("-cot")])),
        "zero_shot": summarize(subset([m for m in preds if not m.endswith("-cot")])),
        "top_models": top_models,
        "rows": rows,
    }
    OUT.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    for key in ("all", "top5", "top3", "cot", "zero_shot"):
        print(f"\n== {key} ==")
        for k, v in out[key].items():
            print(k, v)
    print("\nwrote", OUT)


if __name__ == "__main__":
    main()
