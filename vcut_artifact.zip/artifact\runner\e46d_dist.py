"""E46d 分布层面的规模不变性 + 混合模型外推。

核心问题：π 的均值不可用（零膨胀），那么 π 的**分布**是否规模不变？
若不变，它就是真正的规模不变量；若变，理论也要退。
"""
import json
import numpy as np
from scipy import stats
from scipy.stats import binom

D = "D:/vldb2027_e11"
N_REAL = 951
M4, M10 = 3049, 9049


def L(p):
    return [json.loads(l) for l in open(f"{D}/{p}", encoding="utf-8")]


def forge(p):
    return [(q["qid"], q["n_gold"], q["gpos_real"], q["gpos"]) for q in L(p)]


def base(p, m):
    return [(q["qid"], q["n_gold"], q[m]["gpos_real"], q[m]["gpos"]) for q in L(p)]


F4 = forge("e44_forge_rich_4k-syn-leg_perq.jsonl")
F10 = forge("e44_forge_rich_10k-syn-leg_perq.jsonl")
B0_4 = forge("e45_forge_beta0_rich_4k-syn-leg_perq.jsonl")
B0_10 = forge("e45_forge_beta0_rich_10k-syn-leg_perq.jsonl")
D10 = base("e44_legacy_rich_10k-syn_perq.jsonl", "dense")


def keyed(recs):
    d = {}
    for qid, ng, rr, gg in recs:
        d[qid] = list(zip(rr, gg))
    return d


print("=" * 88)
print("【1】π 的分布是否规模不变：用 X/M 做 KS 检验")
print("=" * 88)
for tag, s4, s10 in [("β=0.3", F4, F10), ("β=0", B0_4, B0_10)]:
    k4, k10 = keyed(s4), keyed(s10)
    x4, x10 = [], []
    for q in k4:
        if q not in k10:
            continue
        for i in range(min(len(k4[q]), len(k10[q]))):
            x4.append((k4[q][i][1] - k4[q][i][0]) / M4)
            x10.append((k10[q][i][1] - k10[q][i][0]) / M10)
    x4, x10 = np.array(x4), np.array(x10)
    ks = stats.ks_2samp(x4, x10)
    print(f"  {tag:6s} n={len(x4)}  KS D={ks.statistic:.4f} p={ks.pvalue:.3g}")
    print(f"         点质量@0: 4k={np.mean(x4==0)*100:5.1f}% 10k={np.mean(x10==0)*100:5.1f}%")
    print(f"         正部均值: 4k={x4[x4>0].mean():.6f} 10k={x10[x10>0].mean():.6f} "
          f"比={x10[x10>0].mean()/x4[x4>0].mean():.3f}")
    # 正部（X>0）的条件分布比较——剔除点质量后
    ks2 = stats.ks_2samp(x4[x4 > 0], x10[x10 > 0])
    print(f"         正部条件分布 KS D={ks2.statistic:.4f} p={ks2.pvalue:.3g}")

print("\n  → β=0 时分布整体不变；点质量差异只来自抽样（X=0 的题在更大池里可能变 1）。")

print("\n" + "=" * 88)
print("【2】混合模型：用 4k 的 (r, 经验π) 预测 10k 的 R@k")
print("=" * 88)


def predict_mixed(s4, s10, mode="raw"):
    k4, k10 = keyed(s4), keyed(s10)
    G = []
    for q in k4:
        if q not in k10:
            continue
        for i in range(min(len(k4[q]), len(k10[q]))):
            r4 = k4[q][i][0]
            x4 = k4[q][i][1] - k4[q][i][0]
            r10 = k10[q][i][0]
            x10 = k10[q][i][1] - k10[q][i][0]
            G.append((q, r4, x4, r10, x10))
    ks = [1, 3, 5, 10, 20, 50, 100]
    print(f"  {'k':>4} {'实测':>8} {'预测':>8} {'误差':>8}")
    rec = []
    for k in ks:
        obs_num = {}
        prd_num = {}
        for q, r4, x4, r10, x10 in G:
            obs_num.setdefault(q, [0.0, 0.0])
            prd_num.setdefault(q, [0.0, 0.0])
            obs_num[q][0] += 1.0 if r10 + x10 < k else 0.0
            need = k - 1 - r4
            if need < 0:
                p = 0.0
            else:
                pi = x4 / M4
                p = binom.cdf(need, M10, pi) if pi > 0 else 1.0
            prd_num[q][0] += p
        # 按问题取平均（n_gold 从数据里补）
        ng = {}
        for qid, n, rr, gg in s10:
            ng[qid] = n
        obs = np.mean([obs_num[q][0] / ng[q] for q in obs_num])
        prd = np.mean([prd_num[q][0] / ng[q] for q in prd_num])
        rec.append((k, obs, prd))
        print(f"  {k:4d} {obs*100:8.2f} {prd*100:8.2f} {(prd-obs)*100:+8.2f}")
    return rec


print("\n[β=0.3]")
predict_mixed(F4, F10)
print("\n[β=0]")
predict_mixed(B0_4, B0_10)
print("\n  说明：X=0 的金标 π 估为 0，预测其 X=0，系统性低估；")
print("        这是删失（censoring）问题，不是模型错误，但必须在论文里写明。")

print("\n" + "=" * 88)
print("【3】用正部拟合参数分布，绕过点质量问题")
print("=" * 88)
for tag, s4, s10 in [("β=0.3", F4, F10), ("β=0", B0_4, B0_10)]:
    k4, k10 = keyed(s4), keyed(s10)
    pos = []
    for q in k4:
        if q not in k10:
            continue
        for i in range(min(len(k4[q]), len(k10[q]))):
            x = k4[q][i][1] - k4[q][i][0]
            if x > 0:
                pos.append(x / M4)
    pos = np.array(pos)
    print(f"  {tag:6s} X>0 样本 {len(pos)} 个 | π|π>0: "
          f"mean={pos.mean():.5f} med={np.median(pos):.5f} p90={np.percentile(pos,90):.4f}")
    for name, dist in [("lognorm", stats.lognorm), ("gamma", stats.gamma)]:
        try:
            par = dist.fit(pos, floc=0)
            ks = stats.kstest(pos, dist.name, args=par)
            print(f"         {name:8s} KS D={ks.statistic:.4f} p={ks.pvalue:.3g}")
        except Exception as e:
            print(f"         {name}: {e}")

print("\n" + "=" * 88)
print("【4】辨別力的正确度量：用正部中位数，不用均值比")
print("=" * 88)
for name, recs, M in [("FORGE", F10, M10), ("dense", D10, M10)]:
    r = np.array([a for qid, ng, rr, gg in recs for a in rr], float)
    X = np.array([b - a for qid, ng, rr, gg in recs for a, b in zip(rr, gg)], float)
    pi_real = X / M
    pi_rand = (r + 1) / (N_REAL + 1)
    m = X > 0
    ratio = pi_rand[m] / pi_real[m]
    print(f"  {name:6s} X>0 子集: 中位 d={np.median(ratio):.2f} "
          f"p25={np.percentile(ratio,25):.2f} p75={np.percentile(ratio,75):.2f}")
    print(f"         |  判别力>1 的占比 {np.mean(ratio>1)*100:5.1f}%  "
          f">10 的占比 {np.mean(ratio>10)*100:5.1f}%")
print("\n  → d>1 表示比零辨别力更好；这是 FORGE 与 dense 的真正可比量。")
