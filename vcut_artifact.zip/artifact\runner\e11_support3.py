"""E11-SUPPORT3: the frozen certificate has to work outside the catalogue it was
frozen in.

e11_support2.py chose support>=3 & rarest-anchor-df<=2 on the 132 training
databases of the 876-table merged catalogue.  This script applies that rule
unchanged to the two small-schema settings (BIRD 11 dbs, Spider known 34 dbs).

One honest caveat is handled before looking at any accuracy: an absolute df
threshold is catalogue-size dependent -- in a 6-table database almost every token
has df<=2, so the rule degenerates to "accept everything".  Both readings are
reported: the frozen absolute rule, and a scale-normalised version
df <= max(2, 0.02 * n_tables) chosen by a stated formula, not by peeking.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
OUT = REPO / "06_结果" / "e11_support3_known.json"
EPS = 1e-6
K_FROZEN, M_FROZEN = 3, 2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", choices=["bird", "known"], required=True)
    args = ap.parse_args()
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    allc = json.load(open(CASES, encoding="utf-8"))
    if args.kind == "bird":
        cases_all, dbs = allc["bird"], cache["bird"]
        emb = Path("D:/vldb2027_e11/e11_emb_bird.npz")
    else:
        cases_all = [c for c in allc["spider"] if c["split"] == "test"]
        dbs = cache["spider"]
        emb = Path("D:/vldb2027_e11/e11_emb_spider.npz")
    z = np.load(emb, allow_pickle=True)
    ids = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}
    by_db_pos = {}
    for i, t in enumerate(ids):
        by_db_pos.setdefault(t.split("::")[0], []).append(i)

    rows = []
    t0 = time.time()
    by = {}
    for c in cases_all:
        by.setdefault(c["db_id"], []).append(c)
    for db, cs in sorted(by.items()):
        if db not in dbs:
            continue
        tabs = [dict(t, db=db) for t in dbs[db]["tables"]]
        cat = g.Catalog(tabs, dbs[db]["fks"], prefix_db=False)
        N = len(cat.tables)
        tok = {}
        for w in sorted({w for c in cs for w in toks(c["question"])}):
            if ("token", w) not in cat.idx:
                continue
            x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
            s = cat.table_scores(x)
            mx = float(s.max())
            tok[w] = s / mx if mx > 0 else s
        idf = {w: math.log(1 + (N - cat.token_df.get(w, 0) + 0.5) / (cat.token_df.get(w, 0) + 0.5))
               for w in tok}
        cand = by_db_pos.get(db, [])
        for c in cs:
            q = toks(c["question"])
            gold = set(c["gold"])
            ws = [w for w in set(q) if w in tok]
            if ws:
                M = np.stack([tok[w] for w in ws])
                iw = np.array([idf[w] for w in ws])[:, None]
                graph = np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
            else:
                graph = np.zeros(N, dtype=np.float32)
            b = g.bm25(cat, q)
            top = np.argsort(-b)[:min(30, N)]
            mixed = b.copy()
            base = float(b[top[-1]])
            for i, idx in enumerate(top[np.argsort(-graph[top])]):
                mixed[idx] = base + (len(top) - i) * 1e-6
            r_rr = g.rank(mixed, cat)
            m_rr = g.metrics(r_rr, gold)
            top1 = r_rr[0]
            k = len(set(q) & set(g.table_doc(cat.tables[cat.table_pos[top1]])))
            m = min([cat.token_df.get(w, 10 ** 9) for w in ws], default=10 ** 9)
            rec = {"qid": c["qid"], "db": db, "n_tables": N, "k": k, "m": m,
                   "rr_r1": round(m_rr["recall@1"], 4), "rr_r5": round(m_rr["recall@5"], 4),
                   "rr_mrr": round(m_rr["mrr"], 4)}
            if cand:
                sim = Dm[cand] @ Qm[qpos[c["qid"]]]
                rk = [ids[cand[i]].split("::", 1)[1] for i in np.argsort(-sim)]
                m_d = g.metrics(rk, gold)
                rec["dense_r1"] = round(m_d["recall@1"], 4)
                rec["dense_r5"] = round(m_d["recall@5"], 4)
                rec["dense_mrr"] = round(m_d["mrr"], 4)
            rows.append(rec)
    print(f"{args.kind}: {len(rows)} questions in {time.time()-t0:.0f}s", flush=True)

    def read(sel, name):
        acc = [r for r in rows if sel(r)]
        rej = [r for r in rows if not sel(r)]
        f = lambda s, key: round(float(np.mean([r[key] for r in s])), 4) if s else None  # noqa: E731
        return {"rule": name, "accept_cov": round(len(acc) / len(rows), 4),
                "accepted_graph_r1": f(acc, "rr_r1"), "accepted_dense_r1": f(acc, "dense_r1"),
                "accepted_graph_r5": f(acc, "rr_r5"), "accepted_dense_r5": f(acc, "dense_r5"),
                "hybrid_r1": round((sum(r["rr_r1"] for r in acc) + sum(r["dense_r1"] for r in rej)) / len(rows), 4),
                "hybrid_r5": round((sum(r["rr_r5"] for r in acc) + sum(r["dense_r5"] for r in rej)) / len(rows), 4)}

    out = {"kind": args.kind, "n": len(rows),
           "graph_only": {"r1": round(float(np.mean([r["rr_r1"] for r in rows])), 4),
                          "r5": round(float(np.mean([r["rr_r5"] for r in rows])), 4)},
           "dense_only": {"r1": round(float(np.mean([r["dense_r1"] for r in rows])), 4),
                          "r5": round(float(np.mean([r["dense_r5"] for r in rows])), 4)},
           "frozen_absolute": read(lambda r: r["k"] >= K_FROZEN and r["m"] <= M_FROZEN,
                                   f"k>={K_FROZEN} & df<={M_FROZEN}"),
           "scale_normalised": read(lambda r: r["k"] >= K_FROZEN
                                    and r["m"] <= max(M_FROZEN, 0.02 * r["n_tables"]),
                                    f"k>={K_FROZEN} & df<=max(2,2%N)"),
           "support_only": read(lambda r: r["k"] >= K_FROZEN, f"k>={K_FROZEN} only"),
           "rows": rows}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
