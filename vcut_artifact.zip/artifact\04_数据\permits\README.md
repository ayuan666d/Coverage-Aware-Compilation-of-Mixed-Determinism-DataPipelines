# 作业票 JSONL schema（E2 的唯一数据接口）

E2 的 `runner/e2.py` 只读一种格式：每行一条作业票。真实数据、CUAD 桥接数据、
mock 生成器都归一到这个 schema。

## 字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `id` | string | 唯一 id |
| `pre` | object | 结构化字段，必须覆盖决策表的 pre 字段 |
| `post_true` | object | 人工/真值抽取结果，必须覆盖 post 字段；用于算 F1 与 true verdict |
| `text` | string | 原始文本（扫描件/合同条款）；mock 可为空 |
| `true_verdict` | string? | 缺省时由决策表在 `pre + post_true` 上算出；**不要人工标** |

pre 字段（GB 表 v0.2）：

```
work_type, fire_level, valid_hours, approval_level,
multi_permit, multi_permits_ok, approver_authorized,
guardian_certified, gas_before_approval
```

post 字段：

```
measures_done, lel, o2, isolated, cleanup
```

## 约定

- `fire_level` 对非动火作业填 `"none"`，不要省略；缺失字段会被判 review。
- `valid_hours` 是数字（小时）；`lel` 是 % LEL；`o2` 是 %。
- `text` 是模型实际读到的内容；`post_true` 不能喂给模型，只用于评测。
- 真实数据脱敏后再入库；原始扫描件不进 git。

## 示例

见 `04_数据/permits/sample_documents.jsonl`（5 条合成样例，只用于接口冒烟）。

## `documents_web.jsonl` 的来路（重要）

公开渠道没有“真实填写作业票”的机器可读语料：官方只发空白模板，文库站要付费/登录，
竞赛数据有授权限制。当前文件是 30 份的**混合语料**，由 `build_web_corpus.py` 生成：

| `source` | 数量 | 是什么 | 能声称什么 |
|---|---|---|---|
| `public_filled_example` | 8 | 公开填写范例（甲醇车间 2022 年八大票）转写，来源：世展网 `shifair.com/informationDetails/101788.html`、人人文档 `m.renrendoc.com/paper/177943272.html` | 文本是公开的；未在文中出现的字段填 `null`，表判 `review` |
| `generated_public_template` | 22 | 按官方八票结构生成，70% 合规 / 20% 单违规 / 10% 缺字段，部分加 OCR 噪声 | **不是真实作业票**；只能验证管线与分布敏感性 |

每条带 `variant`（`compliant` / `violation:<rule>` / `missing`）便于分层。
跑 E2 时报告必须写明这段来路，不能把 `generated_public_template` 当真实语料。

这 8 份公开范例都缺关键字段（审批级别、完整气体分析、清理验收），真值因此全是
`review`；它们只能测“模型会不会编造缺失字段”，不能测 pass/reject 的区分能力。
这是公开语料的硬限制，不是标注偷懒。

```bash
cd 04_数据/permits
python build_web_corpus.py --n 22
```

## 跑真实 API（E2）

`runner/e2.py` 的 `APIExtractor` 走 OpenAI-compatible `/chat/completions`。默认：
`deepseek-flash`（cheap）与 `deepseek-v4-pro`（exp），base URL `https://api.deepseek.com`。

```bash
export DEEPSEEK_API_KEY='<your-key>'
cd 05_代码
python runner/e2.py --api --docs ../04_数据/permits/documents.jsonl --pilot
```

产物：`06_结果/e2_api.json` + `06_结果/E2_API_报告.md`。报告里的成本列是 **token**，
不是钱；跨模型比较要乘各自单价。没有真实语料时，`--api` 会跑 `gen_docs` 渲染的
合成文本，报告状态会标“非论文证据”。
