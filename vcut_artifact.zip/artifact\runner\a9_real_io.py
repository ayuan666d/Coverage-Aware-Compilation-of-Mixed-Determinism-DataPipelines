# -*- coding: utf-8 -*-
"""A9: real-I/O runtime — 1M decisions with actual side effects, threads, audit.

Modes:
  marker : verdict only, audit in memory (the A2 prototype)
  file   : sink appends to a file; audit NDJSON with batched fsync (1 and 4 threads)
  sqlite : sink inserts into a WAL table (batched commits)
  http   : sink POSTs to a local echo server (keep-alive, 4 threads)

Correctness runs: cover=1.0/reject -> 0 unjudged actions; cover=0.3/pass ->
exactly 75% of inputs execute without a verdict.
"""
from __future__ import annotations

import http.client
import json
import os
import sqlite3
import statistics
import sys
import threading
import time
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

OUT = Path(r"E:\vldb2027_pipeline_safety\06_结果\a9_real_io.json")
WORK = Path(r"E:\vldb2027_pipeline_safety\06_结果\_a9_tmp")
VALUES = ("normal", "normal2", "normal3", "malformed")
ACCEPTS = ("normal", "normal2", "normal3")


class Echo(BaseHTTPRequestHandler):
    count = 0
    lock = threading.Lock()

    def do_POST(self):  # noqa: N802
        n = int(self.headers.get("Content-Length", "0"))
        self.rfile.read(n)
        with Echo.lock:
            Echo.count += 1
        self.send_response(200)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, *a):
        pass


def start_server():
    srv = ThreadingHTTPServer(("127.0.0.1", 18080), Echo)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def decide(v):
    return "pass" if v in ACCEPTS else "reject"


def run_marker(n):
    lat = []
    executed = 0
    for i in range(n):
        s = time.perf_counter_ns()
        v = VALUES[i % 4]
        d = decide(v)
        if d == "pass":
            executed += 1
        lat.append(time.perf_counter_ns() - s)
    return lat, executed, 0, 0


def run_file(n, threads, fsync_every=1000):
    lat_all = [[] for _ in range(threads)]
    executed = [0] * threads
    t0 = time.perf_counter()

    def worker(k):
        audit = open(WORK / f"audit_{k}.ndjson", "w", encoding="utf-8")
        sink = open(WORK / f"sink_{k}.log", "w", encoding="utf-8")
        buf = 0
        for i in range(k, n, threads):
            s = time.perf_counter_ns()
            v = VALUES[i % 4]
            d = decide(v)
            if d == "pass":
                sink.write(f"{i}\t{v}\n")
                executed[k] += 1
            audit.write(json.dumps({"i": i, "v": v, "d": d}) + "\n")
            buf += 1
            if buf >= fsync_every:
                audit.flush()
                os.fsync(audit.fileno())
                buf = 0
            lat_all[k].append(time.perf_counter_ns() - s)
        audit.flush()
        os.fsync(audit.fileno())
        audit.close()
        sink.close()

    ts = [threading.Thread(target=worker, args=(k,)) for k in range(threads)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    wall = time.perf_counter() - t0
    lat = [x for sub in lat_all for x in sub]
    size = sum(f.stat().st_size for f in WORK.glob("*.ndjson")) + sum(
        f.stat().st_size for f in WORK.glob("*.log"))
    return lat, sum(executed), wall, size


def run_sqlite(n):
    db = WORK / "actions.db"
    if db.exists():
        db.unlink()
    con = sqlite3.connect(db)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("CREATE TABLE actions (i INTEGER, v TEXT)")
    lat = []
    executed = 0
    batch = []
    t0 = time.perf_counter()
    for i in range(n):
        s = time.perf_counter_ns()
        v = VALUES[i % 4]
        d = decide(v)
        if d == "pass":
            batch.append((i, v))
            executed += 1
            if len(batch) >= 1000:
                con.executemany("INSERT INTO actions VALUES (?,?)", batch)
                con.commit()
                batch.clear()
        lat.append(time.perf_counter_ns() - s)
    if batch:
        con.executemany("INSERT INTO actions VALUES (?,?)", batch)
        con.commit()
    con.close()
    wall = time.perf_counter() - t0
    size = db.stat().st_size
    return lat, executed, wall, size


def run_http(n, threads):
    lat_all = [[] for _ in range(threads)]
    executed = [0] * threads
    t0 = time.perf_counter()

    def worker(k):
        conn = http.client.HTTPConnection("127.0.0.1", 18080, timeout=5)
        for i in range(k, n, threads):
            s = time.perf_counter_ns()
            v = VALUES[i % 4]
            d = decide(v)
            if d == "pass":
                conn.request("POST", "/act", body=b"x", headers={"Content-Length": "1"})
                conn.getresponse().read()
                executed[k] += 1
            lat_all[k].append(time.perf_counter_ns() - s)
        conn.close()

    ts = [threading.Thread(target=worker, args=(k,)) for k in range(threads)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    wall = time.perf_counter() - t0
    lat = [x for sub in lat_all for x in sub]
    return lat, sum(executed), wall, 0


def stats(lat, n, wall):
    lat.sort()
    q = lambda p: lat[min(len(lat) - 1, int(len(lat) * p))] / 1000.0
    return {"n": n, "wall_s": round(wall, 3),
            "us_per_decision": round(sum(lat) / len(lat) / 1000.0, 2),
            "p50_us": round(q(.50), 2), "p95_us": round(q(.95), 2), "p99_us": round(q(.99), 2),
            "decisions_per_s": int(n / wall) if wall else 0}


def main():
    WORK.mkdir(parents=True, exist_ok=True)
    for f in WORK.glob("*"):
        f.unlink()
    srv = start_server()
    out = {"modes": {}, "correctness": {}}

    n = 1_000_000
    lat, ex, _, _ = run_marker(n)
    t0 = time.perf_counter()
    # rerun timing above already includes loop only; recompute wall from lat
    wall = sum(lat) / 1e9
    out["modes"]["marker_1M_1t"] = dict(stats(lat, n, wall), executed=ex, audit_bytes=0)

    lat, ex, wall, size = run_file(n, 1)
    out["modes"]["file_1M_1t"] = dict(stats(lat, n, wall), executed=ex, audit_bytes=size)
    lat, ex, wall, size = run_file(n, 4)
    out["modes"]["file_1M_4t"] = dict(stats(lat, n, wall), executed=ex, audit_bytes=size)

    lat, ex, wall, size = run_sqlite(n)
    out["modes"]["sqlite_1M_1t"] = dict(stats(lat, n, wall), executed=ex, db_bytes=size)

    lat, ex, wall, _ = run_http(100_000, 4)
    out["modes"]["http_100k_4t"] = dict(stats(lat, 100_000, wall), executed=ex,
                                        server_count=Echo.count)

    # correctness: cover=1.0/reject vs cover=0.3/pass, 100k each
    for cover, fb in ((1.0, "reject"), (0.3, "pass")):
        accepted = VALUES[: round(4 * cover)]
        executed = 0
        blocked = 0
        unjudged = 0
        for i in range(100_000):
            v = VALUES[i % 4]
            if v in accepted:
                executed += 1
            elif fb == "pass":
                executed += 1
                unjudged += 1
            else:
                blocked += 1
        out["correctness"][f"cover={cover},fb={fb}"] = {
            "decisions": 100_000, "executed": executed, "blocked": blocked,
            "unjudged_actions": unjudged}

    srv.shutdown()
    out["note"] = ("marker wall is the sum of per-decision latencies (no I/O); "
                   "file modes use batched fsync every 1000 audit rows; sqlite uses "
                   "1000-row batched commits; http is a local echo server, keep-alive, 4 threads")
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
