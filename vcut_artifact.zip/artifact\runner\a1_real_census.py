# -*- coding: utf-8 -*-
"""A1: real-framework workflow census.

Parse real framework artifacts into one IR and apply the paper's two-part
criterion (vertex cut + fallback/coverage semantics) to each pipeline:

  U  unprotected : a high-risk sink exists, no verdict node anywhere
  H  hole        : a verdict node exists, but a high-risk sink is reachable
                   through pass channels only (default/else branch, no branch edge)
  S  covered     : every high-risk sink is reachable only after a verdict edge
  N  no sink     : nothing high-risk to guard

Pass channel definition per framework:
  Dify   : all edges except edges leaving an if-else / question-classifier
           node through a non-default handle (rule / class handle).
           The if-else `false` handle is the fallback = a pass channel.
  Airflow: all edges except edges leaving a branch / short-circuit task
           (skip semantics = conservative fallback: unselected task is skipped).

Inputs: Dify DSL YAML (community library, real exports), Airflow DAG .py
(official example DAGs, static AST parse).
"""
from __future__ import annotations

import ast
import glob
import io
import json
import os
import re
import sys
from collections import Counter, deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

import yaml

DIFY_DIR = r"E:\vldb2027_pipeline_safety\04_数据\external\dify_dsl"
DIFY_DIRS = [DIFY_DIR, r"E:\vldb2027_pipeline_safety\04_数据\external\dify_dsl_more"]
AIRFLOW_DIR = r"E:\vldb2027_pipeline_safety\04_数据\external\airflow_dags"
OUT_JSON = r"E:\vldb2027_pipeline_safety\06_结果\a1_real_census.json"


@dataclass
class Graph:
    framework: str
    name: str
    path: str
    nodes: Dict[str, str] = field(default_factory=dict)      # id -> kind
    labels: Dict[str, str] = field(default_factory=dict)
    edges: List[Tuple[str, str, str]] = field(default_factory=list)  # src,dst,handle
    sinks: Set[str] = field(default_factory=set)
    verdicts: Set[str] = field(default_factory=set)
    entries: Set[str] = field(default_factory=set)
    notes: List[str] = field(default_factory=list)

    def succ(self) -> Dict[str, List[str]]:
        s = {n: [] for n in self.nodes}
        for a, b, _ in self.edges:
            s.setdefault(a, []).append(b)
        return s

    def sources(self) -> List[str]:
        has_in = {b for a, b, h in self.edges if h == "pass"}
        has_in_all = {b for a, b, _ in self.edges}
        return sorted(n for n in self.nodes if n not in has_in_all)


# ── reachability on pass channels only ────────────────────────────


def verdict_edges(g: Graph) -> Set[Tuple[str, str, str]]:
    """Edges that leave a verdict node through a guarded (non-pass) handle."""
    out = set()
    for a, b, h in g.edges:
        if a in g.verdicts and h != "pass":
            out.add((a, b, h))
    return out


def pass_reach(g: Graph) -> Set[str]:
    """Nodes reachable from a source using only pass channels."""
    succ = {}
    guarded = verdict_edges(g)
    for a, b, h in g.edges:
        if (a, b, h) in guarded:
            continue
        succ.setdefault(a, []).append(b)
    seen = set(g.entries) if g.entries else set(g.sources())
    dq = deque(seen)
    while dq:
        u = dq.popleft()
        for v in succ.get(u, []):
            if v not in seen:
                seen.add(v)
                dq.append(v)
    return seen


def analyse(g: Graph) -> dict:
    reach = pass_reach(g)
    unsafe = sorted(s for s in g.sinks if s in reach)
    if not g.sinks:
        status = "N"
    elif not g.verdicts:
        status = "U"
    elif unsafe:
        status = "H"
    else:
        status = "S"
    # coverage: fraction of high-risk sinks that are behind a verdict edge
    cov = 0.0 if not g.sinks else round(1 - len(unsafe) / len(g.sinks), 4)
    return {
        "framework": g.framework,
        "name": g.name,
        "file": os.path.basename(g.path),
        "nodes": len(g.nodes),
        "edges": len(g.edges),
        "sinks": sorted(g.sinks),
        "sink_labels": [g.labels.get(s, s) for s in sorted(g.sinks)],
        "verdicts": sorted(g.verdicts),
        "verdict_labels": [g.labels.get(v, v) for v in sorted(g.verdicts)],
        "unsafe_sinks": unsafe,
        "status": status,
        "sink_coverage": cov,
        "notes": g.notes,
    }


# ── Dify ─────────────────────────────────────────────────────────

DIFY_VERDICT = {"if-else", "question-classifier"}
READ_TOOL = re.compile(r"search|reader|crawl|scrap|query|get|list|fetch|知识|retriev|translat|"
                       r"翻译|搜索|查询|获取|读取|weather|天气|chart|图表|时间", re.I)
WRITE_TOOL = re.compile(r"create|update|send|post|delete|remove|write|upload|insert|pay|"
                        r"login|订单创建|支付|创建|更新|发送|删除|写入|上传|登录|下单", re.I)
SIDE_EFFECT_CODE = re.compile(r"requests\.|urllib|http\.client|subprocess|os\.system|os\.popen|shutil\.|open\s*\([^)]*['\"][wa]", re.I)


def dify_high_risk(kind: str, data: dict) -> bool:
    if kind == "agent":
        return True                      # unbounded tool space
    if kind == "http-request":
        m = str(data.get("method", "get")).lower()
        return m in ("post", "put", "patch", "delete")
    if kind == "code":
        code = str(data.get("code", ""))
        return bool(SIDE_EFFECT_CODE.search(code))
    if kind == "tool":
        name = " ".join(str(data.get(k, "")) for k in ("tool_name", "provider_name", "title", "tool_label"))
        if WRITE_TOOL.search(name):
            return True
        if READ_TOOL.search(name):
            return False
        return True                      # unknown tool: conservative
    return False


def parse_dify(path: str) -> Graph:
    d = yaml.safe_load(io.open(path, encoding="utf-8"))
    g = d.get("workflow", {}).get("graph", {}) or {}
    name = d.get("app", {}).get("name") or os.path.basename(path)
    G = Graph("dify", str(name), path)
    for n in g.get("nodes", []):
        nid = str(n.get("id"))
        data = n.get("data", {}) or {}
        kind = str(data.get("type", "?"))
        G.nodes[nid] = kind
        G.labels[nid] = str(data.get("title") or kind)
        if kind in DIFY_VERDICT:
            G.verdicts.add(nid)
        if kind == "start":
            G.entries.add(nid)
        if dify_high_risk(kind, data):
            G.sinks.add(nid)
    for e in g.get("edges", []):
        a, b = str(e.get("source")), str(e.get("target"))
        h = str(e.get("sourceHandle") or "")
        # if-else: 'false' is the default/fallback branch; everything else is a rule
        if a in G.verdicts and G.nodes.get(a) == "if-else":
            h = "pass" if h == "false" else "rule"
        elif a in G.verdicts:
            h = "rule"
        else:
            h = "pass"
        G.edges.append((a, b, h))
    return G


# ── Airflow ──────────────────────────────────────────────────────

AF_BRANCH = {"BranchPythonOperator", "ShortCircuitOperator"}
AF_ALWAYS_SINK = {"EmailOperator", "HttpOperator", "SimpleHttpOperator", "SSHOperator",
                  "SFTPOperator", "DockerOperator", "KubernetesPodOperator",
                  "TriggerDagRunOperator"}
BASH_SIDE = re.compile(r"curl|wget|rm\s|mv\s|cp\s|mkdir|>>|\btouch\b|pip install|"
                       r"spark-submit|python\s+\S+\.py|>", re.I)
PY_SIDE = re.compile(r"requests\.(post|put|patch|delete)|session\.(post|put|delete)|"
                     r"open\s*\([^)]*['\"][wa]|os\.remove|os\.system|subprocess|shutil|"
                     r"\.execute\s*\(|\.insert\s*\(|\.delete\s*\(", re.I)
AF_OTHER = {"EmptyOperator", "DummyOperator", "NoOpOperator", "Label", "TaskGroup"}
AF_EXEC = {"BashOperator", "PythonOperator"} | AF_ALWAYS_SINK


def af_is_sink(var: str, P: "AfParser") -> bool:
    op = P.task_ops.get(var, "")
    if op in AF_ALWAYS_SINK:
        return True
    if op == "BashOperator":
        call = P.task_calls.get(var)
        for kw in (call.keywords if call is not None else []):
            if kw.arg == "bash_command" and isinstance(kw.value, ast.Constant):
                return bool(BASH_SIDE.search(str(kw.value.value)))
        return True
    fname = P.task_callees.get(var)
    call = P.task_calls.get(var)
    if fname is None and call is not None:
        for kw in call.keywords:
            if kw.arg in ("python_callable", "python_callable_name") and isinstance(kw.value, ast.Name):
                fname = kw.value.id
    if fname is None and var in P.funcs:
        fname = var
    fn = P.funcs.get(fname) if fname else None
    if fn is None:
        return True                      # opaque callable: conservative
    return bool(PY_SIDE.search(ast.unparse(fn)))


class AfParser(ast.NodeVisitor):
    def __init__(self, path: str):
        self.path = path
        self.tasks: Dict[str, str] = {}       # var -> kind
        self.task_ids: Dict[str, str] = {}    # var -> task_id
        self.task_ops: Dict[str, str] = {}    # var -> operator name
        self.task_callees: Dict[str, str] = {}  # var -> callable function name
        self.task_calls: Dict[str, ast.Call] = {}
        self.edges: List[Tuple[str, str, str]] = []
        self.funcs: Dict[str, ast.FunctionDef] = {}
        self.branch_funcs: Set[str] = set()
        self.short_funcs: Set[str] = set()
        self.task_funcs: Set[str] = set()

    def visit_FunctionDef(self, node):
        for dec in node.decorator_list:
            txt = ast.unparse(dec).split("(")[0]
            if txt.endswith(".branch") or txt == "branch" or txt.endswith("branch_task"):
                self.branch_funcs.add(node.name)
                self.tasks[node.name] = "branch"
            elif txt.endswith(".short_circuit") or txt == "short_circuit":
                self.short_funcs.add(node.name)
                self.tasks[node.name] = "branch"
            elif txt == "task" or txt.endswith(".task"):
                self.task_funcs.add(node.name)
                self.tasks[node.name] = "exec"
            self.task_ids.setdefault(node.name, node.name)
        self.funcs[node.name] = node
        self.generic_visit(node)

    @property
    def _known_ids(self) -> Set[str]:
        return {self.task_ids.get(v, v) for v in self.tasks}

    def visit_Assign(self, node):
        # t0 = BashOperator(...) / PythonOperator(...) / decorated call
        if isinstance(node.value, ast.Call):
            call = node.value
            fname = ast.unparse(call.func).split(".")[-1]
            for tgt in node.targets:
                if isinstance(tgt, ast.Name):
                    var = tgt.id
                    kind = ("exec" if fname in AF_EXEC else
                            "branch" if fname in AF_BRANCH else
                            "other" if fname in AF_OTHER else None)
                    if fname in self.task_funcs or fname in self.branch_funcs:
                        kind = "branch" if fname in self.branch_funcs else "exec"
                    if kind is None:
                        continue
                    self.tasks[var] = kind
                    self.task_ops[var] = fname
                    self.task_calls[var] = call
                    if fname in self.funcs:
                        self.task_callees[var] = fname
                    tid = var
                    for kw in call.keywords:
                        if kw.arg == "task_id" and isinstance(kw.value, ast.Constant):
                            tid = str(kw.value.value)
                    self.task_ids[var] = tid
        self.generic_visit(node)

    def _name(self, n) -> Optional[str]:
        if isinstance(n, ast.Name):
            return n.id
        if isinstance(n, ast.Call):
            return ast.unparse(n.func).split(".")[-1]
        if isinstance(n, ast.Constant) and isinstance(n.value, str):
            return n.value
        return None

    def _endpoints(self, n) -> List[str]:
        """Registered task ids at the exit of an `>>` expression; [] for non-tasks."""
        if isinstance(n, (ast.List, ast.Tuple)):
            out = []
            for e in n.elts:
                out += self._endpoints(e)
            return out
        if isinstance(n, ast.BinOp):
            # (a >> b) >> c : endpoints come from the right if it is a task
            r = self._endpoints(n.right)
            return r if r else self._endpoints(n.left)
        nm = self._name(n)
        if nm is None or nm in ("Label", "TaskGroup"):
            return []
        tid = self.task_ids.get(nm, nm)
        return [tid] if tid in self._known_ids else []

    def _handle_shift(self, left, right, left_shift: bool):
        L = self._endpoints(left)
        R = self._endpoints(right)
        for a in L:
            for b in R:
                self.edges.append((a, b, "pass") if left_shift else (b, a, "pass"))

    def visit_BinOp(self, node):
        if isinstance(node.op, ast.RShift):
            self._handle_shift(node.left, node.right, True)
        elif isinstance(node.op, ast.LShift):
            self._handle_shift(node.left, node.right, False)
        self.generic_visit(node)

    def visit_Expr(self, node):
        v = node.value
        if isinstance(v, ast.Call):
            # t1.set_downstream(t2)
            txt = ast.unparse(v)
            m = re.search(r"(\w+)\.(set_downstream|set_upstream)\(([^)]*)\)", txt)
            if m:
                src, how, arg = m.group(1), m.group(2), m.group(3)
                tgt = re.findall(r"[A-Za-z_]\w*", arg)
                for t in tgt:
                    a = self.task_ids.get(src, src)
                    b = self.task_ids.get(t, t)
                    if how == "set_downstream":
                        self.edges.append((a, b, "pass"))
                    else:
                        self.edges.append((b, a, "pass"))
        self.generic_visit(node)


def af_high_risk(kind: str, node: ast.AST, funcs, path) -> bool:
    if kind == "exec":
        if isinstance(node, ast.FunctionDef):
            txt = ast.unparse(node)
            return bool(re.search(r"open\(|requests\.|subprocess|os\.system|shutil|\.write|hook|bash|curl",
                                  txt, re.I))
        return True
    return False


def parse_airflow(path: str) -> Optional[Graph]:
    src = io.open(path, encoding="utf-8").read()
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return None
    P = AfParser(path)
    P.visit(tree)

    # decorated functions become tasks: @task / @task.branch / @task.short_circuit
    for fname in P.task_funcs | P.branch_funcs | P.short_funcs:
        kind = "branch" if (fname in P.branch_funcs or fname in P.short_funcs) else "exec"
        P.tasks[fname] = kind
        P.task_ops.setdefault(fname, "branch" if kind == "branch" else "task")
        P.task_ids.setdefault(fname, fname)

    G = Graph("airflow", os.path.basename(path), path)
    for var, kind in P.tasks.items():
        tid = P.task_ids.get(var, var)
        G.nodes[tid] = kind
        G.labels[tid] = tid
        if kind == "exec" and af_is_sink(var, P):
            G.sinks.add(tid)
        elif kind == "branch":
            G.verdicts.add(tid)
    for a, b, h in P.edges:
        if a in G.nodes and b in G.nodes:
            G.edges.append((a, b, "rule" if a in G.verdicts else "pass"))
    if not G.nodes:
        return None
    return G


# ── OpenClaw (hand-encoded from static audit E37) ────────────────

def openclaw_graphs() -> List[Graph]:
    """8 verified execution paths (E37), each source -> high-risk sink with the
    before-tool-call approval hook on the path."""
    paths = [
        ("agent_tool_adapter", True),
        ("native_hook_relay", True),
        ("tool_search", True),
        ("mcp_plugin_tools", True),
        ("gateway_openresponses_http", True),
        ("gateway_openai_http", True),
        ("embedded_runner_tool_split", True),
        ("embedded_runner_attempt", True),
    ]
    out = []
    for name, hooked in paths:
        G = Graph("openclaw", name, r"D:\dev\openclaw")
        G.nodes = {"entry": "source", "hook": "rule", "sink": "exec"}
        G.labels = {"entry": "entry", "hook": "runBeforeToolCallHook", "sink": "high-risk tool"}
        G.sinks = {"sink"}
        G.verdicts = {"hook"} if hooked else set()
        G.edges = [("entry", "hook", "pass"), ("hook", "sink", "rule")]
        G.entries = {"entry"}
        out.append(G)
    return out


def main():
    rows = []
    for d in DIFY_DIRS:
        for p in sorted(glob.glob(os.path.join(d, "*.yml"))):
            try:
                g = parse_dify(p)
                r = analyse(g)
                r["file"] = os.path.basename(p)
                rows.append(r)
            except Exception as e:
                rows.append({"framework": "dify", "name": os.path.basename(p),
                             "file": os.path.basename(p), "status": "ERR", "error": str(e)[:120]})
    for p in sorted(glob.glob(os.path.join(AIRFLOW_DIR, "*.py"))):
        g = parse_airflow(p)
        if g is None or not g.nodes:
            rows.append({"framework": "airflow", "name": os.path.basename(p),
                         "status": "ERR", "error": "no tasks parsed"})
            continue
        rows.append(analyse(g))
    rows += [analyse(g) for g in openclaw_graphs()]

    print("\n== per pipeline ==")
    for r in rows:
        print(f"{r['framework']:8s} {r['name'][:42]:42s} {r.get('status')} "
              f"sinks={len(r.get('sinks', []))} verdicts={len(r.get('verdicts', []))} "
              f"unsafe={len(r.get('unsafe_sinks', []))}")

    print("\n== status by framework ==")
    by = {}
    for r in rows:
        by.setdefault(r["framework"], Counter())[r.get("status")] += 1
    for fw, c in sorted(by.items()):
        print(fw, dict(c))

    total = Counter(r.get("status") for r in rows)
    print("TOTAL", dict(total))
    with_sink = [r for r in rows if r.get("sinks")]
    guarded = [r for r in with_sink if r.get("verdicts")]
    false_safe = [r for r in guarded if r.get("status") == "H"]
    print(f"pipelines={len(rows)} with_sink={len(with_sink)} guarded={len(guarded)} "
          f"false_safe={len(false_safe)} rate={len(false_safe)/max(1,len(guarded)):.4f}")

    json.dump({"pipelines": rows, "total": dict(total)}, io.open(OUT_JSON, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print("wrote", OUT_JSON)


if __name__ == "__main__":
    main()
