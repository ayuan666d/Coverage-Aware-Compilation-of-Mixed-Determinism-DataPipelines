"""Measure the body length (excluding references) of a two-column ACM paper.

Body pages = (pages fully before the REFERENCES heading)
           + (fraction of the REFERENCES page occupied before the heading),
where the fraction is counted in columns (left column then right column).
"""
import sys
import pymupdf


def measure(pdf_path: str, ref_marker: str = "REFERENCES"):
    doc = pymupdf.open(pdf_path)
    n = len(doc)
    page_w = doc[0].rect.width
    mid = page_w / 2.0
    top_y, bot_y = None, None

    for pno in range(n):
        page = doc[pno]
        # body text block: find marker as a line
        d = page.get_text("dict")
        hits = []
        for b in d["blocks"]:
            if b.get("type") != 0:
                continue
            for ln in b["lines"]:
                txt = "".join(s["text"] for s in ln["spans"]).strip()
                if txt.upper().startswith(ref_marker):
                    x0, y0, x1, y1 = ln["bbox"]
                    size = max(s["size"] for s in ln["spans"])
                    hits.append((y0, x0, txt, size))
        if hits:
            hits.sort()
            y0, x0, txt, size = hits[0]
            # column index of the heading
            col = 0 if (x0 + 10) < mid else 1
            # text area vertical bounds
            ty = min(b["bbox"][1] for b in d["blocks"] if b.get("type") == 0)
            by = max(b["bbox"][3] for b in d["blocks"] if b.get("type") == 0)
            frac_col = (y0 - ty) / max(by - ty, 1.0)
            frac_col = min(max(frac_col, 0.0), 1.0)
            body = pno + (col + frac_col) / 2.0
            return dict(pages=n, ref_page=pno + 1, ref_col=col + 1,
                        ref_y=round(y0, 1), frac=round(frac_col, 3),
                        body_pages=round(body, 3), total_pages=n)
    return dict(pages=n, ref_page=None, body_pages=float(n), total_pages=n)


if __name__ == "__main__":
    for p in sys.argv[1:]:
        print(p, measure(p))
