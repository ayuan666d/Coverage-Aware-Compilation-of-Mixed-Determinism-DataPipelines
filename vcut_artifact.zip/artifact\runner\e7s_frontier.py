"""E7s: the certification frontier, computed from stored runs.

Joins the checker verdicts (closure) with the independent layout witness on
(b) the 800-receipt train split with DeepSeek and (c) the 100-receipt test split
with qwen3:4b.  Writes the exact operating points quoted in the paper.
"""
from __future__ import annotations

import json
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
OUT = REPO / "06_结果" / "e7s_frontier.json"


def join(rec_path, wit_path):
    rec = {r["file"]: r for r in json.load(open(rec_path, encoding="utf-8"))["rows"]}
    wit = {r["file"]: r for r in json.load(open(wit_path, encoding="utf-8"))["rows"]}
    rows = []
    for f, r in rec.items():
        w = wit.get(f)
        if not w:
            continue
        rows.append({
            "file": f,
            "closure": r["verdict"] in ("accept", "fill"),
            "agree": w.get("agree") is True,
            "correct": r.get("total_correct"),
            "model_correct": r.get("model_total_correct"),
        })
    return rows


def metrics(rows, pred):
    acc = [r for r in rows if pred(r)]
    known = [r for r in acc if r["correct"] is not None]
    fp = sum(1 for r in known if r["correct"] is False)
    return {"accept": len(acc), "automation": round(len(acc) / len(rows), 4),
            "false_pass": fp, "false_pass_rate": round(fp / len(rows), 4),
            "precision": round((len(known) - fp) / len(known), 4) if known else None}


def main():
    train = join(REPO / "06_结果" / "e7_receipts.json",
                 REPO / "06_结果" / "e7l_layout_witness.json")
    test = join(REPO / "06_结果" / "e7n_test_qwen3.json",
                REPO / "06_结果" / "e7l_test_witness.json")
    out = {}
    for name, rows in (("train_800_deepseek", train), ("test_100_qwen3_4b", test)):
        out[name] = {
            "n": len(rows),
            "closure": metrics(rows, lambda r: r["closure"]),
            "witness": metrics(rows, lambda r: r["agree"]),
            "and": metrics(rows, lambda r: r["closure"] and r["agree"]),
            "or": metrics(rows, lambda r: r["closure"] or r["agree"]),
        }
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
