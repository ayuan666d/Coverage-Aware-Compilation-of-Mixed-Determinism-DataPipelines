"""E11-SUPPORT: the router that the hybrid run actually points at.

e11_hybrid.py falsified the first version of the claim: "no query word exists
anywhere in the catalogue" fires on 3/341 questions, not on the 22 that are truly
unanswerable -- absence from the vocabulary is not absence from the right table,
and you cannot see the latter without knowing the answer.  What did survive is
much simpler and stronger: count how many of the query's content words the
answer we are about to return actually contains.  That number is observable, it
is checkable in the database itself, and it orders the queries far better than
the embedding's own similarity score does (dense top-1 cosine is close to
anti-informative here: keeping its most confident half LOWERS accuracy).

This script sweeps accept-rules built on that support count and reports the
accuracy-vs-model-calls curve.  Inputs are the per-question rows already written
by e11_hybrid.py, so nothing is recomputed and nothing is re-tuned on the test set.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[2]
HYB = REPO / "06_结果" / "e11_hybrid.json"
OUT = REPO / "06_结果" / "e11_support.json"


def main():
    rows = json.load(open(HYB, encoding="utf-8"))["rows"]
    n = len(rows)

    def evaluate(accept):
        acc = [r for r in rows if accept(r)]
        rej = [r for r in rows if not accept(r)]
        kept = np.mean([r["rr_r5"] for r in acc]) if acc else float("nan")
        kept_d = np.mean([r["dense_r5"] for r in acc]) if acc else float("nan")
        rest = np.mean([r["dense_r5"] for r in rej]) if rej else float("nan")
        tot = (sum(r["rr_r5"] for r in acc) + sum(r["dense_r5"] for r in rej)) / n
        tot1 = (sum(r["rr_r1"] for r in acc) + sum(r["dense_r1"] for r in rej)) / n
        return {"accept_cov": round(len(acc) / n, 4),
                "call_frac": round(len(rej) / n, 4),
                "accepted_r5": round(float(kept), 4) if acc else None,
                "accepted_dense_r5_on_same_subset": round(float(kept_d), 4) if acc else None,
                "rejected_then_dense_r5": round(float(rest), 4) if rej else None,
                "hybrid_r5": round(float(tot), 4), "hybrid_r1": round(float(tot1), 4)}

    rules = {}
    for k in (1, 2, 3, 4):
        rules[f"support>={k}"] = (lambda k: lambda r: r["top1_shared"] >= k)(k)
    for k in (1, 2):
        for m in (1, 2, 5, 20):
            rules[f"support>={k} & rarest_df<={m}"] = (
                lambda k, m: lambda r: r["top1_shared"] >= k and r["rarest_df"] <= m)(k, m)
    for k in (1, 2):
        for t in (0.3, 0.5):
            rules[f"support>={k} | margin>={t}"] = (
                lambda k, t: lambda r: r["top1_shared"] >= k or r["margin"] >= t)(k, t)
    rules["always accept (graph only)"] = lambda r: True
    rules["never accept (dense only)"] = lambda r: False
    rules["ORACLE (cheat): accept where graph wins"] = lambda r: r["rr_r5"] >= r["dense_r5"]

    res = {k: evaluate(f) for k, f in rules.items()}

    # risk-coverage: accepted precision as a function of coverage, both signals
    def curve(key, reverse):
        s = sorted(rows, key=lambda r: r[key], reverse=reverse)
        return {f"{c}": {"accepted_r5": round(float(np.mean([r["rr_r5"] for r in s[:max(1, int(round(n * c / 100)))]])), 4),
                         "hybrid_r5": round(float((sum(r["rr_r5"] for r in s[:max(1, int(round(n * c / 100)))])
                                                   + sum(r["dense_r5"] for r in s[max(1, int(round(n * c / 100))):])) / n), 4)}
                for c in (100, 90, 80, 70, 60, 50, 40, 30, 20)}

    out = {"n": n, "rules": res,
           "curve_support_count": curve("top1_shared", True),
           "curve_dense_confidence": curve("dense_top1", True),
           "curve_graph_margin": curve("margin", True),
           "support_vs_truly_blind": {
               "truly_blind": sum(1 for r in rows if not r["gold_anchor"]),
               "support0_and_truly_blind": sum(1 for r in rows if r["top1_shared"] == 0 and not r["gold_anchor"]),
               "support0": sum(1 for r in rows if r["top1_shared"] == 0)},
           "mean_query_tokens": round(float(np.mean([len(set(r["gold"])) for r in rows])), 2)}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(out, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
