"""E11 dense baseline with Qwen3-Embedding-0.6B (local, no API).

Encodes the same schema documents as BM25/graph (table name + columns + up to
12 sample values) and ranks tables by cosine.  Also exposes query/doc
embeddings for the paraphrase run.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
MODEL = "D:/vldb2027_e11/models/Qwen3-Embedding-0.6B"
OUTDIR = Path("D:/vldb2027_e11")


def docs_for(cache, kind):
    if kind == "bird":
        out = []
        for db, s in cache["bird"].items():
            for t in s["tables"]:
                out.append((f"{db}::{t['name']}", g.table_text(dict(t, db=db))))
        return out
    out = []
    for db, s in cache["spider"].items():
        for t in s["tables"]:
            out.append((f"{db}::{t['name']}", g.table_text(dict(t, db=db))))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", choices=["bird", "spider"], required=True)
    args = ap.parse_args()
    from sentence_transformers import SentenceTransformer
    cache = json.load(open(CACHE, encoding="utf-8"))
    cases = json.load(open(CASES, encoding="utf-8"))
    docs = docs_for(cache, args.kind)
    ids = [x[0] for x in docs]
    texts = [x[1] for x in docs]
    model = SentenceTransformer(MODEL, device=os.environ.get("ST_DEVICE", "cpu"))
    model.max_seq_length = 384
    D = model.encode(texts, batch_size=16, normalize_embeddings=True,
                     show_progress_bar=True, convert_to_numpy=True)
    cs = cases["bird"] if args.kind == "bird" else [c for c in cases["spider"] if c["split"] == "test"]
    qs = [c["question"] for c in cs]
    Q = model.encode(qs, batch_size=16, normalize_embeddings=True,
                     show_progress_bar=True, convert_to_numpy=True,
                     prompt_name="query") if True else None
    pos = {x: i for i, x in enumerate(ids)}
    idx_by_db = {}
    for i, tid in enumerate(ids):
        db = tid.split("::")[0]
        idx_by_db.setdefault(db, []).append(i)
    rows = []
    for c, qv in zip(cs, Q):
        db = c["db_id"]
        cand = idx_by_db.get(db, []) if args.kind == "bird" else list(range(len(ids)))
        sim = D[cand] @ qv
        order = [cand[j] for j in np.argsort(-sim)]
        ranked = [ids[i] for i in order]
        gold = {f"{db}::{t}" for t in c["gold"]}
        rows.append({"qid": c["qid"], "db": db, "gold": sorted(gold),
                     "top5": ranked[:5], **g.metrics(ranked, gold)})
    out = {"kind": args.kind, "n": len(rows), "dim": int(D.shape[1]),
           "metrics": g.mean_metrics(rows), "rows": rows}
    path = OUTDIR / f"e11_dense_{args.kind}.json"
    json.dump(out, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    np.savez_compressed(OUTDIR / f"e11_emb_{args.kind}.npz",
                        ids=np.array(ids), D=D.astype(np.float16),
                        qids=np.array([c["qid"] for c in cs]), Q=Q.astype(np.float16))
    print(json.dumps({"kind": args.kind, "dim": out["dim"], "metrics": out["metrics"]}, indent=2))
    print("wrote", path)


if __name__ == "__main__":
    main()
