"""E7: text-to-SQL pilot on BIRD mini-dev.

Real model outputs (9 zero-shot + 4 CoT prediction files shipped with the
benchmark) executed against the real SQLite databases.  The point is not to
re-rank models: it is to measure how much of a model-produced SQL statement a
*deterministic* checker can reject, certify, or must send to review, and what
that costs in false passes / false kills.

Usage:
    python e7_sql_pilot.py --models gpt-4,gpt-4-turbo --limit 100
    python e7_sql_pilot.py --all --workers 8 --timeout 8
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sqlite3
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
BIRD = REPO / "04_数据" / "external" / "bird"
DB_ROOT = BIRD / "minidev" / "MINIDEV" / "dev_databases"
GOLD = BIRD / "mini_dev_sqlite_2025.json"
PRED_DIR = BIRD / "preds"
PRED_TA = BIRD / "preds_ta"
OUT = REPO / "06_结果" / "e7_sql_pilot.json"


def model_name(path: Path) -> str:
    n = path.stem
    n = n.replace("predict_mini_dev_", "").replace("_sqlite", "").replace("_SQLite", "")
    n = n.replace("_cot", "-cot")
    n = n.replace("meta-llama-3-70b-instruct-2", "llama3-70b")
    n = n.replace("meta-llama-3-8b-instruct-2", "llama3-8b")
    n = n.replace("mistralai-mixtral-8x7b-instru-4", "mixtral-8x7b")
    n = n.replace("phi-3-medium-128k-instruct-1", "phi3-medium")
    n = n.replace("gpt-35-turbo-instruct", "gpt-3.5-instruct")
    n = n.replace("gpt-35-turbo", "gpt-3.5")
    return n


def load_cases(limit: int | None = None) -> list[dict]:
    """The prediction files are keyed by *position* in the 2025 list, so the
    index (not question_id) is the join key."""
    rows = json.load(GOLD.open(encoding="utf-8"))
    if limit:
        rows = rows[:limit]
    for idx, r in enumerate(rows):
        r["idx"] = idx
        r["db_path"] = str(DB_ROOT / r["db_id"] / f"{r['db_id']}.sqlite")
    return rows


def load_preds(path: Path) -> dict[int, str]:
    data = json.load(path.open(encoding="utf-8"))
    out: dict[int, str] = {}
    for k, v in data.items():
        if not isinstance(v, str):
            continue
        sql = v
        if "\t----- bird -----\t" in sql:
            sql = sql.split("\t----- bird -----\t", 1)[0]
        sql = sql.strip()
        # strip markdown fences if the model wrapped its answer
        m = re.search(r"```(?:sql)?\s*(.*?)```", sql, re.S | re.I)
        if m:
            sql = m.group(1).strip()
        out[int(k)] = sql
    return out


def first_statement(sql: str) -> str:
    """Keep the first statement; BIRD answers are single SELECTs."""
    sql = sql.strip().rstrip(";").strip()
    # naive split on semicolons outside quotes
    in_q = None
    for i, ch in enumerate(sql):
        if in_q:
            if ch == in_q:
                in_q = None
        elif ch in ("'", '"', "`"):
            in_q = ch
        elif ch == ";":
            return sql[:i].strip()
    return sql


class ExecResult:
    __slots__ = ("ok", "rows", "err", "truncated", "ms")

    def __init__(self, ok, rows, err, truncated, ms):
        self.ok = ok
        self.rows = rows
        self.err = err
        self.truncated = truncated
        self.ms = ms


def execute(db_path: str, sql: str, timeout: float = 8.0, max_rows: int = 20000) -> ExecResult:
    t0 = time.perf_counter()
    deadline = t0 + timeout
    conn = None
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=2.0)
        conn.set_progress_handler(
            lambda: 1 if time.perf_counter() > deadline else 0, 20000
        )
        cur = conn.cursor()
        cur.execute(sql)
        rows = cur.fetchmany(max_rows + 1)
        truncated = len(rows) > max_rows
        if truncated:
            rows = rows[:max_rows]
        return ExecResult(True, rows, None, truncated, (time.perf_counter() - t0) * 1000)
    except Exception as e:  # noqa: BLE001
        msg = f"{type(e).__name__}: {e}"
        if time.perf_counter() > deadline:
            msg = "Timeout"
        return ExecResult(False, [], msg, False, (time.perf_counter() - t0) * 1000)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


def canon_cell(v):
    if isinstance(v, float):
        if v != v:  # NaN
            return ("nan",)
        return ("num", round(v, 6))
    if isinstance(v, int):
        return ("num", float(v))
    if isinstance(v, bytes):
        try:
            return ("str", v.decode("utf-8", "replace"))
        except Exception:
            return ("bytes", v.hex())
    if v is None:
        return ("null",)
    return ("str", str(v))


def canon_rows(rows) -> frozenset:
    return frozenset(tuple(canon_cell(c) for c in row) for row in rows)


def same_result(a: ExecResult, b: ExecResult) -> bool:
    if not (a.ok and b.ok):
        return False
    if a.truncated != b.truncated:
        return False
    return canon_rows(a.rows) == canon_rows(b.rows)


# --------------------------------------------------------------------------
# Deterministic checks.  Each returns (name, status, detail); status is
# "violation" (reject), "pass" (this check is satisfied), "unknown" (review).
# --------------------------------------------------------------------------

AGG_WORDS = re.compile(
    r"\b(how many|number of|count|total|average|avg|mean|maximum|max|minimum|min|"
    r"highest|lowest|largest|smallest|sum|percentage|ratio|share)\b",
    re.I,
)
DISTINCT_WORDS = re.compile(r"\b(distinct|different|unique)\b", re.I)
WRITE_WORDS = re.compile(r"^\s*(insert|update|delete|drop|alter|create|replace|attach|pragma)\b", re.I)


def check_single_statement(sql: str):
    s = sql.strip()
    # count semicolons outside quotes
    in_q = None
    n = 0
    for ch in s:
        if in_q:
            if ch == in_q:
                in_q = None
        elif ch in ("'", '"', "`"):
            in_q = ch
        elif ch == ";":
            n += 1
    if n > 1 or (n == 1 and not s.rstrip().endswith(";")):
        return ("single_statement", "violation", f"{n} semicolons")
    return ("single_statement", "pass", "")


def check_select_only(sql: str):
    s = sql.lstrip("(").strip()
    if WRITE_WORDS.match(s):
        return ("select_only", "violation", s[:30])
    if not re.match(r"(?is)^\s*(select|with)\b", s):
        return ("select_only", "violation", s[:30])
    return ("select_only", "pass", "")


def check_parse(sql: str):
    try:
        import sqlglot

        sqlglot.parse_one(sql, read="sqlite")
        return ("parse", "pass", "")
    except Exception as e:  # noqa: BLE001
        return ("parse", "violation", f"{type(e).__name__}: {e}"[:160])


def check_exec(res: ExecResult):
    if res.ok:
        return ("execute", "pass", "")
    if res.err == "Timeout":
        return ("execute", "unknown", "timeout")
    return ("execute", "violation", (res.err or "")[:200])


def check_nonempty(res: ExecResult):
    if not res.ok:
        return ("nonempty", "unknown", "not executed")
    if len(res.rows) == 0:
        # An empty answer can be legitimate; do not call it a violation.
        return ("nonempty", "unknown", "empty result")
    return ("nonempty", "pass", "")


def check_huge(res: ExecResult):
    if not res.ok:
        return ("bounded_result", "unknown", "not executed")
    if res.truncated or len(res.rows) > 5000:
        return ("bounded_result", "unknown", f"{len(res.rows)}+ rows")
    return ("bounded_result", "pass", "")


def check_aggregate_shape(sql: str, question: str):
    q = question.lower()
    if not AGG_WORDS.search(q):
        return ("aggregate_shape", "pass", "no aggregate cue")
    # strip string literals before looking for aggregates
    s = re.sub(r"'(?:''|[^'])*'", "''", sql).lower()
    has_agg = bool(re.search(r"\b(count|sum|avg|min|max|total)\s*\(", s))
    if not has_agg:
        return ("aggregate_shape", "unknown", "question asks aggregate, SQL has none")
    return ("aggregate_shape", "pass", "")


def check_distinct_shape(sql: str, question: str):
    if not DISTINCT_WORDS.search(question):
        return ("distinct_shape", "pass", "no distinct cue")
    s = re.sub(r"'(?:''|[^'])*'", "''", sql).lower()
    if re.search(r"\bdistinct\b", s) or re.search(r"\bgroup\s+by\b", s):
        return ("distinct_shape", "pass", "")
    return ("distinct_shape", "unknown", "question asks distinct, SQL lacks DISTINCT/GROUP BY")


def check_cross_join(sql: str):
    try:
        import sqlglot
        from sqlglot import exp

        tree = sqlglot.parse_one(sql, read="sqlite")
        for j in tree.find_all(exp.Join):
            if j.args.get("on") is None and j.args.get("using") is None:
                kind = (j.args.get("kind") or "").upper()
                side = (j.args.get("side") or "").upper()
                if kind != "CROSS" and not side:
                    return ("no_cross_join", "unknown", "join without condition")
        return ("no_cross_join", "pass", "")
    except Exception:
        return ("no_cross_join", "unknown", "parse failed")


def check_star(sql: str):
    try:
        import sqlglot
        from sqlglot import exp

        tree = sqlglot.parse_one(sql, read="sqlite")
        if any(True for _ in tree.find_all(exp.Star)):
            return ("no_select_star", "unknown", "SELECT *")
        return ("no_select_star", "pass", "")
    except Exception:
        return ("no_select_star", "unknown", "parse failed")


CHECKS = [
    check_single_statement,
    check_select_only,
    check_parse,
]


def decide(sql: str, question: str, res: ExecResult):
    """A conservative decision table: any violation -> reject; any unknown ->
    review; otherwise accept.  This is exactly the violation-only shape whose
    asymmetry the paper proves."""
    results = []
    for fn in CHECKS:
        results.append(fn(sql))
    results.append(check_exec(res))
    results.append(check_nonempty(res))
    results.append(check_huge(res))
    results.append(check_aggregate_shape(sql, question))
    results.append(check_distinct_shape(sql, question))
    results.append(check_cross_join(sql))
    results.append(check_star(sql))
    statuses = [s for _, s, _ in results]
    if "violation" in statuses:
        verdict = "reject"
    elif "unknown" in statuses:
        verdict = "review"
    else:
        verdict = "accept"
    return verdict, {n: (s, d) for n, s, d in results}


def eval_one(case: dict, model: str, sql: str, gold_res: ExecResult, timeout: float):
    sql = first_statement(sql)
    res = execute(case["db_path"], sql, timeout=timeout)
    match = same_result(res, gold_res)
    verdict, checks = decide(sql, case["question"], res)
    return {
        "model": model,
        "idx": case["idx"],
        "qid": case["question_id"],
        "db": case["db_id"],
        "difficulty": case["difficulty"],
        "question": case["question"],
        "gold": case["SQL"],
        "pred": sql,
        "exec_ok": res.ok,
        "exec_err": res.err,
        "truncated": res.truncated,
        "n_rows": len(res.rows),
        "ms": round(res.ms, 3),
        "match": match,
        "verdict": verdict,
        "checks": checks,
    }


def run(models: list[str], limit: int | None, workers: int, timeout: float):
    cases = load_cases(limit)
    print(f"cases={len(cases)} models={models}", flush=True)

    # gold results once
    gold_res = {}
    for c in cases:
        gold_res[c["idx"]] = execute(c["db_path"], c["SQL"], timeout=timeout)
    bad_gold = [q for q, r in gold_res.items() if not r.ok]
    print(f"gold execution failures: {len(bad_gold)} {bad_gold[:8]}", flush=True)

    pred_files = {}
    for p in sorted(PRED_DIR.glob("*.json")) + sorted(PRED_TA.glob("*.json")):
        m = model_name(p)
        pred_files[m] = p
    if models and models != ["all"]:
        keep = []
        for m in models:
            if m in pred_files:
                keep.append(m)
            else:
                hits = [k for k in pred_files if m in k]
                keep.extend(hits)
        pred_files = {k: pred_files[k] for k in dict.fromkeys(keep)}
    print("using:", sorted(pred_files), flush=True)

    records = []
    for model, path in sorted(pred_files.items()):
        preds = load_preds(path)
        todo = [c for c in cases if c["idx"] in preds and gold_res[c["idx"]].ok]
        t0 = time.perf_counter()
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {
                ex.submit(eval_one, c, model, preds[c["idx"]],
                          gold_res[c["idx"]], timeout): c
                for c in todo
            }
            for i, fut in enumerate(as_completed(futs), 1):
                try:
                    records.append(fut.result())
                except Exception as e:  # noqa: BLE001
                    c = futs[fut]
                    records.append({
                        "model": model, "idx": c["idx"], "qid": c["question_id"], "db": c["db_id"],
                        "difficulty": c["difficulty"], "question": c["question"],
                        "gold": c["SQL"], "pred": preds.get(c["idx"], ""),
                        "exec_ok": False, "exec_err": f"harness:{type(e).__name__}:{e}",
                        "truncated": False, "n_rows": 0, "ms": 0.0,
                        "match": False, "verdict": "review", "checks": {},
                    })
                if i % 100 == 0:
                    print(f"  {model}: {i}/{len(todo)} ({(time.perf_counter()-t0):.1f}s)", flush=True)
        print(f"{model}: done {len(todo)} in {time.perf_counter()-t0:.1f}s", flush=True)

    summary = summarize(records)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"summary": summary, "records": records}, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return records, summary


def summarize(records: list[dict]) -> dict:
    by_model = defaultdict(list)
    for r in records:
        by_model[r["model"]].append(r)
    out = {}
    for m, rs in sorted(by_model.items()):
        n = len(rs)
        acc = sum(r["match"] for r in rs) / n if n else 0
        verdicts = Counter(r["verdict"] for r in rs)
        accepted = [r for r in rs if r["verdict"] == "accept"]
        rejected = [r for r in rs if r["verdict"] == "reject"]
        reviewed = [r for r in rs if r["verdict"] == "review"]
        true_acc = sum(r["match"] for r in accepted)
        out[m] = {
            "n": n,
            "exec_acc": round(acc, 4),
            "accept": len(accepted),
            "review": len(reviewed),
            "reject": len(rejected),
            "automation": round(len(accepted) / n, 4) if n else 0,
            "accept_precision": round(true_acc / len(accepted), 4) if accepted else None,
            "false_pass": len(accepted) - true_acc,
            "false_pass_rate": round((len(accepted) - true_acc) / n, 4) if n else 0,
            "false_kill": sum(1 for r in rejected if r["match"]),
            "false_kill_rate": round(sum(1 for r in rejected if r["match"]) / n, 4) if n else 0,
            "exec_fail": sum(1 for r in rs if not r["exec_ok"]),
            "timeout": sum(1 for r in rs if r["exec_err"] == "Timeout"),
            "median_ms": round(sorted(r["ms"] for r in rs)[n // 2], 2) if n else 0,
            "by_verdict_acc": {
                v: round(sum(r["match"] for r in rs if r["verdict"] == v) /
                         max(1, sum(1 for r in rs if r["verdict"] == v)), 4)
                for v in ("accept", "review", "reject")
            },
        }
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default="all", help="comma list or all")
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--timeout", type=float, default=8.0)
    args = ap.parse_args()
    models = [] if args.models == "all" else [s.strip() for s in args.models.split(",") if s.strip()]
    run(models, args.limit, args.workers, args.timeout)


if __name__ == "__main__":
    main()
