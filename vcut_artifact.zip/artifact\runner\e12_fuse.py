"""E12-FUSE: the class attribution says the two lines fix different classes, so
try the cheapest combination a reviewer would ask for.

e12_join.py: my graph arm fixes 8/19 of the lexical-tie class (best of any arm)
but only 6/33 of the morphology class, where their char-ngram space fixes 22/33
and the GA 15/33.  If those are really different mechanisms, a combination should
beat each part; if it does not, the complementarity is a story and not a result --
which is exactly what this probe decides.

Only top-5 lists are stored per arm, so the fusion is a truncated reciprocal-rank
fusion (a table outside every arm's top-5 cannot appear).  That limitation can
only understate the fusion, never inflate it.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
WORK = Path("D:/vldb2027_e11")
OUT = R / "e12_fuse.json"
K = 60


def main():
    gp = json.load(open(R / "e12_gp.json", encoding="utf-8"))["rows"]
    spec = json.load(open(R / "e12_spectral.json", encoding="utf-8"))["rows"]
    dense = {r["qid"]: r for r in json.load(open(WORK / "e11_dense_spider.json", encoding="utf-8"))["rows"]}
    cls = json.load(open(R / "e12_verdict.json", encoding="utf-8"))["classes"]
    sup2 = json.load(open(R / "e11_support2.json", encoding="utf-8"))

    arms = {"gp_ex": {r["qid"]: [t.lower() for t in r["top5"]] for r in gp["gp_ex"]},
            "gram": {r["qid"]: [t.lower() for t in r["gram"]["top5"]] for r in spec},
            "dense": {q: [t.lower() for t in r["top5"]] for q, r in dense.items()}}
    gold = {r["qid"]: {x.lower() for x in r["gold"]} for r in gp["gp_ex"]}
    qids = sorted(gold)

    def fuse(weights):
        out = {}
        for q in qids:
            s = {}
            for arm, w in weights.items():
                for i, t in enumerate(arms[arm].get(q, [])):
                    s[t] = s.get(t, 0.0) + w / (K + i + 1)
            ranked = sorted(s, key=lambda t: -s[t])
            g = gold[q]
            out[q] = {"hit1": float(bool(ranked) and ranked[0] in g),
                      "r5": sum(1 for t in ranked[:5] if t in g) / max(1, len(g))}
        return out

    combos = {"gp_ex only": {"gp_ex": 1.0},
              "gram only": {"gram": 1.0},
              "dense only": {"dense": 1.0},
              "gp_ex+gram": {"gp_ex": 1.0, "gram": 1.0},
              "gram x2 + gp_ex": {"gp_ex": 1.0, "gram": 2.0},
              "gp_ex+dense": {"gp_ex": 1.0, "dense": 1.0},
              "gram+dense": {"gram": 1.0, "dense": 1.0},
              "all three": {"gp_ex": 1.0, "gram": 1.0, "dense": 1.0}}
    res = {}
    for name, w in combos.items():
        sc = fuse(w)
        per_cls = {}
        for q in qids:
            if q in cls:
                c = cls[q]["class"]
                a = per_cls.setdefault(c, [0, 0])
                a[1] += 1
                a[0] += sc[q]["hit1"]
        res[name] = {"top1_hit": round(float(np.mean([sc[q]["hit1"] for q in qids])), 4),
                     "r5": round(float(np.mean([sc[q]["r5"] for q in qids])), 4),
                     "fixed_164": int(sum(v[0] for v in per_cls.values())),
                     "by_class": {c: f"{int(v[0])}/{v[1]}" for c, v in sorted(per_cls.items())}}
    tr = sup2["test_reading_of_chosen_rule"]
    out = {"note": "truncated RRF over stored top-5 lists",
           "results": res,
           "reference_my_arm": {"graph_only_test_r5": sup2["graph_only_test_r5"],
                                "certified_accept_cov": tr["accept_cov"],
                                "certified_graph_r1": tr["accepted_graph_r5"],
                                "hybrid_r5": tr["hybrid_r5"]}}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(out, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
