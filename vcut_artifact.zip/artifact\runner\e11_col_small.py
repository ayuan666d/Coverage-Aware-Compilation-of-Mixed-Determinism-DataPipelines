"""E11-COL-SMALL: does the column operator transfer outside the 876-table lake?

Same comparison as e11_col.py (v0 = table-level idf geometric mean of the per-token
diffusion, c3 = each query token takes its best COLUMN, then the same idf geometric
conjunction) run per database on the two small-schema settings, with the dense
reference and the frozen certificate read on top.  Nothing here selects a variant:
c3 was already selected on the train half of the merged catalogue in e11_col.py.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_col import col_index, col_bm25_scores, gm, seg_top12  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
OUT = REPO / "06_结果" / "e11_col_small.json"
EPS, ALPHA, ITERS, TOPK = 1e-6, 0.85, 20, 30
K_FROZEN, M_FROZEN = 3, 2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", choices=["bird", "known"], required=True)
    args = ap.parse_args()
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    allc = json.load(open(CASES, encoding="utf-8"))
    if args.kind == "bird":
        cases_all, dbs = allc["bird"], cache["bird"]
        emb = Path("D:/vldb2027_e11/e11_emb_bird.npz")
    else:
        cases_all = [c for c in allc["spider"] if c["split"] == "test"]
        dbs = cache["spider"]
        emb = Path("D:/vldb2027_e11/e11_emb_spider.npz")
    z = np.load(emb, allow_pickle=True)
    ids = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}
    by_db_pos = {}
    for i, t in enumerate(ids):
        by_db_pos.setdefault(t.split("::")[0], []).append(i)

    by = {}
    for c in cases_all:
        by.setdefault(c["db_id"], []).append(c)
    rows = []
    t0 = time.time()
    for db, cs in sorted(by.items()):
        if db not in dbs:
            continue
        tabs = [dict(t, db=db) for t in dbs[db]["tables"]]
        cat = g.Catalog(tabs, dbs[db]["fks"], prefix_db=False)
        N = len(cat.tables)
        colnodes, cdocs, starts, ends = col_index(cat)
        tok_tab, tok_col, idf_of = {}, {}, {}
        for w in sorted({w for c in cs for w in toks(c["question"])}):
            k = ("token", w)
            if k not in cat.idx:
                continue
            x = g.ppr(cat.union, {cat.idx[k]: 1.0}, ALPHA, ITERS)
            st = cat.table_scores(x)
            mx = float(st.max())
            if mx <= 0:
                continue
            tok_tab[w] = (st / mx).astype(np.float32)
            idf_of[w] = math.log(1 + (N - cat.token_df.get(w, 0) + 0.5)
                                 / (cat.token_df.get(w, 0) + 0.5))
            cv = np.asarray(x)[colnodes].astype(np.float32)
            cmx = float(cv.max())
            tok_col[w] = cv / cmx if cmx > 0 else cv
        cand = by_db_pos.get(db, [])
        for c in cs:
            q = toks(c["question"])
            gold = set(c["gold"])
            ws = sorted({w for w in q if w in tok_tab})
            b = g.bm25(cat, q)
            top = np.argsort(-b)[:min(TOPK, N)]
            base = float(b[top[-1]])
            keys = {}
            if ws:
                iw = np.array([idf_of[w] for w in ws], dtype=np.float32)[:, None]
                keys["v0_table_gm"] = gm(np.stack([tok_tab[w] for w in ws]), iw)
                Tt = np.maximum.reduceat(np.stack([tok_col[w] for w in ws]), starts, axis=1)
                keys["c3_tokmaxpool_gm"] = gm(Tt, iw)
            else:
                keys = {k: np.zeros(N, dtype=np.float32) for k in
                        ("v0_table_gm", "c3_tokmaxpool_gm")}
            L = col_bm25_scores(cdocs, q)
            l1, _ = seg_top12(L, starts, ends)
            keys["l1_bm25col_max"] = l1
            rec = {"qid": c["qid"], "db": db, "n_tables": N}
            rarest = min([cat.token_df.get(w, 10 ** 9) for w in ws], default=10 ** 9)
            rec["m_q"] = int(rarest)
            for name, sc in keys.items():
                mixed = b.copy()
                for i, idx in enumerate(top[np.argsort(-sc[top])]):
                    mixed[idx] = base + (len(top) - i) * 1e-6
                r = g.rank(mixed, cat)
                mm = g.metrics(r, gold)
                rec[name] = {"r1": round(mm["recall@1"], 4), "r5": round(mm["recall@5"], 4),
                             "mrr": round(mm["mrr"], 4),
                             "k": int(len(set(q) & set(g.table_doc(
                                 cat.tables[cat.table_pos[r[0]]]))))}
            if c["qid"] in qpos and cand:
                sim = Dm[cand] @ Qm[qpos[c["qid"]]]
                rk = [ids[cand[i]].split("::", 1)[1] for i in np.argsort(-sim)]
                md = g.metrics(rk, gold)
                rec["dense"] = {"r1": round(md["recall@1"], 4), "r5": round(md["recall@5"], 4)}
            rows.append(rec)
    print(f"{args.kind}: {len(rows)} questions in {time.time()-t0:.0f}s", flush=True)

    V = ["v0_table_gm", "c3_tokmaxpool_gm", "l1_bm25col_max"]
    m = lambda rs, v, key: round(float(np.mean([r[v][key] for r in rs])), 4) if rs else None  # noqa: E731
    out = {"kind": args.kind, "n": len(rows),
           "mean_tables": round(float(np.mean([r["n_tables"] for r in rows])), 1)}
    for v in V:
        acc = [r for r in rows if r[v]["k"] >= K_FROZEN and r["m_q"] <= M_FROZEN]
        out[v] = {"r1": m(rows, v, "r1"), "r5": m(rows, v, "r5"), "mrr": m(rows, v, "mrr"),
                  "acc_cov": round(len(acc) / len(rows), 4),
                  "acc_r1": m(acc, v, "r1"), "acc_r5": m(acc, v, "r5")}
        if all("dense" in r for r in rows):
            rej = [r for r in rows if not (r[v]["k"] >= K_FROZEN and r["m_q"] <= M_FROZEN)]
            out[v]["hybrid_r5"] = round((sum(r[v]["r5"] for r in acc)
                                         + sum(r["dense"]["r5"] for r in rej)) / len(rows), 4)
            out[v]["hybrid_r1"] = round((sum(r[v]["r1"] for r in acc)
                                         + sum(r["dense"]["r1"] for r in rej)) / len(rows), 4)
    if all("dense" in r for r in rows):
        out["dense"] = {"r1": round(float(np.mean([r["dense"]["r1"] for r in rows])), 4),
                        "r5": round(float(np.mean([r["dense"]["r5"] for r in rows])), 4)}
    out["rows"] = rows
    op = Path(str(OUT).replace(".json", f"_{args.kind}.json"))
    json.dump(out, open(op, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=1, ensure_ascii=False))
    print("wrote", op)


if __name__ == "__main__":
    main()
