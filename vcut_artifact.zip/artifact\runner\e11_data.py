"""E11 data layer: BIRD control set + Spider-Lake catalog + splits.

Builds a schema cache with table/column names, sample values and foreign keys
for (a) the 11 BIRD mini-dev databases and (b) the 166 Spider databases whose
schemas are in ``04_数据/external/sql/tables.json``.  The Spider SQLite files
are extracted from ``D:/vldb2027_e11/spider_data.zip`` when present.

No model calls.  The cache is written outside the repo because it contains
sample values; the small question/split file is written into ``06_结果``.
"""
from __future__ import annotations

import json
import re
import sqlite3
import zipfile
from collections import Counter
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
BIRD = REPO / "04_数据" / "external" / "bird"
BIRD_JSON = BIRD / "mini_dev_sqlite_2025.json"
BIRD_DB = BIRD / "minidev" / "MINIDEV" / "dev_databases"
SPIDER_META = REPO / "04_数据" / "external" / "sql"
SPIDER_DEV = SPIDER_META / "dev.json"
SPIDER_TABLES = SPIDER_META / "tables.json"
WORK = Path("D:/vldb2027_e11")
SPIDER_ROOT = WORK / "spider"
CACHE = WORK / "schema_cache.json"
CASES_OUT = REPO / "06_结果" / "e11_cases.json"

TOK = re.compile(r"[a-z0-9_]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us""".split())


def toks(s: str) -> list[str]:
    # single source of truth: e11_graph holds the SPLIT_IDENT switch, and the
    # query side must tokenise exactly like the document side.
    import e11_graph as _g
    return _g.toks(s)


def parse_gold_tables(sql: str) -> set[str]:
    """Table names after FROM/JOIN, excluding subqueries and CTE aliases.

    Handles bare names, backtick/double-quoted names and ``db.table``.
    """
    ident = r"(?:[`\"\[]?[A-Za-z_][A-Za-z0-9_]*[`\"\]]?)"
    out = set()
    pat = re.compile(rf"\b(?:from|join)\s+({ident}(?:\s*\.\s*{ident})?)", re.I)
    for m in pat.finditer(sql):
        parts = re.split(r"\s*\.\s*", m.group(1))
        name = parts[-1].strip("`\"[] ")
        if not name or name.lower() in {"select", "where", "group", "order", "limit", "with"}:
            continue
        out.add(name)
    return out


def quote(x: str) -> str:
    return '"' + x.replace('"', '""') + '"'


def sample_values(con, table, col, limit=12, scan=40):
    try:
        rows = con.execute(
            f"SELECT {quote(col)} FROM {quote(table)} WHERE {quote(col)} IS NOT NULL LIMIT {scan}"
        ).fetchall()
    except Exception:
        return []
    vals, seen = [], set()
    for (v,) in rows:
        if isinstance(v, bytes):
            continue
        s = str(v).strip()
        if not s or len(s) > 80:
            continue
        if s in seen:
            continue
        seen.add(s)
        vals.append(s)
        if len(vals) >= limit:
            break
    return vals


def bird_schema(db_path: Path):
    con = sqlite3.connect(db_path)
    tables = [r[0] for r in con.execute(
        "select name from sqlite_master where type='table' and name not like 'sqlite_%'")]
    out = {"tables": [], "fks": []}
    tinfo = {}
    for t in tables:
        cols = []
        for r in con.execute(f'pragma table_info({quote(t)})'):
            cname, ctype = r[1], (r[2] or "")
            vals = sample_values(con, t, cname)
            cols.append({"name": cname, "type": ctype, "values": vals})
        out["tables"].append({"name": t, "columns": cols})
        tinfo[t] = {c["name"] for c in cols}
    for t in tables:
        for fk in con.execute(f'pragma foreign_key_list({quote(t)})'):
            ref_t, ref_c = fk[2], fk[4]
            if ref_t in tinfo and ref_c in tinfo[ref_t]:
                out["fks"].append([t, fk[3], ref_t, ref_c])
    con.close()
    return out


def spider_schema(db_path: Path, meta: dict):
    con = sqlite3.connect(db_path)
    tabs = meta["table_names_original"]
    cols = meta["column_names_original"]
    tables = []
    per_table = {i: [] for i in range(len(tabs))}
    for ci, (ti, cn) in enumerate(cols):
        if ti < 0:
            continue
        per_table[ti].append((cn, ci))
    for ti, tn in enumerate(tabs):
        cc = []
        for cn, ci in per_table[ti]:
            vals = sample_values(con, tn, cn)
            cc.append({"name": cn, "type": meta["column_types"][ci], "values": vals})
        tables.append({"name": tn, "columns": cc})
    fks = []
    for a, b in meta.get("foreign_keys", []):
        ta, ca = cols[a]
        tb, cb = cols[b]
        if ta >= 0 and tb >= 0:
            fks.append([tabs[ta], ca, tabs[tb], cb])
    con.close()
    return {"tables": tables, "fks": fks}


def extract_spider():
    if not (WORK / "spider_data.zip").exists():
        return None
    dst = SPIDER_ROOT / "database"
    if dst.exists() and any(dst.iterdir()):
        return dst
    dst.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(WORK / "spider_data.zip") as z:
        for n in z.namelist():
            low = n.lower()
            if low.endswith(".sqlite") or low.endswith(".db"):
                # keep the path under database/
                parts = [p for p in Path(n).parts if p not in {"spider_data", "database"}]
                if len(parts) >= 2:
                    out = dst / parts[-2] / parts[-1]
                else:
                    out = dst / Path(n).name
                out.parent.mkdir(parents=True, exist_ok=True)
                with z.open(n) as src, open(out, "wb") as f:
                    while True:
                        b = src.read(1 << 20)
                        if not b:
                            break
                        f.write(b)
    return dst


def canon_gold(schema_tables, gold):
    """SQLite table names are case-insensitive; canonicalise gold to the schema."""
    lower = {t["name"].lower(): t["name"] for t in schema_tables}
    out = []
    for g in gold:
        if g.lower() in lower:
            out.append(lower[g.lower()])
    return sorted(set(out))


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--bird-only", action="store_true")
    ap.add_argument("--spider-only", action="store_true")
    ap.add_argument("--reuse-cache", action="store_true")
    args = ap.parse_args()
    WORK.mkdir(parents=True, exist_ok=True)
    if args.reuse_cache and CACHE.exists():
        cache = json.load(open(CACHE, encoding="utf-8"))
        if args.spider_only:
            cache["bird"] = {}
        if args.bird_only:
            cache["spider"] = {}
    else:
        cache = {"bird": {}, "spider": {}}
    bird_cases = json.load(open(BIRD_JSON, encoding="utf-8"))
    if not args.spider_only and not args.reuse_cache:
        for db_id in sorted({c["db_id"] for c in bird_cases}):
            p = BIRD_DB / db_id / f"{db_id}.sqlite"
            cache["bird"][db_id] = bird_schema(p)

    if args.bird_only:
        bird_out = []
        for c in bird_cases:
            gt = parse_gold_tables(c["SQL"])
            if gt:
                bird_out.append({
                    "qid": f"bird{c['question_id']}", "db_id": c["db_id"],
                    "question": c["question"], "evidence": c.get("evidence", ""),
                    "sql": c["SQL"], "gold": sorted(gt), "split": "all",
                    "difficulty": c.get("difficulty", ""),
                })
        json.dump(cache, open(CACHE, "w", encoding="utf-8"), ensure_ascii=False)
        json.dump({"bird": bird_out, "spider": [], "spider_train_dbs": [],
                   "spider_test_dbs": [], "spider_missing_dbs": []},
                  open(CASES_OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print("bird cases", len(bird_out), "cache", CACHE, CACHE.stat().st_size // 1024 // 1024, "MB")
        return

    spider_dev = json.load(open(SPIDER_DEV, encoding="utf-8"))
    spider_meta = {m["db_id"]: m for m in json.load(open(SPIDER_TABLES, encoding="utf-8"))}
    dbroot = None if args.reuse_cache else extract_spider()
    have = set()
    if dbroot:
        for p in dbroot.rglob("*"):
            if p.suffix.lower() in {".sqlite", ".db"}:
                have.add(p.stem)
    else:
        have = set(cache["spider"])
    missing = sorted(set(spider_meta) - have)
    for db_id in sorted(set(spider_meta) & have):
        if args.reuse_cache and db_id in cache["spider"]:
            continue
        p = next(p for p in dbroot.rglob(f"{db_id}.sqlite")) if not (dbroot / db_id / f"{db_id}.sqlite").exists() else (dbroot / db_id / f"{db_id}.sqlite")
        try:
            cache["spider"][db_id] = spider_schema(p, spider_meta[db_id])
        except Exception as e:
            print("spider schema failed", db_id, e)
    print("spider dbs", len(cache["spider"]), "missing", len(missing), missing[:10])

    # splits: Spider by database, BIRD by question (5 folds)
    dbs = sorted(cache["spider"])
    import random
    rnd = random.Random(0)
    rnd.shuffle(dbs)
    cut = int(len(dbs) * 0.8)
    train_dbs, test_dbs = set(dbs[:cut]), set(dbs[cut:])
    spider_cases = []
    skipped = 0
    for i, c in enumerate(spider_dev):
        if c["db_id"] not in cache["spider"]:
            continue
        gt = canon_gold(cache["spider"][c["db_id"]]["tables"], parse_gold_tables(c["query"]))
        if not gt:
            skipped += 1
            continue
        spider_cases.append({
            "qid": f"sp{i}", "db_id": c["db_id"], "question": c["question"],
            "sql": c["query"], "gold": gt,
            "split": "train" if c["db_id"] in train_dbs else "test",
        })
    bird_out = []
    for c in bird_cases:
        gt = canon_gold(cache["bird"].get(c["db_id"], {}).get("tables", []),
                        parse_gold_tables(c["SQL"]))
        if gt:
            bird_out.append({
                "qid": f"bird{c['question_id']}", "db_id": c["db_id"],
                "question": c["question"], "evidence": c.get("evidence", ""),
                "sql": c["SQL"], "gold": gt, "split": "all",
                "difficulty": c.get("difficulty", ""),
            })
    out = {
        "bird": bird_out,
        "spider": spider_cases,
        "spider_train_dbs": sorted(train_dbs),
        "spider_test_dbs": sorted(test_dbs),
        "spider_missing_dbs": missing,
    }
    json.dump(cache, open(CACHE, "w", encoding="utf-8"), ensure_ascii=False)
    json.dump(out, open(CASES_OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("bird cases", len(bird_out), "spider cases", len(spider_cases),
          "test", sum(1 for c in spider_cases if c["split"] == "test"))
    print("cache", CACHE, CACHE.stat().st_size // 1024 // 1024, "MB")
    print("cases", CASES_OUT)


if __name__ == "__main__":
    main()
