"""E11-COST2: the cost comparison done in the same cabin on both sides.

The original H6 verdict ("free operators rejected", e11_cost.json) timed the
dense baseline as a 876x1024 dot product -- 1.2 ms.  That is not what a dense
retriever costs per query: it has to *encode the query* first, and that is a
forward pass through a 0.6B model.  The graph side needs no model at all, so the
honest comparison has to include encoding, index build, and the one-off
per-token diffusion cache.  Everything below is measured on this machine.
"""
from __future__ import annotations

import json
import math
import os
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_run_spider import band_fn, coquery_map, fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
MODEL = "D:/vldb2027_e11/models/Qwen3-Embedding-0.6B"
OUT = REPO / "06_结果" / "e11_cost2.json"
EPS = 1e-6


def pct(ts):
    ts = np.asarray(ts, dtype=np.float64) * 1000.0
    return {"p50": round(float(np.percentile(ts, 50)), 2),
            "p95": round(float(np.percentile(ts, 95)), 2),
            "mean": round(float(ts.mean()), 2), "n": len(ts)}


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    coq = coquery_map([c for c in data["spider"] if c["split"] == "train"], prefix=True)

    t0 = time.perf_counter()
    cat = g.Catalog(tabs, fks, coquery=coq, prefix_db=True)
    build_s = time.perf_counter() - t0
    bf, _ = band_fn(test)
    N = len(cat.tables)
    res = {"n_tables": N, "n_nodes": len(cat.idx), "catalog_build_s": round(build_s, 2),
           "vocab_tokens": sum(1 for k in cat.idx if k[0] == "token")}

    # ---------- graph side ----------
    queries = [toks(c["question"]) for c in test]
    tok = {}
    t_ppr = []
    for w in sorted({w for q in queries for w in q}):
        if ("token", w) not in cat.idx:
            continue
        t0 = time.perf_counter()
        x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
        t_ppr.append(time.perf_counter() - t0)
        s = cat.table_scores(x)
        mx = float(s.max())
        tok[w] = s / mx if mx > 0 else s
    res["per_token_ppr_ms"] = pct(t_ppr)
    res["per_token_ppr_total_s"] = round(float(np.sum(t_ppr)), 2)
    res["tokens_needed_for_341_queries"] = len(tok)
    res["full_vocab_ppr_projected_s"] = round(res["per_token_ppr_ms"]["mean"] / 1000
                                              * res["vocab_tokens"], 1)

    bm25_idx = {"docs": [Counter(g.table_doc(t)) for t in cat.tables]}
    bm25_idx["df"] = Counter()
    for d in bm25_idx["docs"]:
        bm25_idx["df"].update(d.keys())
    avgdl = sum(sum(d.values()) for d in bm25_idx["docs"]) / N
    bm25_idx["idf"] = {t: math.log(1 + (N - n + 0.5) / (n + 0.5)) for t, n in bm25_idx["df"].items()}

    def bm25_fast(q):
        out = np.zeros(N, dtype=np.float32)
        for i, tf in enumerate(bm25_idx["docs"]):
            dl = sum(tf.values())
            s = 0.0
            for w in q:
                f = tf.get(w, 0)
                if f:
                    s += bm25_idx["idf"][w] * f * 2.2 / (f + 1.2 * (0.75 + 0.75 * dl / avgdl))
            out[i] = s
        return out

    lat = {"tokenise": [], "bm25": [], "fuse_and_rerank": [], "graph_full": [], "dense_dot": []}
    z = np.load(EMB, allow_pickle=True)
    Dm = z["D"].astype(np.float32)
    for c, q in zip(test, queries):
        t0 = time.perf_counter(); toks(c["question"]); lat["tokenise"].append(time.perf_counter() - t0)
        t0 = time.perf_counter(); b = bm25_fast(q); lat["bm25"].append(time.perf_counter() - t0)
        ws = [w for w in set(q) if w in tok]
        t0 = time.perf_counter()
        if ws:
            M = np.stack([tok[w] for w in ws])
            iw = np.array([bm25_idx["idf"].get(w, 1.0) for w in ws])[:, None]
            graph = np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
        else:
            graph = np.zeros(N, dtype=np.float32)
        top = np.argsort(-b)[:30]
        base = float(b[top[-1]])
        mixed = b.copy()
        for i, idx in enumerate(top[np.argsort(-graph[top])]):
            mixed[idx] = base + (30 - i) * 1e-6
        _ = g.rank(mixed, cat)
        lat["fuse_and_rerank"].append(time.perf_counter() - t0)
        t0 = time.perf_counter(); _ = g.single_ppr(cat, q, band_weight=bf(q))
        lat["graph_full"].append(time.perf_counter() - t0)
        t0 = time.perf_counter(); _ = Dm @ np.zeros(Dm.shape[1], dtype=np.float32)
        lat["dense_dot"].append(time.perf_counter() - t0)
    res["graph_query_ms"] = {k: pct(v) for k, v in lat.items()}
    res["model_calls_per_query_graph"] = 0

    # ---------- dense side, including the encoding the old run left out ----------
    texts = [g.table_text(dict(t)) for t in cat.tables]
    qs = [c["question"] for c in test]
    for device in (["cpu", "cuda"] if True else []):
        try:
            from sentence_transformers import SentenceTransformer
        except Exception as e:  # noqa: BLE001
            res["dense"] = {"import_failed": str(e)}
            break
        try:
            m = SentenceTransformer(MODEL, device=device)
            m.max_seq_length = 384
        except Exception as e:  # noqa: BLE001
            res.setdefault("dense", {})[device] = {"load_failed": str(e)}
            continue
        if device == "cuda":
            try:
                m.encode(["warmup"], convert_to_numpy=True)
            except Exception as e:  # noqa: BLE001
                res.setdefault("dense", {})[device] = {"cuda_failed": str(e)}
                continue
        t0 = time.perf_counter()
        m.encode(texts, batch_size=16, normalize_embeddings=True, convert_to_numpy=True,
                 show_progress_bar=False)
        index_s = time.perf_counter() - t0
        one = []
        for s in qs[:120]:
            t0 = time.perf_counter()
            m.encode([s], normalize_embeddings=True, convert_to_numpy=True, prompt_name="query",
                     show_progress_bar=False)
            one.append(time.perf_counter() - t0)
        batched = None
        t0 = time.perf_counter()
        m.encode(qs, batch_size=32, normalize_embeddings=True, convert_to_numpy=True,
                 prompt_name="query", show_progress_bar=False)
        batched = time.perf_counter() - t0
        res.setdefault("dense", {})[device] = {
            "index_build_876_docs_s": round(index_s, 2),
            "query_encode_ms_single": pct(one),
            "query_encode_ms_batched": round(1000 * batched / len(qs), 2),
            "end_to_end_query_ms_p50": round(res["dense"][device]["query_encode_ms_single"]["p50"]
                                             + res["graph_query_ms"]["dense_dot"]["p50"], 2)}
        del m
        if device == "cuda" and os.environ.get("COST2_STOP_AFTER_CUDA") == "1":
            break
    res["note"] = ("dense_dot is the 876x1024 similarity scan only; the number that matters "
                   "is query_encode_ms_single, which is what a serving path pays per query.")
    json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(res, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
