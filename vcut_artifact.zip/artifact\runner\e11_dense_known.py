"""E11: dense retrieval and certificates inside a single known database.

The merged-catalog run is a data-lake stress test.  This is the realistic
deployment setting: the analyst knows which database they are querying, so the
candidate set is that database's tables.  Same schema documents, same
certificate rules.
"""
from __future__ import annotations

import json
import math
import sys
from collections import Counter
from itertools import combinations
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
OUT = REPO / "06_结果" / "e11_spider_known_dense.json"


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    train = [c for c in data["spider"] if c["split"] == "train"]
    npz = np.load(EMB, allow_pickle=True)
    ids = [str(x) for x in npz["ids"]]
    D = npz["D"].astype(np.float32)
    Q = {str(q): v for q, v in zip([str(x) for x in npz["qids"]], npz["Q"].astype(np.float32))}
    pos = {t: i for i, t in enumerate(ids)}

    by_db = {}
    for c in test:
        by_db.setdefault(c["db_id"], []).append(c)
    rows = []
    for db, cs in by_db.items():
        tabs = [dict(t, db=db) for t in cache["spider"][db]["tables"]]
        have = {t["name"] for t in cache["spider"][db]["tables"]}
        fks = [[a, ca, b, cb] for a, ca, b, cb in cache["spider"][db]["fks"]
               if a in have and b in have]
        coq = Counter()
        tc = [c for c in train if c["db_id"] == db]
        for c in tc:
            for a, b in combinations(sorted(c["gold"]), 2):
                coq[(a, b)] += 1
                coq[(b, a)] += 1
        coq = Counter({k: math.log(1 + v) for k, v in coq.items()})
        cat = g.Catalog(tabs, fks, coquery=coq, prefix_db=False)
        qdf = Counter()
        for c in cs:
            qdf.update(set(toks(c["question"])))
        hi = float(np.quantile(sorted(qdf.values()), 0.8))
        cand = [pos[f"{db}::{t['name']}"] for t in cat.tables]
        for c in cs:
            q = toks(c["question"])
            gold = set(c["gold"])
            bw = {x: (0.15 if qdf[x] >= hi else 1.0) for x in q}
            dense = np.zeros(len(cat.tables), dtype=np.float32)
            dense[:] = D[cand] @ Q[c["qid"]]
            typed = g.fuse(cat, q, band_weight=bw)
            bm = g.bm25(cat, q)
            tn = typed / (typed.max() + 1e-9)
            scores = {"dense": dense, "typed_band": typed, "bm25": bm,
                      "dense_plus_typed": dense + tn}
            row = {"qid": c["qid"], "db": db, "gold": sorted(gold)}
            for name, s in scores.items():
                r = g.rank(s, cat)
                row[name] = {"top5": r[:5], **g.metrics(r, gold),
                             "cert": g.certify(cat, s, q, gold)}
            rows.append(row)
    out = {"n": len(rows), "metrics": {m: g.mean_metrics([r[m] for r in rows])
                                       for m in scores}, "rows": rows}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({"n": out["n"], "metrics": out["metrics"]}, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
