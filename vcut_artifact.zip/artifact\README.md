# Artifact for "Coverage-Aware Compilation of Mixed-Determinism Data Pipelines"

This artifact contains the checker, the pipeline generator, the experiment runners and
the decision tables needed to reproduce every number in the paper.

## Layout

```
checker/                static analysis core
  graphutil.py            reachability, dominators, min vertex/edge cut
  decision_table.py       verdict tables, coverage and default-region semantics
  triple_judge.py         per-tuple judgment and the judged bit
  repair.py               minimum-cut repair, insertion and certificate
  axioms.py               the five-way check on a compiled pipeline
generator/
  synth.py                pipeline generator used by the factorial studies
runner/
  e1.py                   E1: 1,728-pipeline factorial design, both error directions
  e1b_real_false_safety.py E1a/E1b: the two failures on the permit-pipeline compiler
  e2.py                   E2: cascade and layout checks
  e3.py                   E3: checker cost against the compilation budget
  e4.py                   E4: re-verification after rewriting
  e7_receipts.py          E7: arithmetic closure on receipts
  e7_sql_pilot.py         E8: structural checks on text-to-SQL output
tests/                  unit tests for the decision table, repair and semantics
04_数据/gb30871/         the GB 30871 decision table encoded as executable rules
04_数据/permits/         receipt and permit samples used by E7
06_结果/                experiment output, created by the runners
e0_selfcheck.py         E0: definition self-consistency on random pipelines
run_all.py              one-command entry point
```

## Run

```bash
python -m pip install -r requirements.txt
python run_all.py             # E0 2k + unit tests + E1 + E2 mock + E3 pilot + E4
python run_all.py --full      # E0 2x10k + E1 + E2 500 + E3 1500
python run_all.py --with-real # additionally E1b, needs an external compiler checkout
```

Every runner writes JSON into `06_结果/`. E1b is skipped by default because it reads a
proprietary permit-platform checkout; set it up at `D:/prod/permit-platform` and pass
`--with-real` to run it.

## Reviewer tests

```bash
python -m unittest discover -s tests -v
```

The suite covers the decision table, repair, semantics and the two failure directions.
E1a and E1b cannot run without the proprietary compiler, so `tests/test_two_failures.py`
rebuilds both graphs with the shipped generator: it asserts that the dominator check
rejects the safe branching pipeline (E1a), accepts the pass-default pipeline (E1b), and
that the cut over effective verdicts is correct in both cases.

E7 and E8 replay model outputs and are invoked directly:

```bash
python runner/e7_receipts.py
python runner/e7_sql_pilot.py
```

Both read cached model responses; no API key is needed for the reported numbers.

## Hardware

CPU only. The full path takes a few minutes; the quick path takes under a minute.

## Paper item -> script

| Paper item | What it reports | Script |
|---|---|---|
| E0, §6.1 | four theorems, two independent implementations, zero disagreement | `e0_selfcheck.py` |
| E1, §6.2, Table 4 | false release and false alarm over 1,728 pipelines | `runner/e1.py` |
| E1a/E1b, §6.3 | both failure directions on the real compiler | `runner/e1b_real_false_safety.py` |
| E3, §6.4 | check cost, 19.3 ms at 500 nodes | `runner/e3.py` |
| E4, §6.5 | repair restores safety, second pass changes nothing | `runner/e4.py` |
| E7, §6.6, Tables 7-8 | coverage and false pass on receipts | `runner/e7_receipts.py` |
| E8, §6.6, Table 9 | 498 text-to-SQL questions, zero false kills | `runner/e7_sql_pilot.py` |
| Fig. 1-3 | architecture, repair loop, repair cost | figure sources in `07_写作/vcut/`, not shipped here |

## License

Code MIT. GB 30871 decision table is a derived encoding of the public standard.
