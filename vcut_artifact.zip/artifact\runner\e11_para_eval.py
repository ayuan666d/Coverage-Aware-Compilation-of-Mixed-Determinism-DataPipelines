"""E11 paraphrase robustness on the merged Spider catalog.

For 262 questions with three leak-free rewrites, compare the drop from the
original question for BM25, typed diffusion and the dense embedding.  This is
the direct test of the claim that lexical/graph retrieval breaks when the user
does not use schema vocabulary.
"""
from __future__ import annotations

import json
import os
import math
import sys
from collections import Counter
from itertools import combinations
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
PARA = REPO / "06_结果" / "e11_paraphrase.json"
MODEL = "D:/vldb2027_e11/models/Qwen3-Embedding-0.6B"
OUT = REPO / "06_结果" / "e11_paraphrase_eval.json"
STYLES = ["orig", "synonym", "colloquial", "expert"]


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    para = json.load(open(PARA, encoding="utf-8"))["rows"]
    train = [c for c in data["spider"] if c["split"] == "train"]

    tables, fks = [], []
    for db, s in cache["spider"].items():
        tables += [dict(t, db=db) for t in s["tables"]]
        have = {t["name"] for t in s["tables"]}
        fks += [[f"{db}::{a}", ca, f"{db}::{b}", cb] for a, ca, b, cb in s["fks"]
                if a in have and b in have]
    pc = Counter()
    for c in train:
        for a, b in combinations(sorted(c["gold"]), 2):
            pc[(f"{c['db_id']}::{a}", f"{c['db_id']}::{b}")] += 1
            pc[(f"{c['db_id']}::{b}", f"{c['db_id']}::{a}")] += 1
    coq = Counter({k: math.log(1 + v) for k, v in pc.items()})
    cat = g.Catalog(tables, fks, coquery=coq, prefix_db=True, views=False)
    para = [c for c in para if not c.get("fallback")][:120]

    qdf = Counter()
    for c in para:
        qdf.update(set(toks(c["orig"])))
    hi = float(np.quantile(sorted(qdf.values()), 0.8))

    from sentence_transformers import SentenceTransformer
    npz = np.load(Path("D:/vldb2027_e11/e11_emb_spider.npz"), allow_pickle=True)
    doc_ids = [str(x) for x in npz["ids"]]
    order = [f"{t['db']}::{t['name']}" for t in cat.tables]
    assert doc_ids == order, "catalog and cached embeddings are out of sync"
    Dt = npz["D"].astype(np.float32)
    cache_emb = Path("D:/vldb2027_e11/para_emb.npz")
    texts = []
    for c in para:
        texts += [c[s] for s in STYLES]
    if cache_emb.exists():
        z = np.load(cache_emb, allow_pickle=True)
        if [str(x) for x in z["ids"]] == [c["qid"] for c in para]:
            E = z["E"].astype(np.float32)
        else:
            E = None
    else:
        E = None
    if E is None:
        model = SentenceTransformer(MODEL, device=os.environ.get("ST_DEVICE", "cpu"))
        model.max_seq_length = 128
        E = model.encode(texts, batch_size=32, normalize_embeddings=True,
                         show_progress_bar=False, convert_to_numpy=True,
                         prompt_name="query")
        np.savez_compressed(cache_emb, ids=np.array([c["qid"] for c in para]),
                            E=E.astype(np.float16))

    rows = []
    for i, c in enumerate(para):
        gold = {f"{c['db']}::{t}" for t in c["gold"]}
        rec = {"qid": c["qid"], "fallback": bool(c.get("fallback"))}
        for j, style in enumerate(STYLES):
            q = toks(c[style])
            bw = {x: (0.15 if qdf[x] >= hi else 1.0) for x in q}
            dense = Dt @ E[i * len(STYLES) + j]
            scores = {"bm25": g.bm25(cat, q),
                      "graph": g.single_ppr(cat, q, band_weight=bw),
                      "dense": dense}
            for name, s in scores.items():
                r = g.rank(s, cat)
                rec[f"{style}_{name}"] = g.metrics(r, gold)
        rows.append(rec)

    clean = [r for r in rows if not r["fallback"]]
    agg = {}
    for style in STYLES:
        agg[style] = {m: g.mean_metrics([r[f"{style}_{m}"] for r in clean])
                      for m in ("bm25", "graph", "dense")}
    drop = {m: round(agg["orig"][m]["recall@5"] - agg["expert"][m]["recall@5"], 4)
            for m in ("bm25", "graph", "dense")}
    out = {"n": len(rows), "n_clean": len(clean), "by_style": agg,
           "drop_expert_vs_orig": drop, "rows": rows}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
