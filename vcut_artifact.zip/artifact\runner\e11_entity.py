"""E11 entity matching: field-typed graph versus bag-of-tokens graph.

Magellan-style records are "title: ... manufacturer: ... price: ...".  The
untyped graph connects a token directly to a record, so a token that happens to
appear in a different field still votes.  The typed graph routes every token
through its field node (title/manufacturer/price/venue/year), which is the same
role-versus-proximity distinction the receipts showed.

Retrieval setting: for each left record, rank all distinct right records; the
gold set is the right records labelled as a match.
"""
from __future__ import annotations

import json
import os
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import sparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e11_graph import ppr, rownorm, toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
EM = Path("D:/vldb2027_e11/em")
OUT = REPO / "06_结果" / "e11_entity.json"
MODEL = "D:/vldb2027_e11/models/Qwen3-Embedding-0.6B"
FIELDS = ["title", "manufacturer", "price", "venue", "year"]
PAT = re.compile(r"(title|manufacturer|price|venue|year|publisher|authors|date)\s*:\s*([^.]*)")


def parse(s):
    out = {}
    for k, v in PAT.findall(str(s).lower()):
        out.setdefault(k, v.strip())
    return out


def build(df):
    rights = sorted({r for r in df["productB"]})
    ridx = {r: i for i, r in enumerate(rights)}
    lefts = []
    gold = defaultdict(set)
    for _, row in df.iterrows():
        if bool(row["same"]):
            gold[row["productA"]].add(ridx[row["productB"]])
    return rights, ridx, gold


def recall_at(ranked, g, k):
    return len(set(ranked[:k]) & g) / max(1, len(g))


def graph_scores(recs, queries, typed):
    """Token -> (field) -> record bipartite graph; query tokens seed, rank records."""
    n_rec, n_q = len(recs), len(queries)
    nodes = {}

    def nid(kind, key):
        k = (kind, key)
        if k not in nodes:
            nodes[k] = len(nodes)
        return nodes[k]

    edges = []
    for i, fields in enumerate(recs):
        rn = nid("record", i)
        for f, txt in fields.items():
            for w in set(toks(txt)):
                # typed: the token node is scoped by the field it came from, so a
                # word can only vote through the same field on the other side.
                # untyped: one bag of token nodes shared by every field.
                key = f"{f}:{w}" if typed else w
                wn = nid("token", key)
                edges += [(wn, rn, 1.0), (rn, wn, 1.0)]
    for j, fields in enumerate(queries):
        qn = nid("query", j)
        for f, txt in fields.items():
            for w in set(toks(txt)):
                key = f"{f}:{w}" if typed else w
                wn = nid("token", key)
                edges += [(qn, wn, 1.0), (wn, qn, 1.0)]
    N = len(nodes)
    r = np.array([e[0] for e in edges], dtype=np.int32)
    c = np.array([e[1] for e in edges], dtype=np.int32)
    w = np.array([e[2] for e in edges], dtype=np.float32)
    A = sparse.coo_matrix((w, (r, c)), shape=(N, N)).tocsr()
    P = rownorm(A)
    out = np.zeros((n_q, n_rec), dtype=np.float32)
    rec_pos = {nid("record", i): i for i in range(n_rec)}
    for j in range(n_q):
        x = ppr(P, {nid("query", j): 1.0}, alpha=0.85, iters=25)
        for node, i in rec_pos.items():
            out[j, i] = x[node]
    return out


def main():
    res = {}
    for name in ["DBLP_ACM", "Amazon_Google"]:
        df = pd.read_parquet(EM / f"{name}_test.parquet")
        rights, ridx, gold = build(df)
        right_fields = [parse(r) for r in rights]
        left_names = sorted(gold)
        left_fields = [parse(l) for l in left_names]
        df_doc = [" ".join(f.values()) for f in right_fields]
        q_doc = [" ".join(f.values()) for f in left_fields]

        # BM25
        from e11_graph import Catalog, bm25, tfidf
        N = len(df_doc)
        docs = [toks(d) for d in df_doc]
        dfc = Counter()
        for d in docs:
            dfc.update(set(d))
        avgdl = np.mean([len(d) for d in docs])
        def bm25_scores(q, k1=1.2, b=0.75):
            import math
            out = np.zeros(N, dtype=np.float32)
            for i, d in enumerate(docs):
                tf = Counter(d)
                s = 0.0
                for w in set(q):
                    f = tf.get(w, 0)
                    if not f:
                        continue
                    idf = math.log(1 + (N - dfc[w] + 0.5) / (dfc[w] + 0.5))
                    s += idf * f * (k1 + 1) / (f + k1 * (1 - b + b * len(d) / avgdl))
                out[i] = s
            return out

        untyped = graph_scores(right_fields, left_fields, typed=False)
        typed = graph_scores(right_fields, left_fields, typed=True)

        from sentence_transformers import SentenceTransformer
        m = SentenceTransformer(MODEL, device=os.environ.get("ST_DEVICE", "cpu"))
        m.max_seq_length = 256
        Dr = m.encode(df_doc, batch_size=32, normalize_embeddings=True, convert_to_numpy=True)
        Dl = m.encode(q_doc, batch_size=32, normalize_embeddings=True, convert_to_numpy=True,
                      prompt_name="query")
        dense = Dl @ Dr.T

        # tail = left records whose title tokens are rare in the right corpus
        tok_df = Counter()
        for d in docs:
            tok_df.update(set(d))
        methods = {"bm25": [], "graph_untyped": [], "graph_typed": [], "dense": []}
        tail_rows = []
        for j, l in enumerate(left_names):
            g = gold[l]
            for name_, S in [("bm25", bm25_scores(toks(q_doc[j]))),
                             ("graph_untyped", untyped[j]),
                             ("graph_typed", typed[j]),
                             ("dense", dense[j])]:
                ranked = list(np.argsort(-S))
                methods[name_].append({"r@1": recall_at(ranked, g, 1),
                                       "r@5": recall_at(ranked, g, 5),
                                       "r@10": recall_at(ranked, g, 10)})
            rare = [w for w in toks(q_doc[j]) if tok_df[w] <= 2]
            if rare:
                tail_rows.append(j)
        out = {"n_left": len(left_names), "n_right": N,
               "metrics": {k: {kk: round(float(np.mean([r[kk] for r in v])), 4)
                               for kk in ("r@1", "r@5", "r@10")} for k, v in methods.items()},
               "tail_n": len(tail_rows),
               "tail_metrics": {k: {kk: round(float(np.mean([methods[k][j][kk] for j in tail_rows])), 4)
                                    for kk in ("r@1", "r@5", "r@10")} for k in methods}}
        res[name] = out
        print(name, json.dumps(out["metrics"], ensure_ascii=False), flush=True)
    json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
