"""E25: hierarchical routing — route the question to databases first, rank inside.

The catalog is flat: 876 tables scored together.  Databases are a hierarchy
(database -> table -> column) and the flat scorer has no database level.  This
arm adds the missing level:

  stage 1: BM25 between question and a database-level document (all names+values
           of that database)
  stage 2: the existing 9-primitive closed-form score, restricted to the tables
           of the top-k databases

Compare with the flat scorer (k = all databases).  Spider 693/341.
"""
from __future__ import annotations

import json
import math
import sys
from collections import Counter

import numpy as np

sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码\runner")
import e14_db_anchor as e14  # noqa: E402
import e16_transfer as e16  # noqa: E402
from e15_objective import fit_fisher  # noqa: E402

OUT = e14.REPO / "06_结果" / "e25_routing.json"


def main():
    meta = e14.load()
    cache = json.load(open(e14.CACHE, encoding="utf-8"))["spider"]
    doc_ids = [str(x) for x in np.load(e14.NPZ, allow_pickle=True)["doc_ids"]]
    didx = {f: i for i, f in enumerate(doc_ids)}
    db_of = [d.split("::")[0] for d in doc_ids]
    dbs = sorted(set(db_of))
    db_tables = {db: [j for j, d in enumerate(db_of) if d == db] for db in dbs}

    # database-level documents: all tokens of all tables
    db_tokens = {}
    for db, s in cache.items():
        toks = []
        for t in s["tables"]:
            toks += e14.wtoks(t["name"])
            for c in t["columns"]:
                toks += e14.wtoks(c["name"])
                for v in (c.get("values") or [])[:12]:
                    toks += e14.wtoks(str(v))
        db_tokens[db] = set(toks)
    idf_db = {t: math.log(1 + (len(dbs) - sum(1 for d in dbs if t in db_tokens[d]) + 0.5)
                          / (sum(1 for d in dbs if t in db_tokens[d]) + 0.5))
              for t in set().union(*db_tokens.values())}

    Ft = meta["build_F"](meta["train_q"])[:, :, e16.KEEP]
    mu = Ft.reshape(-1, 9).mean(0)
    sd = Ft.reshape(-1, 9).std(0) + 1e-9
    Fte = ((meta["build_F"](meta["test_q"])[:, :, e16.KEEP] - mu) / sd)
    Y = np.zeros((len(meta["train_q"]), meta["D"]), dtype=np.float32)
    for qi, q in enumerate(meta["train_q"]):
        for f in meta["gold_all"][q]:
            j = meta["didx"].get(f)
            if j is not None:
                Y[qi, j] = 1.0
    w = fit_fisher(((Ft.reshape(-1, 9) - mu) / sd), Y.reshape(-1), 0.1)

    qtext = {c["qid"]: c["question"] for c in meta["cases"]}
    out = {}
    for k in (1, 2, 3, 5, 10, 20, 50, len(dbs)):
        rows = []
        for qi, q in enumerate(meta["test_q"]):
            qt = set(e14.wtoks(qtext[q]))
            dsc = {db: sum(idf_db.get(t, 0.0) for t in qt & db_tokens[db]) for db in dbs}
            keep = sorted(dsc, key=lambda d: -dsc[d])[:k]
            allowed = [j for db in keep for j in db_tables[db]]
            sc = Fte[qi] @ w
            order = [j for j in np.argsort(-sc) if j in set(allowed)][:5]
            top = [doc_ids[i] for i in order]
            r, m = e14.metrics_top(top, meta["gold_all"][q])
            rows.append((r[1], r[3], r[5], m, len(allowed)))
        out[str(k)] = {kk: round(float(np.mean([r[i] for r in rows])), 4)
                       for i, kk in enumerate(("recall@1", "recall@3", "recall@5", "mrr"))}
        out[str(k)]["avg_candidates"] = round(float(np.mean([r[4] for r in rows])), 1)
        print("k", k, json.dumps(out[str(k)]), flush=True)

    json.dump({"routing": out, "n_dbs": len(dbs),
               "reference": {"flat_first_r5": 0.7023, "flat_first_r1": 0.3974}},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
