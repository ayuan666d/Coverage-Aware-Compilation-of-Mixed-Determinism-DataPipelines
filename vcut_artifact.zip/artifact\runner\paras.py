"""List prose paragraph sizes in a LaTeX paper, so tiny paragraphs can be merged.

Skips float environments, lists, sections and display math.
"""
import re
import sys

FLOAT = re.compile(r"\\begin\{(table|figure|tabular|tabularx|itemize|enumerate|equation|align)\*?\}")


def blocks(text):
    """Yield (start, end, kind) for float-ish environments vs prose."""
    i = 0
    while True:
        m = FLOAT.search(text, i)
        if not m:
            yield (i, len(text), "prose")
            return
        if m.start() > i:
            yield (i, m.start(), "prose")
        name = m.group(1)
        end = re.compile(r"\\end\{" + name + r"\*?\}").search(text, m.end())
        e = end.end() if end else len(text)
        yield (m.start(), e, "float")
        i = e


def main(path):
    s = open(path, encoding="utf-8").read()
    body = s.split("\\bibliographystyle")[0]
    paras = []
    for a, b, kind in blocks(body):
        if kind != "prose":
            continue
        seg = body[a:b]
        # split on blank lines
        for chunk in re.split(r"\n\s*\n", seg):
            c = chunk.strip()
            if not c:
                continue
            if c.startswith("\\") and re.match(r"\\(sub)?section|\\label|\\maketitle|\\begin|\\end", c):
                continue
            # drop command-only lines
            plain = re.sub(r"\\[a-zA-Z]+\*?(\[[^\]]*\])?(\{[^{}]*\})?", "", c)
            plain = re.sub(r"[{}$\\]", "", plain)
            n = len(re.findall(r"[A-Za-z][A-Za-z'\-]+", plain))
            if n == 0:
                continue
            paras.append((n, c[:90].replace("\n", " ")))
    small = [p for p in paras if p[0] < 40]
    print(f"paragraphs={len(paras)}  words={sum(p[0] for p in paras)}  tiny(<40w)={len(small)}")
    for n, head in small:
        print(f"  {n:3d}  {head}")


if __name__ == "__main__":
    main(sys.argv[1])
