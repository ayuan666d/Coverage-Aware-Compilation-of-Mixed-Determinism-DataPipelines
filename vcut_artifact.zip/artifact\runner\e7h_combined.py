"""E7h: combine arithmetic certification with the OCR total reader.

Two deterministic witnesses are available without gold:

1. arithmetic closure of subtotal / tax / service / discount (E7e);
2. an independent OCR label reader that takes the amount printed next to
   "total", "grand total", "netto", "due", ... (E7f).

The model total is a third, uncertain witness.  This script measures three
operating points on the 800 CORD receipts: arithmetic only, agreement only,
and their union.  It re-judges the saved model outputs, so no API call is made.
"""
from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e7_receipts as e7  # noqa: E402

REPO = e7.REPO
RAW = REPO / "06_结果" / "e7_receipts.json"
RULE = REPO / "06_结果" / "e7f_ocr_total.json"
OUT = REPO / "06_结果" / "e7h_combined.json"


def metrics(rows, pred):
    acc = [r for r in rows if pred(r)]
    known = [r for r in acc if r["total_correct"] is not None]
    fp = sum(1 for r in known if r["total_correct"] is False)
    return {
        "n": len(rows),
        "accept": len(acc),
        "automation": round(len(acc) / len(rows), 4),
        "known": len(known),
        "false_pass": fp,
        "false_pass_rate": round(fp / len(rows), 4),
        "precision": round((len(known) - fp) / len(known), 4) if known else None,
    }


def main():
    raw = {r["file"]: r for r in json.load(open(RAW, encoding="utf-8"))["rows"]}
    rule = {r["file"]: r for r in json.load(open(RULE, encoding="utf-8"))["rows"]}
    rows = []
    for f, r in raw.items():
        j = e7.judge(r["model"], r["gold"], r["text"])
        rr = rule.get(f, {})
        rows.append({
            "file": f,
            "gold": r["gold"]["total"],
            "model": r["model"].get("total"),
            "final": j["final_total"],
            "verdict": j["verdict"],
            "total_correct": j["total_correct"],
            "model_total_correct": j["model_total_correct"],
            "rule": rr.get("rule"),
            "rule_ok": rr.get("rule_ok"),
            "agree": rr.get("agree"),
            "checks": j["checks"],
        })
    policies = {
        "model_only": lambda r: True,
        "arith_certified": lambda r: r["verdict"] in ("accept", "fill"),
        "agreement_only": lambda r: r["agree"] is True,
        "arith_or_agreement": lambda r: r["verdict"] in ("accept", "fill") or r["agree"] is True,
    }
    summary = {k: metrics(rows, p) for k, p in policies.items()}
    summary["verdicts"] = dict(Counter(r["verdict"] for r in rows))
    summary["review_agree"] = sum(1 for r in rows if r["verdict"] == "review" and r["agree"])
    summary["review_total"] = sum(1 for r in rows if r["verdict"] == "review")
    summary["review_correct"] = sum(1 for r in rows if r["verdict"] == "review" and r["total_correct"])
    summary["review_wrong"] = sum(1 for r in rows if r["verdict"] == "review" and r["total_correct"] is False)
    summary["model_wrong"] = sum(1 for r in rows if r["model_total_correct"] is False)
    summary["false_pass_files"] = [
        {"file": r["file"], "gold": r["gold"], "model": r["model"], "final": r["final"],
         "verdict": r["verdict"], "agree": r["agree"]}
        for r in rows
        if r["total_correct"] is False and (r["verdict"] in ("accept", "fill") or r["agree"])
    ]
    json.dump({"summary": summary, "rows": rows}, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
