# -*- coding: utf-8 -*-
"""构造性修复器的最小单测（无 pytest 依赖：python -m unittest）。

覆盖：
    · 旁路修复（width=1 割）
    · 双路宽度 2 割（Menger 对偶）
    · 幂等性（repair(repair(x)) = already_safe）
    · 源即汇不可修复
    · 多出口残余贪心（共享割复用，插入数 ≤ 出口数）
    · 兜底方向约束（胶水层强制 fallback=reject）
    · 环输入拒绝
    · A 组枚举对拍（修复后管线经 axioms.v1_by_enumeration 独立确认）
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from checker import axioms  # noqa: E402
from checker.repair import repair_edge_insertion  # noqa: E402
from generator.synth import Pipe, Table  # noqa: E402
from runner.e4b_repair import repair_pipe  # noqa: E402


def _pipe(nodes, edges) -> Pipe:
    return Pipe(nodes=dict(nodes), edges=list(edges))


def _a_side_safe(pipe: Pipe) -> bool:
    """A 组枚举对拍（axioms 刻意不 import graphutil）。"""
    case = axioms.Case(
        nodes=tuple(sorted(pipe.nodes)),
        edges=tuple(pipe.edges),
        sinks=tuple(pipe.sinks()),
        v_eff=frozenset(pipe.verdicts()),
    )
    safe, _bad = axioms.v1_by_enumeration(case)
    return safe


class TestRepairEdgeInsertion(unittest.TestCase):
    def test_bypass_width1(self):
        # src→map→v→sink，外加旁路 map→sink（避开 v）
        nodes = {"src": "source", "map": "map", "v": "rule", "sink": "sink"}
        edges = [("src", "map"), ("map", "v"), ("v", "sink"), ("map", "sink")]
        out = repair_edge_insertion(nodes, edges, {"v"}, ["src"], ["sink"])
        self.assertEqual(out.status, "repaired")
        self.assertTrue(out.verified_safe)
        self.assertEqual(out.stats["n_insertions"], 1)
        self.assertEqual(out.per_sink[0].width, out.per_sink[0].menger)

    def test_two_disjoint_paths_width2(self):
        # 双路均无判决：最小边割宽 = 2
        nodes = {"src": "source", "a": "map", "b": "map", "s": "sink"}
        edges = [("src", "a"), ("src", "b"), ("a", "s"), ("b", "s")]
        out = repair_edge_insertion(nodes, edges, set(), ["src"], ["s"])
        self.assertEqual(out.status, "repaired")
        self.assertTrue(out.verified_safe)
        self.assertEqual(out.stats["n_insertions"], 2)
        self.assertEqual(out.per_sink[0].width, 2)
        self.assertEqual(out.per_sink[0].menger, 2)

    def test_idempotent(self):
        nodes = {"src": "source", "m": "map", "s": "sink"}
        edges = [("src", "m"), ("m", "s")]
        first = repair_edge_insertion(nodes, edges, set(), ["src"], ["s"])
        self.assertEqual(first.status, "repaired")
        second = repair_edge_insertion(
            {**nodes, **first.new_nodes}, first.new_edges,
            {"v_fix0"}, ["src"], ["s"],
        )
        self.assertEqual(second.status, "already_safe")
        self.assertEqual(second.stats["n_insertions"], 0)

    def test_source_sink_unrepairable(self):
        # 单节点既是源又是汇：空路径无边可割
        nodes = {"s": "sink"}
        out = repair_edge_insertion(nodes, [], set(), ["s"], ["s"])
        self.assertEqual(out.status, "unrepairable")
        self.assertIn("s", out.unrepairable_reasons)

    def test_multi_sink_residual_greedy(self):
        # src→m→s1 / m→s2：无判决。修 s1 后其插入可能顺带护住 s2
        # （割落点实现定义），断言安全与插入数上界，不钉死具体数。
        nodes = {"src": "source", "m": "map", "s1": "sink", "s2": "sink"}
        edges = [("src", "m"), ("m", "s1"), ("m", "s2")]
        out = repair_edge_insertion(nodes, edges, set(), ["src"], ["s1", "s2"])
        self.assertTrue(out.verified_safe)
        self.assertLessEqual(out.stats["n_insertions"], 2)

    def test_cycle_refused(self):
        nodes = {"a": "map", "b": "map"}
        edges = [("a", "b"), ("b", "a")]
        with self.assertRaises(ValueError):
            repair_edge_insertion(nodes, edges, set(), ["a"], [])

    def test_cut_edges_exclude_verdict_incident(self):
        # 割只落在非判决节点之间（blocked 集把判决节点整点移除）
        nodes = {"src": "source", "m": "map", "v": "rule", "s": "sink"}
        edges = [("src", "m"), ("m", "v"), ("v", "s"), ("m", "s")]
        out = repair_edge_insertion(nodes, edges, {"v"}, ["src"], ["s"])
        for sr in out.per_sink:
            for (a, b) in sr.cut_edges:
                self.assertNotIn(a, {"v"})
                self.assertNotIn(b, {"v"})


class TestRepairPipeGlue(unittest.TestCase):
    def test_glue_attaches_conservative_fallback(self):
        pipe = _pipe(
            {"src": "source", "m": "map", "s": "sink"},
            [("src", "m"), ("m", "s")],
        )
        fixed, out = repair_pipe(pipe)
        self.assertEqual(out.status, "repaired")
        self.assertTrue(out.verified_safe)
        for v in out.new_nodes:
            self.assertEqual(fixed.nodes[v], "rule")
            self.assertIn(v, fixed.tables)
            self.assertEqual(fixed.tables[v].fallback, "reject")
            self.assertEqual(fixed.tables[v].rules, [])
        # 修复后整表逐输入 judged（v0.3 定义 5：兜底 reject ⟹ judged）
        for t in fixed.tables.values():
            if t.rules == [] and t.fallback == "reject":
                self.assertTrue(t.eff_all(fixed.input_space))

    def test_glue_safe_pipe_untouched(self):
        pipe = _pipe(
            {"src": "source", "v": "rule", "s": "sink"},
            [("src", "v"), ("v", "s")],
        )
        pipe.tables["v"] = Table(rules=[], fallback="reject")
        fixed, out = repair_pipe(pipe)
        self.assertEqual(out.status, "already_safe")
        self.assertEqual(fixed.edges, pipe.edges)

    def test_glue_repaired_passes_a_side(self):
        pipe = _pipe(
            {"src": "source", "m": "map", "s": "sink"},
            [("src", "m"), ("m", "s")],
        )
        fixed, out = repair_pipe(pipe)
        self.assertTrue(out.verified_safe)
        self.assertTrue(_a_side_safe(fixed))


if __name__ == "__main__":
    unittest.main()
