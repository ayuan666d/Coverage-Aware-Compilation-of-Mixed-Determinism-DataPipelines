"""E7i: history-selected guards on random splits.

The 400/400 table in E7 is a stability check, not a clean forward test: the
discount guard was motivated by cases in both halves.  Here the split is
pre-registered (seed 0..9), each guard is enabled only if, on the training
half, it rejects more wrong totals than correct ones among the arithmetic
accepted set, and the frozen selection is applied to the test half.
"""
from __future__ import annotations

import json
import random
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e7_receipts as e7  # noqa: E402

REPO = e7.REPO
RAW = REPO / "06_结果" / "e7_receipts.json"
RULE = REPO / "06_结果" / "e7f_ocr_total.json"
OUT = REPO / "06_结果" / "e7i_split_guards.json"


def pre_accept(ch):
    return bool(ch.get("components_close") and ch.get("total_grounded"))


def metrics(rows, pred):
    acc = [r for r in rows if pred(r)]
    known = [r for r in acc if r["correct"] is not None]
    fp = sum(1 for r in known if r["correct"] is False)
    return {
        "n": len(rows), "accept": len(acc),
        "automation": round(len(acc) / len(rows), 4) if rows else 0,
        "false_pass": fp,
        "false_pass_rate": round(fp / len(rows), 4) if rows else 0,
        "precision": round((len(known) - fp) / len(known), 4) if known else None,
    }


def main():
    raw = {r["file"]: r for r in json.load(open(RAW, encoding="utf-8"))["rows"]}
    rule = {r["file"]: r for r in json.load(open(RULE, encoding="utf-8"))["rows"]}
    rows = []
    for f, r in raw.items():
        j = e7.judge(r["model"], r["gold"], r["text"])
        ch = j["checks"]
        rows.append({
            "file": f, "correct": j["total_correct"], "pre": pre_accept(ch),
            "scale": bool(ch.get("scale_shift")),
            "disc": bool(ch.get("discount_unlabeled")),
            "agree": rule.get(f, {}).get("agree") is True,
            "model_ok": j["model_total_correct"],
        })

    all_results = []
    for seed in range(10):
        rnd = random.Random(seed)
        idx = list(range(len(rows)))
        rnd.shuffle(idx)
        cut = len(idx) // 2
        train = [rows[i] for i in idx[:cut]]
        test = [rows[i] for i in idx[cut:]]
        selected = []
        detail = {}
        for name in ("scale", "disc"):
            w = sum(1 for r in train if r["pre"] and r[name] and r["correct"] is False)
            c = sum(1 for r in train if r["pre"] and r[name] and r["correct"] is True)
            detail[name] = {"wrong": w, "correct": c}
            if w > c and w >= 1:
                selected.append(name)
        post = lambda r: r["pre"] and not any(r[g] for g in selected)
        union = lambda r: (r["pre"] and not any(r[g] for g in selected)) or r["agree"]
        res = {
            "seed": seed, "selected": selected, "train_guard": detail,
            "test_model": metrics(test, lambda r: True),
            "test_pre": metrics(test, lambda r: r["pre"]),
            "test_post": metrics(test, post),
            "test_union": metrics(test, union),
        }
        all_results.append(res)
        print(seed, selected, detail,
              "post", res["test_post"], "union", res["test_union"])

    def agg(key, field):
        return {
            "mean": round(statistics.mean(r[key][field] for r in all_results), 4),
            "min": round(min(r[key][field] for r in all_results), 4),
            "max": round(max(r[key][field] for r in all_results), 4),
        }
    summary = {
        "seeds": 10,
        "selected_counts": {
            "scale": sum("scale" in r["selected"] for r in all_results),
            "disc": sum("disc" in r["selected"] for r in all_results),
        },
        "test_pre_fp": agg("test_pre", "false_pass"),
        "test_post_fp": agg("test_post", "false_pass"),
        "test_post_auto": agg("test_post", "automation"),
        "test_union_fp": agg("test_union", "false_pass"),
        "test_union_auto": agg("test_union", "automation"),
        "test_union_precision": agg("test_union", "precision"),
        "runs": all_results,
    }
    json.dump(summary, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
