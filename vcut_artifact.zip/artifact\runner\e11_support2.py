"""E11-SUPPORT2: the support certificate has to survive being chosen on train.

e11_support.py swept accept-rules on the same 341 test questions it reported --
that is tuning on the evaluation set, and a reviewer kills the paper over it.
This script computes the signals and the rule choice on the 132 TRAIN databases'
questions only, freezes the rule, and then reports the test databases' 341
questions untouched.  Same catalogue (the data-lake setting legitimately exposes
every table); what may not see test is the threshold.

Reported per split: the accuracy-vs-calls curve for each rule family, the rule
chosen on train under a call budget, and its test reading.
"""
from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_run_spider import band_fn, coquery_map, fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
OUT = REPO / "06_结果" / "e11_support2.json"
EPS = 1e-6
KS = (1, 2, 3, 4)
MS = (1, 2, 5, 20, 10 ** 9)


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    train = [c for c in data["spider"] if c["split"] == "train"]
    test = [c for c in data["spider"] if c["split"] == "test"]
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    coq = coquery_map(train, prefix=True)
    cat = g.Catalog(tabs, fks, coquery=coq, prefix_db=True)
    N = len(cat.tables)
    z = np.load(EMB, allow_pickle=True)
    ids = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}
    assert ids == cat.table_ids

    t0 = time.time()
    tok = {}
    # the diffusion cache is keyed by token, not by split: a deployed catalogue
    # computes it for any token it can see in the catalogue vocabulary.  Restrict
    # it to train tokens only and the test-side operator is crippled, which is an
    # artefact of the script, not a result (that mistake cost one run).
    for w in sorted({w for c in train + test for w in toks(c["question"])}):
        if ("token", w) not in cat.idx:
            continue
        x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
        s = cat.table_scores(x)
        mx = float(s.max())
        tok[w] = s / mx if mx > 0 else s
    print(f"train vocab coverage {len(tok)} tokens in {time.time()-t0:.0f}s; "
          f"catalogue has {sum(1 for k in cat.idx if k[0]=='token')} tokens", flush=True)

    def run(cases, use_dense):
        out = []
        for c in cases:
            q = toks(c["question"])
            gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
            ws = [w for w in set(q) if ("token", w) in cat.idx]
            known = [w for w in ws if w in tok]
            if known:
                M = np.stack([tok[w] for w in known])
                iw = np.array([math.log(1 + (N - cat.token_df.get(w, 0) + 0.5)
                                        / (cat.token_df.get(w, 0) + 0.5)) for w in known])[:, None]
                graph = np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
            else:
                graph = np.zeros(N, dtype=np.float32)
            b = g.bm25(cat, q)
            top = np.argsort(-b)[:30]
            mixed = b.copy()
            base = float(b[top[-1]])
            for i, idx in enumerate(top[np.argsort(-graph[top])]):
                mixed[idx] = base + (30 - i) * 1e-6
            r_rr = g.rank(mixed, cat)
            m_rr = g.metrics(r_rr, gold)
            top1 = r_rr[0]
            shared = len(set(q) & set(g.table_doc(cat.tables[cat.table_pos[top1]])))
            rarest = min([cat.token_df.get(w, 10 ** 9) for w in ws], default=10 ** 9)
            rec = {"qid": c["qid"], "k": shared, "m": rarest,
                   "rr_r5": round(m_rr["recall@5"], 4), "rr_r1": round(m_rr["recall@1"], 4)}
            if use_dense:
                d = Dm @ Qm[qpos[c["qid"]]]
                m_d = g.metrics([ids[i] for i in np.argsort(-d)], gold)
                rec["dense_r5"] = round(m_d["recall@5"], 4)
                rec["dense_r1"] = round(m_d["recall@1"], 4)
            out.append(rec)
        return out

    tr = run(train, use_dense=False)
    te = run(test, use_dense=True)
    # dense reference on train: the train databases are not in the test embedding
    # file, so encode them with the same cached query vectors when available.
    missing = [c["qid"] for c in train if c["qid"] not in qpos]
    print(f"train questions without cached dense vector: {len(missing)} / {len(train)}", flush=True)

    def curve(rows, budget=None):
        res = {}
        for k in KS:
            for m in MS:
                acc = [r for r in rows if r["k"] >= k and r["m"] <= m]
                rej = [r for r in rows if not (r["k"] >= k and r["m"] <= m)]
                cov = len(acc) / len(rows)
                row = {"k": k, "m": m, "accept_cov": round(cov, 4),
                       "call_frac": round(1 - cov, 4),
                       "accepted_graph_r5": round(float(np.mean([r["rr_r5"] for r in acc])), 4) if acc else None}
                if all("dense_r5" in r for r in rows):
                    row["hybrid_r5"] = round(float((sum(r["rr_r5"] for r in acc)
                                                    + sum(r["dense_r5"] for r in rej)) / len(rows)), 4)
                    row["hybrid_r1"] = round(float((sum(r["rr_r1"] for r in acc)
                                                    + sum(r["dense_r1"] for r in rej)) / len(rows)), 4)
                    row["accepted_dense_r5"] = round(float(np.mean([r["dense_r5"] for r in acc])), 4) if acc else None
                res[f"k{k}_m{m}"] = row
        return res

    ctr, cte = curve(tr), curve(te)
    # choose on train: highest accepted-graph R@5 subject to accept_cov >= 0.35
    ok = [v for v in ctr.values() if v["accept_cov"] >= 0.35 and v["accepted_graph_r5"] is not None]
    best = max(ok, key=lambda v: v["accepted_graph_r5"]) if ok else None
    key = f"k{best['k']}_m{best['m']}" if best else None
    out = {"n_train": len(tr), "n_test": len(te),
           "dense_test_r5": round(float(np.mean([r["dense_r5"] for r in te])), 4),
           "dense_test_r1": round(float(np.mean([r["dense_r1"] for r in te])), 4),
           "graph_only_test_r5": round(float(np.mean([r["rr_r5"] for r in te])), 4),
           "rule_chosen_on_train": best, "train_curve": ctr, "test_curve": cte,
           "test_reading_of_chosen_rule": cte.get(key),
           "train_dense_unavailable": len(missing)}
    json.dump({**out, "train_rows": tr, "test_rows": te},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k.endswith(("r5", "r1")) or k in
                      ("n_train", "n_test", "rule_chosen_on_train", "test_reading_of_chosen_rule",
                       "train_dense_unavailable")}, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
