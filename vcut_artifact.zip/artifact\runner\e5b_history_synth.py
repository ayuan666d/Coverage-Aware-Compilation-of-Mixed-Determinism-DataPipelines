# -*- coding: utf-8 -*-
"""E5b: history-guided repair synthesis vs cold start.

The synthesizer is the same (2-atom DSL + exhaustive verifier). The only
difference is the initial sample:

  * cold start: 10 random states, labeled by the oracle;
  * history:   a range query over the database's past error log, restricted to
               the uncovered region (`5 < lel <= 25`, `19.5 <= o2 < 20.5`).

Metric: how many labels (initial + counterexamples) until the verifier accepts
a guard with 0 false pass / 0 false kill, and how many CEGIS rounds.

This is a toy, but it isolates the claim: history buys sample efficiency;
the verifier is still what makes the guard sound.
"""

from __future__ import annotations

import json
import random
import sys
from pathlib import Path
from typing import List, Tuple

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "05_代码"))
sys.path.insert(0, str(REPO / "05_代码" / "runner"))

import e5_repair_synth as e5  # noqa: E402
from checker.decision_table import load_table  # noqa: E402

OUT = REPO / "06_结果" / "E5b_历史合成.json"


def hidden(s: dict) -> bool:
    return s["lel"] > 5 and s["o2"] < 20.5


def region(s: dict) -> bool:
    """The compiler knows the uncovered region's predicate, not its labels."""
    return 5 < s["lel"] <= 25 and 19.5 <= s["o2"] <= 21.0


def run_cegis(U, bad: set, good: set, init_bad: List[int], init_good: List[int],
              max_rounds: int = 12):
    sample = {"bad": list(init_bad), "good": list(init_good)}
    seen = set(init_bad) | set(init_good)
    history = []
    for rnd in range(1, max_rounds + 1):
        cons = e5.synth_candidates(e5.candidates(), sample, U)
        history.append({"round": rnd, "consistent": len(cons), "labels": len(seen)})
        if not cons:
            return {"ok": False, "rounds": rnd, "labels": len(seen)}, history
        name, pred, size = min(cons, key=lambda x: (x[2], len(x[0])))
        fp, fk = e5.evaluate_candidate(pred, U, bad, good)
        if fp == 0 and fk == 0:
            return {"ok": True, "guard": name, "size": size, "rounds": rnd,
                    "labels": len(seen), "false_pass": 0, "false_kill": 0}, history
        new_bad = [i for i in bad if not pred(U[i]) and i not in seen]
        new_good = [i for i in good if pred(U[i]) and i not in seen]
        if new_bad:
            sample["bad"] = sorted(set(sample["bad"]) | set(new_bad[:8]))
            seen |= set(new_bad[:8])
        if new_good:
            sample["good"] = sorted(set(sample["good"]) | set(new_good[:8]))
            seen |= set(new_good[:8])
    return {"ok": False, "rounds": max_rounds, "labels": len(seen)}, history


def main() -> None:
    table = load_table(e5.TABLE_PATH)
    U = e5.states()
    base = {i: table.evaluate({**e5.PRE, **s}) for i, s in enumerate(U)}
    bad = {i for i in range(len(U)) if base[i].verdict == "pass" and hidden(U[i])}
    good = {i for i in range(len(U)) if base[i].verdict == "pass" and not hidden(U[i])}
    near_good = [i for i in good
                 if 5 < U[i]["lel"] <= 25 and 20.5 <= U[i]["o2"] <= 21.0]
    bank = sorted(bad) + sorted(near_good) + random.Random(7).sample(
        sorted(good), min(12, len(good)))

    cold_labels, hist_labels, cold_rounds, hist_rounds = [], [], [], []
    cold_fail = hist_fail = 0
    examples = []
    for seed in range(30):
        rng = random.Random(seed)
        # cold start: 10 random states, oracle-labeled
        init = rng.sample(range(len(U)), 10)
        cb = [i for i in init if i in bad]
        cg = [i for i in init if i in good]
        c, _ = run_cegis(U, bad, good, cb, cg)
        cold_fail += 0 if c["ok"] else 1
        cold_labels.append(c["labels"]); cold_rounds.append(c["rounds"])

        # history: range query over the error log, restricted to the region
        hits = [i for i in bank if region(U[i])]
        rng.shuffle(hits)
        hits = hits[:10]
        hb = [i for i in hits if i in bad]
        hg = [i for i in hits if i in good]
        h, _ = run_cegis(U, bad, good, hb, hg)
        hist_fail += 0 if h["ok"] else 1
        hist_labels.append(h["labels"]); hist_rounds.append(h["rounds"])
        if seed < 5:
            examples.append({"seed": seed, "cold": c, "history": h,
                             "history_bad": len(hb), "history_good": len(hg)})

    def mean(xs):
        return round(sum(xs) / len(xs), 3)

    out = {
        "domain": {"states": len(U), "bad": len(bad), "good": len(good)},
        "hidden_policy": "lel > 5 AND o2 < 20.5",
        "cold_start": {"mean_labels": mean(cold_labels), "mean_rounds": mean(cold_rounds),
                       "fail": cold_fail, "labels": cold_labels},
        "history": {"mean_labels": mean(hist_labels), "mean_rounds": mean(hist_rounds),
                    "fail": hist_fail, "labels": hist_labels},
        "examples": examples,
    }
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
