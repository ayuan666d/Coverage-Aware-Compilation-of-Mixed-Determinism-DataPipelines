"""E11 simulation: when does one undirected operator conflate role with similarity?

Two overlapping block structures live on the same nodes: a theme partition (the
answer class) and a role partition that agrees with it on a fraction ``rho`` of
the nodes.  Role edges are drawn *denser* than theme edges, which is the usual
situation in a document or schema: the salient relation (cash next to an amount)
is more frequent than the relation that actually answers the question (total
next to an amount).

  untyped      diffusion over the union of the two graphs
  typed-theme  diffusion over the relation that defines the answer class
  typed-role   diffusion over the wrong relation (sanity arm)

Sweeping rho shows the failure mode the CORD role trap exhibits in the wild.
A second sweep varies the planted density and records the best diffusion scale
against the spectral gap, as a controlled companion to the real-graph law test.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[2]
OUT = REPO / "06_结果" / "e11_sim.json"
N = 300
P_OUT = 0.006
ALPHAS = [0.3, 0.5, 0.7, 0.8, 0.85, 0.9, 0.95]


def partitions(rho, K, rng):
    theme = np.repeat(np.arange(K), N // K)[:N]
    rng.shuffle(theme)
    role = theme.copy()
    move = int(round((1 - rho) * N))
    if move:
        idx = rng.choice(N, move, replace=False)
        role[idx] = rng.integers(0, K, move)
    return theme, role


def block_graph(labels, p_in, rng, K):
    A = (rng.random((N, N)) < P_OUT).astype(float)
    for k in range(K):
        m = np.where(labels == k)[0]
        if len(m) > 1:
            A[np.ix_(m, m)] = (rng.random((len(m), len(m))) < p_in).astype(float)
    np.fill_diagonal(A, 0)
    return np.maximum(A, A.T)


def norm(A):
    d = A.sum(1)
    d[d == 0] = 1
    return A / d[:, None]


def ppr(P, seed, alpha, iters=40):
    s = np.zeros(N)
    s[seed] = 1.0
    x = s.copy()
    Pt = P.T
    for _ in range(iters):
        x = alpha * (Pt @ x) + (1 - alpha) * s
    return x


def vote(x, labels, want, K, top=20):
    cnt = np.zeros(K)
    for i in np.argsort(-x)[:top]:
        cnt[labels[i]] += 1
    return int(np.argmax(cnt)) == want


def lambda2(A):
    d = np.maximum(A.sum(1), 1e-9)
    S = A / np.sqrt(d)[:, None] / np.sqrt(d)[None, :]
    w = np.linalg.eigvalsh((S + S.T) / 2)
    return float(np.sort(w)[-2])


def main():
    rng = np.random.default_rng(0)
    K = 6
    rho_rows = []
    for rho in [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]:
        un = ty = tw = tot = 0
        for rep in range(8):
            theme, role = partitions(rho, K, rng)
            A_t = block_graph(theme, 0.06, rng, K)
            A_r = block_graph(role, 0.16, rng, K)
            Pt, Pr, Pu = norm(A_t), norm(A_r), norm(A_t + A_r)
            for s in rng.choice(N, 25, replace=False):
                un += vote(ppr(Pu, int(s), 0.85), theme, theme[s], K)
                ty += vote(ppr(Pt, int(s), 0.85), theme, theme[s], K)
                tw += vote(ppr(Pr, int(s), 0.85), theme, theme[s], K)
                tot += 1
        rho_rows.append({"rho": rho, "untyped": round(un / tot, 4),
                         "typed_theme": round(ty / tot, 4),
                         "typed_role": round(tw / tot, 4), "n": tot})
        print(rho_rows[-1], flush=True)

    law = []
    for KK in (4, 6, 8):
        for pin in (0.03, 0.05, 0.08, 0.12, 0.18, 0.25):
            theme = np.arange(N) % KK
            rng.shuffle(theme)
            A = block_graph(theme, pin, rng, KK)
            P = norm(A)
            lam = lambda2(A)
            rec = {"K": KK, "p_in": pin, "lambda2": round(lam, 4),
                   "inv_gap": round(1 / max(1e-6, 1 - lam), 3)}
            best = (-1.0, None)
            for a in ALPHAS:
                acc = sum(vote(ppr(P, int(s), a), theme, theme[s], KK)
                          for s in rng.choice(N, 60, replace=False)) / 60
                rec[f"acc_a{a}"] = round(acc, 3)
                if acc > best[0]:
                    best = (acc, a)
            rec["alpha_star"] = best[1]
            rec["t_star"] = round(1 / (1 - best[1]), 3)
            rec["acc_star"] = round(best[0], 3)
            a_pred = min(max(lam, 0.3), 0.95)
            rec["alpha_pred"] = round(a_pred, 3)
            rec["acc_pred"] = round(sum(vote(ppr(P, int(s), a_pred), theme, theme[s], KK)
                                        for s in rng.choice(N, 60, replace=False)) / 60, 3)
            law.append(rec)
    keep = [r for r in law if r["t_star"] > 1.0]
    lt = np.array([np.log(r["t_star"]) for r in keep])
    lg = np.array([np.log(r["inv_gap"]) for r in keep])
    pear = float(np.corrcoef(lt, lg)[0, 1]) if len(keep) > 3 else None
    pred = [r["acc_pred"] for r in law]
    out = {"rho_sweep": rho_rows, "law_points": law,
           "law_pearson_log": None if pear is None else round(pear, 4),
           "mean_acc": {"oracle_alpha": round(float(np.mean([r["acc_star"] for r in law])), 4),
                        "predicted_alpha": round(float(np.mean(pred)), 4) if pred else None,
                        "fixed_0.85": round(float(np.mean([r["acc_a0.85"] for r in law])), 4)}}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in out.items() if k != "law_points"}, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
