"""E7l: layout-aware independent witness.

E7k read labels and amounts from the flat token order, which confuses line items
with totals.  Here each token keeps its bounding box; an amount is assigned to a
label only if it is on the same text line (similar y) and to the right of the
label.  The witness remains independent of the model.
"""
from __future__ import annotations

import ast
import json
import argparse
import statistics
import sys
from collections import Counter
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e7k_independent_witness import (  # noqa: E402
    num, match, is_label, SUB_KEYS, TAX_KEYS, SVC_KEYS, DISC_KEYS, TOTAL_KEYS,
)

REPO = Path(__file__).resolve().parents[2]
DATA = REPO / "04_数据" / "external" / "cord" / "train.parquet"
RAW = REPO / "06_结果" / "e7_receipts.json"
OUT = REPO / "06_结果" / "e7l_layout_witness.json"


def parse_box(raw: str):
    try:
        arr = ast.literal_eval(raw)
    except Exception:
        try:
            arr = json.loads(raw)
        except Exception:
            return []
    out = []
    for item in arr:
        try:
            box, (text, conf) = item
            xs = [p[0] for p in box]
            ys = [p[1] for p in box]
            out.append({
                "text": str(text),
                "x": sum(xs) / len(xs),
                "y": sum(ys) / len(ys),
                "h": max(ys) - min(ys),
            })
        except Exception:
            continue
    return out


def read_label(tokens, keys, fallback_text: str):
    """Return (value, source) for the strongest label occurrence."""
    if not tokens:
        return None, "none"
    tol = max(8.0, statistics.median(t["h"] for t in tokens) * 0.8)
    cands = []
    for i, t in enumerate(tokens):
        if not is_label(t["text"], keys):
            continue
        same = [u for u in tokens if u is not t and abs(u["y"] - t["y"]) <= tol]
        amounts = []
        for u in same:
            v = num(u["text"])
            if v is not None and v >= 100:
                amounts.append((u["x"], v))
        if not amounts:
            continue
        # prefer an amount to the right of the label, closest to it
        right = [(x, v) for x, v in amounts if x >= t["x"] - 2]
        if right:
            v = min(right, key=lambda p: p[0])[1]
        else:
            v = max(amounts, key=lambda p: p[0])[1]
        cands.append((t["x"], v))
    if not cands:
        # fall back to flat text order
        from e7k_independent_witness import amounts as flat_amounts
        vals = flat_amounts(fallback_text, keys)
        return (Counter(vals).most_common(1)[0][0] if vals else None), "flat"
    # use the rightmost label occurrence (the final summary block)
    return max(cands, key=lambda p: p[0])[1], "layout"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(DATA))
    ap.add_argument("--raw", default=str(RAW))
    ap.add_argument("--out", default=str(OUT))
    args = ap.parse_args()
    df = pd.read_parquet(args.data)
    raw = {r["file"]: r for r in json.load(open(args.raw, encoding="utf-8"))["rows"]}
    rows = []
    for _, r in df.iterrows():
        f = r["file_name"]
        if f not in raw:
            continue
        toks = parse_box(r["ocr_box"])
        text = raw[f]["text"]
        sub, s1 = read_label(toks, SUB_KEYS, text)
        tax, s2 = read_label(toks, TAX_KEYS, text)
        svc, s3 = read_label(toks, SVC_KEYS, text)
        disc, s4 = read_label(toks, DISC_KEYS, text)
        total, s5 = read_label(toks, TOTAL_KEYS, text)
        derived = None
        if sub is not None:
            derived = sub + (tax or 0) + (svc or 0) - (disc or 0)
        close = (derived is not None and total is not None
                 and abs(derived - total) <= max(2, 0.01 * abs(total)))
        m = raw[f]["model"].get("total")
        rows.append({
            "file": f, "gold": raw[f]["gold"]["total"], "model": m,
            "ocr": {"sub": sub, "tax": tax, "svc": svc, "disc": disc, "total": total},
            "sources": {"sub": s1, "tax": s2, "svc": s3, "disc": s4, "total": s5},
            "derived": derived, "certified": bool(close),
            "ocr_correct": match(total, raw[f]["gold"]["total"]),
            "model_correct": match(m, raw[f]["gold"]["total"]),
            "agree": match(total, m) is True,
            "comp_close_model": (close and match(derived, m) is True),
        })

    n = len(rows)
    def metrics(pred):
        acc = [r for r in rows if pred(r)]
        known = [r for r in acc if r["model_correct"] is not None]
        fp = sum(1 for r in known if r["model_correct"] is False)
        return {
            "accept": len(acc), "automation": round(len(acc) / n, 4),
            "false_pass": fp, "false_pass_rate": round(fp / n, 4),
            "precision": round((len(known) - fp) / len(known), 4) if known else None,
        }
    summary = {
        "n": n,
        "ocr_total_found": sum(1 for r in rows if r["ocr"]["total"] is not None),
        "ocr_total_found_rate": round(sum(1 for r in rows if r["ocr"]["total"] is not None) / n, 4),
        "ocr_total_known": sum(1 for r in rows if r["ocr_correct"] is not None),
        "ocr_total_accuracy": round(sum(1 for r in rows if r["ocr_correct"]) /
                                    max(1, sum(1 for r in rows if r["ocr_correct"] is not None)), 4),
        "components": {k: sum(1 for r in rows if r["ocr"][k] is not None)
                       for k in ("sub", "tax", "svc", "disc")},
        "policies": {
            "ocr_total_only": metrics(lambda r: r["ocr"]["total"] is not None),
            "ocr_total_agree_model": metrics(lambda r: r["agree"]),
            "ocr_comp_close_model": metrics(lambda r: r["comp_close_model"]),
            "ocr_comp_close_ocr_total": metrics(lambda r: r["certified"]),
            "comp_close_model_or_agree": metrics(lambda r: r["comp_close_model"] or r["agree"]),
        },
    }
    json.dump({"summary": summary, "rows": rows}, open(args.out, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("wrote", args.out)


if __name__ == "__main__":
    main()
