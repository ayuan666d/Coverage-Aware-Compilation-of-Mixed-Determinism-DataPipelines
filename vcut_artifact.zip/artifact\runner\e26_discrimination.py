"""E26: discrimination — hard-negative weighting.

All 9 primitives are matching signals.  Retrieval's top-1 needs discrimination:
same-database sibling tables and cross-database same-named tables are the hard
negatives; easy negatives (unrelated tables) dominate the mean and teach nothing.

Weighted Fisher:
  pos           : 1
  same-db neg   : w_sib
  same-name neg : w_name
  easy neg      : w_easy (0 / 0.1 / 1)

Spider 693/341, 9 primitives, first order.
"""
from __future__ import annotations

import json
import sys

import numpy as np

sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码\runner")
import e14_db_anchor as e14  # noqa: E402
import e16_transfer as e16  # noqa: E402

OUT = e14.REPO / "06_结果" / "e26_discrimination.json"


def fit_weighted(F, y, wts, lam=0.1):
    n = len(y)
    sw = wts.sum()
    mean = (F * wts[:, None]).sum(0) / sw
    Cov = (F * wts[:, None]).T @ F / sw - np.outer(mean, mean)
    pw = wts * y
    nw = wts * (1 - y)
    mu_p = (F * pw[:, None]).sum(0) / max(pw.sum(), 1e-9)
    mu_n = (F * nw[:, None]).sum(0) / max(nw.sum(), 1e-9)
    return np.linalg.solve((Cov + lam * np.eye(F.shape[1])).astype(np.float64),
                           (mu_p - mu_n).astype(np.float64)).astype(np.float32)


def evaluate(meta, Fte, w):
    rows = []
    for qi, q in enumerate(meta["test_q"]):
        sc = Fte[qi] @ w
        order = np.argsort(-sc)[:5]
        top = [meta["doc_ids"][i] for i in order]
        r, m = e14.metrics_top(top, meta["gold_all"][q])
        rows.append((r[1], r[3], r[5], m))
    return {k: round(float(np.mean([r[i] for r in rows])), 4)
            for i, k in enumerate(("recall@1", "recall@3", "recall@5", "mrr"))}


def main():
    meta = e14.load()
    Ft = meta["build_F"](meta["train_q"])[:, :, e16.KEEP]
    mu = Ft.reshape(-1, 9).mean(0)
    sd = Ft.reshape(-1, 9).std(0) + 1e-9
    Fn = ((Ft - mu) / sd).reshape(-1, 9)
    Y = np.zeros((len(meta["train_q"]), meta["D"]), dtype=np.float32)
    for qi, q in enumerate(meta["train_q"]):
        for f in meta["gold_all"][q]:
            j = meta["didx"].get(f)
            if j is not None:
                Y[qi, j] = 1.0
    y = Y.reshape(-1)
    doc_ids = meta["doc_ids"]
    db_of = [d.split("::")[0] for d in doc_ids]
    base_names = [d.split("::")[1] for d in doc_ids]
    Fte = ((meta["build_F"](meta["test_q"])[:, :, e16.KEEP] - mu) / sd).reshape(
        len(meta["test_q"]), meta["D"], 9)
    db_map = {c["qid"]: c["db_id"] for c in meta["cases"]}

    out = {}
    for w_sib, w_name, w_easy, tag in [
            (1.0, 1.0, 1.0, "baseline"),
            (3.0, 3.0, 1.0, "sib3"),
            (5.0, 5.0, 1.0, "sib5"),
            (10.0, 10.0, 1.0, "sib10"),
            (5.0, 5.0, 0.1, "sib5_easy0.1"),
            (10.0, 10.0, 0.1, "sib10_easy0.1")]:
        wts = np.ones(len(y), dtype=np.float32)
        for qi, q in enumerate(meta["train_q"]):
            db = db_map[q]
            gold = meta["gold_all"][q]
            gnames = {f.split("::")[1] for f in gold}
            for j in range(meta["D"]):
                if y[qi * meta["D"] + j] > 0.5:
                    continue
                if db_of[j] == db:
                    wts[qi * meta["D"] + j] = w_sib
                elif base_names[j] in gnames:
                    wts[qi * meta["D"] + j] = max(w_name, w_sib)
                else:
                    wts[qi * meta["D"] + j] = w_easy
        w = fit_weighted(Fn, y, wts)
        m = evaluate(meta, Fte, w)
        out[tag] = m
        print(tag, json.dumps(m), flush=True)

    json.dump({"runs": out,
               "reference": {"flat_first_r1": 0.3974, "flat_first_r5": 0.7023}},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
