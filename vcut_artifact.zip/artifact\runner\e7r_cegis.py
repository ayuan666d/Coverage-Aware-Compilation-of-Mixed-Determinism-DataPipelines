"""E7r: CEGIS-style synthesis of an OCR total witness (label + window + vote).

E7j selected a flat label vocabulary with a fixed window of five tokens.  Here
the synthesizer also chooses, per label, the smallest neighbourhood that keeps
the training precision at or above 0.9, and test-time values are weighted by the
training precision of the rule that produced them.  The loop is
counterexample-guided in the weak sense: a candidate rule survives only if the
training half does not contain a receipt on which it fires with the wrong total.
"""
from __future__ import annotations

import json
import random
import re
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e7j_label_synth import num, match, labels_of  # noqa: E402
import e7_receipts as e7  # noqa: E402

REPO = e7.REPO
RAW = REPO / "06_结果" / "e7_receipts.json"
OUT = REPO / "06_结果" / "e7r_cegis.json"
WINDOWS = (1, 2, 3, 5, 8)
MIN_FIRE = 8
MIN_PREC = 0.9


def positions(text):
    """label -> list of (signed token distance, amount) around each occurrence."""
    toks = [t.strip() for t in text.split("|")]
    out = defaultdict(list)
    for i, t in enumerate(toks):
        lab = re.sub(r"[^a-z ]", "", t.lower()).strip()
        if not lab or len(lab) < 2 or len(lab) > 20:
            continue
        for j in range(max(0, i - 8), min(len(toks), i + 9)):
            if j == i:
                continue
            v = num(toks[j])
            if v is not None and v >= 100:
                out[lab].append((j - i, v))
    return out


def rule_value(pos, lab, w):
    vals = [v for d, v in pos.get(lab, []) if abs(d) <= w]
    return Counter(vals).most_common(1)[0][0] if vals else None


def fit(train, cache):
    stat = defaultdict(lambda: [0, 0])
    for r in train:
        pos = cache[r["file"]]
        for lab, pairs in pos.items():
            for w in WINDOWS:
                vals = [v for d, v in pairs if abs(d) <= w]
                if not vals:
                    continue
                stat[(lab, w)][0] += 1
                if any(match(v, r["gold"]["total"]) for v in vals):
                    stat[(lab, w)][1] += 1
    best = {}
    for (lab, w), (n, hit) in stat.items():
        if n < MIN_FIRE:
            continue
        prec = hit / n
        if prec < MIN_PREC:
            continue
        # smallest window that keeps precision; tie-break on coverage
        cur = best.get(lab)
        if cur is None or (w, -n) < (cur[1], -cur[2]):
            best[lab] = (prec, w, n)
    return best


def predict(row, rules, cache):
    pos = cache[row["file"]]
    votes = Counter()
    weight = defaultdict(float)
    for lab, (prec, w, _n) in rules.items():
        v = rule_value(pos, lab, w)
        if v is None:
            continue
        votes[v] += 1
        weight[v] += prec
    if not votes:
        return None
    return max(votes, key=lambda v: (weight[v], votes[v]))


def metrics(test, base, rules, cache):
    acc = fp = known = 0
    for r in test:
        b, c = base[r["file"]]
        rt = predict(r, rules, cache)
        agree = match(rt, r["model"].get("total")) is True
        if b or agree:
            acc += 1
            if c is not None:
                known += 1
                if c is False:
                    fp += 1
    return {"n": len(test), "accept": acc, "automation": round(acc / len(test), 4),
            "false_pass": fp, "false_pass_rate": round(fp / len(test), 4),
            "precision": round((known - fp) / known, 4) if known else None}


def main():
    rows = list(json.load(open(RAW, encoding="utf-8"))["rows"])
    cache = {r["file"]: positions(r["text"]) for r in rows}
    base = {}
    for r in rows:
        j = e7.judge(r["model"], r["gold"], r["text"])
        base[r["file"]] = (bool(j["checks"].get("components_close")
                               and j["checks"].get("total_grounded")), j["total_correct"])

    runs = []
    for seed in range(10):
        rnd = random.Random(seed)
        idx = list(range(len(rows)))
        rnd.shuffle(idx)
        cut = len(idx) // 2
        train = [rows[i] for i in idx[:cut]]
        test = [rows[i] for i in idx[cut:]]
        rules = fit(train, cache)
        syn = metrics(test, base, rules, cache)
        runs.append({"seed": seed, "rules": {k: v for k, v in rules.items()}, "synth": syn})
        print(seed, len(rules), syn)

    def agg(field):
        return {"mean": round(statistics.mean(r["synth"][field] for r in runs), 4),
                "min": round(min(r["synth"][field] for r in runs), 4),
                "max": round(max(r["synth"][field] for r in runs), 4)}

    summary = {"seeds": 10,
               "automation": agg("automation"),
               "false_pass": agg("false_pass"),
               "precision": agg("precision"),
               "runs": runs}
    json.dump(summary, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in summary.items() if k != "runs"},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
