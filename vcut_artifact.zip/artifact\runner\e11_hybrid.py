"""E11-HYBRID: the paper-B thesis experiment.

Claim under test: the catalogue itself can tell you, for free and without a
score threshold, when it cannot answer -- and if you spend model calls only
there, you match a dense retriever at a small fraction of the calls.

Pre-registered decision rules (written before the run):
  P1  hybrid R@5 >= dense R@5 - 1.0 pt while calling the model on <= 20% of queries.
  P2  the structural abstention signal selects subsets at least as accurate as the
      embedding's own confidence (dense top-1 cosine) at every coverage level
      50-90%.  If P2 fails, the "sound signal" wording is dropped.
  P3  report the operating point's call fraction.

Router signals are all query-time observable: does any query token exist in the
catalogue vocabulary at all, how many tables contain the rarest anchor, and
whether the answer we are about to return shares any query token with the
question.  "The gold table has no anchor" is used only as a labelled oracle row,
never as a router.
"""
from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_run_spider import band_fn, coquery_map, fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
OUT = REPO / "06_结果" / "e11_hybrid.json"
EPS = 1e-6
TAUS = (1, 2, 3, 5, 10, 20, 50)


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    coq = coquery_map([c for c in data["spider"] if c["split"] == "train"], prefix=True)
    t0 = time.time()
    cat = g.Catalog(tabs, fks, coquery=coq, prefix_db=True)
    N = len(cat.tables)
    bf, _ = band_fn(test)
    z = np.load(EMB, allow_pickle=True)
    ids = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}

    tok = {}
    for w in sorted({w for c in test for w in toks(c["question"])}):
        if ("token", w) not in cat.idx:
            continue
        x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
        s = cat.table_scores(x)
        mx = float(s.max())
        tok[w] = s / mx if mx > 0 else s
    idf = {w: math.log(1 + (N - cat.token_df.get(w, 0) + 0.5) / (cat.token_df.get(w, 0) + 0.5))
           for w in tok}
    print(f"catalog {N} tables, vocab {len(cat.idx)} nodes, {len(tok)} query tokens "
          f"in catalogue vocabulary, {time.time()-t0:.0f}s", flush=True)

    rows = []
    for c in test:
        q = toks(c["question"])
        gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
        ws = [w for w in set(q) if w in tok]
        if ws:
            M = np.stack([tok[w] for w in ws])
            iw = np.array([idf[w] for w in ws])[:, None]
            graph = np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
        else:
            graph = np.zeros(N, dtype=np.float32)
        b = g.bm25(cat, q)
        order = np.argsort(-b)
        top = order[:30]
        mixed = b.copy()
        base = float(b[top[-1]])
        for i, idx in enumerate(top[np.argsort(-graph[top])]):
            mixed[idx] = base + (30 - i) * 1e-6
        dense = Dm @ Qm[qpos[c["qid"]]]

        # ---- query-time observable signals
        rarest_df = min([cat.token_df.get(w, 10 ** 9) for w in ws], default=10 ** 9)
        cov = len(ws) / max(1, len(set(q)))
        r_rr = g.rank(mixed, cat)
        top1 = r_rr[0]
        top1_shared = len(set(q) & set(g.table_doc(cat.tables[cat.table_pos[top1]])))
        s1 = float(mixed[cat.table_pos[top1]])
        s2 = float(np.sort(mixed)[-2])
        margin = (s1 - s2) / (s1 + 1e-9)
        dense_top1 = float(dense.max())

        # ---- oracle rows (labelled, never routed on)
        gt = set()
        for t in gold:
            if t in cat.table_pos:
                gt |= set(g.table_doc(cat.tables[cat.table_pos[t]]))
        gold_anchor = bool(set(q) & gt)
        m_rr = g.metrics(r_rr, gold)
        m_d = g.metrics([ids[i] for i in np.argsort(-dense)], gold)

        rec = {"qid": c["qid"], "gold": sorted(gold),
               "n_anchor": len(ws), "cov": round(cov, 3), "rarest_df": rarest_df,
               "top1_shared": top1_shared, "margin": round(margin, 4),
               "dense_top1": round(dense_top1, 4), "gold_anchor": gold_anchor,
               "rr_r5": round(m_rr["recall@5"], 4), "rr_r1": round(m_rr["recall@1"], 4),
               "dense_r5": round(m_d["recall@5"], 4), "dense_r1": round(m_d["recall@1"], 4)}
        rows.append(rec)

    n = len(rows)
    mean = lambda k: float(np.mean([r[k] for r in rows]))  # noqa: E731

    def hybrid(blind):
        use = [blind(r) for r in rows]
        calls = sum(use) / n
        return {"call_frac": round(calls, 4),
                "r5": round(float(np.mean([r["dense_r5"] if u else r["rr_r5"]
                                           for r, u in zip(rows, use)])), 4),
                "r1": round(float(np.mean([r["dense_r1"] if u else r["rr_r1"]
                                           for r, u in zip(rows, use)])), 4)}

    rules = {}
    rules["A: no catalogue anchor"] = lambda r: r["n_anchor"] == 0
    rules["C: answer shares no query token"] = lambda r: r["top1_shared"] == 0
    rules["A|C"] = lambda r: r["n_anchor"] == 0 or r["top1_shared"] == 0
    for tau in TAUS:
        rules[f"B: rarest anchor df>{tau}"] = lambda r, tau=tau: r["rarest_df"] > tau
        rules[f"A|C|B df>{tau}"] = lambda r, tau=tau: (r["n_anchor"] == 0 or r["top1_shared"] == 0
                                                       or r["rarest_df"] > tau)
        rules[f"A|B df>{tau}"] = lambda r, tau=tau: (r["n_anchor"] == 0 or r["rarest_df"] > tau)
    rules["ORACLE: gold table has no anchor"] = lambda r: not r["gold_anchor"]
    rules["ORACLE-max (cheat): dense would win here"] = lambda r: r["dense_r5"] > r["rr_r5"]
    curves = {k: hybrid(f) for k, f in rules.items()}

    # ---- P2: selective accuracy of each abstention signal (graph kept where confident)
    def frontier(key, reverse):
        s = sorted(rows, key=lambda r: r[key], reverse=reverse)
        out = {}
        for cov_pct in (100, 90, 80, 70, 60, 50):
            k = max(1, int(round(n * cov_pct / 100)))
            out[str(cov_pct)] = round(float(np.mean([r["rr_r5"] for r in s[:k]])), 4)
        return out

    front = {"dense_top1_cosine": frontier("dense_top1", True),
             "graph_margin": frontier("margin", True),
             "rarest_anchor_df(low=conf)": frontier("rarest_df", False),
             "top1_shared_tokens": frontier("top1_shared", True)}
    # lexicographic anchor certificate: evidence exists, then rare anchor, then margin
    lex = sorted(rows, key=lambda r: (r["top1_shared"] > 0, -min(r["rarest_df"], 10 ** 6), r["margin"]),
                 reverse=True)
    front["anchor_certificate(lex)"] = {str(cp): round(float(np.mean(
        [r["rr_r5"] for r in lex[:max(1, int(round(n * cp / 100)))]])), 4)
        for cp in (100, 90, 80, 70, 60, 50)}

    # ---- certificate confusion matrix against the gold-anchor oracle
    def cm(pred):
        tp = sum(1 for r in rows if pred(r) and not r["gold_anchor"])
        fp = sum(1 for r in rows if pred(r) and r["gold_anchor"])
        fn = sum(1 for r in rows if not pred(r) and not r["gold_anchor"])
        return {"flagged_blind": tp + fp, "truly_blind": tp + fn, "sound_tp": tp,
                "wasted_calls": fp, "missed_blind": fn}

    out = {"n": n, "dense_r5": round(mean("dense_r5"), 4), "dense_r1": round(mean("dense_r1"), 4),
           "rerank_r5": round(mean("rr_r5"), 4), "rerank_r1": round(mean("rr_r1"), 4),
           "P1_call_frac_at_dense_minus_1": None,
           "curves": curves, "selective_frontiers": front,
           "certificate_vs_oracle": {k: cm(f) for k, f in
                                     [("A", rules["A: no catalogue anchor"]),
                                      ("C", rules["C: answer shares no query token"]),
                                      ("A|C", rules["A|C"]),
                                      ("A|C|B df>5", rules["A|C|B df>5"]),
                                      ("A|B df>2", rules["A|B df>2"])]},
           "rows": rows}
    ok = [k for k, v in curves.items() if v["call_frac"] <= 0.20 and v["r5"] >= out["dense_r5"] - 0.01]
    out["P1_pass"] = bool(ok)
    out["P1_best"] = (min(ok, key=lambda k: curves[k]["call_frac"]) if ok else None)
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
