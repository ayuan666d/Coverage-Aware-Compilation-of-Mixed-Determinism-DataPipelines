# -*- coding: utf-8 -*-
"""APIExtractor 的离线解析单测（不联网）。"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from runner.e2 import _coerce, parse_extraction  # noqa: E402


class TestParseExtraction(unittest.TestCase):
    def test_wrapped_json_with_confidence(self):
        content = '''```json
{"measures_done": {"value": true, "confidence": 0.98},
 "lel": {"value": "30% LEL", "confidence": 0.9},
 "o2": {"value": "21%", "confidence": 0.95},
 "isolated": {"value": false, "confidence": 0.8},
 "cleanup": {"value": true, "confidence": 0.7}}
```'''
        e = parse_extraction(content, ["measures_done", "lel", "o2", "isolated", "cleanup"])
        self.assertEqual(e.values, {"measures_done": True, "lel": 30.0, "o2": 21.0,
                                    "isolated": False, "cleanup": True})
        self.assertAlmostEqual(e.min_conf, 0.7)

    def test_missing_field_is_null_and_zero_conf(self):
        e = parse_extraction('{"lel": 10}', ["lel", "o2"])
        self.assertEqual(e.values["lel"], 10)
        self.assertIsNone(e.values["o2"])
        self.assertEqual(e.conf["o2"], 0.0)

    def test_chinese_booleans(self):
        self.assertIs(_coerce("measures_done", "未落实"), False)
        self.assertIs(_coerce("measures_done", "已落实"), True)
        self.assertIs(_coerce("isolated", "否"), False)
        self.assertIs(_coerce("cleanup", "是"), True)


if __name__ == "__main__":
    unittest.main()
