"""E44：dense 基线的上下文预算敏感性——只改 max_seq_length 一个变量。

动机
----
E29/E43 的 dense 协议把 `max_seq_length` 设为 128，而 `doc_text` 形如
    db :: name | columns: c1, c2, ... | values: v11, v12, ...
每列附 12 个样本值。用 Qwen3 自己的 tokenizer 实测，951 张真实表的中位长度是
344 token，87.2% 超过 128，p99 是 2323。也就是说 e43 的 dense 只读到了
"库名 + 表名 + 部分列名 + 少量值"，而 FORGE 读的是完整 schema。两者不是同一
信息预算下的比较。

本实验不改变目录、问集、prompt、归一化、评价函数，只把 max_seq_length 变成
128 / 512 / 2048 三个点，看 R@k 随上下文预算怎么走：
  - 若 2048 相对 128 基本不动 -> 截断不是 dense 退化的原因，结论稳。
  - 若 2048 把 dense 追到接近 FORGE -> 原 +10.78 的归因要重写。

协议一致性
----------
目录构造直接复用 e43.build_catalog()（同 seed=40、同 donors、同 place），
`doc_hash` 必须复现 194214fd59f31ca3，否则立即中止。
排序取 top-20 后按与 e43 相同的 ev() 计算 R1/R5/top1/hit20。
唯一的实现差异：为压低 padding，编码时按 token 长度排序、分块编码后还原顺序；
这不改变任何一条向量，只改变 batch 组成。

用法（hermes venv）：
  E44_SEQS="128,512,2048" E44_SIZES="951,10000" python e44_dense_longctx.py
输出：
  D:\\vldb2027_e11\\e44_dense_longctx.json
  D:\\vldb2027_e11\\e44_dense_longctx_seq{SEQ}_{tag}_perq.jsonl
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e43_legacy_baselines as b43  # noqa: E402

WORK = Path(r"D:\vldb2027_e11")
OUT = Path(os.environ.get("E44_OUT", str(WORK / "e44_dense_longctx.json")))
SEQS = [int(x) for x in os.environ.get("E44_SEQS", "128,512,2048").split(",")]
SIZES = sorted(int(x) for x in os.environ.get("E44_SIZES", "951,10000").split(","))
CHUNK = int(os.environ.get("E44_CHUNK", "64"))
BATCH = int(os.environ.get("E44_BATCH", "0"))  # 0 = 按 token 预算自动取
EXPECT_HASH = os.environ.get("E44_EXPECT_HASH", "194214fd59f31ca3")


def main():
    all_tabs, fks, n_real, cases, test = b43.build_catalog()
    doc_ids = [b43.fid(t["db"], t["name"]) for t in all_tabs]

    import hashlib
    h = hashlib.sha1()
    for i, t in enumerate(all_tabs):
        h.update(f"{doc_ids[i]}|{len(t['columns'])}|".encode())
    doc_hash = h.hexdigest()[:16]
    print(f"[catalog] N={len(all_tabs)} doc_hash={doc_hash} expect={EXPECT_HASH}", flush=True)
    if EXPECT_HASH and doc_hash != EXPECT_HASH:
        raise SystemExit("doc_hash 与 e43 不一致，目录构造漂移，中止")

    docs = [b43.doc_text(t) for t in all_tabs]
    qs = [c["question"] for c in test]
    golds = [{b43.fid(c["db_id"], x) for x in c["gold"]} for c in test]

    # 真实 token 长度（Qwen3 自己的 BPE），用于排序与截断统计
    from tokenizers import Tokenizer
    tk = Tokenizer.from_file(str(WORK / "models" / "Qwen3-Embedding-0.6B" / "tokenizer.json"))
    doc_len = np.array([len(e.ids) for e in tk.encode_batch(docs, add_special_tokens=False)])
    q_len = np.array([len(e.ids) for e in tk.encode_batch(qs, add_special_tokens=False)])
    print("[len] docs median %d p90 %d p99 %d max %d | queries median %d max %d"
          % (np.median(doc_len), np.percentile(doc_len, 90), np.percentile(doc_len, 99),
             doc_len.max(), np.median(q_len), q_len.max()), flush=True)

    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer(str(WORK / "models" / "Qwen3-Embedding-0.6B"), device="cuda")
    model.half()

    order = np.argsort(doc_len, kind="stable")
    res = json.load(open(OUT, encoding="utf-8")) if OUT.exists() else {}

    for seq in SEQS:
        model.max_seq_length = seq
        bs = BATCH or max(4, min(64, int(os.environ.get("E44_TOKEN_BUDGET", "8192")) // seq))
        t0 = time.perf_counter()

        # 问句：按 seq 同一预算编码（与 e43 相同的 prompt_name="query"）
        Q = model.encode(qs, batch_size=32, convert_to_numpy=True,
                         normalize_embeddings=True, prompt_name="query",
                         show_progress_bar=False).astype(np.float32)

        # 文档：按长度排序分块，块内 padding 到本块最长，编码后还原原序
        D = np.empty((len(docs), Q.shape[1]), dtype=np.float32)
        for c0 in range(0, len(order), CHUNK):
            idx = order[c0:c0 + CHUNK]
            E = model.encode([docs[i] for i in idx], batch_size=bs,
                             convert_to_numpy=True, normalize_embeddings=True,
                             show_progress_bar=False).astype(np.float32)
            D[idx] = E
        enc_s = time.perf_counter() - t0
        n_trunc = int((doc_len > seq).sum())
        print(f"[seq={seq}] batch={bs} 编码 {enc_s:.0f}s  truncated {n_trunc}/{len(docs)} "
              f"({100.0*n_trunc/len(docs):.1f}%)  q_trunc {int((q_len>seq).sum())}", flush=True)

        S_all = Q @ D.T
        for n in SIZES:
            tag = "951" if n == 951 else f"{n // 1000}k-syn"
            sub_ids = [x.lower() for x in doc_ids[:n]]
            rows, rows_real, pq = [], [], []
            real_ids = [x.lower() for x in doc_ids[:n_real]]
            for qi, gold in enumerate(golds):
                S = S_all[qi, :n]
                order_q = np.argsort(-S)[:20]
                rank = [sub_ids[i] for i in order_q]
                r = b43.ev(rank, gold)
                rows.append(r)
                # 只在真实表内排序：把干扰项全部移除后再排一次。
                # 与 rows 的差 = 槽位竞争（干扰项占掉 top-k），而不是语义排序变化。
                o2 = np.argsort(-S_all[qi, :n_real])[:20]
                r2 = b43.ev([real_ids[i] for i in o2], gold)
                rows_real.append(r2)
                pq.append({"seq": seq, "tag": tag, "qid": test[qi]["qid"],
                           "db": test[qi]["db_id"], "n_gold": len(gold),
                           "src": test[qi].get("src", "dev"),
                           "dense": r, "dense_real": r2,
                           "top20": rank, "hit_top20": [1 if x in gold else 0 for x in rank]})
            agg = {k: float(np.mean([r[k] for r in rows]))
                   for k in ("R1", "R5", "top1", "hit20")}
            agg["R1_real"] = float(np.mean([r["R1"] for r in rows_real]))
            agg["R5_real"] = float(np.mean([r["R5"] for r in rows_real]))
            key = f"seq{seq}"
            res.setdefault(key, {})
            res[key][tag] = dict(N=n, seq=seq, n_real=n_real, n_synth=n - n_real,
                                 doc_hash=doc_hash, truncated_docs=n_trunc,
                                 truncated_frac=n_trunc / len(docs),
                                 encode_s=enc_s, **agg)
            res.setdefault("_meta", {})
            res["_meta"].update({"cases": str(b43.CASES), "doc_hash": doc_hash,
                                 "model": "Qwen3-Embedding-0.6B", "dtype": "fp16"})
            json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            print(f"  [{key} {tag}] N={n:6d} dense R1 {agg['R1']*100:5.2f} "
                  f"R5 {agg['R5']*100:5.2f} | 真实表内 {agg['R1_real']*100:5.2f}/"
                  f"{agg['R5_real']*100:5.2f}", flush=True)

            pq_path = OUT.with_name(f"{OUT.stem}_seq{seq}_{tag}_perq.jsonl")
            with open(pq_path, "w", encoding="utf-8") as f:
                for rec in pq:
                    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            del sub_ids
        del S_all, Q, D
        import gc
        gc.collect()
        import torch
        torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
