"""E7e: receipt extraction with arithmetic closure (CORD).

The model reads OCR tokens and returns total / subtotal / tax / service /
line-item prices.  The database-side checker never sees the gold answer: it
grounds every amount in the OCR text and checks the arithmetic identities.
When the components close, the total is *derived* and the model's own total
can be corrected or discarded -- determinism pushed past the model, not just a
filter in front of it.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd

REPO = Path(__file__).resolve().parents[2]
DATA = REPO / "04_数据" / "external" / "cord" / "train.parquet"
OUT_RAW = REPO / "06_结果" / "e7_receipts_raw.json"
OUT = REPO / "06_结果" / "e7_receipts.json"

SYSTEM = (
    "You extract amounts from a noisy OCR token list of an Indonesian receipt. "
    "Return one JSON object and nothing else. Amounts are integer rupiah: remove "
    "thousands separators and decimals, do not multiply by item counts. "
    "Schema: {\"total\": int|null, \"subtotal\": int|null, \"tax\": int|null, "
    "\"service\": int|null, \"discount\": int|null, \"items\": [int]}. "
    "total is the final amount due; subtotal is before tax/service/discount; tax is PB1/PPN; "
    "service is service charge; discount is a positive amount subtracted from the subtotal. "
    "items are the individual line prices (not the subtotal, tax, discount, or total). "
    "Use null when the value is absent. "
    "Do not guess: every number you return must occur in the OCR text."
)


def num(s):
    if s is None:
        return None
    s = str(s).strip().replace(" ", "")
    s = re.sub(r"[^0-9,.\-]", "", s)
    if not s or s in "-":
        return None
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        parts = s.split(",")
        if len(parts) > 1 and all(len(p) == 3 for p in parts[1:]):
            s = "".join(parts)
        else:
            s = s.replace(",", ".")
    try:
        return int(round(float(s)))
    except Exception:
        return None


def _re_amt(raw: str, key: str):
    m = re.search(r'"' + re.escape(key) + r'"\s*:\s*"([^"]*)"', raw)
    return num(m.group(1)) if m else None


def gold_of(raw: str) -> dict:
    """Parse the gold KIE; fall back to field regexes when a menu name contains
    an unescaped quote (a handful of CORD rows are malformed JSON)."""
    kie = None
    try:
        kie = json.loads(raw)
    except Exception:
        kie = None
    if isinstance(kie, dict):
        st = kie.get("sub_total") or {}
        if not isinstance(st, dict):
            st = {}
        tot = kie.get("total") or {}
        if not isinstance(tot, dict):
            tot = {}
        menu = [x for x in (kie.get("menu") or []) if isinstance(x, dict)]
        items = [num(x.get("price")) for x in menu]
        items = [x for x in items if x is not None]
        return {
            "total": num(tot.get("total_price")),
            "subtotal": num(st.get("subtotal_price")),
            "tax": num(st.get("tax_price")),
            "service": num(st.get("service_price")),
            "items": items, "n_items": len(items), "gold_source": "json",
        }
    items = [num(x) for x in re.findall(r'"price"\s*:\s*"([^"]*)"', raw)]
    items = [x for x in items if x is not None]
    return {
        "total": _re_amt(raw, "total_price"),
        "subtotal": _re_amt(raw, "subtotal_price"),
        "tax": _re_amt(raw, "tax_price"),
        "service": _re_amt(raw, "service_price"),
        "items": items, "n_items": len(items), "gold_source": "regex",
    }


def tokens_text(raw: str, max_chars: int = 5000) -> str:
    try:
        toks = json.loads(raw)
    except Exception:
        toks = [raw]
    if isinstance(toks, list):
        s = " | ".join(str(x) for x in toks)
    else:
        s = str(toks)
    return s[:max_chars]


def call_api(key: str, model: str, text: str, timeout: int = 90,
             base_url: str = "https://api.deepseek.com") -> dict:
    body = json.dumps({
        "model": model,
        "messages": [{"role": "system", "content": SYSTEM},
                     {"role": "user", "content": "OCR tokens:\n" + text + "\n\nReturn the JSON object now."}],
        "temperature": 0,
        "max_tokens": 1200,
        "response_format": {"type": "json_object"},
    }, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        base_url.rstrip("/") + "/chat/completions", data=body,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        method="POST")
    last = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = json.loads(r.read().decode("utf-8"))
            content = (data.get("choices") or [{}])[0].get("message", {}).get("content", "")
            return {"raw": content, "usage": data.get("usage") or {}}
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", "replace")[:300]
            last = f"HTTP {e.code}: {detail}"
            if e.code not in (408, 409, 429, 500, 502, 503, 504):
                break
        except Exception as e:  # noqa: BLE001
            last = f"{type(e).__name__}: {e}"
        time.sleep(1.5 * (attempt + 1))
    return {"raw": "", "error": last, "usage": {}}


def parse_model(raw: str) -> dict:
    if not raw:
        return {}
    m = re.search(r"```(?:json)?\s*(.*?)```", raw, re.S | re.I)
    s = m.group(1) if m else raw
    m = re.search(r"\{.*\}", s, re.S)
    if m:
        s = m.group(0)
    try:
        d = json.loads(s)
    except Exception:
        return {}
    out = {}
    for k in ("total", "subtotal", "tax", "service", "discount"):
        out[k] = num(d.get(k)) if d.get(k) is not None else None
    items = d.get("items") or []
    if isinstance(items, list):
        out["items"] = [num(x) for x in items if num(x) is not None]
    else:
        out["items"] = []
    return out


def ocr_digits(text: str) -> str:
    return re.sub(r"[^0-9]", "", text)


def grounded(v: int | None, digits: str) -> bool:
    if v is None:
        return False
    s = str(int(v))
    if s in digits:
        return True
    # tolerate a lost trailing zero / OCR group separator
    return s.rstrip("0") in digits if len(s.rstrip("0")) >= 4 else False


def amount_match(a, b) -> bool | None:
    if a is None or b is None:
        return None
    for scale, frac in ((1, 0.005), (1000, 0.05)):
        target = b * scale
        if abs(a - target) <= max(2, frac * abs(target)):
            return True
    return False


TOTAL_KEYS = ("grand total", "total", "amount due", "total due", "due", "netto", "net", "paid", "payment", "debit", "tl")
SUB_KEYS = ("subtotal", "sub total", "sub-total")
TAX_KEYS = ("pb1", "ppn", "tax", "vat")
SVC_KEYS = ("service", "svc", "service charge")
CASH_KEYS = ("cash", "change", "tendered", "kembalian", "bayar")
DISCOUNT_KEYS = ("discount", "diskon", "disc", "potongan", "saving", "hemat")
PAYMENT_KEYS = ("cash", "t-cash", "kupon", "voucher", "debit", "credit", "qris", "ovo", "gopay")


def _is_label(t: str, keys) -> bool:
    t = t.strip().lower()
    if not t:
        return False
    if any(k in t for k in ("subtotal", "sub total", "sub-total", "total item", "total qty")):
        if "subtotal" in keys or "sub total" in keys or "sub-total" in keys:
            pass
        else:
            return False
    for k in keys:
        if k == "tl":
            if t == "tl":
                return True
            continue
        if t == k or t.startswith(k + " ") or t.endswith(" " + k) or k in t:
            return True
        # OCR typo tolerance for the common label "total"
        if k == "total" and len(t) <= 7:
            import difflib
            if difflib.SequenceMatcher(None, t, "total").ratio() >= 0.8:
                return True
    return False


def role_grounded(value, text: str, keys, window=5) -> bool | None:
    """Is `value` printed next to a label for this field?

    Returns None when the label does not occur at all, True when the amount is
    within `window` tokens of the label, False when the label is present but
    the amount is not next to it.  Amounts are compared on digit strings, so
    "261.333", "261,333" and 261333 all match.
    """
    if value is None:
        return None
    vd = str(int(value))
    toks = [t.strip() for t in text.split("|")]
    label_seen = False
    for i, t in enumerate(toks):
        if _is_label(t, keys):
            label_seen = True
            for j in range(max(0, i - 2), min(len(toks), i + window + 1)):
                if j == i:
                    continue
                td = ocr_digits(toks[j])
                if td and (td == vd or td.endswith(vd) or (len(vd) >= 4 and vd in td)):
                    return True
    return False if label_seen else None


def judge(model: dict, gold: dict, text: str) -> dict:
    d = ocr_digits(text)
    checks = {}
    for f in ("total", "subtotal", "tax", "service", "discount"):
        v = model.get(f)
        checks[f + "_present"] = v is not None
        checks[f + "_grounded"] = grounded(v, d) if v is not None else False
    T, S, X, V, D = (model.get("total"), model.get("subtotal"), model.get("tax"),
                     model.get("service"), model.get("discount"))
    items = model.get("items") or []
    item_sum = sum(items) if items else None

    checks["total_role"] = role_grounded(T, text, TOTAL_KEYS)
    checks["total_near_cash"] = role_grounded(T, text, CASH_KEYS)
    checks["total_positive"] = T is not None and T > 0
    checks["total_ge_sub"] = (T is not None and S is not None and T >= S) if (T and S) else None
    tol = max(2, int(0.01 * (T or 0)))
    derived = None
    if S is not None and X is not None:
        derived = S + X + (V or 0) - (D or 0)
    elif S is not None and V is not None:
        derived = S + V - (D or 0)
    elif S is not None:
        derived = S - (D or 0)
    checks["components_close"] = (derived is not None and T is not None and abs(derived - T) <= tol)
    checks["items_close"] = (item_sum is not None and S is not None and abs(item_sum - S) <= 2)
    checks["discount_unknown"] = (T is not None and S is not None and T < S and D is None)
    checks["discount_role"] = role_grounded(D, text, DISCOUNT_KEYS) if D is not None else None
    checks["discount_near_payment"] = role_grounded(D, text, PAYMENT_KEYS) if D is not None else None
    discount_suspect = bool(D is not None and checks["discount_role"] is not True
                            and checks["discount_near_payment"] is True)
    discount_unlabeled = bool(D is not None and checks["discount_role"] is not True)
    checks["discount_suspect"] = discount_suspect
    checks["discount_unlabeled"] = discount_unlabeled
    checks["scale_shift"] = bool(item_sum is not None and S not in (None, 0)
                                 and (abs(item_sum / S - 10) < 0.5 or abs(item_sum / S - 0.1) < 0.05))

    violations = []
    unknowns = []
    if T is None:
        unknowns.append("no total")
    elif T <= 0:
        violations.append("total not positive")
    if T is not None and not checks["total_grounded"] and derived is None:
        violations.append("total not grounded in OCR")
    if T is not None and S is not None and S > 0 and T > 3 * S:
        violations.append("total > 3x subtotal")
    if T is not None and S is not None and T < S and D is None:
        unknowns.append("total < subtotal, no discount extracted")
    if checks["total_role"] is False:
        unknowns.append("total not next to a total label")
    if discount_unlabeled:
        unknowns.append("discount is not labelled as a discount")
    if checks["scale_shift"]:
        unknowns.append("line-item sum is 10x the subtotal")
    if checks["total_near_cash"] is True and checks["total_role"] is not True:
        unknowns.append("total next to cash/change")

    # Certification is arithmetic: the total is accepted only when the
    # components close.  Role grounding is reported but does not overrule a
    # closing arithmetic identity (OCR labels are noisy).
    corrected_total = None
    corrected_fields = {}
    if (T is None or not checks["total_grounded"]) and derived is not None:
        if grounded(derived, d) and checks["items_close"] and D is None:
            corrected_total = derived
            corrected_fields["total"] = derived
    if violations:
        verdict = "reject"
    elif corrected_total is not None:
        verdict = "fill"
    elif checks["components_close"] and checks["total_grounded"] and not discount_unlabeled and not checks["scale_shift"]:
        verdict = "accept"
    else:
        verdict = "review"
    final_total = corrected_total if corrected_total is not None else T
    return {
        "verdict": verdict,
        "checks": checks,
        "derived": derived,
        "item_sum": item_sum,
        "corrected": corrected_total,
        "corrected_fields": corrected_fields,
        "final_total": final_total,
        "violations": violations,
        "unknowns": unknowns,
        "total_correct": amount_match(final_total, gold["total"]),
        "model_total_correct": amount_match(T, gold["total"]),
        "sub_correct": amount_match(S, gold["subtotal"]),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=200)
    ap.add_argument("--offset", type=int, default=0)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--model", default="deepseek-chat")
    ap.add_argument("--key-env", default="DEEPSEEK_API_KEY")
    ap.add_argument("--data", default=str(DATA))
    ap.add_argument("--base-url", default="https://api.deepseek.com")
    ap.add_argument("--out-raw", default=str(OUT_RAW))
    ap.add_argument("--out", default=str(OUT))
    args = ap.parse_args()
    key = os.environ.get(args.key_env, "")
    if not key:
        print(f"missing env {args.key_env}", file=sys.stderr)
        sys.exit(2)

    df = pd.read_parquet(args.data)
    df = df.iloc[args.offset: args.offset + args.limit]
    print(f"receipts={len(df)}", flush=True)

    texts = [tokens_text(r["ocr_text"]) for _, r in df.iterrows()]
    raws: list[dict] = [{} for _ in range(len(df))]
    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(call_api, key, args.model, t, 90, args.base_url): i for i, t in enumerate(texts)}
        for i, fut in enumerate(as_completed(futs), 1):
            idx = futs[fut]
            raws[idx] = fut.result()
            if i % 20 == 0:
                print(f"{i}/{len(df)} {time.perf_counter()-t0:.1f}s", flush=True)
    print(f"api done {time.perf_counter()-t0:.1f}s", flush=True)

    rows = []
    for i, (_, r) in enumerate(df.iterrows()):
        gold = gold_of(r["ocr_kie"])
        model = parse_model(raws[i].get("raw", ""))
        j = judge(model, gold, texts[i])
        rows.append({
            "file": r["file_name"], "text": texts[i][:2000], "gold": gold,
            "model": model, "raw": raws[i].get("raw", "")[:4000],
            "usage": raws[i].get("usage", {}), "error": raws[i].get("error"),
            **j,
        })
    json.dump({"rows": rows}, open(args.out_raw, "w", encoding="utf-8"), ensure_ascii=False)

    # metrics
    from collections import Counter
    n = len(rows)
    verdicts = Counter(r["verdict"] for r in rows)
    model_total_known = [r for r in rows if r["model_total_correct"] is not None]
    model_total_acc = sum(r["model_total_correct"] for r in model_total_known) / max(1, len(model_total_known))
    final_known = [r for r in rows if r["total_correct"] is not None]
    final_acc = sum(r["total_correct"] for r in final_known) / max(1, len(final_known))
    accepted = [r for r in rows if r["verdict"] in ("accept", "fill")]
    fp = sum(1 for r in accepted if r["total_correct"] is False)
    caught = [r for r in rows if r["verdict"] == "reject" and r["model_total_correct"] is False]
    fills = [r for r in rows if r["verdict"] == "fill"]
    fill_ok = sum(1 for r in fills if r["total_correct"])
    wrong_model_total = [r for r in rows if r["model_total_correct"] is False]
    summary = {
        "n": n, "verdicts": dict(verdicts),
        "model_total_accuracy": round(model_total_acc, 4),
        "final_total_accuracy": round(final_acc, 4),
        "accepted": len(accepted), "automation": round(len(accepted) / n, 4),
        "false_pass": fp, "false_pass_rate": round(fp / n, 4),
        "accepted_precision": round((len(accepted) - fp) / len(accepted), 4) if accepted else None,
        "wrong_model_total": len(wrong_model_total),
        "caught_wrong_total": len(caught),
        "fill_count": len(fills), "fill_correct": fill_ok,
        "fill_precision": round(fill_ok / len(fills), 4) if fills else None,
        "closure_accept": verdicts.get("accept", 0),
        "usage_tokens": sum((r["usage"] or {}).get("total_tokens", 0) for r in rows),
        "errors": sum(1 for r in rows if r["error"]),
    }
    json.dump({"summary": summary, "rows": rows}, open(args.out, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
