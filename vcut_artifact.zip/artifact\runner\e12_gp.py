"""E12 leg 4: genetic search over a DB-native primitive DSL.

Primitives (no external knowledge, no pretrained model):
  bm25 / raw overlap / idf overlap / prefix-4 stem overlap / word-latent cosine /
  ngram-latent cosine / name hit / column hit / value hit / typed multiplicative /
  exact-SQL value evidence (second arm only)

A real-coded GA searches scoring weights on TRAIN-database questions; test
databases are held out.  Two arms: gp (10 primitives) and gp_ex (+exact).
Minimal instantiation of the "searched structure" leg; tree-GP over expression
composition is left for a later iteration.
"""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from pathlib import Path

import numpy as np

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
CASES = REPO / "06_结果" / "e11_cases.json"
CACHE = WORK / "schema_cache.json"
NPZ = WORK / "e12_spectral.npz"
EXACT = REPO / "06_结果" / "e12_exact.json"
OUT = REPO / "06_结果" / "e12_gp.json"

WORD = re.compile(r"[a-z0-9]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us list show give find return
number names name""".split())


def wtoks(s):
    return [t for t in WORD.findall(s.lower()) if t not in STOP]


def ngrams(w, ns=(3, 4, 5)):
    pad = f"<{w}>"
    return {pad[i:i + n] for n in ns for i in range(len(pad) - n + 1)} if len(pad) >= 3 else set()


def stem4(w):
    return w[:4] if len(w) >= 4 else w


def metrics_top(top_ids, gold_set):
    r = {1: 0.0, 3: 0.0, 5: 0.0}
    mrr = 0.0
    for i, d in enumerate(top_ids[:5]):
        if d in gold_set:
            mrr = max(mrr, 1.0 / (i + 1))
            for k in r:
                if i < k:
                    r[k] += 1.0 / len(gold_set)
    return r, mrr


def main():
    z = np.load(NPZ, allow_pickle=True)
    doc_ids = [str(x) for x in z["doc_ids"]]
    didx = {f: i for i, f in enumerate(doc_ids)}
    D = len(doc_ids)
    doc_wn = z["doc_word"] / np.maximum(np.linalg.norm(z["doc_word"], axis=1, keepdims=True), 1e-9)
    doc_gn = z["doc_gram"] / np.maximum(np.linalg.norm(z["doc_gram"], axis=1, keepdims=True), 1e-9)

    cache = json.load(open(CACHE, encoding="utf-8"))["spider"]
    name_t, col_t, val_t, all_t, stem_t = {}, {}, {}, {}, {}
    for db, s in cache.items():
        for t in s["tables"]:
            fid = f"{db}::{t['name'].lower()}"
            nm = list(wtoks(t["name"]))
            cl, vl = [], []
            for c in t["columns"]:
                cl += wtoks(c["name"])
                for v in (c.get("values") or [])[:12]:
                    vl += wtoks(str(v))
            name_t[fid], col_t[fid], val_t[fid] = set(nm), set(cl), set(vl)
            all_t[fid] = set(nm) | set(cl) | set(vl)
            stem_t[fid] = {stem4(x) for x in all_t[fid] if len(x) >= 4}
    df = Counter()
    for ts in all_t.values():
        df.update(ts)
    N = D
    idf = {t: math.log(1 + (N - df[t] + 0.5) / (df[t] + 0.5)) for t in df}
    tf = np.zeros((D, len(df)), dtype=np.float32)
    tidx = {t: i for i, t in enumerate(sorted(df))}
    for j, f in enumerate(doc_ids):
        for t in all_t[f]:
            tf[j, tidx[t]] = 1.0
    dlr = tf.sum(axis=1)

    exact = {r["qid"]: r for r in json.load(open(EXACT, encoding="utf-8"))}
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    gold_all = {c["qid"]: {f"{c['db_id']}::{g.lower()}" for g in c["gold"]} for c in cases}
    qtext = {c["qid"]: c["question"] for c in cases}
    split = {c["qid"]: c["split"] for c in cases}
    qids = sorted(qtext, key=lambda q: int(q[2:]))
    train_q = [q for q in qids if split[q] == "train"]
    test_q = [q for q in qids if split[q] == "test"]

    wv_vocab = {t: i for i, t in enumerate(z["word_vocab"])}
    gr_vocab = {t: i for i, t in enumerate(z["gram_vocab"])}
    term_w, term_g = z["term_word"], z["term_gram"]

    def q_latent(tokens, vocab, term):
        vs = [term[vocab[t]] for t in set(tokens) if t in vocab]
        if not vs:
            return None
        v = np.mean(vs, axis=0)
        return v / max(np.linalg.norm(v), 1e-9)

    def build_F(qs, use_exact):
        nf = 11 if use_exact else 10
        F = np.zeros((len(qs), D, nf), dtype=np.float32)
        for qi, q in enumerate(qs):
            qt = wtoks(qtext[q])
            qset = set(qt)
            qstem = {stem4(w) for w in qt if len(w) >= 4}
            wv = q_latent(qt, wv_vocab, term_w)
            gv = q_latent([g for w in qt for g in ngrams(w)], gr_vocab, term_g)
            if wv is not None:
                F[qi, :, 4] = doc_wn @ wv
            if gv is not None:
                F[qi, :, 5] = doc_gn @ gv
            s = np.zeros(D, dtype=np.float32)
            for t, qc in Counter(qt).items():
                if t not in tidx:
                    continue
                col = tf[:, tidx[t]]
                s += qc * idf[t] * (col * 2.2) / (col + 1.2 * (0.25 + 0.75 * dlr / (dlr.mean() + 1e-9)))
            F[qi, :, 3] = s
            if use_exact:
                ex = F[qi, :, 10]
                if q in exact:
                    for fid, ev in zip(exact[q]["pool"], exact[q]["evidence"]):
                        j = didx.get(fid)
                        if j is not None:
                            ex[j] = ev
            for j, f in enumerate(doc_ids):
                inter = qset & all_t[f]
                F[qi, j, 0] = len(inter)
                F[qi, j, 1] = sum(idf.get(t, 0.0) for t in inter)
                F[qi, j, 2] = len(qstem & stem_t[f])
                F[qi, j, 6] = len(qset & name_t[f])
                F[qi, j, 7] = len(qset & col_t[f])
                F[qi, j, 8] = len(qset & val_t[f])
            F[:, :, 9] = 0  # filled below vectorised
        log1p = np.log1p
        F[:, :, 9] = log1p(F[:, :, 6]) * log1p(F[:, :, 7]) * log1p(F[:, :, 8])
        return F

    def run_arm(use_exact, tag):
        print(f"[{tag}] building features (train)…", flush=True)
        Ft = build_F(train_q, use_exact)
        mu = Ft.reshape(-1, Ft.shape[-1]).mean(0)
        sd = Ft.reshape(-1, Ft.shape[-1]).std(0) + 1e-9
        Fn = (Ft - mu) / sd
        del Ft
        gold_tr = [gold_all[q] for q in train_q]

        def fitness_batch(W, chunk=120):
            P = W.shape[0]
            out = np.zeros(P)
            for s0 in range(0, len(train_q), chunk):
                e = min(s0 + chunk, len(train_q))
                sc = Fn[s0:e] @ W.T
                for p in range(P):
                    part = np.argpartition(-sc[:, :, p], 8, axis=1)[:, :8]
                    for qi in range(e - s0):
                        loc = part[qi]
                        order = loc[np.argsort(-sc[qi, loc, p])]
                        g = gold_tr[s0 + qi]
                        r5 = 0.0
                        for di in order[:5]:
                            if doc_ids[di] in g:
                                r5 += 1.0 / len(g)
                        out[p] += r5
            return out / len(train_q)

        rng = np.random.default_rng(7)
        P, G = 80, 60
        pop = rng.uniform(-0.5, 1.5, (P, Fn.shape[-1]))
        hist = []
        for gen in range(G):
            fit = fitness_batch(pop)
            hist.append(round(float(fit.max()), 4))
            elite = pop[np.argsort(-fit)[:2]].copy()
            new = [elite[0], elite[1]]
            while len(new) < P:
                i, j = rng.integers(0, P, 2)
                a, b = (pop[i], pop[j]) if fit[i] >= fit[j] else (pop[j], pop[i])
                lam = rng.uniform(-0.25, 1.25, Fn.shape[-1])
                child = a + lam * (b - a)
                child += (rng.random(Fn.shape[-1]) < 0.25) * rng.normal(0, 0.2, Fn.shape[-1])
                new.append(np.clip(child, -3, 3))
            pop = np.array(new)
            if (gen + 1) % 10 == 0:
                print(f"[{tag}] gen {gen+1}: best train R@5={fit.max():.4f}", flush=True)
        fit = fitness_batch(pop)
        w_best = pop[int(np.argmax(fit))]
        print(f"[{tag}] train best R@5={fit.max():.4f} weights={np.round(w_best,2).tolist()}")

        print(f"[{tag}] building features (test)…", flush=True)
        Fte = (build_F(test_q, use_exact) - mu) / sd
        rows, scores = [], []
        for qi, q in enumerate(test_q):
            sc = Fte[qi] @ w_best
            scores.append(sc)
            order = np.argsort(-sc)[:5]
            top = [doc_ids[i] for i in order]
            r, m = metrics_top(top, gold_all[q])
            rows.append({"qid": q, "db": next(c["db_id"] for c in cases if c["qid"] == q),
                         "gold": sorted(gold_all[q]), "top5": top,
                         "recall@1": r[1], "recall@3": r[3], "recall@5": r[5], "mrr": m})
        n = len(rows)
        summ = {k: round(sum(r[k] for r in rows) / n, 4) for k in ("recall@1", "recall@3", "recall@5", "mrr")}
        print(f"[{tag}] test:", json.dumps(summ))
        return {"tag": tag, "weights": np.round(w_best, 4).tolist(), "train_curve": hist,
                "test_metrics": summ, "rows": rows}

    arm1 = run_arm(False, "gp")
    arm2 = run_arm(True, "gp_ex")
    json.dump({"arms": {a["tag"]: {k: a[k] for k in ("weights", "train_curve", "test_metrics")}
                        for a in (arm1, arm2)},
               "rows": {"gp": arm1["rows"], "gp_ex": arm2["rows"]}},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
