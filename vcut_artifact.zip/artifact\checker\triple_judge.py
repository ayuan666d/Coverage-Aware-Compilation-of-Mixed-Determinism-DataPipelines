# -*- coding: utf-8 -*-
"""三判据对拍 —— 路径枚举 / 支配 / 割集

设计纪律（见 03_实验/实验方案_v1.0.md §2.1）：
    三种判据必须用**三套互不共享的代码**实现，否则对拍无意义。
    · 路径枚举  —— 穷举所有 source→sink 路径，逐条检查
    · 支配判据  —— 逐判决节点删除 + 可达性（不用支配树算法）
    · 割集判据  —— 一次删除全部判决节点 + 可达性

用法：
    python triple_judge.py <spec.yaml> [--json]

返回码：0 = 三判据一致；2 = 不一致（例如定理 1' 的误杀）
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from typing import Dict, FrozenSet, Iterable, List, Sequence, Set, Tuple

VERDICT_KINDS = ("rule", "gate")
SINK_KINDS = ("sink",)


# ── 载入 ──────────────────────────────────────────────────────


def load_spec(path: str) -> dict:
    import yaml

    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def build(spec: dict):
    nodes = spec.get("nodes") or {}
    if isinstance(nodes, list):
        nodes = {n["id"]: n for n in nodes}
    succ: Dict[str, List[str]] = defaultdict(list)
    pred: Dict[str, List[str]] = defaultdict(list)
    for e in spec.get("edges") or []:
        a, b = e["src"], e["dst"]
        succ[a].append(b)
        pred[b].append(a)
    for n in nodes:
        succ.setdefault(n, [])
        pred.setdefault(n, [])

    verdicts = {n for n, v in nodes.items() if v.get("kind") in VERDICT_KINDS}
    sinks = {n for n, v in nodes.items() if v.get("kind") in SINK_KINDS}
    sources = [n for n in nodes if not pred[n]]
    return nodes, dict(succ), dict(pred), verdicts, sinks, sources


# ── 判据 A：路径枚举 ──────────────────────────────────────────


def enumerate_paths(
    sources: Sequence[str], sinks: Set[str], succ: Dict[str, List[str]], cap: int = 2_000_000
) -> List[List[str]]:
    """穷举所有 source→sink 简单路径。DAG 上有限。"""
    out: List[List[str]] = []
    stack: List[Tuple[str, List[str]]] = [(s, [s]) for s in sources]
    while stack:
        node, path = stack.pop()
        if node in sinks:
            out.append(path)
            if len(out) > cap:
                raise RuntimeError(f"路径数超过上限 {cap}，图过大，改用可达性判据")
            continue
        for nxt in succ.get(node, []):
            if nxt in path:      # 防御性：理论上无环
                continue
            stack.append((nxt, path + [nxt]))
    return out


def judge_by_paths(paths: Iterable[Sequence[str]], verdicts: Set[str]):
    bad = [list(p) for p in paths if not (set(p) & verdicts)]
    return (len(bad) == 0), bad


# ── 判据 B：支配（逐节点删除 + 可达性）────────────────────────


def reachable(
    src: str, dst: str, succ: Dict[str, List[str]], blocked: FrozenSet[str] = frozenset()
) -> bool:
    if src in blocked:
        return False
    seen = {src}
    stack = [src]
    while stack:
        n = stack.pop()
        if n == dst:
            return True
        for k in succ.get(n, []):
            if k not in seen and k not in blocked:
                seen.add(k)
                stack.append(k)
    return False


def judge_by_dominance(
    sources: Sequence[str], sinks: Set[str], succ: Dict[str, List[str]], verdicts: Set[str]
):
    """存在单个判决节点 v，使删掉 v 后所有 source 都到不了 sink。"""
    per_sink: Dict[str, bool] = {}
    witness: Dict[str, str | None] = {}
    for s in sorted(sinks):
        ok, who = False, None
        for v in sorted(verdicts):
            if all(not reachable(src, s, succ, frozenset({v})) for src in sources):
                ok, who = True, v
                break
        per_sink[s], witness[s] = ok, who
    return all(per_sink.values()), per_sink, witness


# ── 判据 C：割集（一次删掉全部判决节点）──────────────────────


def judge_by_cut(
    sources: Sequence[str], sinks: Set[str], succ: Dict[str, List[str]], verdicts: Set[str]
):
    per_sink: Dict[str, bool] = {}
    offender: Dict[str, List[str] | None] = {}
    for s in sorted(sinks):
        ok = all(not reachable(src, s, succ, frozenset(verdicts)) for src in sources)
        per_sink[s] = ok
        offender[s] = None
    return all(per_sink.values()), per_sink, offender


# ── 主程序 ────────────────────────────────────────────────────


def main(argv: Sequence[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="三判据对拍")
    ap.add_argument("spec")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    spec = load_spec(args.spec)
    nodes, succ, pred, verdicts, sinks, sources = build(spec)

    paths = enumerate_paths(sources, sinks, succ)
    ok_paths, bad_paths = judge_by_paths(paths, verdicts)
    ok_dom, dom_per_sink, dom_witness = judge_by_dominance(sources, sinks, succ, verdicts)
    ok_cut, cut_per_sink, _ = judge_by_cut(sources, sinks, succ, verdicts)

    report = {
        "spec": spec.get("id"),
        "nodes": len(nodes),
        "edges": sum(len(v) for v in succ.values()),
        "sources": sources,
        "sinks": sorted(sinks),
        "verdicts": sorted(verdicts),
        "path_count": len(paths),
        "judge_paths": {"safe": ok_paths, "bad_path_count": len(bad_paths)},
        "judge_dominance": {"safe": ok_dom, "per_sink": dom_per_sink, "witness": dom_witness},
        "judge_cut": {"safe": ok_cut, "per_sink": cut_per_sink},
    }

    verdicts_agree = ok_paths == ok_cut
    all_agree = ok_paths == ok_dom == ok_cut
    report["paths_vs_cut_agree"] = verdicts_agree
    report["all_three_agree"] = all_agree

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"管线 {report['spec']}   节点 {report['nodes']}   边 {report['edges']}")
        print(f"  源 {sources}   出口 {sorted(sinks)}   判决 {sorted(verdicts)}")
        print(f"  路径总数 {len(paths)}")
        print()
        print(f"  [A] 路径枚举   safe = {ok_paths}   坏路径 {len(bad_paths)} 条")
        print(f"  [B] 支配判据   safe = {ok_dom}   逐出口 {dom_per_sink}")
        if not ok_dom:
            print("      → 无单个判决节点支配出口")
        print(f"  [C] 割集判据   safe = {ok_cut}   逐出口 {cut_per_sink}")
        print()
        if ok_paths != ok_cut:
            print("  ✗ A 与 C 不一致 —— 割集实现或 V_eff 有 bug，必须先修")
        if ok_paths != ok_dom:
            print("  ⚠ B 与 A/C 不一致 —— 定理 1' 的误杀已被复现：")
            print("     该图实际安全（每条路径都过判决），支配判据却判危险。")
        if all_agree:
            print("  ✓ 三判据一致")

    return 0 if all_agree else 2


if __name__ == "__main__":
    sys.exit(main())
