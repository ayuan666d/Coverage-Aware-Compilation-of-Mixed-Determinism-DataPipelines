# -*- coding: utf-8 -*-
"""E1b —— 真实系统上的“假安全”单例

同一拓扑、同一插件集，只换判决表的覆盖与兜底方向：
    A  l0_permit_complete      ：9/9 输入有规则，兜底 reject
    B  l0_permit_pass_default  ：6/9 输入有规则，兜底 pass

真实编译器的 C4 只看拓扑（是否存在判决节点支配出口），不看表。
预期：A、B 都编译通过；B 在运行时把 3 个未覆盖输入直接放行。

不修改 D:\\prod\\permit-platform；只读它的 compiled API。
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Dict, Tuple

import yaml

HERE = Path(__file__).resolve().parent.parent
REPO = HERE.parent
REAL = Path("D:/prod/permit-platform")
FIXTURES = HERE / "generator" / "fixtures" / "real"
PROBE = HERE / "runner" / "_real_compile_probe.py"
OUT_JSON = REPO / "06_结果" / "e1b_real.json"
OUT_MD = REPO / "06_结果" / "E1b_报告.md"

SPECS = {
    "A_complete": FIXTURES / "l0_permit_complete.yaml",
    "B_pass_default": FIXTURES / "l0_permit_pass_default.yaml",
}

FTYPES = ["hot", "confined", "high"]
FLEVELS = ["sp", "1st", "2nd"]
INPUTS = [{"ftype": f, "flevel": l} for f in FTYPES for l in FLEVELS]
CONSERVATIVE = frozenset({"reject", "review"})


def load_spec(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def decide(table: dict, t: Dict[str, str]) -> Tuple[str, str | None]:
    for r in table.get("rules") or []:
        when = r.get("when") or {}
        if all(t.get(k) == v for k, v in when.items()):
            return r.get("verdict", "reject"), r.get("id") or "hit"
    return table.get("fallback", "pass"), None


def judged(verdict: str, hit: str | None) -> bool:
    return hit is not None or verdict in CONSERVATIVE


def compile_with_real(spec_path: Path) -> dict:
    cmd = [str(REAL / "env" / "Scripts" / "python.exe"),
           str(PROBE), str(spec_path)]
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    p = subprocess.run(
        cmd, cwd=str(REAL), env=env,
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    if p.returncode != 0:
        return {"ok": False, "problems": [f"probe failed: {p.stderr[-800:]}"],
                "warnings": []}
    try:
        return json.loads(p.stdout.strip().splitlines()[-1])
    except Exception:
        return {"ok": False, "problems": [f"bad probe output: {p.stdout[-800:]}"],
                "warnings": []}


def main() -> int:
    if not (REAL / "env" / "Scripts" / "python.exe").exists():
        print(f"未找到真实环境：{REAL / 'env' / 'Scripts' / 'python.exe'}")
        return 2

    specs = {k: load_spec(p) for k, p in SPECS.items()}
    compile_res = {k: compile_with_real(p) for k, p in SPECS.items()}

    rows = []
    bypass = []
    for t in INPUTS:
        row = {"input": dict(t)}
        for k, spec in specs.items():
            table = (spec.get("meta") or {}).get("verdict_table") or {}
            v, hit = decide(table, t)
            row[k] = {"verdict": v, "hit": hit, "judged": judged(v, hit)}
        row["bypass"] = {
            k: (row[k]["verdict"] == "pass" and not row[k]["judged"])
            for k in SPECS
        }
        if row["bypass"]["B_pass_default"]:
            bypass.append(dict(t))
        rows.append(row)

    both_compile = all(r["ok"] for r in compile_res.values())
    result = {
        "schema": "e1b-v0.1",
        "real_repo": str(REAL),
        "both_compile": both_compile,
        "compile": compile_res,
        "rows": rows,
        "bypass_inputs_B": bypass,
        "conclusion": (
            "同一拓扑、同一插件集，编译器对 A/B 给出相同结论；"
            "但 B 的兜底 pass 在 3 个未覆盖输入上产生未判放行。"
            if both_compile and bypass else
            "预期未完全成立：检查编译结果或表定义。"
        ),
    }
    OUT_JSON.write_text(json.dumps(result, ensure_ascii=False, indent=2),
                        encoding="utf-8")

    # ── Markdown 报告 ──
    lines = [
        "# E1b 报告：真实系统上的假安全单例",
        "",
        "> 2026-10-30 · 同一拓扑、两张表；真实编译器只读拓扑，不读表覆盖",
        "",
        "## 一、结论",
        "",
    ]
    if both_compile:
        lines += [
            "**两张表都编译通过。** 真实编译器的 C4 只检查“是否存在判决节点支配出口”，"
            "不检查判决表是否覆盖输入、兜底往哪走。因此同一拓扑下，"
            "全覆盖表和有洞表拿到同一个结论。",
            "",
            f"**B 在 {len(bypass)} 个输入上未判放行：** "
            + "、".join(f"`{b['ftype']}/{b['flevel']}`" for b in bypass) + "。",
        ]
    else:
        lines.append("**预期未成立**：至少一张表没有编译通过，见下表。")
    lines += [
        "",
        "## 二、编译器结论",
        "",
        "| 表 | 编译 | 问题 |",
        "|---|---|---|",
    ]
    for k, r in compile_res.items():
        probs = "<br>".join(str(x) for x in r.get("problems", [])) or "—"
        lines.append(f"| {k} | {'✓ 通过' if r.get('ok') else '✗ 失败'} | {probs} |")

    lines += [
        "",
        "## 三、运行时逐输入",
        "",
        "| 输入 | A 判决 | A 判过 | B 判决 | B 判过 | B 绕过 |",
        "|---|---|---|---|---|---|",
    ]
    for row in rows:
        a, b = row["A_complete"], row["B_pass_default"]
        lines.append(
            f"| {row['input']['ftype']}/{row['input']['flevel']} "
            f"| {a['verdict']} | {'是' if a['judged'] else '否'} "
            f"| {b['verdict']} | {'是' if b['judged'] else '否'} "
            f"| {'**是**' if row['bypass']['B_pass_default'] else '否'} |"
        )

    lines += [
        "",
        "## 四、这证明了什么、没证明什么",
        "",
        "**已证明**",
        "- 真实编译器对“同一拓扑、不同表覆盖”是盲的：A、B 同结论。",
        "- 兜底 `pass` + 覆盖缺口会在运行时产生未判放行；这是 H1 的“假安全”方向，"
        "不再是纯合成图上的推演。",
        "",
        "**没证明**",
        "- 没有证明真实系统的判决表一定长这样。A/B 是构造的对照，不是线上表的统计。",
        "- 没有证明编译器“应该”读表——它当前的设计就是拓扑编译器；"
        "本文的主张是：安全结论需要把表覆盖纳入判据（`eff`），这是接口缺口，不是实现 bug。",
        "",
        "## 五、复现",
        "",
        "```bash",
        "cd 05_代码",
        "python runner/e1b_real_false_safety.py",
        "```",
        "",
        f"产物：`{OUT_JSON.relative_to(REPO)}`；spec：`05_代码/generator/fixtures/real/`。",
    ]
    OUT_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(json.dumps({
        "both_compile": both_compile,
        "bypass_inputs_B": bypass,
        "compile": {k: v.get("ok") for k, v in compile_res.items()},
    }, ensure_ascii=False, indent=2))
    print(f"\n已写入 {OUT_JSON} 和 {OUT_MD}")
    return 0 if both_compile else 1


if __name__ == "__main__":
    sys.exit(main())
