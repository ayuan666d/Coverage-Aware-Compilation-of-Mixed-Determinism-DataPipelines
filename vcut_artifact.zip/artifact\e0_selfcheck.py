# -*- coding: utf-8 -*-
"""E0 —— 定义自洽性验证

对随机小图（≤10 节点）跑 A/B 双实现对拍，验三条：
    V1 定理 1（割集判据）
    V2 命题 1（坏路径节点集）
    V3 定理 2（最小修复规模 = Menger）

判定：不一致条数必须为 0。不为 0 说明定义有歧义或实现有 bug，
      修完才能进 E1。

用法：
    python e0_selfcheck.py [--n 10000] [--seed 0] [--verbose]
"""

from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from checker.axioms import Case, edge_check_applicable, verify  # noqa: E402


def gen_case(rng: random.Random, max_nodes: int = 10) -> Case | None:
    """随机 DAG。按索引序加边保证无环；v0.3 起随机加入 1–2 个额外源。"""
    n = rng.randint(3, max_nodes)
    names = [f"n{i}" for i in range(n)]

    edges: list[tuple[str, str]] = []
    p = rng.choice([0.15, 0.25, 0.35, 0.45])
    for i in range(n):
        for j in range(i + 1, n):
            if rng.random() < p:
                edges.append((names[i], names[j]))

    # 从 n0 可达的节点才保留（避免孤立点干扰）
    succ = {x: [] for x in names}
    for a, b in edges:
        succ[a].append(b)
    reach = {"n0"}
    stack = ["n0"]
    while stack:
        u = stack.pop()
        for v in succ[u]:
            if v not in reach:
                reach.add(v)
                stack.append(v)
    if len(reach) < 2:
        return None
    nodes = sorted(reach)
    edges = [(a, b) for a, b in edges if a in reach and b in reach]

    # v0.3：额外源。它们没有入边，因此 sources() 会返回多个源。
    extra = rng.choice([0, 0, 1, 2])
    for k in range(extra):
        src = f"s{k}"
        nodes.append(src)
        targets = [x for x in nodes if x != src]
        for _ in range(rng.randint(1, min(3, len(targets)))):
            tgt = rng.choice(targets)
            if (src, tgt) not in edges:
                edges.append((src, tgt))

    succ = {x: [] for x in nodes}
    for a, b in edges:
        succ[a].append(b)

    sinks = tuple(sorted(x for x in nodes if not succ.get(x)))
    if not sinks:
        return None

    has_in = {b for _, b in edges}
    sources = {x for x in nodes if x not in has_in}

    # V_eff 只取内部节点（非源非出口），规模偏小以制造足够多的不安全例
    internals = [x for x in nodes if x not in sinks and x not in sources]
    k = rng.randint(0, min(2, len(internals))) if internals else 0
    v_eff = frozenset(rng.sample(internals, k)) if k else frozenset()

    return Case(nodes=tuple(sorted(nodes)), edges=tuple(edges),
                sinks=sinks, v_eff=v_eff)


def main() -> int:
    ap = argparse.ArgumentParser(description="E0 定义自洽性验证")
    ap.add_argument("--n", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--max-nodes", type=int, default=10)
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--show", type=int, default=5, help="最多打印几条 issue")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    total = 0
    skipped = 0
    counts = {"V1": 0, "V2": 0, "V3": 0, "V4": 0}
    samples: list[str] = []
    unsafe = 0
    multi_source = 0
    edge_skipped = 0

    while total < args.n:
        case = gen_case(rng, args.max_nodes)
        if case is None:
            skipped += 1
            if skipped > args.n * 20:
                print("生成器连续失败过多，检查参数")
                return 1
            continue
        total += 1
        if len(case.sources()) > 1:
            multi_source += 1
        if not edge_check_applicable(case):
            edge_skipped += 1

        from checker.axioms import v1_by_reachability
        safe, _, _ = v1_by_reachability(case)
        if not safe:
            unsafe += 1

        for iss in verify(case):
            counts[iss.kind] = counts.get(iss.kind, 0) + 1
            if len(samples) < args.show:
                samples.append(f"[{iss.kind}] {iss.detail}")
            if args.verbose:
                print(f"  ✗ {iss.kind}: {iss.detail}")
                print(f"     case: nodes={case.nodes} edges={case.edges} "
                      f"sinks={case.sinks} v_eff={sorted(case.v_eff)}")

    bad = sum(counts.values())
    print(f"\n{'='*62}")
    print(f"E0 结果  n={total}  seed={args.seed}  max_nodes={args.max_nodes}")
    print(f"  跳过的退化样本   {skipped}")
    print(f"  多源图           {multi_source}  ({multi_source/total*100:.1f}%)")
    print(f"  不安全的图       {unsafe}  ({unsafe/total*100:.1f}%)   ← 保证测例非平凡")
    print(f"  V1 定理1 不一致  {counts.get('V1', 0)}")
    print(f"  V2 命题1 不一致  {counts.get('V2', 0)}")
    print(f"  V3 定理2(顶点)不一致  {counts.get('V3', 0)}")
    print(f"  V4 定理2(边割)不一致  {counts.get('V4', 0)}"
          f"   （{edge_skipped} 例超出枚举范围，已跳过）")
    print(f"{'='*62}")
    for s in samples:
        print("  " + s)
    if bad == 0:
        print("\n✓ E0 通过：四组命题在同 100% 样本上双实现一致")
        return 0
    print(f"\n✗ E0 失败：{bad} 条不一致，必须先修定义或实现，不得进入 E1")
    return 2


if __name__ == "__main__":
    sys.exit(main())
