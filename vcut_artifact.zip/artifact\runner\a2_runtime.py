# -*- coding: utf-8 -*-
"""A2: end-to-end runtime — compile -> run -> judge -> audit, with latency.

The runtime executes the census IR (real Dify / Airflow / OpenClaw topologies)
under a decision table per verdict node, and records one audit row per decision
(verdict, rule id, executed sinks, witness id). It is a prototype of the
"safe runtime" shape, not a production engine: no LLM call is made here; the
model output is an input field of the decision, which is exactly the object
the contract constrains.

Loads: 1k / 5k / 10k decisions over the real topologies that carry sinks; a
500-node synthetic chain as the per-decision cost control; a 10k-node chain
for compile scale.
"""
from __future__ import annotations

import hashlib
import importlib.util
import io
import json
import os
import sys
import time
from dataclasses import dataclass
from typing import Dict, List, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = r"E:\vldb2027_pipeline_safety\06_结果\a2_runtime.json"

spec = importlib.util.spec_from_file_location("a1", os.path.join(HERE, "a1_real_census.py"))
a1 = importlib.util.module_from_spec(spec)
sys.modules["a1"] = a1
spec.loader.exec_module(a1)

VALUES = ("malformed", "unsafe", "low_conf", "normal")


# ── decision table ───────────────────────────────────────────────

@dataclass(frozen=True)
class Table:
    accepts: Tuple[str, ...]     # values for which the judgment is complete (pass)
    fallback: str                # pass / reject

    def decide(self, t: Dict[str, str]) -> Tuple[str, str | None]:
        v = t.get("outcome")
        if v in self.accepts:
            return "pass", f"r_{v}"
        return self.fallback, None


def compile_tables(g, cover: float, fallback: str) -> Dict[str, Table]:
    k = max(0, round(len(VALUES) * cover))
    return {v: Table(tuple(VALUES[:k]), fallback) for v in g.verdicts}


# ── compiled graph ───────────────────────────────────────────────

def compile_graph(g):
    succ = {n: [] for n in g.nodes}
    for a, b, h in g.edges:
        succ.setdefault(a, []).append((b, h))
    return succ


def run_one(g, succ, tables, t: Dict[str, str]) -> dict:
    entries = g.entries if g.entries else set(g.sources())
    reached = set(entries)
    frontier = list(entries)
    executed = set()
    hits = []
    blocked = 0
    while frontier:
        u = frontier.pop()
        allowed = True
        if u in g.verdicts:
            v, rid = tables[u].decide(t)
            hits.append((u, v, rid))
            if v != "pass":
                blocked += 1
                allowed = False
        if u in g.sinks:
            executed.add(u)
        for b, h in succ.get(u, ()):
            if not allowed and h != "pass":
                continue
            if b not in reached:
                reached.add(b)
                frontier.append(b)
    audit = {"v": hits, "blocked": blocked, "exec": sorted(executed)}
    audit["w"] = hashlib.sha1(repr(audit).encode()).hexdigest()[:10]
    return audit


def bench(g, tables, n: int, mode: str) -> dict:
    succ = compile_graph(g)
    lat = []
    t0 = time.perf_counter()
    for i in range(n):
        s = time.perf_counter_ns()
        run_one(g, succ, tables, {"outcome": VALUES[i % len(VALUES)]})
        lat.append(time.perf_counter_ns() - s)
    wall = time.perf_counter() - t0
    lat.sort()
    q = lambda p: lat[min(len(lat) - 1, int(len(lat) * p))] / 1000.0
    return {"mode": mode, "n": n, "wall_s": round(wall, 4),
            "us_per_decision": round(sum(lat) / len(lat) / 1000.0, 2),
            "p50_us": round(q(.50), 2), "p95_us": round(q(.95), 2), "p99_us": round(q(.99), 2),
            "decisions_per_s": int(n / wall) if wall else 0}


# ── synthetic chains ─────────────────────────────────────────────

def chain(n_nodes: int, n_verdict: int, n_sink: int) -> a1.Graph:
    g = a1.Graph("synthetic", f"chain{n_nodes}", "-")
    g.nodes = {f"n{i}": "map" for i in range(n_nodes)}
    for i in range(n_nodes - 1):
        g.edges.append((f"n{i}", f"n{i+1}", "pass"))
    step = max(1, n_nodes // max(1, n_verdict))
    vids = [f"n{i}" for i in range(0, n_nodes, step)][:n_verdict]
    for v in vids:
        g.nodes[v] = "rule"
        g.verdicts.add(v)
    sinks = []
    for v in vids:
        i = int(v[1:])
        if i + 1 < n_nodes:
            g.nodes[f"n{i+1}"] = "exec"
            sinks.append(f"n{i+1}")
            g.edges.append((v, f"n{i+1}", "rule"))
    step2 = max(1, n_nodes // max(1, n_sink))
    for i in range(n_nodes - 1, -1, -step2):
        if g.nodes[f"n{i}"] == "map":
            g.nodes[f"n{i}"] = "exec"
            sinks.append(f"n{i}")
        if len(sinks) >= n_sink:
            break
    g.sinks = set(sinks)
    g.entries = {"n0"}
    return g


def main():
    rows = json.load(io.open(r"E:\vldb2027_pipeline_safety\06_结果\a1_real_census.json",
                              encoding="utf-8"))
    pipes = [r for r in rows["pipelines"] if r.get("sinks")]
    graphs = []
    for p in pipes:
        fw = p["framework"]
        path = None
        if fw == "dify":
            for d in a1.DIFY_DIRS:
                q = os.path.join(d, p["file"])
                if os.path.exists(q):
                    path = q
                    break
        elif fw == "airflow":
            path = os.path.join(a1.AIRFLOW_DIR, p["file"])
        if not path:
            continue
        if fw == "dify":
            g = a1.parse_dify(path)
        elif fw == "airflow":
            g = a1.parse_airflow(path)
        else:
            continue
        if g is not None:
            graphs.append(g)

    out = {"real_topologies": [], "loads": [], "scale": []}

    for cover, fallback in ((1.0, "reject"), (0.3, "pass")):
        tables = [compile_tables(g, cover, fallback) for g in graphs]
        for g, tb in zip(graphs, tables):
            r = bench(g, tb, 1000, f"cover={cover},fb={fallback}")
            r.update({"workflow": g.name, "framework": g.framework,
                      "nodes": len(g.nodes), "verdicts": len(g.verdicts),
                      "sinks": len(g.sinks), "cover": cover, "fallback": fallback})
            out["real_topologies"].append(r)

        for load in (1000, 5000, 10000):
            t0 = time.perf_counter()
            lat = []
            unsafe = 0
            for i in range(load):
                g = graphs[i % len(graphs)]
                tb = tables[i % len(graphs)]
                s = time.perf_counter_ns()
                a = run_one(g, compile_graph(g), tb, {"outcome": VALUES[i % 4]})
                lat.append(time.perf_counter_ns() - s)
                unsafe += 1 if (a["exec"] and a["blocked"] == 0 and
                                VALUES[i % 4] not in VALUES[: round(4 * cover)]) else 0
            wall = time.perf_counter() - t0
            lat.sort()
            out["loads"].append({
                "cover": cover, "fallback": fallback, "decisions": load,
                "workflows": len(graphs), "wall_s": round(wall, 4),
                "us_per_decision": round(sum(lat) / len(lat) / 1000.0, 2),
                "p50_us": round(lat[len(lat) // 2] / 1000.0, 2),
                "p95_us": round(lat[int(len(lat) * .95)] / 1000.0, 2),
                "p99_us": round(lat[int(len(lat) * .99)] / 1000.0, 2),
                "decisions_per_s": int(load / wall) if wall else 0,
                "unjudged_actions": unsafe})

    for nodes, nv, ns, load in ((500, 50, 100, 200), (10000, 500, 1000, 200)):
        g = chain(nodes, nv, ns)
        tb = compile_tables(g, 0.3, "pass")
        runs = [bench(g, tb, load, "cover=0.3,fb=pass") for _ in range(5)]
        runs.sort(key=lambda x: x["us_per_decision"])
        r = runs[2]
        r.update({"nodes": len(g.nodes), "verdicts": len(g.verdicts),
                  "sinks": len(g.sinks), "reps": 5})
        out["scale"].append(r)

    json.dump(out, io.open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    print("== real topologies (1k decisions each, cover=1.0, fallback=reject) ==")
    for r in out["real_topologies"][: len(graphs)]:
        print(f"{r['framework']:8s} {r['workflow'][:30]:30s} nodes={r['nodes']:3d} "
              f"{r['us_per_decision']:8.2f} us  p95={r['p95_us']:8.2f}  "
              f"{r['decisions_per_s']:7d}/s")
    print("\n== pooled loads ==")
    for r in out["loads"]:
        print(f"cover={r['cover']} fb={r['fallback']:6s} n={r['decisions']:5d} "
              f"{r['us_per_decision']:8.2f} us p99={r['p99_us']:8.2f} "
              f"{r['decisions_per_s']:7d}/s unjudged={r['unjudged_actions']}")
    print("\n== scale ==")
    for r in out["scale"]:
        print(f"nodes={r['nodes']:5d} n={r['n']:5d} {r['us_per_decision']:9.2f} us "
              f"{r['decisions_per_s']:7d}/s")
    print("wrote", OUT)


if __name__ == "__main__":
    main()
