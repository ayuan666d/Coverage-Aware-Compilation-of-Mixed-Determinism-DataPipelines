# -*- coding: utf-8 -*-
"""E3 —— 编译与检查开销：编译期可用性

实验方案 §6-E3：管线规模 8/20/60/200/500 节点，各形状各配置 50 条，
逐组件计时（B 组算法实现）：

    t_veff   V_eff 计算（逐判决 × 逐输入调表）
    t_v1     割判定（定理 1，可达性）
    t_v2     坏路径节点集（命题 1，fwd ∩ bwd）
    t_v3     最小修复规模（定理 2，多源超级源 Dinic）
    t_b1     支配判据（B1 删除法，参照线：便宜但 E1 已证双向皆错）
    t_total  t_v1 + t_v2 + t_v3（单输入）；×|输入空间| = 逐输入全检

判定线：500 节点 × 全输入 的总检查时间 < 1 秒 → "编译期可用"成立。

用法：
    python runner/e3.py [--pilot]      # pilot 只跑每格前 3 条
"""

from __future__ import annotations

import argparse
import json
import random
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Dict, List

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

from checker import axioms  # noqa: E402
from checker.graphutil import reachable_set  # noqa: E402
from generator.synth import Pipe, synth  # noqa: E402
from runner.e1 import judge_dominance  # noqa: E402

SHAPES = ["line", "fork_join", "branch_verdict"]
NODES = [8, 20, 60, 200, 500]
CONFIGS = [("1src", 1, 1), ("4src", 4, 4)]
PER_CELL = 50
P_MISS = 0.3
COMPONENTS = ["t_veff", "t_v1", "t_v2", "t_v3", "t_b1"]


def time_one(pipe: Pipe) -> Dict[str, float]:
    """对一条管线逐组件计时（秒）。"""
    out: Dict[str, float] = {}

    # ── t_veff：V_eff 计算 ──
    verdicts = pipe.verdicts()
    t0 = time.perf_counter()
    for v in verdicts:
        tbl = pipe.tables[v]
        for t in pipe.input_space:
            tbl.eff(t)
    out["t_veff"] = time.perf_counter() - t0

    # ── 组装 Case（v_eff 固化为全部判决；逐输入版本耗时 = 单次 × |输入|） ──
    case = axioms.Case(
        nodes=tuple(sorted(pipe.nodes)),
        edges=tuple(pipe.edges),
        sinks=tuple(pipe.sinks()),
        v_eff=frozenset(verdicts),
    )

    t0 = time.perf_counter()
    axioms.v1_by_reachability(case)
    out["t_v1"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    axioms.v2_by_intersection(case)
    out["t_v2"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    axioms.v3_edge_by_menger(case)
    out["t_v3"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    judge_dominance(pipe)
    out["t_b1"] = time.perf_counter() - t0

    out["t_total"] = out["t_v1"] + out["t_v2"] + out["t_v3"]
    return out


def pct(xs: List[float], q: float) -> float:
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(len(xs) * q))]


def run(pilot: bool) -> dict:
    rng = random.Random(23)
    per_cell = 3 if pilot else PER_CELL
    # (shape, size, config) → 组件 → [秒]
    acc: Dict[tuple, Dict[str, List[float]]] = defaultdict(
        lambda: {c: [] for c in COMPONENTS}
    )
    actual_nodes: Dict[tuple, List[int]] = defaultdict(list)

    for shape in SHAPES:
        for nn in NODES:
            for cname, nsrc, nsnk in CONFIGS:
                for _ in range(per_cell):
                    pipe = synth(shape, nn, nsnk, nsrc, P_MISS, rng)
                    actual_nodes[(shape, nn, cname)].append(len(pipe.nodes))
                    r = time_one(pipe)
                    for c in COMPONENTS:
                        acc[(shape, nn, cname)][c].append(r[c])
            done = f"{shape} n={nn}"
            if not pilot:
                print(f"  … {done}", flush=True)

    summary = {"per_cell_ms": {}, "n_per_cell": per_cell, "p_miss": P_MISS}
    for key, comps in acc.items():
        shape, nn, cname = key
        cell = {}
        for c in COMPONENTS + ["t_total"]:
            xs = comps.get(c) or comps["t_v1"] and [] or []
        # 逐组件统计
        for c in COMPONENTS:
            xs = comps[c]
            cell[c] = {
                "mean": round(1000 * sum(xs) / len(xs), 3),
                "p95": round(1000 * pct(xs, 0.95), 3),
                "max": round(1000 * max(xs), 3),
            }
        tt = comps["t_v1"]  # t_total 逐条重算
        # 重新收集 t_total（time_one 里算过，这里从分量重建保证一致）
        cell["t_total"] = {
            "mean": round(cell["t_v1"]["mean"] + cell["t_v2"]["mean"] + cell["t_v3"]["mean"], 3),
            "p95": round(cell["t_v1"]["p95"] + cell["t_v2"]["p95"] + cell["t_v3"]["p95"], 3),
            "max": round(cell["t_v1"]["max"] + cell["t_v2"]["max"] + cell["t_v3"]["max"], 3),
        }
        xs_nodes = actual_nodes[key]
        cell["actual_nodes"] = {
            "mean": round(sum(xs_nodes) / len(xs_nodes), 1) if xs_nodes else None,
            "min": min(xs_nodes) if xs_nodes else None,
            "max": max(xs_nodes) if xs_nodes else None,
        }
        summary["per_cell_ms"][f"{shape}|n={nn}|{cname}"] = cell
    return summary


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pilot", action="store_true")
    ap.add_argument("--out", default=str(HERE / ".." / "06_结果" / "e3_summary.json"))
    args = ap.parse_args()

    s = run(args.pilot)
    out_path = Path(args.out)
    if args.pilot:
        out_path = out_path.with_name("e3_pilot.json")

    # 汇总打印：按规模聚合三形状
    print(f"\n{'规模':>6} {'实际':>6} {'配置':>6} | {'V_eff':>9} {'V1割':>9} {'V2坏集':>9} "
          f"{'V3边割':>9} {'合计':>9} | {'×9输入':>9} {'B1参照':>9}   (ms, mean over shapes)")
    for nn in NODES:
        for cname, _, _ in CONFIGS:
            keys = [k for k in s["per_cell_ms"] if f"n={nn}|" in k and f"|{cname}" in k]
            agg = {c: 0.0 for c in ["t_veff", "t_v1", "t_v2", "t_v3", "t_total", "t_b1"]}
            for k in keys:
                for c in agg:
                    agg[c] += s["per_cell_ms"][k][c]["mean"] / len(keys)
            act = sum(s["per_cell_ms"][k]["actual_nodes"]["mean"] for k in keys) / len(keys)
            x9 = agg["t_total"] * 9
            print(f"{nn:>6} {act:>6.0f} {cname:>6} | {agg['t_veff']:>9.2f} {agg['t_v1']:>9.2f} "
                  f"{agg['t_v2']:>9.2f} {agg['t_v3']:>9.2f} {agg['t_total']:>9.2f} | "
                  f"{x9:>9.2f} {agg['t_b1']:>9.2f}")

    ok = all(
        s["per_cell_ms"][k]["t_total"]["mean"] * 9 < 1000
        for k in s["per_cell_ms"] if "n=500" in k
    )
    print(f"\n判定（500 节点 × 9 输入 < 1 s）：{'✓ 编译期可用' if ok else '✗ 超线，需优化或改口径'}")

    out_path.write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"已写入 {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
