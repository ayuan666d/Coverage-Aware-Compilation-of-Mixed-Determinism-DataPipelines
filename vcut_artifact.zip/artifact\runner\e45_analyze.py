"""E45：两个证伪性检验。

## 检验一：随机插入解析式能否预测未见规模

若干扰表相对于真实表**随机插入**（这正是「无身份指纹」目录的性质，E40 审计
AUC 0.4972），则金标在全目录中的位置服从

    rank_N(t) = r_t + X,   X ~ Binomial(M, (r_t+1)/(n_real+1))

其中 r_t 是金标在**真实表内**的位置（0 起），M = N - n_real。
于是仅凭 951 目录上的 rank 分布就能预测任意 N 的 R@k：

    R@k(N) = mean_q mean_{t in gold_q} P(X <= k-1-r_t)

这一步是证伪性的：
  · 若预测 ≈ 实测 → 容量定律成立，「R@5 在 43.5% 污染处穿越 90」是可外推的定律，
    不是三点拟合；
  · 若预测 ≫ 实测 → 干扰表被排到了随机水平之上（目录有指纹，或检索器被干扰集
    带偏）；
  · 若预测 ≪ 实测 → 检索器把干扰表压到了随机之下，差值即「局部性收益」。

**这个差值 Δ = 实测 − 预测 是本论文真正的核心量**，不是「不变性」。
它衡量的是：给定同样的真实表排序能力，系统额外压掉了多少干扰表。

## 检验二：分数不变性 ≠ 性能不变性

同一个金标在 951 与 10k 下、**剔除干扰表之后**的真实表内位置是否变化。
dense 的 cos 与目录无关，理论上应当完全不变；β=0 的 FORGE 同理（E42 已证位级）；
BM25 的 idf 依赖语料，应当漂移。若 dense 的漂移也为 0，则「冻结参数」不是
规模稳定性的来源——变的是判别余量，不是参数。

用法：python e45_analyze.py
输出：D:\\vldb2027_e11\\e45_analyze.json + 控制台表
"""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import binom

WORK = Path(r"D:\vldb2027_e11")
N_REAL = 951
OUT = WORK / "e45_analyze.json"

# (标签, 文件, 是否嵌套字段)
FORGE = {"951": "e44_forge_rich_951-leg_perq.jsonl",
         "1500": "e41_scale_legacy_1500-leg_perq.jsonl",
         "4k": "e44_forge_rich_4k-syn-leg_perq.jsonl",
         "10k": "e44_forge_rich_10k-syn-leg_perq.jsonl"}
BASE = {"951": "e44_legacy_rich_951_perq.jsonl",
        "10k": "e44_legacy_rich_10k-syn_perq.jsonl"}
N_OF = {"951": 951, "1500": 1500, "4k": 4000, "10k": 10000}
# E41 的实测值，用于交叉校验（β=0.3，官方 dev20 / 1034 问）
E41_MEAS = {"951": (0.6062, 0.9195), "1500": (0.6044, 0.9087),
            "4k": (0.5870, 0.8437), "10k": (0.5732, 0.7791)}


def load(p):
    p = WORK / p
    if not p.exists():
        return None
    return [json.loads(line) for line in open(p, encoding="utf-8")]


def pred_rk(ranks, N, k):
    """给定 951 上的真实表内 rank 列表（每问一个 list），预测规模 N 的 R@k。

    注意 rank 列表可以是「每问的金标 rank 集合」，需按问分组求均值。
    """
    M = N - N_REAL
    if M <= 0:
        return float(np.mean([np.mean([1.0 if r < k else 0.0 for r in rs])
                              for rs in ranks]))
    out = []
    for rs in ranks:
        if not rs:
            continue
        ps = [float(binom.cdf(k - 1 - r, M, (r + 1) / (N_REAL + 1))) for r in rs]
        out.append(float(np.mean(ps)))
    return float(np.mean(out)) if out else 0.0


def main():
    res = {}

    # ---------------- 检验一：解析式外推 ----------------
    print("=" * 78)
    print("检验一  随机插入解析式：只用 951 的 rank 分布预测更大目录的 R@5")
    print("=" * 78)
    print(f"{'方法':8s} {'951实测':>8s} {'预测10k':>8s} {'实测10k':>8s} "
          f"{'Δ局部性':>9s} {'Δ/缺口':>8s}")
    res["predict"] = {}
    for name, files, key in (("FORGE", FORGE, None), ("dense", BASE, "dense"),
                             ("bm25", BASE, "bm25"), ("fuse", BASE, "fuse")):
        r951 = load(files["951"])
        if r951 is None:
            print(f"{name}: 缺 951 数据，跳过")
            continue
        if key is None:
            ranks = [r["gpos_real"] for r in r951]
            meas951 = float(np.mean([r["R5"] for r in r951]))
        else:
            ranks = [r[key]["gpos_real"] for r in r951]
            meas951 = float(np.mean([r[key]["R5"] for r in r951]))
        # 自检：N=951 时预测必须等于实测
        self_chk = pred_rk(ranks, 951, 5)
        row = {"measured_951": meas951, "selfcheck_951": self_chk, "pred": {}}
        for tag in ("1500", "4k", "10k"):
            p = pred_rk(ranks, N_OF[tag], 5)
            row["pred"][tag] = p
        r10 = load(files.get("10k", ""))
        meas10 = None
        if r10 is not None:
            meas10 = (float(np.mean([r[key]["R5"] for r in r10])) if key
                      else float(np.mean([r["R5"] for r in r10])))
        row["measured_10k"] = meas10
        if meas10 is not None:
            row["delta_10k"] = meas10 - row["pred"]["10k"]
            row["gap_10k"] = 0.90 - row["pred"]["10k"]
            print(f"{name:8s} {meas951*100:8.2f} {row['pred']['10k']*100:8.2f} "
                  f"{meas10*100:8.2f} {row['delta_10k']*100:+9.2f} "
                  f"{(row['delta_10k']/row['gap_10k'] if row['gap_10k'] > 1e-9 else float('nan'))*100:7.1f}%")
        else:
            print(f"{name:8s} {meas951*100:8.2f} {row['pred']['10k']*100:8.2f} "
                  f"{'—':>8s}")
        res["predict"][name] = row

    # ---------------- 检验二：真实表内排序漂移 ----------------
    print()
    print("=" * 78)
    print("检验二  分数不变性检验：剔除干扰表后，真实表内位置是否漂移（951 → 10k）")
    print("=" * 78)
    print(f"{'方法':8s} {'位置完全一致':>12s} {'平均|Δrank|':>12s} {'Spearman':>10s}")
    res["drift"] = {}
    for name, files, key in (("FORGE", FORGE, None), ("dense", BASE, "dense"),
                             ("bm25", BASE, "bm25"), ("fuse", BASE, "fuse")):
        a, b = load(files.get("951", "")), load(files.get("10k", ""))
        if a is None or b is None:
            continue
        ga = {r["qid"]: (r["gpos_real"] if key is None else r[key]["gpos_real"])
              for r in a}
        gb = {r["qid"]: (r["gpos_real"] if key is None else r[key]["gpos_real"])
              for r in b}
        same = tot = 0
        dsum = 0.0
        xs, ys = [], []
        for q in ga:
            if q not in gb:
                continue
            x, y = ga[q], gb[q]
            for i in range(min(len(x), len(y))):
                same += int(x[i] == y[i])
                tot += 1
                dsum += abs(x[i] - y[i])
                xs.append(x[i])
                ys.append(y[i])
        if not tot:
            continue
        sp = float(np.corrcoef(np.argsort(np.argsort(xs)),
                               np.argsort(np.argsort(ys)))[0, 1])
        res["drift"][name] = dict(exact=same / tot, mad=dsum / tot, spearman=sp,
                                  n=tot)
        print(f"{name:8s} {same/tot*100:11.1f}% {dsum/tot:12.3f} {sp:10.4f}")

    # ---------------- 槽位占用 vs 随机期望 ----------------
    print()
    print("=" * 78)
    print("附表  干扰表占 top5 槽位数：实测 vs 随机插入期望 5M/N")
    print("=" * 78)
    print(f"{'方法':8s} {'951':>7s} {'10k实测':>9s} {'10k随机':>8s} {'压掉':>7s}")
    res["slots"] = {}
    for name, files, key in (("FORGE", FORGE, None), ("dense", BASE, "dense"),
                             ("bm25", BASE, "bm25"), ("fuse", BASE, "fuse")):
        b10 = load(files.get("10k", ""))
        if b10 is None:
            continue
        if key is None:
            s10 = float(np.mean([r["synth5"] for r in b10]))
            s951 = float(np.mean([r["synth5"] for r in load(files["951"])]))
        else:
            s10 = float(np.mean([5 - r[key]["top20_real"][:5].count(1) for r in b10]))
            s951 = float(np.mean([5 - r[key]["top20_real"][:5].count(1)
                                  for r in load(files["951"])]))
        exp = 5 * (10000 - N_REAL) / 10000
        res["slots"][name] = dict(s951=s951, s10k=s10, expect=exp, cut=exp - s10)
        print(f"{name:8s} {s951:7.2f} {s10:9.2f} {exp:8.2f} {exp-s10:7.2f}")

    json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"\n[saved] {OUT}")


if __name__ == "__main__":
    main()
