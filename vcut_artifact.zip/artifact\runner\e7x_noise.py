"""E7x: OCR noise robustness of the receipt checker.

We corrupt the OCR token stream (digit substitutions, deletions, lookalike
letters) at 5/10/20% and rerun the same prompt and checker.  The question is
whether the checker loses soundness or only coverage: a noisy document should
move to review, not become a false pass.
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import os
import random
import re
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e7_receipts import SYSTEM, gold_of, judge, parse_model, tokens_text  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
DATA = REPO / "04_数据" / "external" / "cord" / "train.parquet"
OUT = REPO / "06_结果" / "e7x_noise.json"
HOST = "https://ws-8fbno0c0h3isjc0g.cn-beijing.maas.aliyuncs.com/compatible-mode/v1"
MODEL = "qwen-plus"
LOOK = {"O": "0", "o": "0", "l": "1", "I": "1", "S": "5", "B": "8", "Z": "2", "G": "6"}


def key() -> str:
    p = glob.glob(os.path.expanduser("~/Downloads/*apiKey*.csv"))[0]
    return dict(csv.reader(open(p, encoding="utf-8-sig")))["apiKey"]


def corrupt(text: str, p: float, seed: int) -> str:
    rnd = random.Random(seed)
    toks = text.split(" | ")
    out = []
    for t in toks:
        chars = list(t)
        for i, ch in enumerate(chars):
            if rnd.random() < p:
                if ch.isdigit():
                    chars[i] = str(rnd.randrange(10))
                elif ch in LOOK:
                    chars[i] = LOOK[ch]
                elif ch.isalpha():
                    chars[i] = rnd.choice("abcdefghijklmnopqrstuvwxyz")
        if rnd.random() < p / 2 and len(chars) > 3:
            del chars[rnd.randrange(len(chars))]
        out.append("".join(chars))
    return " | ".join(out)


def call(k: str, text: str, timeout: int = 90) -> dict:
    body = json.dumps({"model": MODEL,
                       "messages": [{"role": "system", "content": SYSTEM},
                                    {"role": "user", "content": "OCR tokens:\n" + text
                                     + "\n\nReturn the JSON object now."}],
                       "temperature": 0, "max_tokens": 1200,
                       "response_format": {"type": "json_object"}}).encode()
    req = urllib.request.Request(HOST + "/chat/completions", data=body,
                                 headers={"Authorization": f"Bearer {k}",
                                          "Content-Type": "application/json"},
                                 method="POST")
    last = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                d = json.loads(r.read())
            return {"raw": d["choices"][0]["message"]["content"] or "",
                    "usage": d.get("usage") or {}}
        except Exception as e:  # noqa: BLE001
            last = f"{type(e).__name__}: {e}"
            time.sleep(1.5 * (attempt + 1))
    return {"raw": "", "error": last, "usage": {}}


def metrics(rows, p):
    n = len(rows)
    acc = [r for r in rows if r["verdict"] in ("accept", "fill")]
    fp = sum(1 for r in acc if r["total_correct"] is False)
    known = [r for r in rows if r["model_total_correct"] is not None]
    return {"noise": p, "n": n, "automation": round(len(acc) / n, 4),
            "false_pass": fp, "false_pass_rate": round(fp / n, 4),
            "precision": round((len(acc) - fp) / len(acc), 4) if acc else None,
            "model_accuracy": round(sum(r["model_total_correct"] for r in known) / max(1, len(known)), 4),
            "review": sum(1 for r in rows if r["verdict"] == "review"),
            "reject": sum(1 for r in rows if r["verdict"] == "reject")}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--workers", type=int, default=8)
    args = ap.parse_args()
    k = key()
    df = pd.read_parquet(DATA).head(args.n)
    levels = [0.0, 0.05, 0.10, 0.20]
    jobs = []
    for i, (_, r) in enumerate(df.iterrows()):
        clean = tokens_text(r["ocr_text"])
        gold = gold_of(r["ocr_kie"])
        for p in levels:
            text = clean if p == 0 else corrupt(clean, p, seed=i * 100 + int(p * 100))
            jobs.append((i, p, text, gold))
    print(f"docs={len(df)} calls={len(jobs)}", flush=True)
    results = {}
    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(call, k, t): j for j, t in enumerate([x[2] for x in jobs])}
        for n, fut in enumerate(as_completed(futs), 1):
            j = futs[fut]
            results[j] = fut.result()
            if n % 100 == 0:
                print(f"{n}/{len(jobs)} {time.perf_counter()-t0:.0f}s", flush=True)
    by_p = {p: [] for p in levels}
    for j, (i, p, text, gold) in enumerate(jobs):
        r = results[j]
        m = parse_model(r.get("raw", ""))
        v = judge(m, gold, text)
        by_p[p].append({"i": i, "text": text[:1500], "model": m,
                        "gold": gold, "error": r.get("error"), **v})
    summary = [metrics(by_p[p], p) for p in levels]
    json.dump({"summary": summary,
               "rows": {str(p): by_p[p] for p in levels}},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
