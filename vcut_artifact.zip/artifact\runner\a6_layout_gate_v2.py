# -*- coding: utf-8 -*-
"""A6: gate coverage with the v2 layout witness (readings only, no API)."""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

RUN = Path(r"E:\vldb2027_pipeline_safety\05_代码\runner")
sys.path.insert(0, str(RUN))


def load(name, fname):
    spec = importlib.util.spec_from_file_location(name, str(RUN / fname))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


e7 = load("e7", "e7_receipts.py")
e7k = load("e7k", "e7k_independent_witness.py")

A3 = Path(r"E:\vldb2027_pipeline_safety\06_结果\a3_injection.json")
LAY = Path(r"E:\vldb2027_pipeline_safety\06_结果\a5_layout_v2.json")
OUT = Path(r"E:\vldb2027_pipeline_safety\06_结果\a6_layout_gate_v2.json")


def scaled(m, k):
    d = dict(m)
    d["items"] = list(m.get("items") or [])
    for key in ("total", "subtotal", "tax", "service", "discount"):
        d[key] = None if m.get(key) is None else int(m[key] * k)
    d["items"] = [None if x is None else int(x * k) for x in d["items"]]
    return d


def evaluate(rows, scale, layout_key):
    out = {}
    for policy in ("C", "B", "C_and_B", "C_or_B"):
        acc = []
        for r in rows:
            m = scaled(r["model"], scale)
            t = m.get("total")
            j = e7.judge(m, {"total": r["gold"], "subtotal": None}, r["text"])
            c = j["verdict"] in ("accept", "fill")
            b = (t is not None and r["layout"] is not None and e7k.match(t, r["layout"]) is True)
            ok = (c if policy == "C" else b if policy == "B"
                  else (c and b) if policy == "C_and_B" else (c or b))
            if ok:
                acc.append(t is not None and e7k.match(t, r["gold"]) is True)
        fp = sum(1 for good in acc if not good)
        out[policy] = {"accept": len(acc), "accept_rate": round(len(acc) / len(rows), 4),
                       "false_pass": fp, "false_pass_rate": round(fp / len(rows), 4),
                       "precision": round((len(acc) - fp) / len(acc), 4) if acc else None}
    return out


def main():
    a3 = json.loads(A3.read_text(encoding="utf-8"))
    lay = {r["file"]: r for r in json.loads(LAY.read_text(encoding="utf-8"))["rows"]}
    rows = []
    for r in a3["rows"]:
        if r["cond"] != "clean" or r["model"].get("total") is None or r["file"] not in lay:
            continue
        L = lay[r["file"]]
        rows.append({"file": r["file"], "model": r["model"], "gold": r["gold_total"],
                     "text": r["text"], "layout": L["total"]})
    old = json.loads((Path(r"E:\vldb2027_pipeline_safety\06_结果\e7l_layout_witness.json")
                      ).read_text(encoding="utf-8"))
    oldmap = {x["file"]: x["ocr"]["total"] for x in old["rows"]}
    rows_old = [dict(r, layout=oldmap.get(r["file"])) for r in rows]
    out = {"n": len(rows),
           "v1_clean": evaluate(rows_old, 1, "v1"),
           "v1_x10": evaluate(rows_old, 10, "v1"),
           "v2_clean": evaluate(rows, 1, "v2"),
           "v2_x10": evaluate(rows, 10, "v2")}
    for k, v in out.items():
        if isinstance(v, dict):
            print(k, json.dumps(v, ensure_ascii=False))
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print("wrote", OUT)


if __name__ == "__main__":
    main()
