# -*- coding: utf-8 -*-
"""v0.3 语义与边割的最小单测（无 pytest 依赖：python -m unittest）。"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from checker.decision_table import DecisionTable  # noqa: E402
from checker.graphutil import (  # noqa: E402
    INF,
    is_edge_cut,
    max_edge_disjoint_paths_multi,
    min_edge_cut_multi,
)
from generator.synth import CONSERVATIVE_VERDICTS as CONSERVATIVE, Rule, Table, _input_space  # noqa: E402


class TestFallbackSemantics(unittest.TestCase):
    def setUp(self):
        self.space = _input_space({"f": ["a", "b"]})
        self.table = Table(
            rules=[Rule("r0", frozenset({("f", "a")}), "reject")],
            fallback="pass",
        )

    def test_pass_fallback_is_not_judged(self):
        self.assertTrue(self.table.judged({"f": "a"}))
        self.assertFalse(self.table.judged({"f": "b"}))
        self.assertFalse(self.table.eff_all(self.space))

    def test_reject_fallback_is_judged(self):
        t = Table(rules=list(self.table.rules), fallback="reject")
        self.assertTrue(t.judged({"f": "b"}))
        self.assertTrue(t.eff_all(self.space))

    def test_full_coverage_with_pass_fallback_is_judged(self):
        t = Table(
            rules=[
                Rule("r0", frozenset({("f", "a")}), "reject"),
                Rule("r1", frozenset({("f", "b")}), "reject"),
            ],
            fallback="pass",
        )
        self.assertTrue(t.eff_all(self.space))


class TestEdgeRepair(unittest.TestCase):
    def test_direct_source_to_sink_is_repairable(self):
        # v0.2 的内部顶点模型会返回 INF；v0.3 的边插入模型应为 1
        nodes = ("s", "t")
        succ = {"s": ["t"], "t": []}
        self.assertEqual(max_edge_disjoint_paths_multi(["s"], "t", nodes, succ), 1)
        cut = min_edge_cut_multi(["s"], "t", nodes, succ)
        self.assertEqual(cut, [("s", "t")])
        self.assertTrue(is_edge_cut(["s"], "t", succ, cut))

    def test_two_parallel_paths(self):
        nodes = ("s", "a", "b", "t")
        succ = {"s": ["a", "b"], "a": ["t"], "b": ["t"], "t": []}
        self.assertEqual(max_edge_disjoint_paths_multi(["s"], "t", nodes, succ), 2)

    def test_shared_choke_has_one_cut(self):
        nodes = ("s1", "s2", "x", "t")
        succ = {"s1": ["x"], "s2": ["x"], "x": ["t"], "t": []}
        self.assertEqual(max_edge_disjoint_paths_multi(["s1", "s2"], "t", nodes, succ), 1)
        cut = min_edge_cut_multi(["s1", "s2"], "t", nodes, succ)
        self.assertEqual(cut, [("x", "t")])

    def test_edge_disjoint_but_vertex_shared(self):
        # s-a-v-c-t 与 s-b-v-d-t：边不相交 = 2；若只按顶点割会得到 1
        nodes = ("s", "a", "b", "v", "c", "d", "t")
        succ = {"s": ["a", "b"], "a": ["v"], "b": ["v"],
                "v": ["c", "d"], "c": ["t"], "d": ["t"], "t": []}
        self.assertEqual(max_edge_disjoint_paths_multi(["s"], "t", nodes, succ), 2)


class TestPathComposition(unittest.TestCase):
    """v0.3：H 累计、V 取限制性 meet；下游兜底不能抹掉上游证据。"""

    RANK = {"⊥": -1, "pass": 0, "review": 1, "reject": 2}

    def _step(self, V, H, table, t):
        v, rid = table.decide(t)
        V2 = v if self.RANK[v] > self.RANK[V] else V
        H2 = H | ({rid} if rid else set())
        return V2, H2

    def test_upstream_hit_survives_downstream_pass_fallback(self):
        up = Table([Rule("r0", frozenset({("f", "a")}), "reject")], fallback="reject")
        down = Table([], fallback="pass")
        V, H = "⊥", frozenset()
        V, H = self._step(V, H, up, {"f": "a"})
        V, H = self._step(V, H, down, {"f": "b"})
        self.assertEqual(V, "reject")
        self.assertTrue(H)
        self.assertTrue(H != frozenset() or V in CONSERVATIVE)

    def test_all_fallbacks_pass_is_unjudged(self):
        down = Table([], fallback="pass")
        V, H = "⊥", frozenset()
        V, H = self._step(V, H, down, {"f": "b"})
        self.assertEqual(V, "pass")
        self.assertFalse(H)
        self.assertFalse(H != frozenset() or V in CONSERVATIVE)


class TestCumulativeJudgment(unittest.TestCase):
    """v0.3.2：认证默认 pass 判过之后，下游未认证 pass 不能撤销 J。"""

    def test_certified_pass_survives_unverified_downstream_pass(self):
        up = DecisionTable(pre=[], post=[], fallback="pass", certified_default=True)
        down = DecisionTable(pre=[], post=[], fallback="pass", certified_default=False)
        d1 = up.post_decision({})
        d2 = down.post_decision({})
        self.assertTrue(d1.judged)       # 上游靠认证默认判过
        self.assertFalse(d2.judged)      # 下游本次未判
        J = False
        for d in (d1, d2):
            J = J or d.judged
        self.assertTrue(J)               # 累计后仍判过：J 单调


class TestPartialEvaluation(unittest.TestCase):
    """部分求值：已知字段上的违规可以先 reject；pass 仍要求全覆盖。"""

    def setUp(self):
        self.table = DecisionTable(
            pre=[],
            post=[{"id": "Q2", "when": {"field": "lel", "op": "gt", "value": 25}},
                  {"id": "Q3", "when": {"field": "o2", "op": "lt", "value": 19.5}}],
            fallback="pass", certified_default=True)

    def test_partial_reject_with_other_fields_missing(self):
        d = self.table.partial_evaluate({"lel": 30})
        self.assertEqual(d.verdict, "reject")
        self.assertEqual(d.rule_id, "Q2")

    def test_partial_cannot_pass_with_missing_field(self):
        d = self.table.partial_evaluate({"lel": 0})
        self.assertEqual(d.verdict, "review")
        self.assertIn("o2", d.missing)

    def test_partial_pass_requires_full_coverage(self):
        d = self.table.partial_evaluate({"lel": 0, "o2": 21.0})
        self.assertEqual(d.verdict, "pass")
        self.assertTrue(d.judged)

    def test_partial_does_not_fire_rule_on_missing_field(self):
        # o2 缺失时不能因为“没命中 Q3”就放行
        d = self.table.partial_evaluate({"lel": 0})
        self.assertNotEqual(d.verdict, "pass")


if __name__ == "__main__":
    unittest.main()
