"""E31：闭式（监督）臂的规模压力测试 —— 受信核心编译 + 规模期目录审计。

主张（范式层）：
- 参数只在**受信核心**（已验证的真实表）上编译：词表统计、谱基、Fisher 权重都锚定在
  核心上，新进目录的未验证表只做 transform / 打分，不参与拟合。规模增长不改变已编译的
  排序能力（core-trained 在 951 与 10k 上真实表内 R@1 完全一致，见输出 realonly）。
- 规模在**查询期**被审计，而不是被塞进参数：每张表都带"目录自洽度"审计量
  （库内词法一致性 db_coh、证据密度 evidence_density），未验证表只罚不奖。

协议：
- 训练：693 问（14 库）金标表，只拟合线性/二次权重；测试：341 问冷启动（6 未见库）。
- 特征只用目录显式量 + 数值 zone map 覆盖（无预训练、无外部标注）。
"""
from __future__ import annotations

import gc
import json
import math
import re
import sys
import time
from pathlib import Path

import numpy as np
import scipy.sparse as sp

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
import e28_scale as s28  # noqa: E402

WORK = Path(r"D:\vldb2027_e11")
CASES = Path(r"E:\vldb2027_pipeline_safety\06_结果\e11_cases.json")
OUT = WORK / "e31_scale_supervised.json"
CAMEL = re.compile(r"[A-Z]+(?![a-z])|[A-Z][a-z0-9]*|[a-z0-9]+")
NUM = re.compile(r"\d[\d,]*\.?\d*")
STOP = set("""a an the of to in on for and or is are was were be been by with as at from
that this it its their there what which who whom whose how when where why does do did
can could should would will may might must not no all any each every per into than then
them they we you i he she his her our your me my""".split())


def split_ident(s):
    out = []
    for part in re.split(r"[^A-Za-z0-9]+", s):
        if part:
            out += [w.lower() for w in CAMEL.findall(part)]
    return out


def norm(w):
    if len(w) > 4 and w.endswith("ies"):
        return w[:-3] + "y"
    if len(w) > 4 and w.endswith(("ses", "xes", "zes", "ches", "shes")):
        return w[:-2]
    if len(w) > 3 and w.endswith("s") and not w.endswith(("ss", "us", "is")):
        return w[:-1]
    return w


def qtoks(s):
    return [norm(t) for t in split_ident(s) if t not in STOP and len(t) > 1]


def qnums(s):
    out = []
    for m in NUM.findall(s):
        try:
            v = float(m.replace(",", ""))
        except ValueError:
            continue
        if abs(v) >= 100:
            out.append(v)
    return out


def spectral(ref_w, ref_c, all_w, all_c):
    """只把谱基拟合在受信核心上，其余表投影进同一基。"""
    from sklearn.decomposition import TruncatedSVD
    from sklearn.feature_extraction.text import TfidfVectorizer

    tw = TfidfVectorizer(analyzer=lambda x: x, lowercase=False, max_features=20000,
                         min_df=2)
    Xw = tw.fit_transform(ref_w)
    nw = min(128, max(2, min(Xw.shape) - 1))
    sw = TruncatedSVD(n_components=nw, random_state=0)
    sw.fit(Xw)
    Dw = sw.transform(tw.transform(all_w)).astype(np.float32)
    Dw /= np.maximum(np.linalg.norm(Dw, axis=1, keepdims=True), 1e-9)

    tc = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=3,
                         max_features=20000, lowercase=True)
    Xc = tc.fit_transform([" ".join(d) for d in ref_c])
    nc = min(64, max(2, min(Xc.shape) - 1))
    sc = TruncatedSVD(n_components=nc, random_state=0)
    sc.fit(Xc)
    Dc = sc.transform(tc.transform([" ".join(d) for d in all_c])).astype(np.float32)
    Dc /= np.maximum(np.linalg.norm(Dc, axis=1, keepdims=True), 1e-9)
    return dict(tw=tw, sw=sw, Dw=Dw, tc=tc, sc=sc, Dc=Dc)


def spec_feats(qt, sp):
    qw = sp["tw"].transform([qt])
    qw = sp["sw"].transform(qw).astype(np.float32)
    qw /= max(float(np.linalg.norm(qw)), 1e-9)
    qc = sp["tc"].transform([" ".join(qt)])
    qc = sp["sc"].transform(qc).astype(np.float32)
    qc /= max(float(np.linalg.norm(qc)), 1e-9)
    return sp["Dw"] @ qw.ravel(), sp["Dc"] @ qc.ravel()


def zones():
    z = json.load(open(WORK / "z_num_ranges.json", encoding="utf-8"))
    out = {}
    for k, v in z.items():
        out[k.lower()] = [(mn, mx) for (mn, mx, nd, nrow) in v.values()
                          if not (nrow and nd / max(nrow, 1) > 0.98)]
    return out


def build_cache(tabs, fks, ref_n=None):
    """稀疏通道矩阵 + idf/avgdl + 目录审计量（全部零标签）。"""
    name_t, col_t, val_t, db_t = [], [], [], []
    docs_w, docs_c = [], []
    dens, nz = [], []
    zeb = zones()
    fids = [f"{t['db']}::{t['name']}".lower() for t in tabs]
    vocab = {}
    for k, t in enumerate(tabs):
        nm = qtoks(t["name"])
        cl, vl, nv = [], [], 0
        for c in t["columns"]:
            cl += qtoks(c["name"])
            vals = c.get("values") or []
            nv += 1
            for v in vals[:12]:
                vl += qtoks(str(v))
        dens.append(np.mean([len(c.get("values") or []) for c in t["columns"]])
                    if t["columns"] else 0.0)
        dbt = qtoks(re.sub(r"\d+$", "", t["db"]))
        name_t.append(set(nm))
        col_t.append(set(cl))
        val_t.append(set(vl))
        db_t.append(set(dbt))
        docs_w.append(nm * 2 + cl + vl)
        docs_c.append(nm * 2 + cl)
        nz.append(zeb.get(fids[k], []))
        for w in set(nm) | set(cl) | set(vl):
            vocab.setdefault(w, len(vocab))
    N, V = len(tabs), len(vocab)
    db_vocab = {}
    for s in db_t:
        for w in s:
            db_vocab.setdefault(w, len(db_vocab))

    def mat(sets, vv, width):
        r, c, d = [], [], []
        for i, s in enumerate(sets):
            for w in s:
                r.append(i)
                c.append(vv[w])
                d.append(1.0)
        return sp.csr_matrix((np.array(d, np.float32), (r, c)), shape=(N, width))

    all_sets = [name_t[i] | col_t[i] | val_t[i] for i in range(N)]
    A = mat(all_sets, vocab, V)
    Nm = mat(name_t, vocab, V)
    Cm = mat(col_t, vocab, V)
    stem_sets = [{w[:4] for w in s if len(w) >= 4} for s in all_sets]
    stem_vocab = {}
    for s in stem_sets:
        for w in s:
            stem_vocab.setdefault(w, len(stem_vocab))
    Sm = mat(stem_sets, stem_vocab, len(stem_vocab))
    refN = len(tabs) if ref_n is None else min(ref_n, N)
    df = np.asarray(A[:refN].sum(0)).ravel().astype(np.float64)
    idf = np.log(1 + (refN - df + 0.5) / (df + 0.5)).astype(np.float32)
    dl = np.asarray(A.sum(1)).ravel().astype(np.float32)
    dbm = mat(db_t, db_vocab, len(db_vocab))
    db_len = np.maximum(np.asarray(dbm.sum(1)).ravel(), 1.0)
    nc = np.asarray(Nm.multiply(Cm).sum(1)).ravel().astype(np.float32)
    name_len = np.maximum(np.asarray(Nm.sum(1)).ravel(), 1.0)
    col_len = np.maximum(np.asarray(Cm.sum(1)).ravel(), 1.0)
    col_idf = np.asarray(Cm @ idf).ravel().astype(np.float32) / col_len

    # 目录审计量①：库内词法自洽度（与同库其它表的平均 Jaccard，留一）
    bidx = {}
    for i, t in enumerate(tabs):
        bidx.setdefault(t["db"], []).append(i)
    db_coh = np.zeros(N, np.float32)
    for _, idx in bidx.items():
        if len(idx) < 2:
            continue
        for i in idx:
            a = all_sets[i]
            s, c = 0.0, 0
            for j in idx:
                if i == j:
                    continue
                b = all_sets[j]
                u = len(a | b)
                if u:
                    s += len(a & b) / u
                c += 1
            db_coh[i] = s / max(c, 1)

    # 目录审计量②：证据密度（每列可采样值的平均条数，画像完备度）
    density = np.array(dens, np.float32)

    # 目录审计量③：血缘连通度（FID 入边+出边数），同库内归一化（无 FK 声明的库不区分）
    fk_deg = np.zeros(N, np.float32)
    fidx = {f: i for i, f in enumerate(fids)}
    for a, _ca, b, _cb in fks:
        ia, ib = fidx.get(str(a).lower()), fidx.get(str(b).lower())
        if ia is not None:
            fk_deg[ia] += 1
        if ib is not None:
            fk_deg[ib] += 1
    fk_in_db = np.zeros(N, np.float32)
    for _, idx in bidx.items():
        v = fk_deg[idx]
        if v.max() > 0:
            fk_in_db[idx] = v / v.max()

    return dict(vocab=vocab, all=A, name=Nm, col=Cm,
                val=mat(val_t, vocab, V), db=dbm, db_vocab=db_vocab,
                db_len=db_len, idf=idf, dl=dl, N=N, V=V, refN=refN,
                name_len=name_len, namecol=(nc / name_len).astype(np.float32),
                col_idf_mean=col_idf, zone=nz,
                db_coh=db_coh, density=density, fk_in_db=fk_in_db,
                spec=spectral(docs_w[:refN], docs_c[:refN], docs_w, docs_c),
                stem=Sm, stem_vocab=stem_vocab)


def zs1(v):
    return (v - v.mean()) / (v.std() + 1e-9)


def gov_prior(C):
    """目录审计先验：只罚不奖（未验证表需额外证据才能进 top-k）。"""
    raw = (zs1(C["db_coh"].astype(np.float64), ) + zs1(C["density"].astype(np.float64))
           + 0.5 * zs1(C["fk_in_db"].astype(np.float64)))
    z = zs1(raw)
    return np.minimum(0.0, z).astype(np.float64)


def feats(qt, nums, C, tokmap, idf_graph):
    """单问句的 (N, 19) 特征矩阵。"""
    N, V = C["N"], C["V"]
    qb = np.zeros(V, np.float32)
    for w in set(qt):
        j = C["vocab"].get(w)
        if j is not None:
            qb[j] = 1.0
    f0 = np.asarray(C["all"] @ qb).ravel()
    f1 = np.asarray(C["all"] @ np.asarray(qb * C["idf"]).ravel()).ravel()
    f2 = np.asarray(C["name"] @ qb).ravel()
    f3 = np.asarray(C["col"] @ qb).ravel()
    f4 = np.asarray(C["val"] @ qb).ravel()
    f9 = np.log1p(f2) * np.log1p(f3) * np.log1p(f4)
    dbq = np.zeros(len(C["db_vocab"]), np.float32)
    for w in set(qt):
        j = C["db_vocab"].get(w)
        if j is not None:
            dbq[j] = 1.0
    f11 = (C["db"] @ dbq) / C["db_len"]
    k1, b = 1.2, 0.75
    qi = [C["vocab"][w] for w in set(qt) if w in C["vocab"]]
    if qi:
        dfq = np.asarray(C["all"][:C["refN"]][:, qi].sum(0), dtype=np.float64).ravel()
        bm_idf = np.log(1 + (C["refN"] - dfq + 0.5) / (dfq + 0.5))
        den = 1.0 + k1 * (1 - b + b * C["dl"] / (C["dl"][:C["refN"]].mean() + 1e-9))
        bm = np.asarray(C["all"][:, qi] @ (bm_idf * (k1 + 1))).ravel() / den
    else:
        bm = np.zeros(N, np.float32)
    ws = [w for w in set(qt) if w in tokmap]
    if ws:
        M = np.stack([tokmap[w] for w in ws])
        iw = np.array([idf_graph[w] for w in ws])[:, None]
        graph = np.exp((iw * np.log(M + 1e-9)).sum(0) / iw.sum())
    else:
        graph = np.zeros(N, np.float32)
    sw, sc = spec_feats(qt, C["spec"])
    stq = np.zeros(len(C["stem_vocab"]), np.float32)
    for w in set(qt):
        if len(w) >= 4:
            j = C["stem_vocab"].get(w[:4])
            if j is not None:
                stq[j] = 1.0
    fst = np.asarray(C["stem"] @ stq).ravel()
    # 数值 zone map 覆盖（查询期现算的 profile 证据）
    fnum = np.zeros(N, np.float32)
    fall = np.zeros(N, np.float32)
    if nums:
        for i, zs in enumerate(C["zone"]):
            if not zs:
                continue
            cov = sum(1 for v in nums if any(mn <= v <= mx for (mn, mx) in zs))
            fnum[i] = cov / len(nums)
            fall[i] = 1.0 if cov == len(nums) else 0.0
    return np.stack([f0, f1, f2, f3, f4, f9, f11, bm, graph,
                     np.log1p(C["dl"]),
                     f0 / max(len(set(qt)), 1),
                     f2 / C["name_len"],
                     C["namecol"], C["col_idf_mean"],
                     sw, sc, fst, fnum, fall], axis=1)


def quad(X):
    k = X.shape[1]
    idx = [(i, j) for i in range(k) for j in range(i, k)]
    return np.concatenate([X] + [X[:, i:i + 1] * X[:, j:j + 1] for i, j in idx], axis=1)


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(WORK / "schema_cache.json", encoding="utf-8"))
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    train = [c for c in cases if c["split"] == "train"]
    test = [c for c in cases if c["split"] == "test"]
    test_dbs = {c["db_id"] for c in test}
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += s28.tables_of(cache, db, prefix=True)
        fks += s28.fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    bird = []
    for db, s in cache["bird"].items():
        bird += [dict(t, db=db) for t in s["tables"]]
    donors = [t for t in tabs if t["db"] not in test_dbs] + bird

    plans = [(876, "spider"), (951, "951"), (4000, "4k-syn"), (10000, "10k-syn")]
    targets = [int(x) for x in sys.argv[1].split(",")] if len(sys.argv) > 1 else [876, 4000, 10000]
    plans = [p for p in plans if p[0] in targets]
    res = json.load(open(OUT, encoding="utf-8")) if OUT.exists() else {}

    for n_target, tag in plans:
        base = tabs + bird if n_target > len(tabs) else tabs
        extra = s28.synth_tables(donors, n_target - len(base)) if n_target > len(base) else []
        all_tabs = base + extra
        cat = g.Catalog(all_tabs, fks, coquery=None, prefix_db=True)
        C = build_cache(all_tabs, fks, ref_n=len(base))
        qsets = {c["qid"]: set(g.toks(c["question"])) for c in cases}
        toks = sorted({w for qs in qsets.values() for w in qs if ("token", w) in cat.idx})
        tokmap = {}
        for w in toks:
            x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
            s = cat.table_scores(x)
            mx = float(s.max())
            tokmap[w] = s / mx if mx > 0 else s
        N = C["N"]
        idf_graph = {w: float(C["idf"][C["vocab"][w]]) if w in C["vocab"] else 1.0
                     for w in tokmap}

        t0 = time.perf_counter()
        ntr, nte = len(train), len(test)
        core = C["refN"]
        G = gov_prior(C)

        def get(c):
            return feats(qtoks(c["question"]), qnums(c["question"]), C, tokmap, idf_graph)

        k = 19
        s1 = np.zeros(k, np.float64)
        s2 = np.zeros((k, k), np.float64)
        nr = 0
        for c in train:
            X = get(c)[:core]
            s1 += X.sum(0)
            s2 += X.T @ X
            nr += len(X)
        mu = s1 / nr
        sd = np.sqrt(np.maximum(np.diag(s2 / nr) - mu * mu, 1e-6))
        dmap = {f"{t['db']}::{t['name']}".lower(): i for i, t in enumerate(all_tabs[:core])}
        kq = quad(np.zeros((1, k), np.float32)).shape[1]
        nt = 0
        S1 = np.zeros(kq, np.float64)
        S2 = np.zeros((kq, kq), np.float64)
        pos_sum = np.zeros(kq, np.float64)
        pos_n = 0.0
        neg_sum = np.zeros(kq, np.float64)
        neg_n = 0.0
        for c in train:
            Xq = quad(((get(c)[:core] - mu) / sd).astype(np.float32))
            S1 += Xq.sum(0)
            S2 += Xq.T @ Xq
            nt += len(Xq)
            y = np.zeros(len(Xq), np.float32)
            for gt in c["gold"]:
                j = dmap.get(f"{c['db_id']}::{gt}".lower())
                if j is not None:
                    y[j] = 1.0
            if y.sum():
                pos_sum += Xq[y > 0].sum(0)
                pos_n += y.sum()
            neg_sum += Xq[y == 0].sum(0)
            neg_n += (y == 0).sum()
        m = S1 / nt
        Cov = S2 / nt - np.outer(m, m)
        ours = pos_sum / max(pos_n, 1) - neg_sum / max(neg_n, 1)
        w = np.linalg.solve(Cov + 0.1 * np.eye(kq), ours)
        del S1, S2
        gc.collect()

        dbmap = {d: i for i, d in enumerate(sorted({t["db"] for t in all_tabs}))}
        DB_OF = np.array([dbmap[t["db"]] for t in all_tabs])
        nDB = len(dbmap)

        def posterior(S):
            z = S - S.max()
            mass = np.bincount(DB_OF, weights=np.exp(z), minlength=nDB)
            lg = np.log(mass + 1e-12) + S.max()
            return (lg - lg.mean())[DB_OF]

        def score(c):
            """逐问 z 标准化（保序），只为让 β/λ 跨目录可比。"""
            S = quad(((get(c) - mu) / sd).astype(np.float32)) @ w
            return (S - S.mean()) / (S.std() + 1e-9)

        def rankev(S, c):
            idx = np.argsort(-S)
            top = [all_tabs[i] for i in idx[:5]]
            ids = [f"{t['db']}::{t['name']}".lower() for t in top]
            gold = {f"{c['db_id']}::{x}".lower() for x in c["gold"]}
            return (len(set(ids[:1]) & gold) / len(gold),
                    len(set(ids) & gold) / len(gold))

        # 在训练问句上选 (beta, lambda)：训练问句的金标表都在受信核心内，
        # 但同一目录里已经混入了来自非测试库的干扰表，所以这是"同分布加噪"的验证。
        trS = [score(c) for c in train]
        best = (0.0, 0.0, -1.0, 0.0)
        for beta in (0.0, 0.1, 0.2, 0.3, 0.5, 0.8, 1.2):
            for lam in (0.0, 0.5, 1.0, 2.0, 4.0, 8.0):
                rows = [rankev(trS[i] + beta * posterior(trS[i]) + lam * G, c)
                        for i, c in enumerate(train)]
                r1 = float(np.mean([r[0] for r in rows]))
                r5 = float(np.mean([r[1] for r in rows]))
                if (r5, r1) > (best[2], best[3]):
                    best = (beta, lam, r5, r1)
        beta, lam = best[0], best[1]
        del trS
        gc.collect()

        raw = [rankev(score(c), c) for c in test]
        post = [rankev(score(c) + beta * posterior(score(c)) + lam * G, c) for c in test]
        r1 = float(np.mean([r[0] for r in post]))
        r5 = float(np.mean([r[1] for r in post]))
        base_mask = np.zeros(N, bool)
        base_mask[:len(base)] = True
        real = [rankev(np.where(base_mask, score(c), -1e9), c) for c in test]
        r1_real = float(np.mean([r[0] for r in real]))
        r5_real = float(np.mean([r[1] for r in real]))
        intr = float(np.mean([sum(1 for i in np.argsort(-(score(c) + beta * posterior(score(c))
                                                        + lam * G))[:5]
                                if i >= len(base)) for c in test]))
        res[tag] = {"N": N, "n_train": ntr, "n_test": nte,
                    "R1_raw": float(np.mean([r[0] for r in raw])),
                    "R5_raw": float(np.mean([r[1] for r in raw])),
                    "beta": beta, "lam": lam,
                    "train_R1_sel": best[3], "train_R5_sel": best[2],
                    "R1": r1, "R5": r5,
                    "R1_realonly": r1_real, "R5_realonly": r5_real,
                    "synth_in_top5": intr, "sec": time.perf_counter() - t0}
        print(f"{tag:9s} N={N:6d} raw={res[tag]['R1_raw']*100:5.2f}/"
              f"{res[tag]['R5_raw']*100:5.2f} β={beta} λ={lam} "
              f"=> {r1*100:5.2f}/{r5*100:5.2f} | 真实表内 {r1_real*100:5.2f}/{r5_real*100:5.2f} "
              f"top5 合成 {intr:.2f} ({time.perf_counter()-t0:.0f}s)", flush=True)
        json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        del cat, C
        gc.collect()


if __name__ == "__main__":
    main()
