"""E11: typed relational graph, diffusion operators and lexical baselines.

The graph has four node kinds (table, column, token, value) and six relation
layers (contain, name, value, fk, coquery, alias).  Each layer is a separate
sparse adjacency; diffusion is run per layer and fused.  The single-layer PPR
baseline uses the union of all edges, which is the object criticised in the
E9 report: it cannot tell proximity from role.
"""
from __future__ import annotations

import math
import re
from collections import Counter, defaultdict

import numpy as np
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer

TOK = re.compile(r"[a-z0-9_]+")
TOK_PART = re.compile(r"[a-z0-9]+")
CAMEL = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")
# Spider/BIRD identifiers are compounds: the column is contestant_name or
# AirportName, the user says "contestant" and "name".  Keeping the underscore
# makes the whole identifier one vocabulary item, and then no lexical operator
# can see the part the user asked for.  This flag is the experiment on that.
SPLIT_IDENT = False
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us""".split())


def toks(s: str) -> list[str]:
    raw = str(s)
    if SPLIT_IDENT:
        raw = CAMEL.sub(" ", raw).lower()
        return [t for t in TOK_PART.findall(raw) if len(t) >= 2 and t not in STOP]
    return [t for t in TOK.findall(raw.lower()) if len(t) >= 2 and t not in STOP]


def table_doc(t: dict) -> list[str]:
    parts = toks(t["name"])
    for c in t["columns"]:
        parts += toks(c["name"])
        for v in c.get("values", [])[:6]:
            parts += toks(v)[:3]
    return parts


def table_text(t: dict) -> str:
    cols = []
    vals = []
    for c in t["columns"]:
        cols.append(c["name"])
        for v in c.get("values", [])[:6]:
            vals.append(str(v))
    return f"table {t['name']}; columns: {', '.join(cols)}; values: {', '.join(vals)}"


class Catalog:
    """A set of tables, with a global node index shared by all layers."""

    def __init__(self, tables: list[dict], fks: list[list[str]] | None = None,
                 coquery: Counter | None = None, alias: dict[str, set[str]] | None = None,
                 prefix_db: bool = True, views: bool = True, idf_edges: bool = False):
        self.tables = []
        for t in tables:
            tt = dict(t)
            tt["tid"] = f"{tt['db']}::{tt['name']}" if prefix_db else tt["name"]
            self.tables.append(tt)
        self.fks = fks or []
        self.coquery = coquery or Counter()
        self.alias = alias or {}
        self.idx: dict[tuple, int] = {}
        self.kind: list[str] = []
        self.name: list[str] = []
        self.table_ids = [t["tid"] for t in self.tables]
        self.table_pos = {tid: i for i, tid in enumerate(self.table_ids)}
        self.table_node = []
        self.col_node = {}
        self.value_node = {}
        self.token_df = Counter()
        self.value_df = Counter()
        self._views = views
        self.idf_edges = idf_edges
        for t in self.tables:
            self.token_df.update(set(table_doc(t)))
            seen = set()
            for c in t["columns"]:
                for v in c.get("values", []):
                    seen.add(str(v).strip().lower())
            self.value_df.update(seen)
        self._build_nodes()
        self.layers = self._build_layers()

    def _n(self, kind: str, key: str) -> int:
        k = (kind, key)
        if k not in self.idx:
            self.idx[k] = len(self.idx)
            self.kind.append(kind)
            self.name.append(key)
        return self.idx[k]

    def _build_nodes(self):
        for i, t in enumerate(self.tables):
            tn = self._n("table", t["tid"])
            self.table_node.append(tn)
            for c in t["columns"]:
                cn = self._n("column", f"{t['tid']}::{c['name']}")
                self.col_node[(t["tid"], c["name"])] = cn
                for v in c.get("values", []):
                    vn = self._n("value", f"{t['tid']}::{c['name']}::{v}")
                    self.value_node[(t["tid"], c["name"], v)] = vn
        # token nodes are added by edges on demand

    def _add(self, edges, i, j, w):
        if i == j:
            return
        edges.append((i, j, float(w)))
        edges.append((j, i, float(w)))

    def _layer_edges(self):
        contain, name, value, fk, coq, alias = [], [], [], [], [], []
        # Optional idf weighting: a token shared by half the catalogue is a hub
        # and should not carry the same diffusion mass as a discriminative one.
        ntab = max(1, len(self.tables))

        def iw(w: str, base: float) -> float:
            if not self.idf_edges:
                return base
            df = self.token_df.get(w, 0)
            return base * min(4.0, math.log(1.0 + ntab / (df + 1.0)))

        for t in self.tables:
            tn = self._n("table", t["tid"])
            for w in toks(t["name"]):
                wn = self._n("token", w)
                self._add(name, tn, wn, iw(w, 1.0))
            for c in t["columns"]:
                cn = self.col_node[(t["tid"], c["name"])]
                self._add(contain, tn, cn, 1.0)
                for w in toks(c["name"]):
                    wn = self._n("token", w)
                    self._add(name, cn, wn, iw(w, 1.0))
                for v in c.get("values", []):
                    vn = self.value_node[(t["tid"], c["name"], v)]
                    self._add(value, cn, vn, 1.0)
                    for w in toks(v)[:5]:
                        wn = self._n("token", w)
                        self._add(value, vn, wn, iw(w, 1.0))
        for a, ca, b, cb in self.fks:
            if (a, ca) in self.col_node and (b, cb) in self.col_node:
                self._add(fk, self.col_node[(a, ca)], self.col_node[(b, cb)], 1.2)
        for (a, b), w in self.coquery.items():
            if a in self.table_pos and b in self.table_pos:
                self._add(coq, self.table_node[self.table_pos[a]],
                          self.table_node[self.table_pos[b]], min(3.0, max(0.1, w)))
        for a, bs in self.alias.items():
            if ("token", a) not in self.idx:
                continue
            an = self._n("token", a)
            for b in bs:
                if b == a or len(b) < 2:
                    continue
                bn = self._n("token", b)
                self._add(alias, an, bn, 0.8)
        return {k: v for k, v in
                [("contain", contain), ("name", name), ("value", value),
                 ("fk", fk), ("coquery", coq), ("alias", alias)]}

    def _mat(self, edges):
        if not edges:
            return sparse.csr_matrix((len(self.idx), len(self.idx)), dtype=np.float32)
        r = np.fromiter((e[0] for e in edges), dtype=np.int32)
        c = np.fromiter((e[1] for e in edges), dtype=np.int32)
        v = np.fromiter((e[2] for e in edges), dtype=np.float32)
        return sparse.coo_matrix((v, (r, c)), shape=(len(self.idx), len(self.idx))).tocsr()

    def _build_layers(self):
        e = self._layer_edges()
        pure = {r: self._mat(e[r]) for r in
                ("contain", "name", "value", "fk", "coquery", "alias")}
        self.pure = pure
        # Isolated layer: backbone (contain+name) plus one relation.
        A = {
            "contain": pure["contain"],
            "name": pure["contain"] + pure["name"],
            "value": pure["contain"] + pure["value"],
            "fk": pure["contain"] + pure["name"] + pure["fk"],
            "coquery": pure["contain"] + pure["name"] + pure["coquery"],
            "alias": pure["contain"] + pure["name"] + pure["alias"],
        }
        self.raw = A
        self.P = {k: rownorm(v) for k, v in A.items()}
        views = {}
        if self._views:
            # Relation views: one diffusion over the whole graph with the target
            # relation emphasised.  Unlike isolated layers this keeps cross-type
            # paths (name -> table -> fk -> column), which is what a real schema
            # traversal needs.
            for target in ("name", "value", "fk", "coquery", "alias"):
                M = 1.0 * pure["contain"] + 1.0 * pure["name"]
                for r in ("name", "value", "fk", "coquery", "alias"):
                    M = M + (2.0 if r == target else 0.5) * pure[r]
                views[target] = rownorm(M)
        self.views = views
        union = sum(pure[r] for r in pure)
        self.union = rownorm(union)
        if not self._views:
            del self.raw, self.P
            self.raw = self.P = {}
        return A

    def table_scores(self, x: np.ndarray) -> np.ndarray:
        s = np.asarray(x)[self.table_node]
        z = s.sum()
        return s / z if z > 0 else s

    def candidates(self, allowed: set[str] | None = None):
        if allowed is None:
            return list(range(len(self.tables)))
        return [self.table_pos[t] for t in allowed if t in self.table_pos]


def rownorm(A: sparse.csr_matrix) -> sparse.csr_matrix:
    d = np.asarray(A.sum(axis=1)).ravel()
    d[d == 0] = 1.0
    return sparse.diags(1.0 / d).dot(A).tocsr()


def ppr(P: sparse.csr_matrix, seeds: dict[int, float], alpha=0.85, iters=20) -> np.ndarray:
    n = P.shape[0]
    s = np.zeros(n, dtype=np.float32)
    for i, w in seeds.items():
        if 0 <= i < n:
            s[i] += w
    z = s.sum()
    if z <= 0:
        return s
    s /= z
    x = s.copy()
    Pt = P.T.tocsr()
    for _ in range(iters):
        x = alpha * (Pt @ x) + (1.0 - alpha) * s
    return x


def seed_vector(cat: Catalog, query: list[str], band_weight: dict[str, float] | None = None):
    seeds = {}
    for q in set(query):
        k = ("token", q)
        if k in cat.idx:
            seeds[cat.idx[k]] = (band_weight or {}).get(q, 1.0)
    return seeds


def fuse(cat: Catalog, query: list[str], alpha=0.85, iters=20,
         weights: dict[str, float] | None = None,
         band_weight: dict[str, float] | None = None,
         layers: list[str] | None = None, mode: str = "view") -> np.ndarray:
    """Fuse relation-specific diffusions.

    ``mode='view'`` uses the whole graph with one relation emphasised (default);
    ``mode='isolated'`` uses the old per-layer subgraphs.
    """
    weights = weights or {"name": 1.0, "value": 1.0, "fk": 0.8, "coquery": 0.5, "alias": 0.5}
    seeds = seed_vector(cat, query, band_weight)
    score = np.zeros(len(cat.tables), dtype=np.float32)
    mats = cat.views if mode == "view" else cat.P
    for k, w in weights.items():
        if layers is not None and k not in layers:
            continue
        x = ppr(mats[k], seeds, alpha, iters)
        score += w * cat.table_scores(x)
    return score


def single_ppr(cat: Catalog, query: list[str], alpha=0.85, iters=20,
               band_weight: dict[str, float] | None = None) -> np.ndarray:
    seeds = seed_vector(cat, query, band_weight)
    x = ppr(cat.union, seeds, alpha, iters)
    return cat.table_scores(x)


def bm25(cat: Catalog, query: list[str], k1=1.2, b=0.75) -> np.ndarray:
    docs = [table_doc(t) for t in cat.tables]
    N = len(docs)
    avgdl = sum(len(d) for d in docs) / max(1, N)
    df = Counter()
    for d in docs:
        df.update(set(d))
    scores = np.zeros(N, dtype=np.float32)
    for i, d in enumerate(docs):
        tf = Counter(d)
        s = 0.0
        for q in set(query):
            if q not in tf:
                continue
            idf = math.log(1 + (N - df[q] + 0.5) / (df[q] + 0.5))
            s += idf * tf[q] * (k1 + 1) / (tf[q] + k1 * (1 - b + b * len(d) / avgdl))
        scores[i] = s
    return scores


def tfidf(cat: Catalog, query: list[str]) -> np.ndarray:
    docs = [table_doc(t) for t in cat.tables]
    vec = TfidfVectorizer(analyzer=lambda x: x, lowercase=False)
    X = vec.fit_transform(docs)
    q = vec.transform([query])
    return (X @ q.T).toarray().ravel()


def rank(scores: np.ndarray, cat: Catalog, allowed: set[str] | None = None) -> list[str]:
    cand = cat.candidates(allowed)
    order = sorted(cand, key=lambda i: -float(scores[i]))
    return [cat.table_ids[i] for i in order]


def metrics(ranked: list[str], gold: set[str], k=(1, 3, 5)) -> dict:
    out = {}
    for kk in k:
        out[f"recall@{kk}"] = sum(1 for t in ranked[:kk] if t in gold) / max(1, len(gold))
    rr = 0.0
    for i, t in enumerate(ranked[:20], 1):
        if t in gold:
            rr = 1.0 / i
            break
    out["mrr"] = rr
    return out


def mean_metrics(rows: list[dict]) -> dict:
    keys = [k for k in rows[0] if isinstance(rows[0][k], (int, float))]
    return {k: round(float(np.mean([r[k] for r in rows])), 4) for k in keys}


def _num(s):
    try:
        return int(round(float(str(s).replace(",", "").replace(" ", ""))))
    except Exception:
        return None


def support_types(cat: Catalog, tid: str, query: list[str], depth: int = 1) -> set[str]:
    """Evidence types connecting the query to a table, no model involved."""
    if tid not in cat.table_pos:
        return set()
    t = cat.tables[cat.table_pos[tid]]
    qt = set(query)
    out = set()
    names = set(toks(t["name"]))
    for c in t["columns"]:
        names |= set(toks(c["name"]))
    if qt & names:
        out.add("name")
    for c in t["columns"]:
        for v in c.get("values", []):
            vt = set(toks(v))
            if qt & vt:
                out.add("value")
                break
            if any(q.isdigit() and _num(q) is not None and _num(q) == _num(v) for q in qt):
                out.add("value")
                break
        if "value" in out:
            break
    if depth > 0:
        for a, ca, b, cb in cat.fks:
            if a == tid:
                other = b
            elif b == tid:
                other = a
            else:
                continue
            if support_types(cat, other, query, depth - 1):
                out.add("fk")
                break
        for (a, b) in cat.coquery:
            if a == tid and support_types(cat, b, query, 0):
                out.add("coquery")
                break
            if b == tid and support_types(cat, a, query, 0):
                out.add("coquery")
                break
    return out


def certify(cat: Catalog, scores: np.ndarray, query: list[str], gold: set[str]) -> dict:
    r = rank(scores, cat)
    top1 = r[0] if r else None
    top2 = r[1] if len(r) > 1 else None
    s1 = float(scores[cat.table_pos[top1]]) if top1 in cat.table_pos else 0.0
    s2 = float(scores[cat.table_pos[top2]]) if top2 in cat.table_pos else 0.0
    st = support_types(cat, top1, query) if top1 else set()
    value_exact = False
    matched_value = None
    name_hits = 0
    name_rare = False
    unique_name = False
    fk_value = False
    if top1 and top1 in cat.table_pos:
        t = cat.tables[cat.table_pos[top1]]
        qt = set(query)
        names = set(toks(t["name"]))
        for c in t["columns"]:
            names |= set(toks(c["name"]))
        name_hits = len(qt & names)
        name_rare = any(cat.token_df.get(x, 0) <= max(1, len(cat.tables) * 0.03)
                        for x in (qt & names))
        unique_name = any(cat.token_df.get(x, 0) <= 1 for x in (qt & names))
        for c in t["columns"]:
            for v in c.get("values", []):
                vs = str(v).strip().lower()
                for q in qt:
                    if q == vs or (q.isdigit() and _num(q) is not None and _num(q) == _num(v)):
                        value_exact = True
                        matched_value = vs
                        break
                if value_exact:
                    break
            if value_exact:
                break
        for a, ca, b, cb in cat.fks:
            other = b if a == top1 else (a if b == top1 else None)
            if other is None:
                continue
            ot = cat.tables[cat.table_pos[other]]
            for c in ot["columns"]:
                for v in c.get("values", []):
                    vs = str(v).strip().lower()
                    if any(q == vs for q in qt):
                        fk_value = True
                        break
                if fk_value:
                    break
            if fk_value:
                break
    unique_value = bool(value_exact and matched_value and cat.value_df.get(matched_value, 99) == 1)
    return {
        "top1": top1, "top2": top2, "support": sorted(st),
        "value_exact": value_exact, "unique_value": unique_value,
        "name_hits": name_hits, "name_rare": name_rare,
        "unique_name": unique_name, "fk_value": fk_value,
        "margin": round((s1 - s2) / (s1 + 1e-9), 4),
        "correct": top1 in gold,
        "raw": round(s1, 6),
    }
