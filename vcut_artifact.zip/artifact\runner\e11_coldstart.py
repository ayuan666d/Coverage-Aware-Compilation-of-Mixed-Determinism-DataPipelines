"""E11-COLDSTART: does the relational arm work on a database nobody has ever queried?

Reporting rule for this file (agreed before running): this ADDS a capability row.
The with-history numbers already in the report stay exactly as they are -- query
logs are a normal production asset, so "with co-query history" is the default
configuration, not a favour.  The question here is only whether the arm still
clears the same-budget lexical baseline when that history is removed, i.e. whether
it can cold-start on a brand-new database.

Ablation: drop the co-query layer (edges mined from training-split SQL) and nothing
else.  Same 876-table catalogue, same identifier-split tokeniser, same per-token
idf-weighted geometric fusion, same BM25-recall-then-graph-rerank, same 341 test
questions.  Values, names, types and FK constraints stay -- those are native to the
database and exist at second zero.
"""
from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_run_spider import band_fn, coquery_map, fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = WORK / "e11_emb_spider.npz"
OUT = REPO / "06_结果" / "e11_coldstart.json"
EPS = 1e-6


def run(cat, cases, qpos, Dm, Qm, ids):
    N = len(cat.tables)
    bf, _ = band_fn(cases)
    tok = {}
    for w in sorted({w for c in cases for w in g.toks(c["question"])}):
        if ("token", w) not in cat.idx:
            continue
        x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
        s = cat.table_scores(x)
        mx = float(s.max())
        tok[w] = s / mx if mx > 0 else s
    idf = {w: math.log(1 + (N - cat.token_df.get(w, 0) + 0.5) / (cat.token_df.get(w, 0) + 0.5))
           for w in tok}
    rows = []
    for c in cases:
        q = g.toks(c["question"])
        gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
        ws = [w for w in set(q) if w in tok]
        if ws:
            M = np.stack([tok[w] for w in ws])
            iw = np.array([idf[w] for w in ws])[:, None]
            graph = np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
        else:
            graph = np.zeros(N, dtype=np.float32)
        b = g.bm25(cat, q)
        top = np.argsort(-b)[:30]
        mixed = b.copy()
        base = float(b[top[-1]])
        for i, idx in enumerate(top[np.argsort(-graph[top])]):
            mixed[idx] = base + (30 - i) * 1e-6
        bw = bf(q)
        scores = {"bm25": b, "rerank": mixed, "geom_idf": graph,
                  "ppr_band": g.single_ppr(cat, q, band_weight=bw),
                  "typed_band": g.fuse(cat, q, band_weight=bw),
                  "dense": Dm @ Qm[qpos[c["qid"]]]}
        ranked_rr = [ids[i].lower() for i in np.argsort(-mixed)]
        top1_pos = int(np.argsort(-mixed)[0])
        shared = len(set(q) & set(g.table_doc(cat.tables[top1_pos])))
        rarest = min([cat.token_df.get(w, 10 ** 9) for w in ws], default=10 ** 9)
        rec = {"qid": c["qid"], "gold": sorted(gold), "k": shared, "rarest_df": rarest,
               "cert_ok": float(shared >= 3 and rarest <= 2)}
        for name, s in scores.items():
            r = [ids[i].lower() for i in np.argsort(-s)]
            m = g.metrics(r, {x.lower() for x in gold})
            rec[f"{name}_r1"] = round(m["recall@1"], 4)
            rec[f"{name}_r5"] = round(m["recall@5"], 4)
            rec[f"{name}_mrr"] = round(m["mrr"], 4)
            rec[f"{name}_hit1"] = float(r[0] in {x.lower() for x in gold})
        rows.append(rec)
    return rows


def summarise(rows):
    names = [k[:-3] for k in rows[0] if k.endswith("_r5")]
    mean = lambda k: round(float(np.mean([r[k] for r in rows])), 4)  # noqa: E731
    out = {"n": len(rows)}
    for m in names:
        out[m] = {"r1": mean(f"{m}_r1"), "r5": mean(f"{m}_r5"), "mrr": mean(f"{m}_mrr"),
                  "top1_hit": mean(f"{m}_hit1")}
    acc = [r for r in rows if r["cert_ok"] > 0]
    out["certificate"] = {"accept_cov": round(len(acc) / len(rows), 4),
                          "accepted_rerank_r1": round(float(np.mean([r["rerank_r1"] for r in acc])), 4) if acc else None,
                          "accepted_dense_r1": round(float(np.mean([r["dense_r1"] for r in acc])), 4) if acc else None,
                          "accepted_rerank_hit1": round(float(np.mean([r["rerank_hit1"] for r in acc])), 4) if acc else None,
                          "accepted_dense_hit1": round(float(np.mean([r["dense_hit1"] for r in acc])), 4) if acc else None}
    return out


def main():
    g.SPLIT_IDENT = True   # must be set before any Catalog is built
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    train = [c for c in data["spider"] if c["split"] == "train"]
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    z = np.load(EMB, allow_pickle=True)
    ids = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}

    out = {}
    for label, coq in (("with_history", coquery_map(train, prefix=True)), ("cold_start", None)):
        t0 = time.time()
        cat = g.Catalog(tabs, fks, coquery=coq, prefix_db=True)
        rows = run(cat, test, qpos, Dm, Qm, ids)
        out[label] = summarise(rows)
        out[label + "_rows"] = rows
        print(f"{label}: nodes={len(cat.idx)} in {time.time()-t0:.0f}s", json.dumps(
            {k: v for k, v in out[label].items() if k != "n"}), flush=True)

    wh, cs = out["with_history"], out["cold_start"]
    out["readings"] = {
        "rerank_r5_with_history": wh["rerank"]["r5"], "rerank_r5_cold_start": cs["rerank"]["r5"],
        "bm25_cold_start_r5": cs["bm25"]["r5"],
        "cold_start_clears_lexical": cs["rerank"]["r5"] > cs["bm25"]["r5"],
        "cold_start_top1_clears_lexical": cs["rerank"]["top1_hit"] > cs["bm25"]["top1_hit"],
        "certificate_still_selective_cold_start": cs["certificate"]["accepted_rerank_hit1"],
        "certificate_dense_on_same_subset": cs["certificate"]["accepted_dense_hit1"]}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if not k.endswith("_rows")}, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
