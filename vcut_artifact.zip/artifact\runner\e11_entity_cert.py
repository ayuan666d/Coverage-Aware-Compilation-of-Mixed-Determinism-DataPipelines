"""E11: what does a certificate buy in an entity-matching corpus?

Same accept/review contract as the receipts: propose with BM25, then accept
only when the database itself supplies a closed witness -- an identical
normalised title, or a token that occurs in exactly one candidate record.
Everything else goes to review.
"""
from __future__ import annotations

import json
import os
import math
import re
import sys
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e11_graph import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
EM = Path("D:/vldb2027_e11/em")
OUT = REPO / "06_结果" / "e11_entity_cert.json"
MODEL = "D:/vldb2027_e11/models/Qwen3-Embedding-0.6B"
PAT = re.compile(r"(title|manufacturer|price|venue|year|publisher|authors|date)\s*:\s*([^.]*)")


def fields(s):
    out = {}
    for k, v in PAT.findall(str(s).lower()):
        out.setdefault(k, " ".join(toks(v)))
    return out


def main():
    res = {}
    for name in ["DBLP_ACM", "Amazon_Google"]:
        df = pd.read_parquet(EM / f"{name}_test.parquet")
        rights = sorted({r for r in df["productB"]})
        ridx = {r: i for i, r in enumerate(rights)}
        from collections import defaultdict as dd
        gold = dd(set)
        for _, row in df.iterrows():
            if bool(row["same"]):
                gold[row["productA"]].add(ridx[row["productB"]])
        rf = [fields(r) for r in rights]
        titles = [f.get("title", "") for f in rf]
        tset = [set(t.split()) for t in titles]
        # per-token document frequency over right records (all fields)
        dfall = Counter()
        for f in rf:
            seen = set()
            for v in f.values():
                seen |= set(v.split())
            dfall.update(seen)
        lefts = sorted(gold)
        N = len(rights)
        docs = [set(" ".join(f.values()).split()) for f in rf]
        avgdl = np.mean([len(d) for d in docs])
        from sentence_transformers import SentenceTransformer
        try:
            m = SentenceTransformer(str(MODEL), device=os.environ.get("ST_DEVICE", "cpu"))
        except Exception:
            m = SentenceTransformer(str(MODEL), device="cpu")
        m.max_seq_length = 256
        Dr = m.encode([" ".join(d) for d in docs], batch_size=32, normalize_embeddings=True,
                      convert_to_numpy=True)
        Dl = m.encode([" ".join(fields(l).values()) for l in lefts], batch_size=32,
                      normalize_embeddings=True, convert_to_numpy=True, prompt_name="query")
        rows = []
        for li, l in enumerate(lefts):
            lf = fields(l)
            q = set(" ".join(lf.values()).split())
            best = (-1e9, None)
            for i, d in enumerate(docs):
                s = 0.0
                for w in q & d:
                    idf = math.log(1 + (N - dfall[w] + 0.5) / (dfall[w] + 0.5))
                    s += idf
                if s > best[0]:
                    best = (s, i)
            i = best[1]
            j = int(np.argmax(Dr @ Dl[li]))
            exact_title = bool(lf.get("title")) and lf["title"] == titles[i]
            uniq = [w for w in q if dfall.get(w, 0) == 1 and w in docs[i]]
            exact_title_d = bool(lf.get("title")) and lf["title"] == titles[j]
            uniq_d = [w for w in q if dfall.get(w, 0) == 1 and w in docs[j]]
            rows.append({"left": l, "top1": i, "correct": i in gold[l],
                         "exact_title": exact_title, "unique_token": bool(uniq),
                         "d_top1": j, "d_correct": j in gold[l],
                         "d_exact_title": exact_title_d, "d_unique_token": bool(uniq_d)})
        n = len(rows)

        def rule(r, kind, pre=""):
            if kind == "exact_title":
                return r[pre + "exact_title"]
            if kind == "unique":
                return r[pre + "unique_token"]
            if kind == "either":
                return r[pre + "exact_title"] or r[pre + "unique_token"]
            return True
        out = {"n": n}
        for pre, tag in (("", "bm25_"), ("d_", "dense_")):
            key = "correct" if pre == "" else "d_correct"
            all_ok = sum(r[key] for r in rows)
            for kind in ("propose", "exact_title", "unique", "either"):
                acc = [r for r in rows if rule(r, kind, pre)]
                ok = sum(r[key] for r in acc)
                out[tag + kind] = {"coverage": round(len(acc) / n, 4),
                                   "precision": round(ok / len(acc), 4) if acc else None,
                                   "false_pass_rate": round((len(acc) - ok) / n, 4),
                                   "share_of_correct_kept": round(ok / all_ok, 4) if all_ok else None}
        res[name] = out
        print(name, json.dumps(out, ensure_ascii=False))
    json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
