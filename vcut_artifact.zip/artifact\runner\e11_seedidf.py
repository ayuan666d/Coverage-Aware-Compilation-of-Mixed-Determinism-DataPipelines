"""E11-SEEDIDF: the hub regime is the last open loss, so put the frequency
weight on the correct side of the vocabulary.

The band rule in every E11 run down-weights tokens that are frequent in QUERIES
(question df).  Hub dilution is not that: the damage is done by tokens that are
frequent in DOCUMENTS -- after identifier splitting the catalogue is full of
name / id / code / date / city, and a seed vector cannot tell "the query said
name" from "the schema says name everywhere".  So weight each token's
reachability by its document frequency, in both fusion geometries:

  sum          : Σ_w z_w                    (current)
  sum_idf      : Σ_w idf_w · z_w
  geom         : exp( mean_w log z_w )      (e11_split winner)
  geom_idf     : exp( Σ_w idf_w log z_w / Σ_w idf_w )
  max_idf      : the single highest-idf anchor's own vector (no fusion)

where z_w = table score from a PPR seeded only at token w, rescaled to max 1.
"""
from __future__ import annotations

import json
import math
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_run_spider import band_fn, coquery_map, fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
OUT = REPO / "06_结果" / "e11_seedidf.json"
EPS = 1e-6


def buck(x):
    return "0(no anchor)" if x == 0 else ("1" if x == 1 else ("2-5" if x <= 5 else
            ("6-20" if x <= 20 else ">20")))


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    coq = coquery_map([c for c in data["spider"] if c["split"] == "train"], prefix=True)
    cat = g.Catalog(tabs, fks, coquery=coq, prefix_db=True)
    bf, _ = band_fn(test)
    N = len(cat.tables)
    z = np.load(EMB, allow_pickle=True)
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}

    t0 = time.time()
    qs = {c["qid"]: toks(c["question"]) for c in test}
    tok = {}
    for w in sorted({w for q in qs.values() for w in q}):
        if ("token", w) not in cat.idx:
            continue
        x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
        s = cat.table_scores(x)
        mx = float(s.max())
        tok[w] = s / mx if mx > 0 else s
    print(f"per-token PPR: {len(tok)} tokens, {time.time()-t0:.0f}s", flush=True)

    idf = {w: math.log(1 + (N - cat.token_df.get(w, 0) + 0.5) / (cat.token_df.get(w, 0) + 0.5))
           for w in tok}

    def fuse(q, mode):
        ws = [w for w in set(q) if w in tok]
        if not ws:
            return np.zeros(N, dtype=np.float32)
        M = np.stack([tok[w] for w in ws])
        iw = np.array([idf[w] for w in ws])[:, None]
        if mode == "sum":
            return M.sum(axis=0)
        if mode == "sum_idf":
            return (M * iw).sum(axis=0)
        if mode == "geom":
            return np.exp(np.log(M + EPS).mean(axis=0))
        if mode == "geom_idf":
            return np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
        if mode == "max_idf":
            return tok[sorted(ws, key=lambda w: (-idf[w], w))[0]]
        if mode == "and_min":
            return M.min(axis=0)
        if mode == "harm":
            return len(ws) / (1.0 / (M + EPS)).sum(axis=0)
        raise ValueError(mode)

    modes = ("sum", "sum_idf", "geom", "geom_idf", "max_idf", "and_min", "harm")
    rows = []
    for c in test:
        q = qs[c["qid"]]
        gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
        bw = bf(q)
        sc = {m: fuse(q, m) for m in modes}
        sc["ppr_band"] = g.single_ppr(cat, q, band_weight=bw)
        sc["typed_band"] = g.fuse(cat, q, band_weight=bw)
        sc["bm25"] = g.bm25(cat, q)
        sc["dense"] = Dm @ Qm[qpos[c["qid"]]]
        gt = set()
        for t in gold:
            if t in cat.table_pos:
                gt |= set(g.table_doc(cat.tables[cat.table_pos[t]]))
        bt = set(q) & gt
        rec = {"qid": c["qid"], "bucket": buck(min([cat.token_df.get(w, 0) for w in bt], default=0)),
               "gold": sorted(gold), "n_anchor": len(bt),
               "max_idf": round(max([idf[w] for w in bt], default=0.0), 2)}
        for name, s in sc.items():
            r = g.rank(s, cat)
            m = g.metrics(r, gold)
            rec[f"{name}_r1"] = round(m["recall@1"], 4)
            rec[f"{name}_r5"] = round(m["recall@5"], 4)
            rec[f"{name}_mrr"] = round(m["mrr"], 4)
        rows.append(rec)

    names = modes + ("ppr_band", "typed_band", "bm25", "dense")

    def agg(sel):
        s = [r for r in rows if sel(r)]
        if not s:
            return {"n": 0}
        mean = lambda k: round(float(np.mean([r[k] for r in s])), 4)  # noqa: E731
        return {"n": len(s), **{m: [mean(f"{m}_r1"), mean(f"{m}_r5")] for m in names}}

    out = {"n": len(rows), "tokens": len(tok),
           "overall": agg(lambda r: True),
           "by_bucket": {b: agg(lambda r, b=b: r["bucket"] == b)
                         for b in ("0(no anchor)", "1", "2-5", "6-20", ">20")}}
    json.dump({**out, "rows": rows}, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps(out, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
