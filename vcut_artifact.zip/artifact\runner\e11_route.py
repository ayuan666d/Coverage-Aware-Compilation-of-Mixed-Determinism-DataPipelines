"""E11-ROUTE: the operator the diagnosis points at.

After the identifier split the graph is at or above dense wherever the query has
a discriminative anchor (df=1: R@1 0.628 vs 0.541), and below BM25 wherever the
only anchor is a hub (df>=6: 0.25 vs 0.48).  That is a routing decision, and the
variable to route on is observable at query time for free: the document frequency
of the rarest anchor the query actually found in the catalogue.

Variants:
  graph        : geometric mean of per-token reachability, idf-weighted (best so far)
  bm25         : lexical
  route(tau)   : graph if rarest-anchor idf >= tau else bm25
  rerank(K)    : BM25 top-K, then order those K by the graph score
  oracle       : upper bound of picking the better of the two per question (not a claim)
"""
from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_run_spider import band_fn, coquery_map, fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
OUT = REPO / "06_结果" / "e11_route.json"
EPS = 1e-6


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    coq = coquery_map([c for c in data["spider"] if c["split"] == "train"], prefix=True)
    cat = g.Catalog(tabs, fks, coquery=coq, prefix_db=True)
    bf, _ = band_fn(test)
    N = len(cat.tables)
    z = np.load(EMB, allow_pickle=True)
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}

    t0 = time.time()
    tok = {}
    for w in sorted({w for c in test for w in toks(c["question"])}):
        if ("token", w) not in cat.idx:
            continue
        x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
        s = cat.table_scores(x)
        mx = float(s.max())
        tok[w] = s / mx if mx > 0 else s
    idf = {w: math.log(1 + (N - cat.token_df.get(w, 0) + 0.5) / (cat.token_df.get(w, 0) + 0.5))
           for w in tok}
    print(f"{len(tok)} tokens in {time.time()-t0:.0f}s", flush=True)

    rows = []
    for c in test:
        q = toks(c["question"])
        gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
        ws = [w for w in set(q) if w in tok]
        if ws:
            M = np.stack([tok[w] for w in ws])
            iw = np.array([idf[w] for w in ws])[:, None]
            graph = np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
        else:
            graph = np.zeros(N, dtype=np.float32)
        b = g.bm25(cat, q)
        d = Dm @ Qm[qpos[c["qid"]]]
        best_anchor_idf = max([idf[w] for w in ws], default=0.0)
        rec = {"qid": c["qid"], "gold": sorted(gold),
               "anchor_idf": round(best_anchor_idf, 3),
               "anchor_df": min([cat.token_df.get(w, 10 ** 9) for w in ws], default=10 ** 9)}
        variants = {"graph": graph, "bm25": b, "dense": d}
        for tau in (1.0, 2.0, 3.0, 4.0, 5.0):
            variants[f"route{tau}"] = graph if best_anchor_idf >= tau else b
        order = np.argsort(-b)
        for K in (10, 30, 100):
            top = order[:K]
            mixed = b.copy()
            base = float(b[top[-1]])
            for i, idx in enumerate(top[np.argsort(-graph[top])]):
                mixed[idx] = base + (K - i) * 1e-6
            variants[f"rerank{K}"] = mixed
        for name, s in variants.items():
            r = g.rank(s, cat)
            m = g.metrics(r, gold)
            rec[f"{name}_r1"] = round(m["recall@1"], 4)
            rec[f"{name}_r5"] = round(m["recall@5"], 4)
        rec["oracle_r5"] = max(rec["bm25_r5"], rec["graph_r5"])
        rec["oracle_r1"] = max(rec["bm25_r1"], rec["graph_r1"])
        rows.append(rec)

    names = [k[:-3] for k in rows[0] if k.endswith("_r5")]
    mean = lambda k: round(float(np.mean([r[k] for r in rows])), 4)  # noqa: E731
    out = {"n": len(rows), "tokens": len(tok),
           "overall": {m: {"r1": mean(f"{m}_r1"), "r5": mean(f"{m}_r5")} for m in names},
           "by_anchor_df": {},
           "rows": rows}
    for lo, hi, lab in ((0, 1, "df<=1"), (2, 5, "df 2-5"), (6, 20, "df 6-20"), (21, 10 ** 9, "df>20")):
        s = [r for r in rows if lo <= r["anchor_df"] <= hi]
        if not s:
            continue
        out["by_anchor_df"][lab] = {"n": len(s),
                                    **{m: {"r1": round(float(np.mean([x[f"{m}_r1"] for x in s])), 4),
                                               "r5": round(float(np.mean([x[f"{m}_r5"] for x in s])), 4)}
                                       for m in ("bm25", "graph", "route3.0", "rerank30", "dense")}}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
