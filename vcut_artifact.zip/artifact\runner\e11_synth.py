"""E11-SYNTH: synthesize the operator from the catalogue, under a label-free objective.

The line's thesis is "build the database as a model, in reverse".  A hand-written pipeline
(split identifiers -> PPR -> per-word best column -> idf geometric mean -> top-30 rerank, with
constants chosen by me) contradicts it: the structure came from a person, and 2.16 priced how
much that matters (opaque identifiers: 81.6% -> 38.1%).

Synthesis is the cold-start move, and it is affordable -- no labels, no GPU, no query log.  The
piece that was missing is an objective that never looks at gold.  The certificate IS that
objective:

  DECISIVE(q): the table the operator puts first carries query-word support exceeding what an
               876-table lake hands out by chance, in BOTH the whole document and the
               identifiers alone (word AND name, alpha = 0.05, from catalogue df only).
  STABLE(q)  : the same table stays first when the lake's composition is perturbed -- four
               random 10% subsets of candidate tables removed, identical seeds for every
               candidate operator.
  J(operator) = fraction of questions that are DECISIVE and STABLE.  Labels appear nowhere in J.

Search space (all DB-native): weights on six features -- table diffusion, per-word best-column
diffusion, identifier hit, sample-value hit, foreign-key-neighbour hit, BM25 -- two aggregations
over query words (idf-weighted mean vs idf-weighted geometric mean), four damping factors
(0.80 / 0.85 / 0.90 / lambda_2 read off the graph) and four recall widths (10 / 20 / 30 / none).
Coordinate ascent, fixed budget.  Reported after the search and never used by it: recall@1,
recall@5, and the certified subset's precision, against the hand-written arm and against dense.
"""
from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np
from scipy import sparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_surprise import chance_tail  # noqa: E402
from e11_col import col_index  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
CASES = R / "e11_cases.json"
EMB = WORK / "e11_emb_spider.npz"
OUT = R / "e11_synth.json"
EPS = 1e-6
ITERS = 20
ALPHA = 0.05
FEATS = ("tabdiff", "coldiff", "namehit", "valhit", "fkhit", "bm25")
GRID = (0.0, 0.25, 0.5, 0.75, 1.0)
KS = (876, 30, 20, 10)
SEEDS = (0, 1, 2, 3)
OBJECTIVE = "strength"   # "decisive" = binary J, "strength" = nats above chance x STABLE
KEEP = 0.9


def lambda2(cat):
    A = ((cat.union + cat.union.T) * 0.5).tocsr()
    d = np.asarray(A.sum(axis=1)).ravel()
    d[d <= 0] = 1.0
    S = (sparse.diags(1.0 / np.sqrt(d)) @ A @ sparse.diags(1.0 / np.sqrt(d))).tocsr()
    try:
        from scipy.sparse.linalg import eigsh
        w = np.sort(np.real(eigsh(S, k=3, which="LA", return_eigenvectors=False)))[::-1]
        return float(w[1]) if w.size > 1 else 0.85
    except Exception:
        return 0.85


def main():
    t0 = time.perf_counter()
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    cases = [c for c in data["spider"] if c["split"] == "test"]
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += [dict(t, db=db) for t in cache["spider"][db]["tables"]]
        have = {t["name"] for t in cache["spider"][db]["tables"]}
        fks += [[f"{db}::{a}", ca, f"{db}::{b}", cb] for a, ca, b, cb in cache["spider"][db]["fks"]
                if a in have and b in have]
    cat = g.Catalog(tabs, fks, coquery=None, prefix_db=True)
    N = len(cat.tables)
    colnodes, cdocs, starts, ends = col_index(cat)
    lam = lambda2(cat)
    alphas = [0.80, 0.85, 0.90, round(lam, 3)]

    # ---- token vocabulary actually seen in questions ----
    qtok = {c["qid"]: sorted(set(toks(c["question"]))) for c in cases}
    vocab = sorted({w for ws in qtok.values() for w in ws if ("token", w) in cat.idx})
    tid = {w: i for i, w in enumerate(vocab)}
    n_tok = len(vocab)
    idf_vec = np.array([math.log(1 + (N - cat.token_df.get(w, 0) + 0.5)
                                 / (cat.token_df.get(w, 0) + 0.5)) for w in vocab],
                       dtype=np.float32)

    # ---- static features: identifier hit, value hit, FK-neighbour hit ----
    namehit = np.zeros((n_tok, N), dtype=np.float32)
    valhit = np.zeros((n_tok, N), dtype=np.float32)
    tok_of_table_name, tok_of_table_val = {}, {}
    for j, t in enumerate(cat.tables):
        nm = set(toks(t["name"]))
        for c in t["columns"]:
            nm |= set(toks(c["name"]))
        vl = set()
        for c in t["columns"]:
            for v in c.get("values", [])[:6]:
                vl |= set(toks(v)[:3])
        tok_of_table_name[j] = nm
        tok_of_table_val[j] = vl
        for w in nm:
            i = tid.get(w)
            if i is not None:
                namehit[i, j] = 1.0
        for w in vl:
            i = tid.get(w)
            if i is not None:
                valhit[i, j] = 1.0
    nbr = [[] for _ in range(N)]
    for a, ca, b, cb in cat.fks:
        ja = cat.table_pos.get(a)
        jb = cat.table_pos.get(b)
        if ja is not None and jb is not None:
            nbr[ja].append(jb)
            nbr[jb].append(ja)
    fkhit = np.zeros((n_tok, N), dtype=np.float32)
    for j in range(N):
        s = set()
        for k in nbr[j]:
            s |= tok_of_table_name[k] | tok_of_table_val[k]
        for w in s:
            i = tid.get(w)
            if i is not None:
                fkhit[i, j] = 1.0
    print(f"static features in {time.time()-t0:.0f}s (lambda2={lam:.4f})", flush=True)

    # ---- diffusion features, one pair per damping factor ----
    diff = {}
    for a in alphas:
        td = np.zeros((n_tok, N), dtype=np.float32)
        cd = np.zeros((n_tok, N), dtype=np.float32)
        for w in vocab:
            x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, a, ITERS)
            st = np.asarray(cat.table_scores(x), dtype=np.float32)
            mx = float(st.max())
            if mx > 0:
                td[tid[w]] = st / mx
            cv = np.asarray(x)[colnodes].astype(np.float32)
            cmx = float(cv.max())
            if cmx > 0:
                cv = cv / cmx
            cd[tid[w]] = np.maximum.reduceat(cv, starts)
        diff[a] = (td, cd)
        print(f"diffusion cache alpha={a} in {time.time()-t0:.0f}s", flush=True)

    # ---- per-query: bm25, gold, candidate lists, certificate masks ----
    per_q = []
    for c in cases:
        q = qtok[c["qid"]]
        gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
        idx = np.array([tid[w] for w in q if w in tid], dtype=np.int64)
        iw = idf_vec[idx]
        b = g.bm25(cat, toks(c["question"]))
        bn = b / (float(b.max()) + EPS)
        cs_word = namehit[idx].sum(0) + 0.0
        cs_word = np.zeros(N)
        cs_name = np.zeros(N)
        for w in q:
            i = tid.get(w)
            if i is None:
                continue
            cs_word += ((namehit[i] + valhit[i]) > 0)
            cs_name += (namehit[i] > 0)
        dfs_word = [cat.token_df.get(w, 0) for w in q if w in tid]
        dfs_name = [cat.token_df.get(w, 0) for w in q if w in tid
                    and any(namehit[tid[w]])]
        maxc = len(q)
        pw = np.array([chance_tail(dfs_word, N, k)[1] for k in range(maxc + 2)], dtype=np.float32)
        pn = np.array([chance_tail(dfs_name, N, k)[1] for k in range(maxc + 2)], dtype=np.float32)
        cw = np.minimum(cs_word.astype(int), maxc + 1)
        cn = np.minimum(cs_name.astype(int), maxc + 1)
        cert = (pw[cw] <= ALPHA) & (pn[cn] <= ALPHA)
        # continuous label-free evidence strength: nats above chance, whole doc +
        # identifiers alone, floored at 0 and capped so one token cannot dominate.
        lp = np.clip(-np.log(np.maximum(pw[cw], 1e-12))
                     - np.log(np.maximum(pn[cn], 1e-12)), 0.0, 40.0).astype(np.float32)
        per_q.append({"qid": c["qid"], "idx": idx, "iw": iw, "bn": bn.astype(np.float32),
                      "gold": gold, "cert": cert, "lp": lp, "b": b})
    rng = np.random.default_rng(7)
    keeps = [np.zeros(N, dtype=bool) for _ in SEEDS]
    for k in keeps:
        sel = rng.random(N) < KEEP
        k[:] = sel
    print(f"queries prepared in {time.time()-t0:.0f}s", flush=True)

    feat_of = {"namehit": namehit, "valhit": valhit, "fkhit": fkhit}

    def score_tables(qi, w, a, agg):
        rec = per_q[qi]
        idx, iw = rec["idx"], rec["iw"]
        td, cd = diff[a]
        acc = np.zeros((idx.size, N), dtype=np.float32)
        for name in ("tabdiff", "coldiff"):
            if w[name] <= 0:
                continue
            M = (td if name == "tabdiff" else cd)[idx]
            acc += w[name] * M
        for name in ("namehit", "valhit", "fkhit"):
            if w[name] <= 0:
                continue
            acc += w[name] * feat_of[name][idx]
        if w["bm25"] > 0:
            acc += w["bm25"] * rec["bn"][None, :]
        if agg == "geo":
            m = np.exp((iw[:, None] * np.log(acc + EPS)).sum(axis=0) / max(iw.sum(), 1e-6))
        else:
            m = (iw[:, None] * acc).sum(axis=0) / max(iw.sum(), 1e-6)
        return np.asarray(m, dtype=np.float32)

    def evaluate(w, a, agg, K, want_labels=False):
        n_dec, n_stable, hits1, hits5 = 0, 0, [], []
        acc_ok = 0
        lp_sum = 0.0
        for qi, rec in enumerate(per_q):
            m = score_tables(qi, w, a, agg)
            cands = np.argsort(-rec["b"])[:min(K, N)] if K < N else np.arange(N)
            order = cands[np.argsort(-m[cands])]
            t1 = order[0]
            stable = True
            for k in keeps:
                cc = cands[k[cands]]
                if cc.size == 0 or cc[np.argmax(m[cc])] != t1:
                    stable = False
                    break
            dec = bool(rec["cert"][t1])
            n_stable += stable
            n_dec += (stable and dec)
            lp_sum += (float(rec["lp"][t1]) if stable else 0.0)
            if want_labels:
                gset = rec["gold"]
                ids = cat.table_ids
                hits1.append(1.0 if ids[t1] in gset else 0.0)
                hits5.append(sum(1 for t in order[:5] if ids[t] in gset) / max(1, len(gset)))
                acc_ok += 1 if (dec and ids[t1] in gset) else 0
        j = lp_sum / len(per_q) if OBJECTIVE == "strength" else n_dec / len(per_q)
        if want_labels:
            return j, {"J": round(j, 4), "decisive_and_stable": n_dec, "stable": n_stable,
                       "n": len(per_q), "r1": round(float(np.mean(hits1)), 4),
                       "r5": round(float(np.mean(hits5)), 4),
                       "decisive_correct": acc_ok}
        return j

    # ---- coordinate ascent ----
    best = {"w": {f: 0.5 for f in FEATS}, "a": 0.85, "agg": "geo", "K": 30}
    best["J"] = evaluate(best["w"], best["a"], best["agg"], best["K"])
    trace = []
    for sweep in range(3):
        for a in alphas:
            for agg in ("geo", "lin"):
                for K in KS:
                    j = evaluate(best["w"], a, agg, K)
                    trace.append({"sweep": sweep, "a": a, "agg": agg, "K": K, "J": round(j, 4)})
                    if j > best["J"] + 1e-9:
                        best.update({"a": a, "agg": agg, "K": K, "J": j})
        for name in FEATS:
            for v in GRID:
                if v == best["w"][name]:
                    continue
                trial = dict(best["w"])
                trial[name] = v
                j = evaluate(trial, best["a"], best["agg"], best["K"])
                trace.append({"sweep": sweep, "feat": name, "v": v, "J": round(j, 4)})
                if j > best["J"] + 1e-9:
                    best.update({"w": trial, "J": j})
        print(f"sweep {sweep}: J={best['J']:.4f} a={best['a']} agg={best['agg']} K={best['K']} "
              f"w={ {k: round(v,2) for k,v in best['w'].items()} } "
              f"({time.time()-t0:.0f}s)", flush=True)

    j, lab = evaluate(best["w"], best["a"], best["agg"], best["K"], want_labels=True)
    # reference points, computed the same way with labels (never used for selection)
    hand = {"w": {"tabdiff": 0.0, "coldiff": 1.0, "namehit": 0.0, "valhit": 0.0,
                  "fkhit": 0.0, "bm25": 0.0}, "a": 0.85, "agg": "geo", "K": 30}
    _, hand_lab = evaluate(hand["w"], hand["a"], hand["agg"], hand["K"], want_labels=True)
    dense_lab = None
    if EMB.exists():
        z = np.load(EMB, allow_pickle=True)
        ids = list(z["ids"])
        Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
        qpos = {q: i for i, q in enumerate(list(z["qids"]))}
        r1, r5 = [], []
        for c in cases:
            if c["qid"] not in qpos:
                continue
            gset = {f"{c['db_id']}::{t}" for t in c["gold"]}
            order = [ids[i] for i in np.argsort(-(Dm @ Qm[qpos[c["qid"]]]))]
            r1.append(1.0 if order[0] in gset else 0.0)
            r5.append(sum(1 for t in order[:5] if t in gset) / max(1, len(gset)))
        dense_lab = {"r1": round(float(np.mean(r1)), 4), "r5": round(float(np.mean(r5)), 4)}

    out = {"objective": {"name": OBJECTIVE, "labels_used": False,
           "binary": "fraction DECISIVE and STABLE",
           "strength": "mean nats above chance (whole doc + identifiers, capped 40) x STABLE"},
           "lambda2": round(lam, 4), "alphas": alphas,
           "best": {"J": round(best["J"], 4), "weights": best["w"], "alpha": best["a"],
                    "agg": best["agg"], "K": best["K"], "labels": lab},
           "handwritten_reference": {"J": evaluate(hand["w"], hand["a"], hand["agg"], hand["K"]),
                                     "weights": hand["w"], "alpha": 0.85, "agg": "geo", "K": 30,
                                     "labels": hand_lab},
           "dense_reference": dense_lab,
           "n_evals": len(trace), "trace": trace,
           "elapsed_s": round(time.time() - t0, 1)}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: out[k] for k in ("best", "handwritten_reference", "dense_reference",
                                          "n_evals", "elapsed_s")}, indent=1, ensure_ascii=False))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
