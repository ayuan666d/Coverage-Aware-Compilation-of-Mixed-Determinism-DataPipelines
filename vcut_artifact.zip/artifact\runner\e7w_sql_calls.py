"""E7w: fresh text-to-SQL calls with a cloud model (qwen-plus).

Writes a prediction file in the format expected by `e7_sql_pilot.py` so the
same structural checker scores our own model outputs, not only the predictions
shipped with BIRD.
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import os
import re
import sqlite3
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
BIRD = REPO / "04_数据" / "external" / "bird"
GOLD = BIRD / "mini_dev_sqlite_2025.json"
DB_ROOT = BIRD / "minidev" / "MINIDEV" / "dev_databases"
OUT_PRED = BIRD / "preds" / "predict_mini_dev_qwenplus_sqlite.json"
OUT_RAW = REPO / "06_结果" / "e7w_sql_qwenplus_raw.json"
HOST = "https://ws-8fbno0c0h3isjc0g.cn-beijing.maas.aliyuncs.com/compatible-mode/v1"
MODEL = "qwen-plus"
SYS = ("You translate a question into one SQLite query. Return only the SQL "
       "query, starting with SELECT or WITH. No explanation, no markdown.")


def key() -> str:
    p = glob.glob(os.path.expanduser("~/Downloads/*apiKey*.csv"))[0]
    return dict(csv.reader(open(p, encoding="utf-8-sig")))["apiKey"]


def schema(db: Path) -> str:
    con = sqlite3.connect(db)
    tabs = [r[0] for r in con.execute(
        "select name from sqlite_master where type='table' and name not like 'sqlite_%'")]
    out = []
    for t in tabs:
        cols = [f"{r[1]} {r[2]}" for r in con.execute(f'pragma table_info("{t}")')]
        out.append(f"CREATE TABLE {t} ({', '.join(cols)});")
    con.close()
    return "\n".join(out)


def extract(text: str) -> str:
    m = re.search(r"```(?:sql)?\s*(.*?)```", text, re.S | re.I)
    s = m.group(1) if m else text
    m = re.search(r"(?is)\b(select|with)\b.*", s)
    s = m.group(0) if m else s
    return s.strip().rstrip(";").strip()


def call(k: str, prompt: str, timeout: int = 90) -> dict:
    body = json.dumps({
        "model": MODEL,
        "messages": [{"role": "system", "content": SYS},
                     {"role": "user", "content": prompt}],
        "temperature": 0, "max_tokens": 700,
    }).encode()
    req = urllib.request.Request(HOST + "/chat/completions", data=body,
                                 headers={"Authorization": f"Bearer {k}",
                                          "Content-Type": "application/json"},
                                 method="POST")
    last = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                d = json.loads(r.read())
            return {"text": (d["choices"][0]["message"]["content"] or ""),
                    "usage": d.get("usage") or {}}
        except Exception as e:  # noqa: BLE001
            last = f"{type(e).__name__}: {e}"
            time.sleep(1.5 * (attempt + 1))
    return {"text": "", "error": last, "usage": {}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=500)
    ap.add_argument("--workers", type=int, default=8)
    args = ap.parse_args()
    k = key()
    cases = json.load(open(GOLD, encoding="utf-8"))[:args.limit]
    prompts = []
    for c in cases:
        db = DB_ROOT / c["db_id"] / f"{c['db_id']}.sqlite"
        prompts.append(f"Schema:\n{schema(db)}\n\nQuestion: {c['question']}\n"
                       f"Evidence: {c.get('evidence', '')}\n\nSQL:")
    preds, raws = {}, {}
    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(call, k, p): i for i, p in enumerate(prompts)}
        for n, fut in enumerate(as_completed(futs), 1):
            i = futs[fut]
            r = fut.result()
            sql = extract(r.get("text", ""))
            preds[str(i)] = sql
            raws[str(i)] = r
            if n % 50 == 0:
                print(f"{n}/{len(prompts)} {time.perf_counter()-t0:.0f}s", flush=True)
    json.dump(preds, open(OUT_PRED, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(raws, open(OUT_RAW, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    errs = sum(1 for r in raws.values() if r.get("error"))
    empty = sum(1 for s in preds.values() if not s)
    print(json.dumps({"n": len(preds), "errors": errs, "empty_sql": empty,
                      "seconds": round(time.perf_counter() - t0, 1),
                      "out": str(OUT_PRED)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
