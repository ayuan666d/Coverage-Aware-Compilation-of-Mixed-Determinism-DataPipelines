"""Report the prose weight of each section of a LaTeX paper (floats excluded)."""
import re
import sys


def strip_floats(s: str) -> str:
    out = []
    i = 0
    pat = re.compile(r"\\begin\{(table|figure|equation|align)\*?\}")
    while True:
        m = pat.search(s, i)
        if not m:
            out.append(s[i:])
            break
        out.append(s[i:m.start()])
        env = m.group(1)
        end = re.compile(r"\\end\{" + env + r"\*?\}")
        e = end.search(s, m.end())
        i = e.end() if e else len(s)
    return "".join(out)


def main(path):
    s = open(path, encoding="utf-8").read()
    body = s.split("\\bibliographystyle")[0]
    body = strip_floats(body)
    # split at top-level sections
    parts = re.split(r"(?=\\section\{)", body)
    total = 0
    rows = []
    for p in parts:
        m = re.match(r"\\section\{([^}]*)\}", p)
        name = m.group(1) if m else "(front)"
        txt = re.sub(r"%.*", "", p)
        txt = re.sub(r"\\(cite[a-z]*|ref|label)\{[^}]*\}", "", txt)
        txt = re.sub(r"\\[a-zA-Z]+", "", txt)
        words = len(re.findall(r"[A-Za-z][A-Za-z'\-]+", txt))
        rows.append((name, words))
        total += words
    for n, w in rows:
        print(f"{w:6d}  {n}")
    print(f"{total:6d}  TOTAL")


if __name__ == "__main__":
    main(sys.argv[1])
