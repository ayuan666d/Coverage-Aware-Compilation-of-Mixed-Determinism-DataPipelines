"""E7d: learn schema-linking guards from past corrected SQL.

Each historical case carries a question and the SQL a human accepted.  The
learner extracts "question token -> column/table" associations from those
corrected queries and turns them into deterministic guards: if a test question
contains a token whose learned target is absent from the candidate SQL, send
it to review.  This is the SQL analogue of repairing a decision table from a
case bank: history supplies the prior, a held-out split measures transfer.
"""
from __future__ import annotations

import json
import math
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e7_sql_pilot as e7  # noqa: E402
import e7c_guards as e7c  # noqa: E402

REPO = e7.REPO
OUT = REPO / "06_结果" / "e7d_schema_link.json"

STOP = set("""a an the of in on at to for from by with and or is are was were be been
what which who whom whose how many much number count list give name names show find
all any each every that this these those it its their there here as than then
between during after before over under more most less least high higher highest low
lower lowest top first last time times year years month day date value values
please return select where group order limit""".split())


def tokens(q: str) -> list[str]:
    ws = re.findall(r"[a-zA-Z][a-zA-Z0-9_]+", q.lower())
    return [w for w in ws if len(w) >= 3 and w not in STOP]


def sql_refs(sql: str) -> tuple[set[str], set[str]]:
    """Return (tables, columns) referenced by a SQL statement."""
    try:
        import sqlglot
        from sqlglot import exp

        tree = sqlglot.parse_one(sql, read="sqlite")
        tables = {t.name.lower() for t in tree.find_all(exp.Table) if t.name}
        cols = {c.name.lower() for c in tree.find_all(exp.Column) if c.name}
        return tables, cols
    except Exception:
        s = sql.lower()
        tables = set(re.findall(r"(?:from|join)\s+[\"'`\[]?(\w+)", s))
        cols = set(re.findall(r"(?:\.|^|\s)([a-z_][a-z0-9_]*)", s))
        return tables, cols


def mine(train: list[dict], min_support=3, min_prec=0.75, min_lift=1.5):
    """token -> (target, precision, support, lift) for columns and tables."""
    tok_n = Counter()
    pair_c = Counter()
    col_n = Counter()
    for e in train:
        ts = set(tokens(e["question"]))
        tabs, cols = sql_refs(e["gold"])
        for t in ts:
            tok_n[t] += 1
            for c in cols:
                pair_c[(t, "col", c)] += 1
            for tb in tabs:
                pair_c[(t, "tab", tb)] += 1
        for c in cols:
            col_n[("col", c)] += 1
        for tb in tabs:
            col_n[("tab", tb)] += 1
    rules = defaultdict(list)
    N = len(train)
    for (t, kind, target), c in pair_c.items():
        if tok_n[t] < min_support:
            continue
        prec = c / tok_n[t]
        lift = prec / (col_n[(kind, target)] / max(1, N))
        if prec >= min_prec and lift >= min_lift:
            rules[t].append((kind, target, prec, c, lift))
    for t in rules:
        rules[t].sort(key=lambda x: (-x[2], -x[3]))
        rules[t] = rules[t][:3]
    return dict(rules)


def guard_hit(e: dict, rules: dict) -> str:
    ts = set(tokens(e["question"]))
    tabs, cols = sql_refs(e["sql"])
    for t in ts:
        for kind, target, prec, sup, lift in rules.get(t, []):
            pool = cols if kind == "col" else tabs
            if target not in pool:
                return f"{t}->{kind}:{target} missing (p={prec:.2f})"
    return ""


def eval_rules(test: list[dict], rules: dict):
    fp = caught_wrong = caught_correct = accepted = 0
    for e in test:
        hit = guard_hit(e, rules)
        if hit:
            if e["correct"]:
                caught_correct += 1
            else:
                caught_wrong += 1
        else:
            accepted += 1
            if not e["correct"]:
                fp += 1
    n = len(test)
    return {
        "n": n, "accepted": accepted, "automation": round(accepted / n, 4),
        "caught_wrong": caught_wrong, "caught_correct": caught_correct,
        "false_pass": fp, "false_pass_rate": round(fp / n, 4),
        "precision": round((accepted - fp) / accepted, 4) if accepted else None,
    }


def run(kind: str, seed: int = 0):
    import random
    exs = e7c.build_examples(kind)
    by_db = defaultdict(list)
    for e in exs:
        by_db[e["db"]].append(e)
    per_db = {}
    pooled = {"n": 0, "false_pass": 0, "accepted": 0, "caught_correct": 0, "caught_wrong": 0}
    pooled_base = {"n": 0, "false_pass": 0, "accepted": 0}
    for db, es in by_db.items():
        if len(es) < 4:
            continue
        rnd = random.Random(f"{seed}:{db}")
        idx = list(range(len(es)))
        rnd.shuffle(idx)
        cut = len(idx) // 2
        train = [es[i] for i in idx[:cut]]
        test = [es[i] for i in idx[cut:]]
        rules = mine(train)
        m = eval_rules(test, rules)
        m["base"] = eval_rules(test, {})
        m["n_rules"] = sum(len(v) for v in rules.values())
        per_db[db] = m
        for k in ("n", "false_pass", "accepted", "caught_correct", "caught_wrong"):
            pooled[k] += m[k]
        pooled_base["n"] += m["base"]["n"]
        pooled_base["false_pass"] += m["base"]["false_pass"]
        pooled_base["accepted"] += m["base"]["accepted"]
    for d in (pooled, pooled_base):
        n = d["n"]
        d["automation"] = round(d["accepted"] / n, 4) if n else 0
        d["false_pass_rate"] = round(d["false_pass"] / n, 4) if n else 0
        d["precision"] = round((d["accepted"] - d["false_pass"]) / d["accepted"], 4) if d["accepted"] else None
    return {"kind": kind, "per_db": per_db, "pooled": pooled, "pooled_base": pooled_base}


def main():
    out = {}
    for kind in ("all", "top5", "top3"):
        out[kind] = run(kind)
        print(kind, "base", out[kind]["pooled_base"])
        print(kind, "guarded", out[kind]["pooled"])
        for db, m in out[kind]["per_db"].items():
            print(f"  {db:32s} n={m['n']:3d} rules={m['n_rules']:2d} "
                  f"fp {m['base']['false_pass']}->{m['false_pass']} "
                  f"auto {m['automation']:.2f} prec {m['precision']}")
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print("wrote", OUT)


if __name__ == "__main__":
    main()
