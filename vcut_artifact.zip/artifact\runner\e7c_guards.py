"""E7c: history-guided semantic guards on top of execution consensus.

The structural checks of E7 are pure rejectors: they remove broken SQL but
cannot separate a wrong answer that executes from a right one.  Consensus adds
redundancy, yet the residual errors are *shared misconceptions*.  This script
mines a small library of question/result/schema guards from a training split
and tests whether the mined guards transfer to held-out questions.

Guards are evaluated as deterministic predicates.  A guard is only admitted if,
on the training split, it rejects more wrong consensus answers than correct
ones; the admitted set is then frozen and applied to the test split.
"""
from __future__ import annotations

import json
import re
import sqlite3
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e7_sql_pilot as e7  # noqa: E402

REPO = e7.REPO
OUT = REPO / "06_结果" / "e7c_guards.json"
CONS = REPO / "06_结果" / "e7b_consensus.json"

SCHEMA_CACHE: dict[str, dict] = {}


def schema(db_path: str) -> dict:
    if db_path in SCHEMA_CACHE:
        return SCHEMA_CACHE[db_path]
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    tables = {}
    for (name,) in conn.execute("SELECT name FROM sqlite_master WHERE type='table'"):
        cols = {}
        for cid, cname, ctype, notnull, dflt, pk in conn.execute(f'PRAGMA table_info("{name}")'):
            cols[cname.lower()] = (ctype or "").upper()
        tables[name.lower()] = cols
    conn.close()
    SCHEMA_CACHE[db_path] = tables
    return tables


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()


def sql_norm(sql: str) -> str:
    return norm(re.sub(r"[`\"\[\]]", "", sql))


def quoted_literals(text: str) -> list[str]:
    out = re.findall(r"'([^']{2,80})'", text)
    out += re.findall(r'"([^"]{2,80})"', text)
    # capitalized multiword phrases (entities) are noisy; skip for now
    return [x for x in out if len(x.strip()) > 1]


def years(text: str) -> list[str]:
    return re.findall(r"\b(?:19|20)\d{2}\b", text)


def date_literals(text: str) -> list[str]:
    return re.findall(r"\b(?:19|20)\d{2}[-/]\d{1,2}[-/]\d{1,2}\b", text)


CUES = {
    "count": re.compile(r"\b(how many|number of|count)\b", re.I),
    "bool": re.compile(r"^\s*(was|is|are|were|does|did|do|has|have|can|could|will)\b", re.I),
    "list": re.compile(r"\b(list|give|name|what are|which are|show|find all|identify)\b", re.I),
    "super": re.compile(r"\b(most|highest|lowest|least|maximum|minimum|top|largest|smallest)\b", re.I),
    "avg": re.compile(r"\b(average|mean)\b", re.I),
    "ratio": re.compile(r"\b(ratio|percentage|share|proportion|rate)\b", re.I),
    "owner": re.compile(r"\b(owner|posted|author|created by)\b", re.I),
    "last_editor": re.compile(r"\b(last editor|last edited|edited last|last time)\b", re.I),
    "distinct": re.compile(r"\b(different|distinct|unique)\b", re.I),
}


def cues(q: str) -> dict:
    return {k: bool(v.search(q)) for k, v in CUES.items()}


def sql_features(sql: str) -> dict:
    s = re.sub(r"'(?:''|[^'])*'", "''", sql).lower()
    return {
        "distinct": bool(re.search(r"\bdistinct\b", s)),
        "group": bool(re.search(r"\bgroup\s+by\b", s)),
        "order": bool(re.search(r"\border\s+by\b", s)),
        "limit": bool(re.search(r"\blimit\b", s)),
        "agg": bool(re.search(r"\b(count|sum|avg|min|max)\s*\(", s)),
        "count_distinct": bool(re.search(r"count\s*\(\s*distinct\b", s)),
        "date_func": bool(re.search(r"\b(date|strftime|datetime|julianday)\s*\(", s)),
        "joins": len(re.findall(r"\bjoin\b", s)),
        "subquery": s.count("select") - 1,
        "union": bool(re.search(r"\bunion\b", s)),
    }


def join_pairs(sql: str) -> set[tuple[str, str]]:
    pairs = set()
    for m in re.finditer(
        r"(?:from|join)\s+[\"'`\[]?(\w+)[\"'`\]]?(?:\s+(?:as\s+)?(\w+))?", sql, re.I
    ):
        pass
    # capture equality comparisons of the form a.x = b.y
    for m in re.finditer(r"(\w+)\.(\w+)\s*=\s*(\w+)\.(\w+)", sql):
        pairs.add((m.group(1).lower(), m.group(2).lower()))
        pairs.add((m.group(3).lower(), m.group(4).lower()))
    return pairs


def result_features(res: e7.ExecResult) -> dict:
    rows = res.rows
    ncols = len(rows[0]) if rows else 0
    vals = [c for row in rows for c in row if c is not None]
    nums = [c for c in vals if isinstance(c, (int, float)) and not isinstance(c, bool)]
    return {
        "empty": len(rows) == 0,
        "n_rows": len(rows),
        "n_cols": ncols,
        "has_null": any(c is None for row in rows for c in row),
        "all_numeric": bool(vals) and len(nums) == len(vals),
        "all_integer": bool(nums) and all(float(x).is_integer() for x in nums),
        "min": min(nums) if nums else None,
        "max": max(nums) if nums else None,
        "n_values": len(vals),
    }


# --------------------------------------------------------------------------
# Guard library.  Each returns a reason string if it fires (=> review), else "".
# --------------------------------------------------------------------------

def g_empty_nonlist(q, sql, resf, sf, cf, sch, pairs, qlit, qyears, qdates):
    if resf["empty"] and not cf["list"] and not cf["super"]:
        return "empty result for a non-list question"
    return ""


def g_count_shape(q, sql, resf, sf, cf, sch, pairs, qlit, qyears, qdates):
    if cf["count"] and not cf["ratio"]:
        if resf["n_rows"] != 1 or resf["n_cols"] != 1 or not resf["all_numeric"]:
            return "count question but result is not one number"
    return ""


def g_bool_shape(q, sql, resf, sf, cf, sch, pairs, qlit, qyears, qdates):
    if cf["bool"] and (resf["n_rows"] > 1 or resf["n_cols"] != 1):
        return "yes/no question but result is not one column"
    return ""


def g_ratio_range(q, sql, resf, sf, cf, sch, pairs, qlit, qyears, qdates):
    if cf["ratio"] and resf["all_numeric"] and resf["n_rows"] == 1:
        lo, hi = resf["min"], resf["max"]
        if lo is not None and hi is not None:
            if hi > 100.5 or lo < -0.0001:
                return f"ratio outside [0,100]: {lo}..{hi}"
    return ""


def g_literal_missing(q, sql, resf, sf, cf, sch, pairs, qlit, qyears, qdates):
    s = sql_norm(sql)
    for lit in qlit:
        n = norm(lit)
        if n and n not in s:
            return f"question literal not in SQL: {lit[:40]}"
    return ""


def g_year_missing(q, sql, resf, sf, cf, sch, pairs, qlit, qyears, qdates):
    s = sql_norm(sql)
    for y in qyears:
        if y not in s:
            return f"year not in SQL: {y}"
    return ""


def g_date_affinity(q, sql, resf, sf, cf, sch, pairs, qlit, qyears, qdates):
    if not qdates:
        return ""
    # find a date-ish column compared to a slash-formatted literal without a date function
    if sf["date_func"]:
        return ""
    has_slash = any("/" in d for d in qdates)
    if not has_slash:
        return ""
    for lit in qdates:
        if lit in sql:
            return "date column compared as raw string"
    return ""


def g_owner_join(q, sql, resf, sf, cf, sch, pairs, qlit, qyears, qdates):
    if not cf["owner"] or cf["last_editor"]:
        return ""
    # joins users but no owner-ish column anywhere
    uses_users = any(t in sch for t, _ in pairs) and "users" in sch
    if uses_users:
        cols = " ".join(c for _, c in pairs)
        if "owner" not in cols and "owner" not in sql_norm(sql):
            return "owner question, but join does not use an owner column"
    return ""


def g_last_editor_join(q, sql, resf, sf, cf, sch, pairs, qlit, qyears, qdates):
    if cf["last_editor"]:
        cols = " ".join(c for _, c in pairs)
        if "owner" in cols and "editor" not in cols:
            return "last-editor question, but join uses owner column"
    return ""


def g_distinct_count(q, sql, resf, sf, cf, sch, pairs, qlit, qyears, qdates):
    if cf["count"] and cf["distinct"] and not sf["count_distinct"]:
        return "distinct count without COUNT(DISTINCT)"
    return ""


GUARDS = [
    g_empty_nonlist,
    g_count_shape,
    g_bool_shape,
    g_ratio_range,
    g_literal_missing,
    g_year_missing,
    g_date_affinity,
    g_owner_join,
    g_last_editor_join,
    g_distinct_count,
]


def build_examples(kind: str):
    d = json.load(CONS.open(encoding="utf-8"))
    rows = d["rows"]
    top5 = d["top_models"][:5]
    top3 = d["top_models"][:3]
    out = []
    for r in rows:
        names = {"all": list(r["models"]),
                 "top5": [m for m in top5 if m in r["models"]],
                 "top3": [m for m in top3 if m in r["models"]]}[kind]
        votes = Counter()
        reps = {}
        for m in names:
            v = r["models"][m]
            if v["ok"] and v["sig"]:
                votes[v["sig"]] += 1
                reps.setdefault(v["sig"], (m, v["sql"]))
        if not votes:
            continue
        sig, n = votes.most_common(1)[0]
        # unanimous / majority according to the same rule as E7b
        if kind == "all" and len(votes) != 1:
            continue
        if kind == "top5" and n < max(2, int(0.8 * len(names) + 0.999999)):
            continue
        if kind == "top3" and n < max(2, int(0.8 * len(names) + 0.999999)):
            continue
        model, sql = reps[sig]
        case = next(c for c in e7.load_cases() if c["idx"] == r["idx"])
        res = e7.execute(case["db_path"], sql, timeout=8.0)
        sch = schema(case["db_path"])
        out.append({
            "idx": r["idx"], "db": r["db"], "difficulty": r["difficulty"],
            "question": r["question"], "sql": sql, "gold": r["gold_sql"],
            "gold_sig": r["gold_sig"], "sig": sig, "correct": sig == r["gold_sig"],
            "resf": result_features(res), "sf": sql_features(sql),
            "cf": cues(r["question"]), "sch": sch, "pairs": join_pairs(sql),
            "qlit": quoted_literals(r["question"]), "qyears": years(r["question"]),
            "qdates": date_literals(r["question"]),
        })
    return out


def evaluate_guard(g, exs, admitted=None):
    wrong = correct = 0
    for e in exs:
        if admitted is not None and g not in admitted:
            continue
        reason = g(e["question"], e["sql"], e["resf"], e["sf"], e["cf"],
                   e["sch"], e["pairs"], e["qlit"], e["qyears"], e["qdates"])
        if reason:
            if e["correct"]:
                correct += 1
            else:
                wrong += 1
    return wrong, correct


def greedy(train, candidates, max_guards=6):
    admitted = []
    remaining = set(candidates)
    best_prev = 0
    while remaining and len(admitted) < max_guards:
        best = None
        for g in remaining:
            # marginal on cases not already caught by admitted guards
            trial = admitted + [g]
            wrong = correct = 0
            for e in train:
                hit = False
                for gg in trial:
                    if gg(e["question"], e["sql"], e["resf"], e["sf"], e["cf"],
                          e["sch"], e["pairs"], e["qlit"], e["qyears"], e["qdates"]):
                        hit = True
                        break
                if hit:
                    if e["correct"]:
                        correct += 1
                    else:
                        wrong += 1
            score = wrong - 2.0 * correct
            if best is None or score > best[0]:
                best = (score, g, wrong, correct)
        if best is None or best[0] <= 0:
            break
        score, g, wrong, correct = best
        admitted.append(g)
        remaining.discard(g)
        print(f"  + {g.__name__}: cumulative wrong={wrong} correct={correct} score={score}")
    return admitted


def metrics(exs, admitted):
    caught_wrong = caught_correct = 0
    fp = 0
    accepted = 0
    for e in exs:
        hit = any(g(e["question"], e["sql"], e["resf"], e["sf"], e["cf"],
                    e["sch"], e["pairs"], e["qlit"], e["qyears"], e["qdates"])
                  for g in admitted)
        if hit:
            if e["correct"]:
                caught_correct += 1
            else:
                caught_wrong += 1
        else:
            accepted += 1
            if not e["correct"]:
                fp += 1
    n = len(exs)
    return {
        "n": n, "accepted": accepted, "automation": round(accepted / n, 4),
        "caught_wrong": caught_wrong, "caught_correct": caught_correct,
        "false_pass": fp, "false_pass_rate": round(fp / n, 4),
        "precision": round((accepted - fp) / accepted, 4) if accepted else None,
    }


def run(kind: str, split: str, seed: int = 0):
    import random
    exs = build_examples(kind)
    if split == "random":
        rnd = random.Random(seed)
        idx = list(range(len(exs)))
        rnd.shuffle(idx)
        cut = len(idx) // 2
        train = [exs[i] for i in idx[:cut]]
        test = [exs[i] for i in idx[cut:]]
    else:  # leave-one-db-out: hold out the db with the most accepted errors
        dbs = sorted({e["db"] for e in exs})
        results = []
        for db in dbs:
            train = [e for e in exs if e["db"] != db]
            test = [e for e in exs if e["db"] == db]
            if len(test) < 5 or len([e for e in test if not e["correct"]]) < 2:
                continue
            admitted = greedy(train, GUARDS)
            m = metrics(test, admitted)
            m["db"] = db
            m["guards"] = [g.__name__ for g in admitted]
            results.append(m)
        return results

    admitted = greedy(train, GUARDS)
    base_train = metrics(train, [])
    base_test = metrics(test, [])
    m_train = metrics(train, admitted)
    m_test = metrics(test, admitted)
    per_guard = {}
    for g in GUARDS:
        w, c = evaluate_guard(g, train)
        per_guard[g.__name__] = {"wrong": w, "correct": c,
                                 "precision": round(w / (w + c), 3) if w + c else None}
    return {
        "kind": kind, "split": split, "n_train": len(train), "n_test": len(test),
        "admitted": [g.__name__ for g in admitted],
        "per_guard_train": per_guard,
        "train_base": base_train, "train_guarded": m_train,
        "test_base": base_test, "test_guarded": m_test,
    }


def main():
    out = {}
    for kind in ("all", "top5", "top3"):
        out[kind] = run(kind, "random", seed=0)
        print(kind, json.dumps(out[kind]["test_guarded"], ensure_ascii=False))
    # leave-one-db-out on the strictest consensus
    out["lodo_all"] = run("all", "lodo")
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print("\nwrote", OUT)
    for r in out["lodo_all"]:
        print(r["db"], r["n"], r["base_fp"] if "base_fp" in r else "", r["false_pass"], r["automation"], r["guards"])


if __name__ == "__main__":
    main()
