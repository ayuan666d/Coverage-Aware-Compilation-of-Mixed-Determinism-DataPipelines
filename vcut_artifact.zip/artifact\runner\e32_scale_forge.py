"""E32：14 原语闭式（FORGE）的规模压力测试 —— 876 / 951 / 4k / 10k。

目的：回答 E28 §5 的问题——把 876 上已验证 60.12 / 93.60 的原语集放到 10k 目录，
      在「参数编译一次、规模期只打分」的约束下还能保住多少。

与 E31 的关系：E31 用 19 维自研特征（含 graph / dl / namecol 等 7 个非原语通道），
876 起点只有 53.67，够不到目标线 55。E32 把特征裁回 14 原语，口径对齐 z_split341
的 cv_fisher（分块 Fisher 闭式 + 二次交互 + 逐题 z 标准化 + 库级后验 β）。

协议（对应 E28_规模压力.md §5.2）：
1. 特征 = 14 原语 = z_allfeat 的 12 通道 + 2 个数值 zone map 通道，二次交互后 119 维。
2. 通道 10（exact evidence）置 0：`e12_exact.json` 的 pool 只含 876 真实 fid，
   对合成表恒 0 会构成「缺通道 = 合成表」的生成器指纹。
3. 通道 11（库名重叠）改为**用源表库名**计算：合成表的 db 是人工名 synthNNNNN，
   问句永不命中；若直接用目录 db 名，同样是指纹。改为继承其列来源的真实库名。
4. NF（值域 zone map）对合成表**继承源表**的真实 MIN/MAX：合成表由源表列拼成，
   不继承就会变成「有值域 = 真实表」的指纹。
5. 编译锚定受信核心：μ/σ、Fisher 权重 w、β 全部只在**真实表** × 693 训练问上拟合。
   合成表只参与打分，不进入任何统计量。因此 4k/10k 与 951 共用同一组参数。
6. 超参跨规模固定：β 在 951 上选一次，4k/10k 强制复用（禁止逐点重选）。
7. 确定性 tie-break：`lexsort((doc_id, -score))`，消除 argsort 在长数组上的 tie 抖动。

输出：D:\\vldb2027_e11\\e32_scale_forge.json
"""
from __future__ import annotations

import gc
import hashlib
import json
import os
import random
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
import e28_scale as s28  # noqa: E402
import e31_scale_supervised as e31  # noqa: E402
from e40_legacy import legacy_tables  # noqa: E402

WORK = Path(r"D:\vldb2027_e11")
REPO = Path(__file__).resolve().parents[2]
# 运行变体："" 纯原语（旧 341 问集） / "g" 追图通道 / "b0" β=0 对照
#          "big" 扩大评估集（E35：1681 问 / 33 库）
_VARIANT = sys.argv[2] if len(sys.argv) > 2 else ""
BIG = _VARIANT == "big"
CASES = REPO / "06_结果" / ("e35_cases.json" if BIG else "e11_cases.json")
# 诊断用：环境变量可覆盖输入集与输出文件，避免为每个对照组新增变体
if os.environ.get("E32_CASES"):
    CASES = Path(os.environ["E32_CASES"])
OUT = WORK / {"g": "e33_scale_forge_graph.json",
              "b0": "e34_scale_forge_beta0.json",
              "big": "e36_scale_forge_big.json",
              "legacy": "e41_scale_legacy.json"}.get(_VARIANT, "e32_scale_forge.json")
if os.environ.get("E32_OUT"):
    OUT = Path(os.environ["E32_OUT"])

# E31 的 19 维特征 → 14 原语的索引映射（None = 该原语在规模实验中被移除）
KEEP = [
    0,     # 原语 0  |qset ∩ all|                    ← f0
    1,     # 原语 1  idf 加权重叠                     ← f1
    16,    # 原语 2  stem4 重叠                       ← fst
    7,     # 原语 3  BM25 式 tf 分数                  ← bm
    14,    # 原语 4  词 latent 余弦                   ← sw
    15,    # 原语 5  字符 gram 余弦                   ← sc
    2,     # 原语 6  表名重叠                         ← f2
    3,     # 原语 7  列名重叠                         ← f3
    4,     # 原语 8  值重叠                           ← f4
    5,     # 原语 9  log1p(6)·log1p(7)·log1p(8)      ← f9
    None,  # 原语 10 exact evidence（移除，见协议 2）
    6,     # 原语 11 库名重叠（值被源表库名覆盖，见协议 3）← f11
    17,    # NF0     数值覆盖比例                     ← fnum
    18,    # NF1     全落域标记                       ← fall
]

# 变体："+g" 追加 E31 的图通道（逐 token PPR 重排分数）。
# E32 纯原语集 R@1 强、R@5 弱；E31 的 19 维含 graph，10k 上 R@5 明显更高。
# 本变体用来判断 55/90 目标里的 R@5 缺口是否由「缺图通道」造成。
KEEP_G = KEEP + [8]  # 8 = graph

FULL = _VARIANT == "g"
B0 = _VARIANT == "b0"   # β 强制为 0：检验 10k 真实表内的 −0.74pt 是否由库级后验稀释造成
# LEGACY：干扰集换成「遗留副本」（e40）。旧 synth 干扰器有四个一行可识别的指纹
# （synth* 库名/每库恰 40 张/列数恒 5/表名带序号），使 10k 读数在两个方向上都不成立。
LEGACY = _VARIANT == "legacy"
# RICH：perq 追加 rank 级明细（金标全目录 rank / 真实表内 rank / top20 真伪掩码 / margin）。
# E44 的解析式验证需要 951 目录上的**完整 rank 分布**，仅有 R@1/R@5/hit20 三点不够。
# 默认关闭，避免拖慢既有对照跑的 IO。
RICH = os.environ.get("E32_RICH") == "1"
KEEP = KEEP_G if FULL else KEEP
K = len(KEEP)


def fid(db, name):
    """目录唯一标识。**库名与表名必须同时小写**。

    BUG 修复（2026-11-06）：此前 `doc_ids` 用 `t['db']` 原样拼接，而 `gold_of`
    与 `z_num_ranges` 的键是全小写。于是 7 个含大写字母的库
    （cre_Drama_Workshop_Groups / insurance_and_eClaims 等，122 问）gold 永远
    对不上目录 id，R@1 与 R@5 恒为 0；编译期 `id_of` 同样失配，这些库的正
    样本从未参与 Fisher 拟合。旧协议 6 个 test 库恰好全小写，所以从未暴露。
    """
    return f"{str(db).lower()}::{str(name).lower()}"


def synth_tables_src(base, need, seed=42):
    """与 s28.synth_tables 完全相同的 rng 调用序列，额外记录源表 fid。

    不新增任何 rng 调用，因此输出表的 db / name / columns 与 E28 逐字相同
    （由 sig() 校验）。仅追加 "src" 字段。
    """
    rng = random.Random(seed)
    out = []
    for i in range(need):
        srcs = [base[rng.randrange(len(base))] for _ in range(3)]
        w1 = [w for w in srcs[0]["name"].lower().split("_") if w] or ["t"]
        w2 = [w for w in srcs[2]["name"].lower().split("_") if w] or ["x"]
        name = f"{w1[rng.randrange(len(w1))]}_{w2[rng.randrange(len(w2))]}_{i}"
        cols = []
        for src in srcs:
            picked = rng.sample(src["columns"], min(2, len(src["columns"])))
            for c in picked:
                vals = [str(v) for v in (c.get("values") or [])[:2]]
                cols.append({"name": c["name"], "values": vals})
        out.append({"db": f"synth{i // 40:05d}", "name": name, "columns": cols[:5],
                    "src": [fid(s["db"], s["name"]) for s in srcs]})
    return out


def sig(tabs):
    """目录签名：只含 db + name + 列名 + 值，校验与 E28 的干扰表逐字一致。"""
    h = hashlib.sha1()
    for t in tabs:
        h.update(f"{t['db']}|{t['name']}|".encode())
        for c in t["columns"]:
            h.update((str(c["name"]) + "," + ",".join(map(str, c.get("values") or []))
                      + ";").encode())
    return h.hexdigest()[:16]


def zone_of(all_tabs, n_real, raw_ranges):
    """每张表的数值区间：真实表查自身，合成表继承第一个有 range 的源表（协议 4）。"""
    out = []
    for i, t in enumerate(all_tabs):
        if i < n_real:
            cols = raw_ranges.get(fid(t["db"], t["name"])) or {}
        else:
            cols = {}
            for s in (t.get("src") or []):
                cols = raw_ranges.get(s) or {}
                if cols:
                    break
        out.append([(mn, mx) for (mn, mx, nd, nrow) in cols.values()
                    if not (nrow and nd / max(nrow, 1) > 0.98)])
    return out


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(WORK / "schema_cache.json", encoding="utf-8"))
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    train = [c for c in cases if c["split"] == "train"]
    test = [c for c in cases if c["split"] == "test"]
    test_dbs = {c["db_id"] for c in test}
    gold_of = {c["qid"]: {fid(c["db_id"], x) for x in c["gold"]} for c in cases}

    raw_ranges = json.load(open(WORK / "z_num_ranges.json", encoding="utf-8"))

    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += s28.tables_of(cache, db, prefix=True)
        fks += s28.fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    bird = []
    for db, s in cache["bird"].items():
        bird += [dict(t, db=db) for t in s["tables"]]
    # 干扰表来源。**必须与评估集解耦**，否则换一个 test 集就换一套 9049 张合成表，
    # 不同评估集之间的「规模曲线」根本不是同一个目录，不可比。
    #   E32_DONOR=fixed → 全部 876 spider 表 + 75 bird 表，任何 test 集下目录完全一致
    #   （默认）       → 排除 test 库，旧行为；仅适用于固定不变的那一套评估集
    # 代价说明：fixed 模式下约 9% 的干扰表会由 test 库的列拼成。这不是标签泄漏
    # （合成表是新表名、不是金标），且更接近真实目录中「同库存在相似遗留表」的情形。
    if os.environ.get("E32_DONOR") == "fixed":
        donors = tabs + bird
    else:
        donors = [t for t in tabs if t["db"] not in test_dbs] + bird
    print(f"[donor] {len(donors)} 张表（{'固定全集' if os.environ.get('E32_DONOR') == 'fixed' else '排除 test 库'}）",
          flush=True)

    # 1500/2000/3000 是污染曲线的中间点：不为「规模」而测，为的是把
    # R@5 跌破 90 的那个污染率读出来（E39）。
    plans = [(876, "spider"), (951, "951"), (1500, "1500"),
             (2000, "2000"), (3000, "3000"),
             (4000, "4k-syn"), (10000, "10k-syn")]
    targets = ([int(x) for x in sys.argv[1].split(",")] if len(sys.argv) > 1
               else [876, 951, 1500, 2000, 3000, 4000, 10000])
    plans = [p for p in plans if p[0] in targets]
    res = json.load(open(OUT, encoding="utf-8")) if OUT.exists() else {}
    beta_pinned = res.get("_meta", {}).get("beta_pinned")

    for n_target, tag in plans:
        if FULL:
            tag = tag + "+g"
        if LEGACY:
            tag = tag + "-leg"
        t_start = time.perf_counter()
        base = tabs + bird if n_target > len(tabs) else tabs
        n_real = len(base)
        if n_target > n_real:
            if LEGACY:
                # 落库覆盖**全部**库（含测试库），否则"没被塞遗留表的那 20 个库"
                # 就是"含答案的库"，db_size 又变成身份指纹。
                place = {db: len(cache["spider"][db]["tables"]) for db in cache["spider"]}
                place.update({db: len(s["tables"]) for db, s in cache["bird"].items()})
                extra = legacy_tables(donors, n_target - n_real, place=place,
                                      seed=int(os.environ.get("LEGACY_SEED", "40")))
            else:
                extra = synth_tables_src(donors, n_target - n_real)
        else:
            extra = []
        all_tabs = base + extra
        doc_ids = [fid(t["db"], t["name"]) for t in all_tabs]
        doc_ids_np = np.array(doc_ids)

        if LEGACY:
            mode = "遗留副本"
            ok_same = False   # 与 E28 不同构：干扰集换了，sig 校验不适用
        else:
            ok_same = True
            if extra:
                ok_same = sig(extra) == sig(s28.synth_tables(donors, len(extra)))
            mode = f"合成 与E28同构={ok_same}"
        print(f"[{tag}] N={len(all_tabs)} 真实={n_real} 干扰={len(extra)} "
              f"{mode}", flush=True)

        cat = g.Catalog(all_tabs, fks, coquery=None, prefix_db=True)
        C = e31.build_cache(all_tabs, fks, ref_n=n_real)
        C["zone"] = zone_of(all_tabs, n_real, raw_ranges)

        # 库级后验与库名通道都改用「源表库名」（协议 3）；统一小写，否则同一
        # 库会因大小写被拆成两组（posterior 的 bincount 会多出空桶）
        # 遗留副本的 db 是真实库名，就是它实际所在的库；旧合成表的 db 是
        # synth00001 这类占位，没有语义，只能用源表库名代替。
        prov = [(t["db"].lower() if (LEGACY or i < n_real)
                 else (t.get("src") or ["::"])[0].split("::")[0])
                for i, t in enumerate(all_tabs)]
        C["db"] = np.zeros((len(all_tabs), len(C["db_vocab"])), np.float32)
        db_len = np.ones(len(all_tabs), np.float32)
        for i, p in enumerate(prov):
            toks = e31.qtoks(p.replace("_", " ")) or ["_"]
            db_len[i] = max(len(toks), 1)
            for wtok in toks:
                j = C["db_vocab"].get(wtok)
                if j is not None:
                    C["db"][i, j] = 1.0
        C["db_len"] = db_len

        qsets = {c["qid"]: set(g.toks(c["question"])) for c in cases}
        toks = sorted({w for qs in qsets.values() for w in qs if ("token", w) in cat.idx})
        tokmap = {}
        for w in toks:
            x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
            s = cat.table_scores(x)
            mx = float(s.max())
            tokmap[w] = s / mx if mx > 0 else s
        idf_graph = {w: float(C["idf"][C["vocab"][w]]) if w in C["vocab"] else 1.0
                     for w in tokmap}

        def feats14(c):
            X19 = e31.feats(e31.qtoks(c["question"]), e31.qnums(c["question"]),
                            C, tokmap, idf_graph)
            cols = [np.zeros(X19.shape[0], np.float32) if j is None else X19[:, j]
                    for j in KEEP]
            return np.stack(cols, axis=1)

        QI = np.array([(i, j) for i in range(K) for j in range(i, K)])
        DIM = K + len(QI)

        def expand(Xb):
            Xd = Xb.reshape(-1, K)
            return np.concatenate([Xd, Xd[:, QI[:, 0]] * Xd[:, QI[:, 1]]], axis=1)

        # ---- 编译期：μ/σ 与 w 只在真实表 × 693 训练问上拟合 ----
        tr_core = [feats14(c)[:n_real] for c in train]
        mu = np.concatenate(tr_core, axis=0).mean(0)
        sd = np.concatenate(tr_core, axis=0).std(0) + 1e-9
        gc.collect()

        id_of = {fid(t["db"], t["name"]): i for i, t in enumerate(all_tabs[:n_real])}
        A = np.zeros((DIM, DIM), np.float64)
        s_all = np.zeros(DIM, np.float64)
        s_pos = np.zeros(DIM, np.float64)
        n_row = n_pos = 0
        for c, x in zip(train, tr_core):
            Xq = expand(((x - mu) / sd).astype(np.float32))
            A += Xq.T @ Xq
            s_all += Xq.sum(0)
            n_row += len(Xq)
            y = np.zeros(n_real, bool)
            for gt in gold_of[c["qid"]]:
                j = id_of.get(gt)
                if j is not None:
                    y[j] = True
            if y.any():
                s_pos += Xq[y].sum(0)
                n_pos += int(y.sum())
        mu_a = s_all / max(n_row, 1)
        mu_p = s_pos / max(n_pos, 1)
        mu_n = (s_all - s_pos) / max(n_row - n_pos, 1)
        Cov = A / max(n_row, 1) - np.outer(mu_a, mu_a)
        w = np.linalg.solve(Cov + 0.1 * np.eye(DIM), mu_p - mu_n).astype(np.float32)
        del A, s_all, s_pos, tr_core
        gc.collect()

        dbl = {d: i for i, d in enumerate(sorted(set(prov)))}
        DB_IDX = np.array([dbl[p] for p in prov])
        nDB = len(dbl)

        def zs(S):
            return (S - S.mean()) / (S.std() + 1e-9)

        def posterior(S):
            z = S - S.max()
            mass = np.bincount(DB_IDX, weights=np.exp(z), minlength=nDB)
            lg = np.log(mass + 1e-12) + S.max()
            return (lg - lg.mean())[DB_IDX]

        def score(c):
            return zs(expand(((feats14(c) - mu) / sd).astype(np.float32)) @ w)

        def rank(S):
            return np.lexsort((doc_ids_np, -S))

        def ev(S, qid):
            order = rank(S)
            gold = gold_of[qid]
            return (len(set(doc_ids[i] for i in order[:1]) & gold) / len(gold),
                    len(set(doc_ids[i] for i in order[:5]) & gold) / len(gold),
                    len(set(doc_ids[i] for i in order[:20]) & gold) / len(gold),
                    1.0 if doc_ids[order[0]] in gold else 0.0,
                    sum(1 for i in order[:5] if i >= n_real))

        # ---- β：只在训练问上选；951 是唯一选参点，选出后跨规模固定（协议 6） ----
        if B0:
            beta = 0.0
        elif os.environ.get("E32_BETA0"):
            # 诊断用：强制 β=0，检验"真实表内排序对目录组成不变"。
            # 结构上应当是精确不变的——β=0 时 Sb = zs(S)，zs 是全局仿射，
            # 而真实表的特征矩阵只依赖 refN 口径的 idf/谱基，与目录长度无关。
            beta = 0.0
        elif beta_pinned is not None and tag != ("951+g" if FULL else "951"):
            beta = float(beta_pinned)
        else:
            trS = [score(c) for c in train]
            best = (0.0, -1.0)
            for b in (0.0, 0.05, 0.1, 0.2, 0.3):
                r5 = float(np.mean([ev(zs(S) + b * posterior(S), c["qid"])[1]
                                    for S, c in zip(trS, train)]))
                if r5 > best[1]:
                    best = (b, r5)
            beta = best[0]
            del trS
            gc.collect()

        # ---- 测试期：只打分 ----
        t_score = time.perf_counter()
        rows, rows_real, pq = [], [], []
        for c in test:
            S = score(c)
            Sb = zs(S) + beta * posterior(S)
            r = ev(Sb, c["qid"])
            rows.append(r)
            Sr = np.where(np.arange(len(S)) < n_real, Sb, -1e18)
            order = rank(Sr)
            gold = gold_of[c["qid"]]
            rows_real.append((len(set(doc_ids[i] for i in order[:1]) & gold) / len(gold),
                              len(set(doc_ids[i] for i in order[:5]) & gold) / len(gold)))
            rec = {"tag": tag, "qid": c["qid"], "db": c["db_id"],
                   "src": c.get("src", "dev"), "n_gold": len(gold),
                   "R1": r[0], "R5": r[1], "hit20": r[2], "top1": r[3],
                   "synth5": r[4],
                   "R1_real": rows_real[-1][0], "R5_real": rows_real[-1][1]}
            if RICH:
                # E44：金标在全目录的 rank（含干扰表竞争）与真实表内的 rank（纯排序）。
                # margin = 最高分金标 − 第 k 名边界分数；k=5，负值表示金标已在边界外。
                ord_full = rank(Sb)
                inv_full = np.empty(len(ord_full), np.int64)
                inv_full[ord_full] = np.arange(len(ord_full))
                inv_real = np.empty(len(order), np.int64)
                inv_real[order] = np.arange(len(order))
                gi = [id_of[g] for g in gold if g in id_of]
                gpos = sorted(int(inv_full[j]) for j in gi)
                gpos_real = sorted(int(inv_real[j]) for j in gi)
                gmax = float(Sb[max(gi, key=lambda j: Sb[j])]) if gi else -1e18
                border = float(Sb[ord_full[min(4, len(ord_full) - 1)]])
                rec["gpos"] = gpos
                rec["gpos_real"] = gpos_real
                rec["top20_real"] = [1 if int(i) < n_real else 0 for i in ord_full[:20]]
                rec["margin5"] = gmax - border
                # 干扰表在 top20 的最高名次；无则 -1
                bad = [int(p) for p, i in enumerate(ord_full[:20]) if int(i) >= n_real]
                rec["first_bad"] = bad[0] if bad else -1
            pq.append(rec)
        q_s = (time.perf_counter() - t_score) / len(test)

        agg = {k: float(np.mean([r[i] for r in rows]))
               for i, k in enumerate(("R1", "R5", "hit20", "top1"))}
        res[tag] = dict(N=len(all_tabs), n_real=n_real, n_synth=len(extra),
                        beta=beta, same_as_e28=bool(ok_same), **agg,
                        R1_realonly=float(np.mean([r[0] for r in rows_real])),
                        R5_realonly=float(np.mean([r[1] for r in rows_real])),
                        synth_in_top5=float(np.mean([r[4] for r in rows])),
                        query_ms=q_s * 1000, sec=time.perf_counter() - t_start)
        if beta_pinned is None:
            res.setdefault("_meta", {})["beta_pinned"] = beta
            beta_pinned = beta
        print(f"[{tag}] N={len(all_tabs):6d} R@1={agg['R1']*100:5.2f} "
              f"R@5={agg['R5']*100:5.2f} hit20={agg['hit20']*100:5.2f} | 真实表内 "
              f"{res[tag]['R1_realonly']*100:5.2f}/{res[tag]['R5_realonly']*100:5.2f} | "
              f"β={beta} 合成进top5={res[tag]['synth_in_top5']:.2f} | "
              f"{q_s*1000:.1f}ms/问 ({time.perf_counter()-t_start:.0f}s)", flush=True)
        json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        pq_path = OUT.with_name(f"{OUT.stem}_{tag}_perq.jsonl")
        with open(pq_path, "w", encoding="utf-8") as f:
            for rec in pq:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        del cat, C
        gc.collect()


if __name__ == "__main__":
    main()
