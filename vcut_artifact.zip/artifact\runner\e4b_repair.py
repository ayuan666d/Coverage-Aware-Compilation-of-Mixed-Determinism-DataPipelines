# -*- coding: utf-8 -*-
"""E4b —— 构造性修复：定理 2（边割插入）的可执行化实验

研究问题（对应实验方案 §4-E4b）：
    Q1 修复完备性   E4 打破的每条管线，修复器能否恢复安全？（约束：修复后
                    违反数必须为 0，出现 1 例即 bug，不是指标）
    Q2 修复代价     插入数是否 = 各出口残余图上的最小边割宽度（Menger 对偶）？
    Q3 幂等性       修复后的管线再进修复器是否零动作？
    Q4 开销         修复耗时相对一次结构判定的比值，随规模如何变化？
    Q5 双重验证     小图上 A 组枚举（独立实现）是否确认 B 组修复结果？

语料：**逐字节重放 E4** 的随机序列（同 rng=Random(11)、同网格
3 形状 × {8,20} 节点 × 6 重复、同五操作 × 40 试验），收集全部被
破坏实例——E4 打破多少，E4b 修多少。重放正确性以破坏数对账
（E4 报告：remove 480 / move 103 / add_edge 255）。

规模档：{50,100,200,500} 节点 × 3 形状 × 3 重复，测 Q4。
注意：本实验的 check 是 E4 同款的**单次结构可达性判定**，与 E3 的
19.3 ms 全 eff 检查（4 源 × 9 输入 × 部分求值）不同口径，不可横比。

运行：cd 05_代码 && python runner/e4b_repair.py
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

from checker import axioms  # noqa: E402
from checker.graphutil import has_cycle  # noqa: E402
from checker.repair import CONSERVATIVE_FALLBACKS, RepairOutcome, repair_edge_insertion  # noqa: E402
from generator.synth import Pipe, Table, synth  # noqa: E402
from runner.e4 import NODES, OPS, OPS_IMPL, SHAPES, TRIALS_PER_PIPE, clone, struct_safe  # noqa: E402

E4_BROKEN_EXPECTED = {"remove_verdict": 480, "move_verdict": 103, "add_edge": 255}
SCALE_SIZES = [50, 100, 200, 500]
SCALE_REPS = 3
A_SIDE_MAX_NODES = 48          # A 组枚举只在小图上做（路径数指数最坏）
SCALE_MUTATE_TRIALS = 30


# ── 胶水层：Pipe 进出 ─────────────────────────────────────────


def repair_pipe(pipe: Pipe, node_prefix: str = "v_fix") -> Tuple[Pipe, RepairOutcome]:
    """对 Pipe 执行构造性修复；插入节点固定挂**兜底 reject** 空表。

    五纪律 #4：兜底方向显式——插入判决的表无规则、fallback="reject"，
    逐输入 judged（v0.3 定义 5），因此 eff 恒真、并入 V_eff。
    """
    if has_cycle(pipe.nodes, pipe.succ()):
        raise ValueError("输入管线有环：修复模型只对 DAG 定义")
    out = repair_edge_insertion(
        pipe.nodes, pipe.edges, pipe.verdicts(), pipe.sources(), pipe.sinks(),
        node_prefix=node_prefix,
    )
    if out.status == "already_safe" and not out.new_nodes:
        return clone(pipe), out

    fixed = clone(pipe)
    fixed.edges = list(out.new_edges)
    for v, kind in out.new_nodes.items():
        fixed.nodes[v] = kind
        tbl = Table(rules=[], fallback="reject")
        if tbl.fallback not in CONSERVATIVE_FALLBACKS:      # 防御：方向必须保守
            raise AssertionError("插入判决的兜底方向不是保守集合")
        fixed.tables[v] = tbl
    return fixed, out


def a_side_safe(pipe: Pipe) -> Optional[bool]:
    """A 组枚举对拍。图过大返回 None（不冒充结论）。"""
    if len(pipe.nodes) > A_SIDE_MAX_NODES:
        return None
    case = axioms.Case(
        nodes=tuple(sorted(pipe.nodes)),
        edges=tuple(pipe.edges),
        sinks=tuple(pipe.sinks()),
        v_eff=frozenset(pipe.verdicts()),
    )
    safe, _bad = axioms.v1_by_enumeration(case)
    return safe


# ── 语料：E4 逐字节重放 ───────────────────────────────────────


def build_corpus() -> Tuple[List[dict], dict]:
    """重放 E4 主循环，收集被破坏实例。返回 (instances, replay_stats)。"""
    rng = __import__("random").Random(11)
    by_op = {op: defaultdict(int) for op in OPS}
    base_unsafe = 0
    instances: List[dict] = []

    for shape in SHAPES:
        for nn in NODES:
            for _rep in range(6):
                pipe = synth(shape, nn, 1, 1, 0.0, rng)
                if not struct_safe(pipe):
                    base_unsafe += 1
                    continue
                for op in OPS:
                    fn = OPS_IMPL[op]
                    for _ in range(TRIALS_PER_PIPE):
                        new = fn(pipe, rng)
                        if new is None:
                            by_op[op]["inapplicable"] += 1
                            continue
                        if struct_safe(new):
                            by_op[op]["kept"] += 1
                        else:
                            by_op[op]["broken"] += 1
                            instances.append({
                                "shape": shape, "n_nodes": nn, "op": op,
                                "pipe": new,
                            })
    stats = {
        "n_base_pipes": 36, "base_unsafe_skipped": base_unsafe,
        "by_op": {op: dict(v) for op, v in by_op.items()},
        "n_unsafe": len(instances),
    }
    return instances, stats


def make_unsafe_at_scale(shape: str, nn: int, rng) -> Optional[Pipe]:
    """规模档语料：**定向旁路注入**（O(V+E)，不用 op_add_edge 的 O(n²) 枚举）。

    在 G\\verdicts 中从源可达的任一非判决节点 x 上加边 (x, sink)：
    src→…→x→sink 全程避开判决 → 结构必然不安全（与 op_add_edge 制造的
    侧门同一结构类；差异是构造而非随机采样，只影响语料分布不影响修复语义）。
    x 不可选时（理论罕见）回退 remove_verdict。
    """
    pipe = synth(shape, nn, 1, 1, 0.0, rng)
    verdicts = frozenset(pipe.verdicts())
    succ = pipe.succ()
    srcs = pipe.sources()
    snks = pipe.sinks()
    from checker.graphutil import reachable_set
    fwd: set = set()
    for src in srcs:
        fwd |= reachable_set(src, succ, verdicts)
    cands = [x for x in fwd
             if x not in verdicts and x not in snks
             and (x, snks[0]) not in set(pipe.edges)]
    if cands:
        pipe.edges.append((rng.choice(cands), snks[0]))
        if not struct_safe(pipe):
            return pipe
    # 回退：顶点数够时直接摘判决（100% 破坏）
    fn = OPS_IMPL["remove_verdict"]
    for _ in range(SCALE_MUTATE_TRIALS):
        new = fn(pipe, rng)
        if new is not None and not struct_safe(new):
            return new
    return None


# ── 主实验 ────────────────────────────────────────────────────


def run_corpus(instances: List[dict]) -> dict:
    status_counts = defaultdict(int)
    violations_after = 0
    a_checked = a_safe = 0
    idempotent = 0
    ins_by_op: Dict[str, List[int]] = defaultdict(list)
    widths: List[int] = []
    total_ms: List[float] = []

    for inst in instances:
        fixed, out = repair_pipe(inst["pipe"])
        status_counts[out.status] += 1
        ins_by_op[inst["op"]].append(out.stats["n_insertions"])
        total_ms.append(out.stats["total_ms"])
        for sr in out.per_sink:
            if sr.cut_edges:
                widths.append(sr.width)
                assert sr.width == sr.menger, "割宽与 Menger 对偶不一致"

        # Q1（约束）：修复后违反数必须为 0
        if out.status in ("repaired", "already_safe"):
            if not struct_safe(fixed):
                violations_after += 1
                continue
            # Q5：小图 A 组独立对拍
            a = a_side_safe(fixed)
            if a is not None:
                a_checked += 1
                a_safe += 1 if a else 0
                violations_after += 0 if a else 1
            # Q3：幂等
            _refixed, out2 = repair_pipe(fixed)
            if out2.status == "already_safe" and out2.stats["n_insertions"] == 0:
                idempotent += 1

    def _summarize(xs: List[int]) -> dict:
        return {
            "n": len(xs), "total": sum(xs),
            "mean": round(sum(xs) / len(xs), 3) if xs else None,
            "max": max(xs) if xs else None,
        }

    return {
        "n_unsafe": len(instances),
        "status_counts": dict(status_counts),
        "violations_after": violations_after,          # 约束：必须为 0
        "a_side": {"checked": a_checked, "safe": a_safe,
                   "max_nodes": A_SIDE_MAX_NODES},
        "idempotent": idempotent,
        "insertions_by_op": {op: _summarize(v) for op, v in sorted(ins_by_op.items())},
        "per_sink_width": _summarize(widths),
        "repair_ms": {
            "mean": round(sum(total_ms) / len(total_ms), 4) if total_ms else None,
            "max": round(max(total_ms), 4) if total_ms else None,
        },
    }


def run_timing() -> dict:
    rng = __import__("random").Random(97)
    out: Dict[int, dict] = {}
    for nn in SCALE_SIZES:
        check_ms, repair_ms, ratios = [], [], []
        n_inst = 0
        for shape in SHAPES:
            for _ in range(SCALE_REPS):
                pipe = make_unsafe_at_scale(shape, nn, rng)
                if pipe is None:
                    continue
                n_inst += 1
                t0 = time.perf_counter()
                struct_safe(pipe)
                check_ms.append((time.perf_counter() - t0) * 1000)
                fixed, o = repair_pipe(pipe)
                repair_ms.append(o.stats["total_ms"])
                assert o.verified_safe, f"{shape}/{nn} 修复后重验失败"
                assert struct_safe(fixed)
                ratios.append(o.stats["total_ms"] / max(check_ms[-1], 1e-9))
        out[nn] = {
            "n": n_inst,
            "check_ms_mean": round(sum(check_ms) / len(check_ms), 4) if check_ms else None,
            "repair_ms_mean": round(sum(repair_ms) / len(repair_ms), 4) if repair_ms else None,
            "repair_vs_check_ratio_mean": round(sum(ratios) / len(ratios), 3) if ratios else None,
        }
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(HERE / ".." / "06_结果" / "e4b_repair.json"))
    args = ap.parse_args()

    print("=" * 64)
    print("E4b · 构造性修复（定理 2 边割插入的可执行化）")
    print("=" * 64)

    instances, replay = build_corpus()
    print(f"\n[语料] E4 重放：{replay['n_base_pipes']} 条基线，"
          f"{replay['n_unsafe']} 个不安全实例")
    for op, v in replay["by_op"].items():
        mark = ""
        if op in E4_BROKEN_EXPECTED:
            mark = ("✓ 与 E4 对账一致" if v.get("broken") == E4_BROKEN_EXPECTED[op]
                    else f"✗ 与 E4 不一致（期望 {E4_BROKEN_EXPECTED[op]}）")
        print(f"  {op:<16} applied={v.get('kept',0)+v.get('broken',0):>5} "
              f"broken={v.get('broken',0):>5}  {mark}")

    print("\n[修复] 逐实例修复 + 双重验证 + 幂等 …")
    rep = run_corpus(instances)
    print(f"  状态分布：{rep['status_counts']}")
    print(f"  修复后违反数：{rep['violations_after']}  "
          f"({'✓ 约束满足' if rep['violations_after'] == 0 else '✗ BUG：出现安全违反'})")
    print(f"  A 组枚举对拍：{rep['a_side']['safe']}/{rep['a_side']['checked']} 安全"
          f"（≤{rep['a_side']['max_nodes']} 节点）")
    print(f"  幂等：{rep['idempotent']}/{rep['n_unsafe']}")
    print(f"  插入数（按来源操作）：")
    for op, v in rep["insertions_by_op"].items():
        print(f"    {op:<16} mean={v['mean']} max={v['max']} total={v['total']}")
    print(f"  单出口割宽：{rep['per_sink_width']}")
    print(f"  修复耗时（8/20 节点档）：mean={rep['repair_ms']['mean']} ms, "
          f"max={rep['repair_ms']['max']} ms")

    print("\n[规模档] 50/100/200/500 节点 …")
    timing = run_timing()
    print(f"  {'节点':>6}{'n':>4}{'结构判定 ms':>14}{'修复 ms':>12}{'比值':>8}")
    for nn, v in timing.items():
        print(f"  {nn:>6}{v['n']:>4}{v['check_ms_mean']:>14.4f}"
              f"{v['repair_ms_mean']:>12.4f}{v['repair_vs_check_ratio_mean']:>8.2f}")

    payload = {"replay": replay, "repair": rep, "timing": timing,
               "config": {"scale_sizes": SCALE_SIZES, "scale_reps": SCALE_REPS,
                          "a_side_max_nodes": A_SIDE_MAX_NODES,
                          "corpus_seed": 11, "scale_seed": 97}}
    Path(args.out).write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                              encoding="utf-8")
    print(f"\n已写入 {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
