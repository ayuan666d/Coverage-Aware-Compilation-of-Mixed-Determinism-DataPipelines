"""E21: hierarchical readout — shared first order, locally regularized second order.

One model, one solve.  The regularizer is split: lam1 on the 9 first-order
terms, lam2 on the 45 second-order terms.  Sweep lam2 and evaluate both ends:
Spider test (large catalog, many pairs) and BIRD transfer (small catalog,
few pairs).  If the optimal lam2 differs between the two, the optimum is a
function of n/d, not a constant; if a lam2 = f(n/d) rule puts both near their
own optimum, the configuration is parameterizable.
"""
from __future__ import annotations

import json
import sys

import numpy as np

sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码\runner")
import e14_db_anchor as e14  # noqa: E402
import e16_transfer as e16  # noqa: E402

OUT = e14.REPO / "06_结果" / "e21_hierarchical.json"
KEEP = e16.KEEP
LAM1 = 0.1
LAM2S = (0.1, 1.0, 10.0, 100.0, 1000.0, 10000.0)


def fit_hier(F, y, lam1, lam2, d1=9):
    A = F.T @ F
    b = F.T @ y
    n = len(y)
    mu = F.mean(0)
    C = A / n - np.outer(mu, mu)
    reg = np.full(F.shape[1], lam2)
    reg[:d1] = lam1
    mu_p = F[y > 0.5].mean(0)
    mu_n = F[y <= 0.5].mean(0)
    return np.linalg.solve((C + np.diag(reg)).astype(np.float64),
                           (mu_p - mu_n).astype(np.float64)).astype(np.float32)


def main():
    meta = e14.load()
    Ft = meta["build_F"](meta["train_q"])[:, :, KEEP]
    mu = Ft.reshape(-1, 9).mean(0)
    sd = Ft.reshape(-1, 9).std(0) + 1e-9
    Fn = ((Ft - mu) / sd).reshape(-1, 9)
    Y = np.zeros((len(meta["train_q"]), meta["D"]), dtype=np.float32)
    for qi, q in enumerate(meta["train_q"]):
        for f in meta["gold_all"][q]:
            j = meta["didx"].get(f)
            if j is not None:
                Y[qi, j] = 1.0
    y = Y.reshape(-1)
    idx = [(i, j) for i in range(9) for j in range(i, 9)]
    Fn2 = np.concatenate([Fn, e14.quad(Fn, idx)], axis=1)
    Fte1 = ((meta["build_F"](meta["test_q"])[:, :, KEEP] - mu) / sd)
    Fte2 = np.concatenate([Fte1.reshape(-1, 9), e14.quad(Fte1.reshape(-1, 9), idx)],
                          axis=1).reshape(len(meta["test_q"]), meta["D"], -1)

    cache = json.load(open(e14.CACHE, encoding="utf-8"))["bird"]
    cases = json.load(open(e14.CASES, encoding="utf-8"))["bird"]
    by_db = {}
    for c in cases:
        by_db.setdefault(c["db_id"], []).append(c)
    bird_ready = {}
    for db, cs in sorted(by_db.items()):
        F9, doc_ids = e16.build_bird_db(cache[db], cs)
        Q = F9.reshape(-1, 9)
        mb, sb = Q.mean(0), Q.std(0) + 1e-9
        Z = ((Q - mb) / sb).reshape(len(cs), len(doc_ids), 9)
        bird_ready[db] = (cs, doc_ids, Z, np.concatenate(
            [Z.reshape(-1, 9), e14.quad(Z.reshape(-1, 9), idx)], axis=1).reshape(
            len(cs), len(doc_ids), -1))

    out = {}
    for lam2 in LAM2S:
        w = fit_hier(Fn2, y, LAM1, lam2)
        s1 = e14.evaluate(meta, Fte2, w)[0]
        rows = []
        for db, (cs, doc_ids, Z, Z2) in bird_ready.items():
            for qi, c in enumerate(cs):
                sc = Z2[qi] @ w
                order = np.argsort(-sc)[:5]
                top = [doc_ids[i] for i in order]
                r, m = e14.metrics_top(top, {g.lower() for g in c["gold"]})
                rows.append((r[1], r[3], r[5], m))
        b = {k: round(float(np.mean([r[i] for r in rows])), 4)
             for i, k in enumerate(("recall@1", "recall@3", "recall@5", "mrr"))}
        out[str(lam2)] = {"spider": s1, "bird": b}
        print("lam2", lam2, "spider", json.dumps(s1), "bird", json.dumps(b), flush=True)

    json.dump({"lam1": LAM1, "lam2_grid": out,
               "reference": {"spider_second_r5": 0.8001, "bird_first_r5": 0.9362,
                             "bird_second_r5": 0.6868}},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
