"""E48 · BIRD dev 1534 问评估集构造。

口径：
- test = BIRD dev 全量 1534 问（11 库，与 mini-dev 同库；金标表 canon 到 schema_cache 的
  BIRD schema——目录里的真实 BIRD 表就来自这份 schema）。
- train = Spider train 7000 问（split=train），供 Fisher 权重与 β 选择编译。
  即：**打分器完全由 Spider 目录编译，在 BIRD 问题上零样本评估**。
- 金标无法 canon 到 schema 的问题跳过（dev_20240627 的 sqlite 与 minidev 版本可能有差异），
  跳过数会打印并写入输出。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(Path(__file__).parent))

import e11_data as d11  # noqa: E402

BASE_CASES = REPO / "06_结果" / "e35_dev20_cases.json"
DEV_JSON = Path(r"D:\vldb2027_e11\dev_20240627\dev.json")
SCHEMA_CACHE = Path(r"D:\vldb2027_e11\schema_cache.json")
OUT = REPO / "06_结果" / "e48_bird_dev_cases.json"


def main() -> None:
    base = json.load(open(BASE_CASES, encoding="utf-8"))
    train = [c for c in base["spider"] if c["split"] == "train"]

    cache = json.load(open(SCHEMA_CACHE, encoding="utf-8"))
    bird_schema = cache["bird"]
    canon = {db: {t["name"].lower(): t["name"] for t in s["tables"]}
             for db, s in bird_schema.items()}

    dev = json.load(open(DEV_JSON, encoding="utf-8"))
    out, skipped = list(train), {"no_gold_tables": 0, "gold_not_in_schema": 0,
                                 "db_not_in_cache": 0}
    for c in dev:
        db = c["db_id"]
        if db not in canon:
            skipped["db_not_in_cache"] += 1
            continue
        gt = d11.parse_gold_tables(c["SQL"])
        gold = sorted({canon[db][g.lower()] for g in gt if g.lower() in canon[db]})
        if not gt:
            skipped["no_gold_tables"] += 1
            continue
        if not gold:
            skipped["gold_not_in_schema"] += 1
            continue
        out.append({"qid": f"bd{c['question_id']}", "db_id": db,
                    "question": c["question"], "sql": c["SQL"], "gold": gold,
                    "split": "test", "src": "bird_dev"})

    json.dump({"spider": out}, open(OUT, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    from collections import Counter
    test = [c for c in out if c["split"] == "test"]
    print(f"train={len(train)}  bird_test={len(test)}  skipped={skipped}")
    print("gold 数分布:", dict(Counter(len(c["gold"]) for c in test)))
    print("库分布:", dict(Counter(c["db_id"] for c in test)))


if __name__ == "__main__":
    main()
