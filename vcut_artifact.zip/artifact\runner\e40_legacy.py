"""E40 · 遗留副本干扰器（legacy variant distractor）

设计动机（2026-11-06）
----------------------
E28/E32 用的干扰表是 `s28.synth_tables()`：从 3 张真实表各抽 2 列拼成新表，
库名 `synth{i//40:05d}`，每库恰好 40 张。这套干扰集有四个可被一行代码识别的痕迹，
导致 10k 全目录读数（R@5 75.31）在**两个方向上都不可用**：

  ① 库名 `synth*` + 每库恰 40 张  → db_size 通道 100% 可分（z_gov_probe: AUC=0.000）
  ② 列数恒为 5（cols[:5] 截断）     → 真实 Spider 表列数中位 4、均值 5.14、长尾到 48
  ③ 表名 `{w1}_{w2}_{i}` 带全局序号 → 尾缀整数是直接指纹
  ④ 无可信来源                      → 库里凭空多出 226 个库

而真实数仓里最难的负例不是随机无关表，是**同一份数据的遗留副本**：过期快照、
不同粒度的汇总表、ETL 中转表、列被裁剪或改名的历史版本。它们列名相似、统计量真实、
没有任何伪造痕迹——这才是"治理"要解决的问题。

本模块按这个形态生成干扰表，四条痕迹全部消除：

  · 落库位置按各真实库的表数**等比分配**，不新建库 → db_size 退化为均匀放大，AUC≈0.5
  · 列数、列名、取值全部**继承真实表** → 列数分布与真实表同源
  · 表名 = 真实表名 + 遗留后缀（`_old` / `_stg` / `_2023` / `_bak_v2` …），无序号
  · 数值区间通过 src 继承（zone_of 已支持），NF 通道对遗留表**不是零**——这与旧干扰器
    不同：旧干扰器虽然也继承了区间，但列数/命名先把身份暴露了

四种变体
--------
  subset  保留 65% 列        模拟列被裁剪的历史版本
  rename  列名换同义词       模拟命名规范迁移后的旧表
  denorm  两张 FK 相关表并集 模拟集市层宽表
  agg     仅留维表列+数值列  模拟日/月粒度汇总

用法
----
    from e40_legacy import legacy_tables
    extra = legacy_tables(donors, need=9049, cache=cache, seed=40)

`donors` 必须是 `s28.tables_of` 产出的表字典列表（含 db / name / columns）。
返回的表结构与 synth_tables_src 一致，另带 `src`（供 zone_of 继承区间）与
`variant`（供事后诊断分组）。
"""

from __future__ import annotations

import random
from collections import Counter, defaultdict

# 真实数仓里遗留表的后缀。刻意不包含纯数字，也不用 `synth`/`_N` 这类生成器痕迹。
SUFFIX = [
    "old", "bak", "backup", "hist", "history", "archive", "stg", "staging",
    "tmp", "temp", "dw", "ods", "dwd", "dws", "raw", "src", "copy", "copy1",
    "v1", "v2", "v3", "new", "latest", "final", "final2", "work", "test",
    "2019", "2020", "2021", "2022", "2023", "2024",
]
SUFFIX2 = ["", "v2", "bak", "2023", "2024", "old"]

# 列名同义词：把现代命名换成历史命名，模拟命名规范迁移
RENAME = {
    "id": ["no", "code", "key", "seq"],
    "name": ["nm", "title", "label", "desc"],
    "date": ["dt", "day", "ts"],
    "time": ["tm", "ts"],
    "amount": ["amt", "val", "sum"],
    "price": ["prc", "cost", "fee"],
    "count": ["cnt", "num", "qty"],
    "type": ["typ", "kind", "cat"],
    "status": ["stat", "state", "flag"],
    "city": ["cty", "town"],
    "address": ["addr", "adr"],
    "phone": ["tel", "phn"],
    "email": ["mail", "eml"],
    "year": ["yr", "yyyy"],
    "month": ["mon", "mm"],
    "customer": ["cust", "client"],
    "student": ["stu", "pupil"],
    "employee": ["emp", "staff"],
    "product": ["prod", "item", "sku"],
    "order": ["ord", "po"],
}


def _rename_col(name: str, rng: random.Random) -> str:
    """把一个列名换成同义词形态；无同义词则加短后缀。"""
    low = name.lower()
    for k, alts in RENAME.items():
        if k in low:
            new = rng.choice(alts)
            # 保留原有大小写风格：全小写 / 首字母大写 / 全大写
            if name.isupper():
                return new.upper()
            if name[:1].isupper():
                return new.capitalize()
            return new
    if name.isupper():
        return name + "_H"
    return name + "_h" if name[:1].islower() else name + "H"


def _mkname(base: str, rng: random.Random) -> str:
    """真实表名 + 遗留后缀，模拟 ETL 产物命名。

    长度约束：真实 Spider 表名均长 10.1 字符。若一律追加后缀，遗留表均长会到 18.6，
    「表名长度」就成了第二个身份指纹（实测 AUC 0.83）。故这里按真实表名长度分布
    **反向构造**：先抽一个目标长度 L，再决定用全称还是缩写基名，超长则从前部丢段。
    """
    segs = [s for s in base.split("_") if s]
    if len(segs) > 2:
        segs = segs[-2:]
    stem = "_".join(segs)
    L = _NAMELEN_CACHE["draw"](rng)

    s1 = rng.choice(SUFFIX)
    # 候选：全称+后缀 / 缩写基名+后缀 / 短基名+后缀。取长度最接近目标 L 的那个，
    # 不要「第一个不超过 L」——那会系统性偏短，反而制造反向指纹。
    abbr = "_".join(s[:3] if len(s) > 3 else s for s in segs)
    trials = [f"{stem}_{s1}", f"{abbr}_{s1}"]
    if len(stem) > 5:
        trials.append(f"{stem[:5]}_{s1}")
    if len(stem) > 4:
        trials.append(f"{stem[:4]}_{s1}")
    return min(trials, key=lambda t: (abs(len(t) - L), len(t)))


# 真实表名长度分布（供 _mkname 反向抽样）。由 legacy_tables() 在入口处填充。
_NAMELEN_CACHE = {"draw": lambda rng: 12}


def _cols_of(t):
    return [dict(name=c["name"], type=c.get("type", "text"),
                 values=list(c.get("values") or []))
            for c in t["columns"]]


def _variant_subset(t, rng):
    cols = _cols_of(t)
    keep = max(2, int(round(len(cols) * rng.uniform(0.5, 0.85))))
    picked = rng.sample(cols, min(keep, len(cols)))
    picked.sort(key=lambda c: [x["name"] for x in cols].index(c["name"]))
    return picked


def _variant_rename(t, rng):
    out, seen = [], set()
    for c in _cols_of(t):
        nm = _rename_col(c["name"], rng)
        if nm.lower() in seen:
            nm = nm + rng.choice(["1", "2", "_o"])
        seen.add(nm.lower())
        out.append(dict(c, name=nm))
    return out


def _variant_denorm(t, other, rng):
    cols = _cols_of(t)
    seen = {c["name"].lower() for c in cols}
    for c in _cols_of(other):
        if c["name"].lower() in seen:
            continue
        seen.add(c["name"].lower())
        cols.append(c)
        if len(cols) >= 16:
            break
    return cols


def _variant_agg(t, rng):
    """汇总表：只留维度列与数值列（真实数仓的 dws 层长相）。"""
    cols = _cols_of(t)
    num = [c for c in cols if c.get("type") == "number"]
    txt = [c for c in cols if c.get("type") != "number"]
    keep = txt[:max(1, min(2, len(txt)))] + num
    if len(keep) < 2:
        keep = cols[:2]
    return keep


_POOL: dict = {}


def legacy_tables(donors, need, place=None, cache=None, seed: int = 40,
                  verbose: bool = True, full: int = 9049):
    """生成 `need` 张遗留副本干扰表。

    **嵌套保证**：内部总是先构造 `full` 张的全集（按各落库库的表数等比分配），
    再对任一 `need < full` 做按库等比下采样。因此小规模目录是 10k 目录的子集，
    规模曲线才是同一条目录的生长过程，而不是若干张不同的目录。

    参数
    ----
    donors : 源表池（必须有 db / name / columns）。**必须排除测试库**，否则会生成
             金标表的近似副本，造成答案歧义。
    place  : 落库分布 `{db: 该库真实表数}`。**必须包含测试库**，否则"没被塞遗留表
             的那 20 个库"就等于"含答案的库"，db_size 变成 100% 可分的身份指纹
             （这正是旧干扰器被否掉的原因之一，不能在新干扰器上重犯）。
             缺省时退化为只用 donors 的库。
    """
    rng = random.Random(seed)
    if need <= 0:
        return []

    key = (id(donors), seed, full, tuple(sorted(place)) if place else None)
    if key not in _POOL:
        _POOL[key] = _build(donors, full, seed, place, verbose)
    items = _POOL[key]
    if need >= len(items):
        return items[:need]

    # ---- 按库等比下采样（最大余数法，保证总数精确 = need）----
    by = defaultdict(list)
    for t in items:
        by[t["db"]].append(t)
    dbs = sorted(by)
    N = len(items)
    k = {d: need * len(by[d]) // N for d in dbs}
    rem = need - sum(k.values())
    if rem > 0:
        frac = sorted(dbs, key=lambda d: -(need * len(by[d]) % N))
        for d in frac[:rem]:
            k[d] += 1
    out = []
    for d in dbs:
        out += by[d][:k[d]]
    return out


def _build(donors, need, seed, place=None, verbose=True):
    """构造全集：按各落库库的真实表数等比分配名额，同库内表名唯一。"""
    rng = random.Random(seed)

    # ---- 0. 拟合真实表名长度分布，供 _mkname 反向抽样 ----
    lens = sorted(len(t["name"]) for t in donors)
    _NAMELEN_CACHE["draw"] = lambda r: lens[r.randrange(len(lens))]

    # ---- 1. 源表池（按库分组）与落库分布（两者解耦）----
    src_by_db = defaultdict(list)
    for t in donors:
        src_by_db[t["db"]].append(t)
    src_all = list(donors)

    if place:
        db_names = sorted(place)
        weights = [max(1, int(place[d])) for d in db_names]
    else:
        db_names = sorted(src_by_db)
        weights = [len(src_by_db[d]) for d in db_names]
    tot = sum(weights)
    quota = [max(1, int(round(need * w / tot))) for w in weights]
    while sum(quota) > need:
        i = max(range(len(quota)), key=lambda j: quota[j])
        quota[i] -= 1
    i = 0
    while sum(quota) < need:
        quota[i % len(quota)] += 1
        i += 1

    # ---- 2. 按名额落表 ----
    out = []
    used_name = defaultdict(set)
    n_local = 0
    for db, q in zip(db_names, quota):
        # 同库有源表 → 本地遗留副本（ETL 残骸）；无源表（测试库）→ 跨库导入副本
        local = src_by_db.get(db) or []
        for _ in range(q):
            if local and rng.random() < 0.7:
                t = local[rng.randrange(len(local))]
                n_local += 1
            else:
                t = src_all[rng.randrange(len(src_all))]
            kind = rng.choices(["subset", "rename", "denorm", "agg"],
                               weights=[30, 25, 25, 20])[0]
            if kind == "subset":
                cols = _variant_subset(t, rng)
            elif kind == "rename":
                cols = _variant_rename(t, rng)
            elif kind == "denorm":
                other = (local or src_all)[rng.randrange(len(local or src_all))]
                cols = _variant_denorm(t, other, rng)
            else:
                cols = _variant_agg(t, rng)
            if not cols:
                cols = _cols_of(t)

            base = t["name"]
            for _try in range(8):
                name = _mkname(base, rng)
                if name.lower() not in used_name[db]:
                    break
            used_name[db].add(name.lower())
            out.append({"db": db, "name": name, "columns": cols,
                        "src": [f"{str(t['db']).lower()}::{str(t['name']).lower()}"],
                        "variant": kind})

    if verbose:
        c = Counter(t["variant"] for t in out)
        print(f"[legacy] {len(out)} 张遗留副本，落 {len(db_names)} 个库 "
              f"（同库派生 {n_local/len(out)*100:.0f}%）| 变体 {dict(c)}", flush=True)
        sz = Counter(t["db"] for t in out)
        ratios = [sz[d] / max(place.get(d, 1) if place else len(src_by_db.get(d) or [1]), 1)
                  for d in db_names]
        print(f"[legacy] 落库倍数 均 {sum(ratios)/len(ratios):.2f} "
              f"min {min(ratios):.2f} max {max(ratios):.2f}", flush=True)
    return out


def audit(tabs_real, tabs_legacy):
    """身份可分性自检：审稿人会跑的那几项。返回 dict。"""
    import statistics as st

    def colcount(ts):
        return [len(t["columns"]) for t in ts]

    def nlen(ts):
        return [len(t["name"]) for t in ts]

    real_sz = Counter(t["db"] for t in tabs_real)
    leg_sz = Counter(t["db"] for t in tabs_legacy)
    all_dbs = sorted(set(real_sz) | set(leg_sz))
    tot = {d: real_sz.get(d, 0) + leg_sz.get(d, 0) for d in all_dbs}

    def auc_up(a, b):
        """P(a > b) 的经验估计（Mann-Whitney）。0.5 = 不可分。"""
        if not a or not b:
            return float("nan")
        s = 0.0
        for x in a:
            for y in b:
                s += 1.0 if x > y else (0.5 if x == y else 0.0)
        return s / (len(a) * len(b))

    def auc(xs_real, xs_leg):
        """把「表属于真实/遗留」当标签，看某个表级统计量能否分开。"""
        # 对称化：同时算正反两向，避免量纲方向影响解读
        return round(auc_up(xs_leg, xs_real), 4)

    # 表级 db_size：每张表继承其所在库的总规模。这是 db_size 通道真正看到的东西。
    size_of = {t["db"]: tot.get(t["db"], 0) for t in tabs_real}
    size_of.update({t["db"]: tot.get(t["db"], 0) for t in tabs_legacy})
    return {
        "real_tables": len(tabs_real), "legacy_tables": len(tabs_legacy),
        "colcount_real": round(st.mean(colcount(tabs_real)), 3),
        "colcount_legacy": round(st.mean(colcount(tabs_legacy)), 3),
        "namelen_real": round(st.mean(nlen(tabs_real)), 2),
        "namelen_legacy": round(st.mean(nlen(tabs_legacy)), 2),
        "auc_dbsize": auc([size_of[t["db"]] for t in tabs_real],
                          [size_of[t["db"]] for t in tabs_legacy]),
        "auc_colcount": auc(colcount(tabs_real), colcount(tabs_legacy)),
        "auc_namelen": auc(nlen(tabs_real), nlen(tabs_legacy)),
        "dbs_totally_legacy": len(set(t["db"] for t in tabs_legacy) - set(t["db"] for t in tabs_real)),
        "dbs_totally_real": len(set(t["db"] for t in tabs_real) - set(t["db"] for t in tabs_legacy)),
    }


if __name__ == "__main__":
    import json
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import e28_scale as s28

    WORK = Path(r"D:\vldb2027_e11")
    cache = json.load(open(WORK / "schema_cache.json", encoding="utf-8"))
    real = []
    for db in cache["spider"]:
        real += s28.tables_of(cache, db, prefix=True)
    for db, s in cache["bird"].items():
        real += [dict(t, db=db) for t in s["tables"]]

    place = {db: len(cache["spider"][db]["tables"]) for db in cache["spider"]}
    place.update({db: len(s["tables"]) for db, s in cache["bird"].items()})

    leg = legacy_tables(real, 9049, place=place, seed=40)
    print(json.dumps(audit(real, leg), ensure_ascii=False, indent=1))
    print("\n前 5 张：")
    for t in leg[:5]:
        print(f"  {t['db']}::{t['name']}  [{t['variant']}]  "
              f"{len(t['columns'])} 列  {[c['name'] for c in t['columns']][:5]}")
