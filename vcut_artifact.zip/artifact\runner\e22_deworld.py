"""E22: de-worlding stress test — strip world-readable names from BIRD.

Private catalogs use internal codes (CUST_MSTR_AMT), not English words.  Replace
every BIRD table/column name with an opaque token, keep structure, values and
questions, and rerun both sides:

  ours   : 9-primitive Spider weight transfer (E16 protocol)
  dense  : Qwen3-Embedding-0.6B zero-shot on the same de-worlded documents

If dense drops more than ours, the private-catalog advantage is measured.
"""
from __future__ import annotations

import json
import sys

import numpy as np

sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码\runner")
import e14_db_anchor as e14  # noqa: E402
import e16_transfer as e16  # noqa: E402
from e15_objective import fit_fisher  # noqa: E402
from e21_hierarchical import fit_hier  # noqa: E402

OUT = e14.REPO / "06_结果" / "e22_deworld.json"
CACHE = e14.CACHE
MODEL = r"D:\vldb2027_e11\models\Qwen3-Embedding-0.6B"


def deworld_schema(schema_db):
    out = {"tables": [], "fks": schema_db.get("fks", [])}
    mapping = {}
    for ti, t in enumerate(schema_db["tables"]):
        mapping[t["name"].lower()] = f"t{ti}"
        cols = []
        for ci, c in enumerate(t["columns"]):
            cols.append({"name": f"c{ci}", "type": c.get("type"), "values": c.get("values")})
        out["tables"].append({"name": f"t{ti}", "columns": cols})
    return out, mapping


def build_doc_texts(schema_db, deworlded):
    texts = []
    for t in schema_db["tables"]:
        parts = [t["name"] if not deworlded else t["name"]]
        for c in t["columns"]:
            parts.append(c["name"])
            for v in (c.get("values") or [])[:12]:
                parts.append(str(v))
        texts.append(" ".join(parts))
    return texts


def main():
    meta = e14.load()
    Ft = meta["build_F"](meta["train_q"])[:, :, e16.KEEP]
    mu = Ft.reshape(-1, 9).mean(0)
    sd = Ft.reshape(-1, 9).std(0) + 1e-9
    Fn = ((Ft - mu) / sd).reshape(-1, 9)
    Y = np.zeros((len(meta["train_q"]), meta["D"]), dtype=np.float32)
    for qi, q in enumerate(meta["train_q"]):
        for f in meta["gold_all"][q]:
            j = meta["didx"].get(f)
            if j is not None:
                Y[qi, j] = 1.0
    y = Y.reshape(-1)
    idx = [(i, j) for i in range(9) for j in range(i, 9)]
    Fn2 = np.concatenate([Fn, e14.quad(Fn, idx)], axis=1)
    w1 = fit_fisher(Fn, y, 0.1)
    w_h = fit_hier(Fn2, y, 0.1, 1000.0)

    cache = json.load(open(CACHE, encoding="utf-8"))["bird"]
    cases = json.load(open(e14.CASES, encoding="utf-8"))["bird"]
    by_db = {}
    for c in cases:
        by_db.setdefault(c["db_id"], []).append(c)

    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer(MODEL, device="cuda")

    results = {"original": {"ours_first": [], "ours_hier": [], "dense": []},
               "deworld": {"ours_first": [], "ours_hier": [], "dense": []}}

    for mode in ("original", "deworld"):
        for db, cs in sorted(by_db.items()):
            schema = cache[db]
            mapping = {}
            if mode == "deworld":
                schema, mapping = deworld_schema(schema)
            F9, doc_ids = e16.build_bird_db(schema, cs)
            Q = F9.reshape(-1, 9)
            mb, sb = Q.mean(0), Q.std(0) + 1e-9
            Z = ((Q - mb) / sb).reshape(len(cs), len(doc_ids), 9)
            Z2 = np.concatenate([Z.reshape(-1, 9), e14.quad(Z.reshape(-1, 9), idx)],
                                axis=1).reshape(len(cs), len(doc_ids), -1)
            texts = build_doc_texts(schema, mode == "deworld")
            docs = model.encode(texts, normalize_embeddings=True, batch_size=32, show_progress_bar=False)
            qs = model.encode([c["question"] for c in cs], normalize_embeddings=True,
                              batch_size=32, show_progress_bar=False, prompt_name="query")
            dsc = qs @ docs.T
            for qi, c in enumerate(cs):
                gold = {mapping.get(g.lower(), g.lower()) for g in c["gold"]}
                for arm, sc in (("ours_first", Z[qi] @ w1),
                                ("ours_hier", Z2[qi] @ w_h),
                                ("dense", dsc[qi])):
                    order = np.argsort(-sc)[:5]
                    top = [doc_ids[i] for i in order]
                    r, m = e14.metrics_top(top, gold)
                    results[mode][arm].append((r[1], r[3], r[5], m))

    out = {}
    for mode, arms in results.items():
        out[mode] = {}
        for arm, rows in arms.items():
            out[mode][arm] = {k: round(float(np.mean([r[i] for r in rows])), 4)
                              for i, k in enumerate(("recall@1", "recall@3", "recall@5", "mrr"))}
            print(mode, arm, json.dumps(out[mode][arm]), flush=True)

    for arm in ("ours_first", "ours_hier", "dense"):
        out.setdefault("drop", {})[arm] = {
            k: round(out["deworld"][arm][k] - out["original"][arm][k], 4)
            for k in ("recall@1", "recall@5", "mrr")}
    print("drop", json.dumps(out["drop"], indent=1), flush=True)

    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
