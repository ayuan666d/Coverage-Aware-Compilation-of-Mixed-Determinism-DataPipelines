"""E11 Spider-Lake: schema linking at 10 / 30 / 100 / 300 / 1000 tables.

Modes
  known   : per-database schema, test databases only (fair control)
  merged  : one catalog containing every database (data-lake setting)
  scale   : random catalogs of N tables; questions whose gold tables fit

The same schema documents (names + up to 12 sample values) are used by BM25,
TF-IDF, single-graph PPR and typed relation views.
"""
from __future__ import annotations

import argparse
import json
import math
import random
import sys
import time
from collections import Counter
from itertools import combinations
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"


def load():
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    return cache, data


def tables_of(cache, db, prefix=True):
    return [dict(t, db=db) for t in cache["spider"][db]["tables"]]


def fks_of(cache, db, tables, prefix=True):
    have = {t["name"] for t in tables}
    out = []
    for a, ca, b, cb in cache["spider"][db]["fks"]:
        if a in have and b in have:
            if prefix:
                out.append([f"{db}::{a}", ca, f"{db}::{b}", cb])
            else:
                out.append([a, ca, b, cb])
    return out


def coquery_map(cases, prefix=True):
    pair = Counter()
    for c in cases:
        gt = c["gold"]
        for a, b in combinations(sorted(gt), 2):
            if prefix:
                a, b = f"{c['db_id']}::{a}", f"{c['db_id']}::{b}"
            pair[(a, b)] += 1
            pair[(b, a)] += 1
    out = Counter()
    for (a, b), n in pair.items():
        out[(a, b)] = math.log(1 + n)
    return out


def evaluate(cat: g.Catalog, cases, gold_key, methods, band_weight_fn=None):
    rows = []
    for c in cases:
        q = toks(c["question"])
        gold = set(gold_key(c))
        bw = band_weight_fn(q) if band_weight_fn else None
        scores = {}
        scores["bm25"] = g.bm25(cat, q)
        scores["tfidf"] = g.tfidf(cat, q)
        scores["ppr"] = g.single_ppr(cat, q)
        if bw is not None:
            scores["ppr_band"] = g.single_ppr(cat, q, band_weight=bw)
        scores["typed"] = g.fuse(cat, q)
        if bw is not None:
            scores["typed_band"] = g.fuse(cat, q, band_weight=bw)
        row = {"qid": c["qid"], "db": c["db_id"], "gold": sorted(gold),
               "n_tables": len(cat.tables)}
        for name, s in scores.items():
            if name not in methods:
                continue
            r = g.rank(s, cat)
            # rank over all catalog tables; gold presence is checked below
            row[name] = {"top5": r[:5], **g.metrics(r, gold),
                         "cert": g.certify(cat, s, q, gold)}
        rows.append(row)
    return rows


def band_fn(cases):
    qdf = Counter()
    for c in cases:
        qdf.update(set(toks(c["question"])))
    vals = sorted(qdf.values())
    hi = float(np.quantile(vals, 0.80))
    lo = float(np.quantile(vals, 0.20))
    def f(q):
        return {x: (0.15 if qdf[x] >= hi else 1.0) for x in q}
    return f, {"head_df_ge": hi, "tail_df_le": lo}


def run_known(cache, data):
    test = [c for c in data["spider"] if c["split"] == "test"]
    by = {}
    for c in test:
        by.setdefault(c["db_id"], []).append(c)
    rows = []
    t0 = time.time()
    for db, cs in by.items():
        if db not in cache["spider"]:
            continue
        tabs = tables_of(cache, db, prefix=False)
        cat = g.Catalog(tabs, fks_of(cache, db, tabs, prefix=False), prefix_db=False)
        bf, _ = band_fn(cs)
        rows += evaluate(cat, cs, lambda c: c["gold"],
                         ["bm25", "tfidf", "ppr", "ppr_band", "typed", "typed_band"], bf)
    return rows, time.time() - t0


def run_merged(cache, data):
    test = [c for c in data["spider"] if c["split"] == "test"]
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    coq = coquery_map([c for c in data["spider"] if c["split"] == "train"], prefix=True)
    t0 = time.time()
    cat = g.Catalog(tabs, fks, coquery=coq, prefix_db=True)
    build = time.time() - t0
    bf, bands = band_fn(test)
    rows = evaluate(cat, test, lambda c: [f"{c['db_id']}::{t}" for t in c["gold"]],
                    ["bm25", "tfidf", "ppr", "ppr_band", "typed", "typed_band"], bf)
    return rows, build, bands, len(tabs)


def run_scale(cache, data, sizes=(10, 30, 100, 300, 1000), repeats=3):
    test = [c for c in data["spider"] if c["split"] == "test"]
    all_tabs = []
    for db in cache["spider"]:
        all_tabs += tables_of(cache, db, prefix=True)
    by_name = {t["tid"]: t for t in all_tabs}
    all_fks = []
    for db in cache["spider"]:
        all_fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    coq = coquery_map([c for c in data["spider"] if c["split"] == "train"], prefix=True)
    out = []
    for N in sizes:
        for rep in range(repeats):
            rnd = random.Random(1000 * N + rep)
            if N >= len(all_tabs):
                sample = all_tabs
            else:
                sample = rnd.sample(all_tabs, N)
            have = {t["tid"] for t in sample}
            fks = [x for x in all_fks if x[0] in have and x[2] in have]
            cat = g.Catalog(sample, fks, coquery=coq, prefix_db=True)
            cs = [c for c in test
                  if all(f"{c['db_id']}::{t}" in have for t in c["gold"])]
            if not cs:
                continue
            rows = evaluate(cat, cs, lambda c: [f"{c['db_id']}::{t}" for t in c["gold"]],
                            ["bm25", "tfidf", "ppr", "typed"])
            out.append({"N": N, "rep": rep, "n_q": len(cs),
                        "n_tables": len(cat.tables),
                        "metrics": {m: g.mean_metrics([r[m] for r in rows]) for m in
                                    ("bm25", "tfidf", "ppr", "typed")},
                        "rows": rows})
            print("scale", N, rep, len(cs), {m: out[-1]["metrics"][m]["recall@5"] for m in out[-1]["metrics"]}, flush=True)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["known", "merged", "scale"], required=True)
    args = ap.parse_args()
    cache, data = load()
    if args.mode == "known":
        rows, secs = run_known(cache, data)
        out = {"mode": "known", "n": len(rows), "build_s": round(secs, 1),
               "metrics": {m: g.mean_metrics([r[m] for r in rows]) for m in
                           ("bm25", "tfidf", "ppr", "ppr_band", "typed", "typed_band")},
               "rows": rows}
        path = REPO / "06_结果" / "e11_spider_known.json"
    elif args.mode == "merged":
        rows, build, bands, nt = run_merged(cache, data)
        out = {"mode": "merged", "n": len(rows), "n_tables": nt,
               "build_s": round(build, 1), "bands": bands,
               "metrics": {m: g.mean_metrics([r[m] for r in rows]) for m in
                           ("bm25", "tfidf", "ppr", "ppr_band", "typed", "typed_band")},
               "rows": rows}
        path = REPO / "06_结果" / "e11_spider_merged.json"
    else:
        out = {"mode": "scale", "runs": run_scale(cache, data)}
        path = REPO / "06_结果" / "e11_spider_scale.json"
    json.dump(out, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k not in {"rows", "runs"}}, indent=2))
    print("wrote", path)


if __name__ == "__main__":
    main()
