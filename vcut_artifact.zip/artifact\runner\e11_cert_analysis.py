"""E11 certificate frontier from a retrieval run.

A path certificate accepts a table only when a query token is connected to it
by a typed edge (sample value, foreign key, or name) and the score margin over
the runner-up is large enough.  This script compares that rule with a plain
score threshold at matched precision.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[2]


def curve(rows, method, mode, ths):
    out = []
    total_ok = sum(r[method]["cert"]["correct"] for r in rows)
    for t in ths:
        acc = ok = 0
        for r in rows:
            c = r[method]["cert"]
            st = set(c["support"])
            if mode == "strong":
                take = bool(st & {"value", "fk"}) and c["margin"] >= t
            elif mode == "any":
                take = bool(st) and c["margin"] >= t
            elif mode == "name":
                take = ("name" in st) and c["margin"] >= t
            elif mode == "value":
                take = (c.get("value_exact") or c.get("fk_value")) and c["margin"] >= t
            elif mode == "strict":
                take = (c.get("value_exact") or c.get("fk_value")
                        or (c.get("name_hits", 0) >= 2 and c.get("name_rare"))) \
                       and c["margin"] >= t
            elif mode == "key":
                take = (c.get("unique_value") or c.get("unique_name") or c.get("fk_value")) \
                       and c["margin"] >= t
            elif mode == "key_exact":
                take = c.get("unique_value") and c["margin"] >= t
            elif mode == "score":
                take = c["raw"] >= t
            else:
                raise ValueError(mode)
            if take:
                acc += 1
                ok += int(c["correct"])
        out.append({"threshold": round(float(t), 4), "coverage": round(acc / len(rows), 4),
                    "precision": round(ok / acc, 4) if acc else None,
                    "accepted": acc, "correct": ok,
                    "false_pass_rate": round((acc - ok) / len(rows), 4),
                    "share_of_correct_kept": round(ok / total_ok, 4) if total_ok else None})
    return out


def at_precision(cur, p=0.95):
    good = [x for x in cur if x["precision"] is not None and x["precision"] >= p]
    return max(good, key=lambda x: x["coverage"]) if good else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run", help="e11_bird.json or e11_spider_*.json")
    ap.add_argument("--out", default="")
    args = ap.parse_args()
    d = json.load(open(args.run, encoding="utf-8"))
    rows = d["rows"]
    methods = [m for m in rows[0] if isinstance(rows[0][m], dict) and "cert" in rows[0][m]]
    margins = [i / 20 for i in range(0, 19)]
    res = {"n": len(rows), "source": str(args.run), "methods": {}}
    for m in methods:
        # score thresholds by quantile of observed top1 raw scores
        raws = sorted(r[m]["cert"]["raw"] for r in rows)
        qs = [raws[int(q * (len(raws) - 1))] for q in np.linspace(0.5, 0.99, 20)]
        res["methods"][m] = {
            "strong": curve(rows, m, "strong", margins),
            "any": curve(rows, m, "any", margins),
            "value": curve(rows, m, "value", margins),
            "strict": curve(rows, m, "strict", margins),
            "key": curve(rows, m, "key", margins),
            "key_exact": curve(rows, m, "key_exact", margins),
            "score": curve(rows, m, "score", qs),
        }
        for k in ("strong", "any", "value", "strict", "key", "key_exact", "score"):
            best = at_precision(res["methods"][m][k], 0.95)
            res["methods"][m][k + "_at_95"] = best
    out = args.out or str(Path(args.run).with_name(Path(args.run).stem + "_cert.json"))
    json.dump(res, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for m, v in res["methods"].items():
        print(m, {k: v[k + "_at_95"] for k in ("strong", "any", "value", "strict", "score")})
    print("wrote", out)


if __name__ == "__main__":
    main()
