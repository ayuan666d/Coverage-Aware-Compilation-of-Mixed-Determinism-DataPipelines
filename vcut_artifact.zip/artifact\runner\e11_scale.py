"""E11 scale curve: retrieval quality as the catalog grows from 10 to 876 tables.

Random catalogs of N tables are drawn from the 166 Spider databases; a question
is scored only when all of its gold tables are inside the catalog.  BM25,
single-graph PPR, typed diffusion and a dense embedding (Qwen3-Embedding-0.6B)
rank the same candidate set with the same schema documents.
"""
from __future__ import annotations

import json
import random
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
OUT = REPO / "06_结果" / "e11_scale.json"
SIZES = [10, 30, 100, 300, 876]
REPS = 3


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    train = [c for c in data["spider"] if c["split"] == "train"]
    npz = np.load(EMB, allow_pickle=True)
    ids = [str(x) for x in npz["ids"]]
    D = npz["D"].astype(np.float32)
    qids = [str(x) for x in npz["qids"]]
    Q = {q: v for q, v in zip(qids, npz["Q"].astype(np.float32))}
    pos = {t: i for i, t in enumerate(ids)}

    all_tables, all_fks = [], []
    for db, s in cache["spider"].items():
        for t in s["tables"]:
            all_tables.append(dict(t, db=db))
        have = {t["name"] for t in s["tables"]}
        for a, ca, b, cb in s["fks"]:
            if a in have and b in have:
                all_fks.append([f"{db}::{a}", ca, f"{db}::{b}", cb])
    coq = {}
    from itertools import combinations
    import math
    from collections import Counter
    pc = Counter()
    for c in train:
        for a, b in combinations(sorted(c["gold"]), 2):
            pc[(f"{c['db_id']}::{a}", f"{c['db_id']}::{b}")] += 1
            pc[(f"{c['db_id']}::{b}", f"{c['db_id']}::{a}")] += 1
    coq = Counter({k: math.log(1 + v) for k, v in pc.items()})

    band = None
    results = []
    for N in SIZES:
        acc = {m: [] for m in ("bm25", "ppr_band", "dense")}
        n_q_total = 0
        for rep in range(REPS):
            rnd = random.Random(7000 + N * 10 + rep)
            if N >= len(all_tables):
                sample = all_tables
            else:
                sample = rnd.sample(all_tables, N)
            have = {f"{t['db']}::{t['name']}" for t in sample}
            fks = [x for x in all_fks if x[0] in have and x[2] in have]
            cat = g.Catalog(sample, fks, coquery=coq, prefix_db=True, views=False)
            cs = [c for c in test if all(f"{c['db_id']}::{t}" in have for t in c["gold"])]
            if not cs:
                continue
            qdf = Counter()
            for c in cs:
                qdf.update(set(toks(c["question"])))
            vals = sorted(qdf.values())
            hi = float(np.quantile(vals, 0.8))
            n_q_total += len(cs)
            for c in cs:
                q = toks(c["question"])
                gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
                bw = {x: (0.15 if qdf[x] >= hi else 1.0) for x in q}
                cand = [pos[t] for t in have if t in pos]
                qv = Q[c["qid"]]
                sim = D[cand] @ qv
                dense_rank = [ids[cand[j]] for j in np.argsort(-sim)]
                for name, scores in [
                    ("bm25", g.bm25(cat, q)),
                    ("ppr_band", g.single_ppr(cat, q, band_weight=bw)),
                ]:
                    acc[name].append(g.metrics(g.rank(scores, cat), gold))
                acc["dense"].append(g.metrics(dense_rank, gold))
        row = {"N": N, "n_q": n_q_total,
               "metrics": {m: g.mean_metrics(v) for m, v in acc.items() if v}}
        results.append(row)
        print(N, n_q_total, {m: row["metrics"][m]["recall@5"] for m in row["metrics"]}, flush=True)
    json.dump({"sizes": SIZES, "reps": REPS, "runs": results},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
