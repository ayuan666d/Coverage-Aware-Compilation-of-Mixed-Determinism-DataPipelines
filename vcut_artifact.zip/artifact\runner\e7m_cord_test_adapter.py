"""E7m: adapt the CORD test split to the train-split schema.

The held-out parquet stores gold as a doubly encoded `parsed_data` blob
(`{"json": "...", "kie": ""}`) and OCR words as a Python repr string.  This
adapter rewrites those rows into the same `ocr_text` / `ocr_kie` / `ocr_box`
columns the runner already understands, so the identical prompt and checker
are applied to truly unseen receipts.
"""
from __future__ import annotations

import ast
import json
from pathlib import Path

import pandas as pd

REPO = Path(__file__).resolve().parents[2]
SRC = REPO / "04_数据" / "external" / "cord" / "test.parquet"
OUT = REPO / "04_数据" / "external" / "cord" / "test_adapted.parquet"


def deep_json(s):
    for _ in range(4):
        if isinstance(s, str):
            s = json.loads(s)
        else:
            break
    return s


def load_list(s):
    if isinstance(s, list):
        return s
    try:
        return json.loads(s)
    except Exception:
        try:
            return ast.literal_eval(s)
        except Exception:
            return []


def first_amount(x):
    if isinstance(x, list):
        return x[0] if x else None
    return x


def convert(pd_row) -> dict:
    parsed = json.loads(pd_row["parsed_data"])
    gold = deep_json(parsed.get("json") or "{}")
    if not isinstance(gold, dict):
        gold = {}
    items_raw = gold.get("line_items") or []
    if isinstance(items_raw, dict):
        items_raw = [items_raw]
    menu = []
    for it in items_raw:
        if not isinstance(it, dict):
            continue
        price = it.get("item_value") or it.get("item_unit_price")
        menu.append({"nm": it.get("item_name"), "price": price})
    sub = gold.get("subtotal") or {}
    tot = gold.get("total") or {}
    if not isinstance(sub, dict):
        sub = {}
    if not isinstance(tot, dict):
        tot = {}
    kie = {
        "menu": menu,
        "sub_total": {
            "subtotal_price": first_amount(sub.get("subtotal")),
            "tax_price": first_amount(sub.get("tax")),
            "service_price": first_amount(sub.get("service")),
            "discount_price": first_amount(sub.get("discount")),
        },
        "total": {"total_price": first_amount(tot.get("total"))},
    }
    raw = json.loads(pd_row["raw_data"])
    words = load_list(raw.get("ocr_words"))
    boxes = raw.get("ocr_boxes") or "[]"
    return {
        "file_name": f"test_{pd_row['id']}.jpg",
        "ocr_text": json.dumps([str(w) for w in words], ensure_ascii=False),
        "ocr_kie": json.dumps(kie, ensure_ascii=False),
        "ocr_box": boxes if isinstance(boxes, str) else json.dumps(boxes),
    }


def main():
    df = pd.read_parquet(SRC)
    rows = [convert(r) for _, r in df.iterrows()]
    out = pd.DataFrame(rows)
    out.to_parquet(OUT, index=False)
    ok_total = sum(1 for r in rows if json.loads(r["ocr_kie"])["total"]["total_price"])
    print(f"rows={len(out)} total_present={ok_total} -> {OUT}")


if __name__ == "__main__":
    main()
