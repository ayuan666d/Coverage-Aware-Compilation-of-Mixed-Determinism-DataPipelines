"""E49: encoder probe.

Question: in E_D o M, does the world-fitted encoder M contribute anything the
catalog channels E_D cannot supply?

Arms, same 12 catalog primitives, same split (693 train / 341 held-out
questions, 876 tables), same closed-form Fisher readout (lam=0.1):
  forge        catalog channels only
  forge+dense  + cos(M(q), M(t)) over the fitted Qwen3-Embedding-0.6B
  forge+rand   + cos of random gaussian vectors (an unfitted encoder)
  forge+noise  + dense scores with additive noise, sigma in {0.1, 0.3, 1.0}

Reading: forge+rand collapsing to forge means the encoder carries no
structure by itself. forge+noise decaying at the same rate as dense means the
readout treats M as one more feature. Decaying much slower means E_D corrects
M from catalog structure.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np

sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码\runner")
import e14_db_anchor as e14  # noqa: E402
from e15_objective import fit_fisher  # noqa: E402

W = r"D:\vldb2027_e11"
REPO = r"E:\vldb2027_pipeline_safety"
OUT = REPO + r"\06_结果\e49_encoder_probe.json"
CACHE_Q = W + r"\e49_q_train.npz"
MODEL = W + r"\models\Qwen3-Embedding-0.6B"


def evaluate(sc, te, doc_ids, gold):
    rows = []
    for qi, q in enumerate(te):
        order = np.argsort(-sc[qi])[:5]
        top = [doc_ids[i] for i in order]
        g = gold[q]
        r = {1: 0.0, 3: 0.0, 5: 0.0}
        mrr = 0.0
        for i, d in enumerate(top):
            if d in g:
                mrr = max(mrr, 1.0 / (i + 1))
                for k in r:
                    if i < k:
                        r[k] += 1.0 / len(g)
        rows.append({"qid": q, "recall@1": r[1], "recall@3": r[3],
                     "recall@5": r[5], "mrr": mrr})
    n = len(rows)
    return {k: round(sum(x[k] for x in rows) / n, 4)
            for k in ("recall@1", "recall@3", "recall@5", "mrr")}


def run(X, tr_i, te_i, tr, te, doc_ids, gold):
    Xtr = X[tr_i].reshape(-1, X.shape[-1]).astype(np.float32)
    mu = Xtr.mean(0)
    sd = Xtr.std(0) + 1e-9
    Xtr = (Xtr - mu) / sd
    Y = np.zeros((len(tr), len(doc_ids)), dtype=np.float32)
    for qi, q in enumerate(tr):
        for g in gold[q]:
            j = _dmap.get(g)
            if j is not None:
                Y[qi, j] = 1.0
    w = fit_fisher(Xtr, Y.reshape(-1), 0.1)
    Xte = ((X[te_i] - mu) / sd).reshape(len(te), len(doc_ids), -1)
    return evaluate(Xte @ w, te, doc_ids, gold), w


_dmap = {}


def main():
    global _dmap
    Z = np.load(W + r"\z_all_feats.npz", allow_pickle=True)
    F = Z["F"].astype(np.float32)
    qids = [str(x) for x in Z["qids"]]
    doc_ids = [str(x) for x in Z["doc_ids"]]
    _dmap = {d: i for i, d in enumerate(doc_ids)}
    idx_of = {q: i for i, q in enumerate(qids)}

    cases = json.load(open(REPO + r"\06_结果\e11_cases.json", encoding="utf-8"))["spider"]
    gold = {c["qid"]: {f"{c['db_id']}::{g.lower()}" for g in c["gold"]} for c in cases}
    qtext = {c["qid"]: c["question"] for c in cases}

    rows = json.load(open(W + r"\e11_dense_spider.json", encoding="utf-8"))["rows"]
    te = [r["qid"] for r in rows]
    tr = [q for q in qids if q not in set(te)]
    tr_i = [idx_of[q] for q in tr]
    te_i = [idx_of[q] for q in te]
    print(f"train {len(tr)} test {len(te)} tables {len(doc_ids)}", flush=True)

    emb = np.load(W + r"\e11_emb_spider.npz", allow_pickle=True)
    ids = [str(x) for x in emb["ids"]]
    Dm = emb["D"].astype(np.float32)
    Qte = emb["Q"].astype(np.float32)
    qte = [str(x) for x in emb["qids"]]
    miss = sum(1 for x in ids if x.lower() not in _dmap)
    print(f"doc id mismatches: {miss}/{len(ids)}", flush=True)

    Dsort = np.zeros((len(doc_ids), Dm.shape[1]), dtype=np.float32)
    for k, x in enumerate(ids):
        j = _dmap.get(x.lower())
        if j is not None:
            Dsort[j] = Dm[k]

    if os.path.exists(CACHE_Q):
        Qtr = np.load(CACHE_Q)["Q"].astype(np.float32)
        print("query cache loaded", flush=True)
    else:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(MODEL, device="cpu")
        model.max_seq_length = 384
        Qtr = model.encode([qtext[q] for q in tr], batch_size=16,
                           normalize_embeddings=True, convert_to_numpy=True,
                           show_progress_bar=True, prompt_name="query").astype(np.float32)
        np.savez_compressed(CACHE_Q, Q=Qtr, qids=np.array(tr))
        print("train queries encoded", flush=True)

    Qall = np.zeros((len(qids), Qte.shape[1]), dtype=np.float32)
    for q, v in zip(qte, Qte):
        Qall[idx_of[q]] = v
    for q, v in zip(tr, Qtr):
        Qall[idx_of[q]] = v
    COS = Qall @ Dsort.T

    rng = np.random.default_rng(0)
    Qr = rng.standard_normal(Qall.shape).astype(np.float32)
    Dr = rng.standard_normal(Dsort.shape).astype(np.float32)
    Qr /= np.linalg.norm(Qr, axis=1, keepdims=True)
    Dr /= np.linalg.norm(Dr, axis=1, keepdims=True)
    COS_R = Qr @ Dr.T

    out = {}
    base = F
    s, _ = run(base, tr_i, te_i, tr, te, doc_ids, gold)
    out["forge"] = s
    print("forge", json.dumps(s), flush=True)

    for name, C in [("forge+dense", COS), ("forge+rand", COS_R)]:
        X = np.concatenate([F, C[:, :, None]], axis=2)
        s, w = run(X, tr_i, te_i, tr, te, doc_ids, gold)
        out[name] = s
        out[name + "_w_last"] = float(w[-1])
        print(name, json.dumps(s), "w_cos", round(float(w[-1]), 4), flush=True)

    xs = F.reshape(-1, F.shape[-1])
    xmu, xsd = xs.mean(0), xs.std(0) + 1e-9
    cs = COS.std()
    for sig in (0.1, 0.3, 1.0):
        r2 = np.random.default_rng(int(sig * 100))
        Cn = COS + sig * cs * r2.standard_normal(COS.shape).astype(np.float32)
        X = np.concatenate([F, Cn[:, :, None]], axis=2)
        s, _ = run(X, tr_i, te_i, tr, te, doc_ids, gold)
        out[f"forge+dense_noise{sig}"] = s
        print(f"noise{sig}", json.dumps(s), flush=True)

    # dense alone, same held-out questions, same tables
    s_dense = evaluate(COS[te_i], te, doc_ids, gold)
    out["dense_alone"] = s_dense
    print("dense_alone", json.dumps(s_dense), flush=True)

    out["reference"] = {"dense_zero_r5": 0.8793, "dense_zero_r1": 0.586,
                        "e14_cf2_ridge_r1": 0.4863, "e14_cf2_ridge_r5": 0.8622}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
