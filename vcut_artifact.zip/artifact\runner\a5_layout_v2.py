# -*- coding: utf-8 -*-
"""A5: layout witness v2 — fix the dominant failure (subtotal read as total).

e7l's TOTAL_KEYS match "subtotal" because `"total" in t`. 152 of its 183 errors
pick the subtotal line. v2 therefore:

  1. rejects label tokens containing sub/item/qty/jml from total candidates;
  2. prefers strong total labels (grand total / total due / amount due / netto /
     paid / debit) over a bare TOTAL;
  3. uses the OCR-derived total as a tie-breaker among printed candidates
     (a candidate equal to sub+tax+svc-disc wins);
  4. penalises the subtotal value when the components say the total is different.

The witness stays independent of the model: it only reads label/amount geometry.
"""
from __future__ import annotations

import importlib.util
import json
import statistics
import sys
from collections import Counter
from pathlib import Path

RUN = Path(r"E:\vldb2027_pipeline_safety\05_代码\runner")
sys.path.insert(0, str(RUN))


def load(name, fname):
    spec = importlib.util.spec_from_file_location(name, str(RUN / fname))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


e7l = load("e7l", "e7l_layout_witness.py")
e7k = load("e7k", "e7k_independent_witness.py")

REPO = Path(r"E:\vldb2027_pipeline_safety")
DATA = REPO / "04_数据" / "external" / "cord" / "train.parquet"
RAW = REPO / "06_结果" / "e7_receipts.json"
OUT = REPO / "06_结果" / "a5_layout_v2.json"

STRONG = ("grand total", "grandtotal", "total due", "amount due", "netto", "paid", "debit")
CASH = ("cash", "change", "kembalian", "bayar", "tendered", "tunai")


def total_label(tok: str) -> bool:
    t = e7k.label_of(tok)
    t = " ".join(t.split())
    if not t:
        return False
    if any(x in t for x in ("sub", "item", "qty", "jml", "jumlah item")):
        return False
    return e7k.is_label(tok, e7k.TOTAL_KEYS)


def cash_label(tok: str) -> bool:
    t = e7k.label_of(tok)
    return any(k in t for k in CASH)


def read_candidates(tokens):
    """All (label_text, value, x, y) candidates for a total label."""
    if not tokens:
        return []
    tol = max(8.0, statistics.median(t["h"] for t in tokens) * 0.8)
    out = []
    for t in tokens:
        if not total_label(t["text"]):
            continue
        same = [u for u in tokens if u is not t and abs(u["y"] - t["y"]) <= tol]
        amounts = [(u["x"], e7k.num(u["text"])) for u in same
                   if e7k.num(u["text"]) is not None and e7k.num(u["text"]) >= 100]
        if not amounts:
            continue
        right = [(x, v) for x, v in amounts if x >= t["x"] - 2]
        v = min(right, key=lambda p: p[0])[1] if right else max(amounts, key=lambda p: p[0])[1]
        near_cash = any(cash_label(u["text"]) and abs(u["y"] - t["y"]) <= tol
                        for u in same)
        out.append({"label": e7k.label_of(t["text"]), "value": v, "x": t["x"], "y": t["y"],
                    "cash": near_cash})
    return out


def pick(cands, sub, derived):
    if not cands:
        return None, "none"
    def score(c):
        s = 0.0
        lab = c["label"]
        if any(k in lab for k in STRONG):
            s += 3
        elif "total" in lab:
            s += 2
        if derived is not None and c["value"] is not None:
            if abs(c["value"] - derived) <= max(2, 0.01 * abs(derived)):
                s += 2.5
        if sub is not None and c["value"] is not None:
            if c["value"] >= sub:
                s += 0.8
            elif derived is not None and abs(sub - derived) > max(2, 0.01 * abs(derived)):
                s -= 3
        if c["cash"]:
            s -= 2
        return s
    best = max(cands, key=lambda c: (score(c), c["y"], c["x"]))
    return best["value"], "layout"


def main():
    import pandas as pd
    df = pd.read_parquet(DATA)
    raw = {r["file"]: r for r in json.loads(RAW.read_text(encoding="utf-8"))["rows"]}
    rows = []
    for _, r in df.iterrows():
        f = r["file_name"]
        if f not in raw:
            continue
        toks = e7l.parse_box(r["ocr_box"])
        text = raw[f]["text"]
        sub, _ = e7l.read_label(toks, e7k.SUB_KEYS, text)
        tax, _ = e7l.read_label(toks, e7k.TAX_KEYS, text)
        svc, _ = e7l.read_label(toks, e7k.SVC_KEYS, text)
        disc, _ = e7l.read_label(toks, e7k.DISC_KEYS, text)
        derived = None
        if sub is not None:
            derived = sub + (tax or 0) + (svc or 0) - (disc or 0)
        total, src = pick(read_candidates(toks), sub, derived)
        if total is None:
            # flat fallback with the same strict label filter
            vals = []
            for i, tog in enumerate(text.replace("|", " ").split()):
                if total_label(tog):
                    for u in text.replace("|", " ").split()[i + 1:i + 4]:
                        v = e7k.num(u)
                        if v is not None and v >= 100:
                            vals.append(v)
                            break
            if vals:
                total, src = Counter(vals).most_common(1)[0][0], "flat"
        rows.append({
            "file": f, "gold": raw[f]["gold"]["total"], "sub": sub,
            "derived": derived, "total": total, "source": src,
            "correct": e7k.match(total, raw[f]["gold"]["total"]),
        })

    known = [x for x in rows if x["correct"] is not None]
    acc = sum(1 for x in known if x["correct"]) / max(1, len(known))
    old = json.loads((REPO / "06_结果" / "e7l_layout_witness.json").read_text(encoding="utf-8"))
    oldmap = {r["file"]: r for r in old["rows"]}
    delta = {"fixed": 0, "broken": 0, "same_ok": 0, "same_bad": 0}
    for x in rows:
        o = oldmap.get(x["file"], {}).get("ocr_correct")
        if o is None or x["correct"] is None:
            continue
        if o is False and x["correct"] is True:
            delta["fixed"] += 1
        elif o is True and x["correct"] is False:
            delta["broken"] += 1
        elif o is True and x["correct"] is True:
            delta["same_ok"] += 1
        else:
            delta["same_bad"] += 1

    found = sum(1 for x in rows if x["total"] is not None)
    out = {"n": len(rows), "found": found, "accuracy": round(acc, 4),
           "old_accuracy": old["summary"]["ocr_total_accuracy"],
           "delta": delta,
           "source": dict(Counter(x["source"] for x in rows)),
           "rows": rows}
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print("n", len(rows), "found", found, "acc", round(acc, 4),
          "old", old["summary"]["ocr_total_accuracy"], "delta", delta)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
