"""E11: rebuild the dense rows from cached embeddings.

The table-name casing bug changed the gold labels but not the embeddings, so the
dense baseline can be recomputed exactly from ``e11_emb_*.npz`` without running
the encoder again (the machine is CPU-bound).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CASES = REPO / "06_结果" / "e11_cases.json"
DENSE = Path("D:/vldb2027_e11")


def recompute(kind):
    data = json.load(open(CASES, encoding="utf-8"))
    npz = np.load(DENSE / f"e11_emb_{kind}.npz", allow_pickle=True)
    ids = [str(x) for x in npz["ids"]]
    D = npz["D"].astype(np.float32)
    Q = npz["Q"].astype(np.float32)
    qids = [str(x) for x in npz["qids"]]
    qmap = {q: Q[i] for i, q in enumerate(qids)}
    pos = {t: i for i, t in enumerate(ids)}
    by_db = {}
    for i, tid in enumerate(ids):
        by_db.setdefault(tid.split("::")[0], []).append(i)
    cases = data["bird"] if kind == "bird" else [c for c in data["spider"] if c["split"] == "test"]
    rows = []
    for c in cases:
        qv = qmap.get(c["qid"])
        if qv is None:
            continue
        cand = by_db[c["db_id"]] if kind == "bird" else list(range(len(ids)))
        sim = D[cand] @ qv
        ranked = [ids[cand[j]] for j in np.argsort(-sim)]
        gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
        rows.append({"qid": c["qid"], "db": c["db_id"], "gold": sorted(gold),
                     "top5": ranked[:5], **g.metrics(ranked, gold)})
    out = {"kind": kind, "n": len(rows), "metrics": g.mean_metrics(rows), "rows": rows}
    path = DENSE / f"e11_dense_{kind}.json"
    json.dump(out, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    print(kind, out["n"], out["metrics"])
    return out


def main():
    for kind in ("bird", "spider"):
        recompute(kind)


if __name__ == "__main__":
    main()
