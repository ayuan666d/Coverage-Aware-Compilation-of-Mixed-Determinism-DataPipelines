"""E12 addendum 3: causal ablation of the GA's strength — which evidence class
carries the +23 points over BM25?

Feature classes (e12_gp 10-primitive layout):
  lexical     [0,1,3,4]  raw/idf overlap, bm25, word-latent cosine
  morphology  [2,5]      prefix-4 stem, char-ngram latent   (equivalence classes on tokens)
  typed       [6,7,8,9]  name/col/value hits, typed product  (where the word hits)

Arms (GA re-run per arm, same budget): lexical / lexical+morph / lexical+typed /
full-minus-morph / full.  If the theory is right (strength = morphology+typing
that BM25's aggregate algebra cannot express), dropping morphology should
collapse toward BM25 and dropping typed should cost less than dropping
morphology... or not — that ordering is exactly what this measures.
"""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from pathlib import Path

import numpy as np

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
CASES = REPO / "06_结果" / "e11_cases.json"
CACHE = WORK / "schema_cache.json"
NPZ = WORK / "e12_spectral.npz"
OUT = REPO / "06_结果" / "e12_ablate.json"

WORD = re.compile(r"[a-z0-9]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us list show give find return
number names name""".split())

ARMS = {
    "lexical": [0, 1, 3, 4],
    "lex+morph": [0, 1, 2, 3, 4, 5],
    "lex+typed": [0, 1, 3, 4, 6, 7, 8, 9],
    "full_no_morph": [0, 1, 3, 4, 6, 7, 8, 9],
    "full": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
}


def wtoks(s):
    return [t for t in WORD.findall(s.lower()) if t not in STOP]


def ngrams(w, ns=(3, 4, 5)):
    pad = f"<{w}>"
    return {pad[i:i + n] for n in ns for i in range(len(pad) - n + 1)} if len(pad) >= 3 else set()


def stem4(w):
    return w[:4] if len(w) >= 4 else w


def metrics_top(top_ids, gold_set):
    r = {1: 0.0, 5: 0.0}
    mrr = 0.0
    for i, d in enumerate(top_ids[:5]):
        if d in gold_set:
            mrr = max(mrr, 1.0 / (i + 1))
            for k in r:
                if i < k:
                    r[k] += 1.0 / len(gold_set)
    return r, mrr


def main():
    z = np.load(NPZ, allow_pickle=True)
    doc_ids = [str(x) for x in z["doc_ids"]]
    D = len(doc_ids)
    doc_wn = z["doc_word"] / np.maximum(np.linalg.norm(z["doc_word"], axis=1, keepdims=True), 1e-9)
    doc_gn = z["doc_gram"] / np.maximum(np.linalg.norm(z["doc_gram"], axis=1, keepdims=True), 1e-9)

    cache = json.load(open(CACHE, encoding="utf-8"))["spider"]
    name_t, col_t, val_t, all_t, stem_t = {}, {}, {}, {}, {}
    for db, s in cache.items():
        for t in s["tables"]:
            fid = f"{db}::{t['name'].lower()}"
            nm = list(wtoks(t["name"]))
            cl, vl = [], []
            for c in t["columns"]:
                cl += wtoks(c["name"])
                for v in (c.get("values") or [])[:12]:
                    vl += wtoks(str(v))
            name_t[fid], col_t[fid], val_t[fid] = set(nm), set(cl), set(vl)
            all_t[fid] = set(nm) | set(cl) | set(vl)
            stem_t[fid] = {stem4(x) for x in all_t[fid] if len(x) >= 4}
    df = Counter()
    for ts in all_t.values():
        df.update(ts)
    idf = {t: math.log(1 + (D - df[t] + 0.5) / (df[t] + 0.5)) for t in df}
    tf = np.zeros((D, len(df)), dtype=np.float32)
    tidx = {t: i for i, t in enumerate(sorted(df))}
    for j, f in enumerate(doc_ids):
        for t in all_t[f]:
            tf[j, tidx[t]] = 1.0
    dlr = tf.sum(axis=1)

    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    gold_all = {c["qid"]: {f"{c['db_id']}::{g.lower()}" for g in c["gold"]} for c in cases}
    qtext = {c["qid"]: c["question"] for c in cases}
    split = {c["qid"]: c["split"] for c in cases}
    qids = sorted(qtext, key=lambda q: int(q[2:]))
    train_q = [q for q in qids if split[q] == "train"]
    test_q = [q for q in qids if split[q] == "test"]

    wv_vocab = {t: i for i, t in enumerate(z["word_vocab"])}
    gr_vocab = {t: i for i, t in enumerate(z["gram_vocab"])}
    term_w, term_g = z["term_word"], z["term_gram"]

    def q_latent(tokens, vocab, term):
        vs = [term[vocab[t]] for t in set(tokens) if t in vocab]
        if not vs:
            return None
        v = np.mean(vs, axis=0)
        return v / max(np.linalg.norm(v), 1e-9)

    def build_F(qs):
        F = np.zeros((len(qs), D, 10), dtype=np.float32)
        for qi, q in enumerate(qs):
            qt = wtoks(qtext[q])
            qset = set(qt)
            qstem = {stem4(w) for w in qt if len(w) >= 4}
            wv = q_latent(qt, wv_vocab, term_w)
            gv = q_latent([g for w in qt for g in ngrams(w)], gr_vocab, term_g)
            if wv is not None:
                F[qi, :, 4] = doc_wn @ wv
            if gv is not None:
                F[qi, :, 5] = doc_gn @ gv
            s = np.zeros(D, dtype=np.float32)
            for t, qc in Counter(qt).items():
                if t not in tidx:
                    continue
                col = tf[:, tidx[t]]
                s += qc * idf[t] * (col * 2.2) / (col + 1.2 * (0.25 + 0.75 * dlr / (dlr.mean() + 1e-9)))
            F[qi, :, 3] = s
            for j, f in enumerate(doc_ids):
                inter = qset & all_t[f]
                F[qi, j, 0] = len(inter)
                F[qi, j, 1] = sum(idf.get(t, 0.0) for t in inter)
                F[qi, j, 2] = len(qstem & stem_t[f])
                F[qi, j, 6] = len(qset & name_t[f])
                F[qi, j, 7] = len(qset & col_t[f])
                F[qi, j, 8] = len(qset & val_t[f])
            F[:, :, 9] = 0
        F[:, :, 9] = np.log1p(F[:, :, 6]) * np.log1p(F[:, :, 7]) * np.log1p(F[:, :, 8])
        return F

    print("building features…", flush=True)
    Ft = build_F(train_q)
    mu = Ft.reshape(-1, Ft.shape[-1]).mean(0)
    sd = Ft.reshape(-1, Ft.shape[-1]).std(0) + 1e-9
    gold_tr = [gold_all[q] for q in train_q]

    def run_ga(idx, tag):
        Fn = (Ft[:, :, idx] - mu[idx]) / sd[idx]

        def fitness_batch(W, chunk=120):
            P = W.shape[0]
            out = np.zeros(P)
            for s0 in range(0, len(train_q), chunk):
                e = min(s0 + chunk, len(train_q))
                sc = Fn[s0:e] @ W.T
                for p in range(P):
                    part = np.argpartition(-sc[:, :, p], 8, axis=1)[:, :8]
                    for qi in range(e - s0):
                        loc = part[qi]
                        order = loc[np.argsort(-sc[qi, loc, p])]
                        g = gold_tr[s0 + qi]
                        r5 = 0.0
                        for di in order[:5]:
                            if doc_ids[di] in g:
                                r5 += 1.0 / len(g)
                        out[p] += r5
            return out / len(train_q)

        rng = np.random.default_rng(7)
        P, G = 80, 60
        pop = rng.uniform(-0.5, 1.5, (P, len(idx)))
        for gen in range(G):
            fit = fitness_batch(pop)
            elite = pop[np.argsort(-fit)[:2]].copy()
            new = [elite[0], elite[1]]
            while len(new) < P:
                i, j = rng.integers(0, P, 2)
                a, b = (pop[i], pop[j]) if fit[i] >= fit[j] else (pop[j], pop[i])
                lam = rng.uniform(-0.25, 1.25, len(idx))
                child = a + lam * (b - a)
                child += (rng.random(len(idx)) < 0.25) * rng.normal(0, 0.2, len(idx))
                new.append(np.clip(child, -3, 3))
            pop = np.array(new)
        fit = fitness_batch(pop)
        w = pop[int(np.argmax(fit))]
        Fte = (build_F(test_q)[:, :, idx] - mu[idx]) / sd[idx]
        rows = []
        for qi, q in enumerate(test_q):
            sc = Fte[qi] @ w
            order = np.argsort(-sc)[:5]
            top = [doc_ids[i] for i in order]
            r, m = metrics_top(top, gold_all[q])
            rows.append({"qid": q, "top5": top, "r5": r[5], "mrr": m})
        summ = {"r5": round(float(np.mean([x["r5"] for x in rows])), 4),
                "mrr": round(float(np.mean([x["mrr"] for x in rows])), 4)}
        print(f"[{tag}] {json.dumps(summ)}", flush=True)
        return {"arms_features": idx, "train_r5": round(float(fit.max()), 4),
                "test": summ, "rows": rows}

    out = {}
    for tag, idx in ARMS.items():
        out[tag] = run_ga(idx, tag)
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
