"""E46 补充：小样本 pi 估计的收缩修复验证（1500→10k dense/fuse/bm25 外推）。

结论动机：逐金标 pi_hat = X/M_S 在 M_S=549 时粒度 1/549≈0.0018，比典型 pi≈0.003
还粗，外推出现"小 k 高估、大 k 低估"。本脚本用 Gamma-Poisson 收缩
    pi_tilde = (X + b*pi_bar) / (M_S + b)
（b 为伪干扰表数，pi_bar 为池均值）验证"定律成立、只是估计需收缩"。
"""
import json
import numpy as np
from scipy.stats import binom

D = "D:/vldb2027_e11"


def load(p):
    return [json.loads(l) for l in open(f"{D}/{p}", encoding="utf-8")]


M_S, M10 = 549, 9049
S = load("e44_legacy_rich_1k-syn_perq.jsonl")     # 1500 目录
B10 = load("e44_legacy_rich_10k-syn_perq.jsonl")  # 10k 实测

KS = [1, 3, 5, 10, 20, 50, 100]


def real_curve(m):
    return [np.mean([sum(1 for p in q[m]["gpos"] if p < k) / q["n_gold"]
                     for q in B10]) * 100 for k in KS]


def predict(m, b):
    """用 1500 的 (r, 收缩 pi) 外推 10k 的 R@k 曲线。b=0 即无收缩。"""
    X = np.array([g - r for q in S
                  for r, g in zip(q[m]["gpos_real"], q[m]["gpos"])], float)
    pi_bar = X.mean() / M_S
    out = []
    for k in range(1, 301):
        vals = []
        for q in S:
            gs = [(r, g - r) for r, g in zip(q[m]["gpos_real"], q[m]["gpos"])]
            r = np.array([g[0] for g in gs], float)
            Xg = np.array([g[1] for g in gs], float)
            pi = (Xg + b * pi_bar) / (M_S + b)
            p = binom.cdf(k - 1 - r, M10, pi)
            p[r > k - 1] = 0.0
            vals.append(p.mean())
        out.append(np.mean(vals) * 100)
    return np.array(out)


print("1500→10k 外推误差（收缩 b：0=无收缩，伪干扰表数）")
print(f"{'方法':7s}{'b':>5s}  " + "  ".join(f"k={k:<4d}" for k in KS) + "   |max|")
for m in ("dense", "fuse", "bm25"):
    real = real_curve(m)
    for b in (0, 2, 10, 50, 200):
        c = predict(m, b)
        errs = [c[KS.index(k)] - v for k, v in zip(KS, real)]
        print(f"{m:7s}{b:>5d}  " + "  ".join(f"{e:+7.2f}" for e in errs)
              + f"   {max(abs(e) for e in errs):6.2f}")
    print()

print("对照：FORGE 4k→10k（M_S=3049，无收缩）最大误差 1.59 —— E46 §3.2")
