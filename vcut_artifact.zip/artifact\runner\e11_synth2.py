"""E11-SYNTH2: label-free objectives that actually discriminate, searched on train.

Two defects in e11_synth.py are fixed before any new number is read.

(1) Protocol.  The previous search scored its objective on the 341 TEST questions.  It never
    touched gold, but it was still tuned on the evaluation set -- the same mistake e11_support.py
    made and e11_support2.py had to undo.  Here the ascent only ever sees the 693 TRAIN questions
    (132 databases); the rule is frozen and the 341 test questions are read once, at the end.
(2) Mechanics.  BM25 was added after the query-word aggregation instead of as a per-word term
    score, so the "bm25 weight" knob could not express a per-word lexical contribution.  Term
    scores are now one of the per-word feature matrices, which also makes the leave-one-word-out
    split exact (dropping a word = subtracting its term score from the candidate set and its row
    from the aggregate).

Three objectives, one search space, one budget, and one supervised control:

  cover_doc   leave-one-word-out.  Rank with the other words.  Is the dropped word literally
              written in the table that wins (whole document: identifiers + sampled values)?
              Scored chance-corrected: subtract df/N, weight by idf.  Labels appear nowhere.
  cover_name  same split, but the held-out evidence may only come from identifiers.  This is the
              stricter corpus: a table earns it only when the user's word is in a name.
  soft        leave-one-word-out, graded.  Instead of containment, the log ratio of the dropped
              word's own column-level diffusion mass on the winning table against that word's
              mean mass over the lake.  Uses only graph quantities already computed for ranking.
  sup         control, NOT a claim: train recall@5 against train gold -- the identical search
              with labels.  It prices how much of the earlier loss was the objective and how much
              was the space or the ascent.

PRE-REGISTERED MAIN CRITERION (written before the first run): an operator found under a
label-free objective must not read below the hand-written arm on the frozen test questions
(recall@1 72.73%, recall@5 81.62%).  If cover and soft both lose while sup wins, then the space
and the search are fine and what the line lacks is an objective; the claim "the structure comes
from the database" is downgraded to "structure still hand-written, label-free objective
unsolved", and that negative is reported with its numbers.

FREE DIAGNOSTIC: every configuration the ascent touches is also scored on train gold (never used
for selection in the label-free runs).  Spearman between objective value and train recall@5 over
the trace is the alignment question itself, answered without a single extra search.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np
from scipy import sparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_col import col_index  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
CASES = R / "e11_cases.json"
EMB = WORK / "e11_emb_spider.npz"
OUT = R / "e11_synth2.json"
EPS = 1e-6
ITERS = 20
FEATS = ("tabdiff", "coldiff", "namehit", "valhit", "fkhit", "bm25")
GRID = (0.0, 0.25, 0.5, 0.75, 1.0)
KS = (876, 30, 20, 10)
AGGS = ("geo", "lin")
OBJECTIVES = ("cover_doc", "cover_name", "soft", "sup")
CAP = 8.0                      # nats cap on any single held-out word
SWEEPS = 3
HAND = {"weights": {"tabdiff": 0.0, "coldiff": 1.0, "namehit": 0.0, "valhit": 0.0,
                    "fkhit": 0.0, "bm25": 0.0}, "alpha": 0.85, "agg": "geo", "K": 30}
HAND_TEST = {"r1": 0.7273, "r5": 0.8162}   # from e11_synth.json, same arm and same reading code


def lambda2(cat):
    A = ((cat.union + cat.union.T) * 0.5).tocsr()
    d = np.asarray(A.sum(axis=1)).ravel()
    d[d <= 0] = 1.0
    S = (sparse.diags(1.0 / np.sqrt(d)) @ A @ sparse.diags(1.0 / np.sqrt(d))).tocsr()
    try:
        from scipy.sparse.linalg import eigsh
        w = np.sort(np.real(eigsh(S, k=3, which="LA", return_eigenvectors=False)))[::-1]
        return float(w[1]) if w.size > 1 else 0.85
    except Exception:
        return 0.85


def spearman(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    if np.allclose(x, x[0]) or np.allclose(y, y[0]):
        return None
    rx = np.argsort(np.argsort(x)).astype(float)
    ry = np.argsort(np.argsort(y)).astype(float)
    return round(float(np.corrcoef(rx, ry)[0, 1]), 4)


def main():
    t0 = time.time()
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    tr_cases = [c for c in data["spider"] if c["split"] == "train"]
    te_cases = [c for c in data["spider"] if c["split"] == "test"]
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += [dict(t, db=db) for t in cache["spider"][db]["tables"]]
        have = {t["name"] for t in cache["spider"][db]["tables"]}
        fks += [[f"{db}::{a}", ca, f"{db}::{b}", cb] for a, ca, b, cb in cache["spider"][db]["fks"]
                if a in have and b in have]
    cat = g.Catalog(tabs, fks, coquery=None, prefix_db=True)   # no co-query: cold catalogue
    N = len(cat.tables)
    colnodes, cdocs, starts, ends = col_index(cat)
    lam = lambda2(cat)
    alphas = [0.80, 0.85, 0.90, round(lam, 3)]

    vocab = sorted({w for c in tr_cases + te_cases for w in toks(c["question"])
                    if ("token", w) in cat.idx})
    tid = {w: i for i, w in enumerate(vocab)}
    n_tok = len(vocab)
    idf = np.array([math.log(1 + (N - cat.token_df.get(w, 0) + 0.5)
                             / (cat.token_df.get(w, 0) + 0.5)) for w in vocab], dtype=np.float32)

    # ---- static per-word / per-table matrices: identifier corpus, value corpus, FK neighbours --
    namehit = np.zeros((n_tok, N), dtype=np.float32)
    valhit = np.zeros((n_tok, N), dtype=np.float32)
    name_df, val_df = Counter(), Counter()
    nm_toks, vl_toks = [], []
    for j, t in enumerate(cat.tables):
        nm = set(toks(t["name"]))
        for c in t["columns"]:
            nm |= set(toks(c["name"]))
        vl = set()
        for c in t["columns"]:
            for v in c.get("values", [])[:6]:
                vl |= set(toks(v)[:3])
        nm_toks.append(nm)
        vl_toks.append(vl)
        name_df.update(nm)
        val_df.update(vl)
        for w in nm:
            i = tid.get(w)
            if i is not None:
                namehit[i, j] = 1.0
        for w in vl:
            i = tid.get(w)
            if i is not None:
                valhit[i, j] = 1.0
    doc_hit = ((namehit + valhit) > 0).astype(np.float32)
    nbr = [[] for _ in range(N)]
    for a, ca, b, cb in cat.fks:
        ja, jb = cat.table_pos.get(a), cat.table_pos.get(b)
        if ja is not None and jb is not None:
            nbr[ja].append(jb)
            nbr[jb].append(ja)
    fkhit = np.zeros((n_tok, N), dtype=np.float32)
    for j in range(N):
        s = set()
        for k in nbr[j]:
            s |= nm_toks[k] | vl_toks[k]
        for w in s:
            i = tid.get(w)
            if i is not None:
                fkhit[i, j] = 1.0
    ch_doc = np.array([cat.token_df.get(w, 0) / N for w in vocab], dtype=np.float32)
    ch_name = np.array([name_df.get(w, 0) / N for w in vocab], dtype=np.float32)
    print(f"catalogue+features in {time.time()-t0:.0f}s  N={N} nodes={len(cat.idx)} "
          f"vocab={n_tok} lambda2={lam:.4f}", flush=True)

    # ---- diffusion per damping factor: table-level and per-word best-column ----
    diff = {}
    for a in alphas:
        td = np.zeros((n_tok, N), dtype=np.float32)
        cd = np.zeros((n_tok, N), dtype=np.float32)
        for w in vocab:
            x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, a, ITERS)
            st = np.asarray(cat.table_scores(x), dtype=np.float32)
            mx = float(st.max())
            if mx > 0:
                td[tid[w]] = st / mx
            cv = np.asarray(x)[colnodes].astype(np.float32)
            cmx = float(cv.max())
            if cmx > 0:
                cv = cv / cmx
            cd[tid[w]] = np.maximum.reduceat(cv, starts)
        diff[a] = (td, cd)
        print(f"  diffusion alpha={a} done {time.time()-t0:.0f}s", flush=True)

    # ---- BM25 as per-word term scores so the operator is additive over words ----
    docs = [g.table_doc(t) for t in cat.tables]
    dl = np.array([len(d) for d in docs], dtype=np.float32)
    avgdl = float(dl.mean())
    dfc = Counter()
    for d in docs:
        dfc.update(set(d))
    tf = np.zeros((n_tok, N), dtype=np.float32)
    for i, w in enumerate(vocab):
        for j, d in enumerate(docs):
            if w in d:
                tf[i, j] = d.count(w)
    k1, bb = 1.2, 0.75
    TS = (idf[:, None] * tf * (k1 + 1.0)
          / (tf + k1 * (1.0 - bb + bb * dl[None, :] / avgdl))).astype(np.float32)
    print(f"bm25 term matrix in {time.time()-t0:.0f}s", flush=True)

    def prep(cases):
        rows = []
        for c in cases:
            q = sorted(set(toks(c["question"])))
            idx = np.array([tid[w] for w in q if w in tid], dtype=np.int64)
            gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
            pos = {cat.table_ids.index(t) for t in gold if t in cat.table_pos}
            rows.append({"qid": c["qid"], "idx": idx, "iw": idf[idx],
                         "TS": TS[idx], "b": TS[idx].sum(0),
                         "goldpos": pos, "ngold": max(1, len(pos))})
        return rows

    train, test = prep(tr_cases), prep(te_cases)
    print(f"rows train={len(train)} test={len(test)} in {time.time()-t0:.0f}s", flush=True)

    FM = {"tabdiff": None, "coldiff": None, "namehit": namehit, "valhit": valhit,
          "fkhit": fkhit, "bm25": TS}

    def rank_full(rec, w, alpha, agg, K):
        """Aggregate over query words with idf weights, restrict to BM25 top-K, then order.

        geo aggregation is returned in log space: it is monotone, so the ranking is unchanged.
        """
        td, cd = diff[alpha]
        idx, iw = rec["idx"], rec["iw"]
        acc = np.zeros((idx.size, N), dtype=np.float32)
        for name in FEATS:
            if w[name] <= 0:
                continue
            M = (td if name == "tabdiff" else cd if name == "coldiff" else FM[name])[idx]
            acc += w[name] * M
        base = np.log(acc + EPS) if agg == "geo" else acc
        m = (iw @ base) / max(float(iw.sum()), 1e-6)
        cands = np.argsort(-rec["b"])[:K] if K < N else np.arange(N)
        order = cands[np.argsort(-m[cands])]
        return order, acc, base, float(iw.sum())

    # the leave-one-word-out pass rebuilds acc once per question and then drops one word by
    # subtraction -- exact for both aggregations, so a search step costs one extra O(N) pass
    # per query word instead of a full recompute.
    def loo_objective(rec, w, alpha, agg, K, objective):
        td, cd = diff[alpha]
        idx, iw, TSp = rec["idx"], rec["iw"], rec["TS"]
        if idx.size < 2:
            return None
        acc = np.zeros((idx.size, N), dtype=np.float32)
        for name in FEATS:
            if w[name] <= 0:
                continue
            M = (td if name == "tabdiff" else cd if name == "coldiff" else FM[name])[idx]
            acc += w[name] * M
        logacc = np.log(acc + EPS)
        Aall = iw @ (acc if agg == "lin" else logacc)
        S = float(iw.sum())
        gq = wq = 0.0
        for p in range(idx.size):
            sp = S - float(iw[p])
            if sp <= 1e-6:
                continue
            mp = (Aall - float(iw[p]) * (acc[p] if agg == "lin" else logacc[p])) / sp
            bp = rec["b"] - TSp[p]
            cands = np.argsort(-bp)[:K] if K < N else np.arange(N)
            t1 = int(cands[np.argmax(mp[cands])])
            v = int(idx[p])
            if objective == "cover_doc":
                g = float(doc_hit[v, t1]) - float(ch_doc[v])
            elif objective == "cover_name":
                g = float(namehit[v, t1]) - float(ch_name[v])
            else:
                row = cd[v]
                mass = float(row[t1])
                g = min(max(math.log((mass + EPS) / (float(row.mean()) + EPS)), 0.0), CAP) \
                    if mass > 0 else 0.0
            gq += float(iw[p]) * g
            wq += float(iw[p])
        return gq / wq if wq > 0 else None

    def eval2(cfg, rows, objective):
        w, alpha, agg, K = cfg["weights"], cfg["alpha"], cfg["agg"], cfg["K"]
        gains, r1, r5 = [], [], []
        for rec in rows:
            order, _acc, _L, _S = rank_full(rec, w, alpha, agg, K)
            gp = rec["goldpos"]
            r1.append(1.0 if order[0] in gp else 0.0)
            r5.append(sum(1 for t in order[:5] if t in gp) / rec["ngold"])
            if objective != "sup":
                v = loo_objective(rec, w, alpha, agg, K, objective)
                if v is not None:
                    gains.append(v)
        j = float(np.mean(r5)) if objective == "sup" else (float(np.mean(gains)) if gains else 0.0)
        return {"J": round(j, 5), "r1": round(float(np.mean(r1)), 4),
                "r5": round(float(np.mean(r5)), 4), "n_loo": len(gains)}

    def label_read(cfg, rows):
        r1, r5 = [], []
        w, alpha, agg, K = cfg["weights"], cfg["alpha"], cfg["agg"], cfg["K"]
        for rec in rows:
            order, _a, _l, _s = rank_full(rec, w, alpha, agg, K)
            gp = rec["goldpos"]
            r1.append(1.0 if order[0] in gp else 0.0)
            r5.append(sum(1 for t in order[:5] if t in gp) / rec["ngold"])
        return {"r1": round(float(np.mean(r1)), 4), "r5": round(float(np.mean(r5)), 4)}

    def ascent(objective):
        cur = {"weights": {f: 0.5 for f in FEATS}, "alpha": 0.85, "agg": "geo", "K": 30}
        best = json.loads(json.dumps(cur))
        best.update(eval2(cur, train, objective))
        tr = []
        for sweep in range(SWEEPS):
            for a in alphas:
                for agg in AGGS:
                    for K in KS:
                        cur["alpha"], cur["agg"], cur["K"] = a, agg, K
                        e = eval2(cur, train, objective)
                        tr.append({"sweep": sweep, "cfg": {**cur}, **e, "what": "knob"})
                        if e["J"] > best["J"] + 1e-9:
                            best = {**cur, **e}
            for name in FEATS:
                for v in GRID:
                    if v == cur["weights"][name]:
                        continue
                    cur["weights"][name] = v
                    e = eval2(cur, train, objective)
                    tr.append({"sweep": sweep, "cfg": {**cur}, **e, "what": name})
                    if e["J"] > best["J"] + 1e-9:
                        best = {**cur, **e, "weights": dict(cur["weights"])}
            print(f"  {objective} sweep {sweep}: J={best['J']:.5f} train r1/r5="
                  f"{best['r1']:.4f}/{best['r5']:.4f} alpha={best['alpha']} agg={best['agg']} "
                  f"K={best['K']} w={ {k: round(v, 2) for k, v in best['weights'].items()} } "
                  f"({time.time()-t0:.0f}s)", flush=True)
            cur = json.loads(json.dumps(best))
        return best, tr

    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true",
                    help="reproduce the hand arm's archived test reading and stop")
    args = ap.parse_args()
    if args.check:
        bm25_cfg = {"weights": {f: 0.0 for f in FEATS} | {"bm25": 1.0},
                    "alpha": 0.85, "agg": "lin", "K": 876}
        print(json.dumps({
            "hand_train": eval2(HAND, train, "sup"), "hand_test": label_read(HAND, test),
            "hand_test_archive": HAND_TEST,
            "hand_objective_values": {o: eval2(HAND, train, o)["J"] for o in OBJECTIVES},
            "bm25_only_test": label_read(bm25_cfg, test),
            "bm25_objective_values": {o: eval2(bm25_cfg, train, o)["J"] for o in OBJECTIVES},
            "n_train": len(train), "n_test": len(test),
            "eval_seconds_per_pass": None}, indent=1))
        ts = time.time()
        for _ in range(3):
            eval2(HAND, train, "cover_doc")
        print("cover pass %.1f s" % ((time.time() - ts) / 3))
        return

    results = {}
    for objective in OBJECTIVES:
        print(f"=== {objective} ===", flush=True)
        ts = time.time()
        best, tr = ascent(objective)
        te = label_read(best, test)
        rho = spearman([e["J"] for e in tr], [e["r5"] for e in tr])
        rho1 = spearman([e["J"] for e in tr], [e["r1"] for e in tr])
        results[objective] = {"best": best, "test": te, "n_evals": len(tr),
                              "spearman_J_vs_train_r5": rho, "spearman_J_vs_train_r1": rho1,
                              "search_s": round(time.time() - ts, 1), "trace": tr}
        print(f"  -> test r1={te['r1']} r5={te['r5']}  rho(J,r5)={rho} rho(J,r1)={rho1}", flush=True)

    # references, read through the same code path
    hand_tr = eval2(HAND, train, "sup")
    hand_te = label_read(HAND, test)
    bm25_cfg = {"weights": {f: 0.0 for f in FEATS} | {"bm25": 1.0},
                "alpha": 0.85, "agg": "lin", "K": 876}
    refs = {"hand_train": hand_tr, "hand_test": hand_te,
            "hand_test_archive": HAND_TEST,
            "bm25_only": {**label_read(bm25_cfg, test),
                          "objective_values": {o: eval2(bm25_cfg, train, o)["J"]
                                               for o in OBJECTIVES}},
            "constant": {"objective_values": {
                o: eval2({"weights": {f: 0.0 for f in FEATS}, "alpha": 0.85, "agg": "geo",
                          "K": 876}, train, o)["J"] for o in OBJECTIVES},
                "note": "all weights 0 -> argmax ties fall back to BM25 candidate order"}}
    dense = None
    if EMB.exists():
        z = np.load(EMB, allow_pickle=True)
        ids = list(z["ids"])
        Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
        qpos = {q: i for i, q in enumerate(list(z["qids"]))}
        r1, r5 = [], []
        for c in te_cases:
            if c["qid"] not in qpos:
                continue
            gp = {f"{c['db_id']}::{t}" for t in c["gold"]}
            order = [ids[i] for i in np.argsort(-(Dm @ Qm[qpos[c["qid"]]]))]
            r1.append(1.0 if order[0] in gp else 0.0)
            r5.append(sum(1 for t in order[:5] if t in gp) / max(1, len(gp)))
        dense = {"r1": round(float(np.mean(r1)), 4), "r5": round(float(np.mean(r5)), 4),
                 "n": len(r1)}

    main_judge = {}
    for o in ("cover_doc", "cover_name", "soft"):
        te = results[o]["test"]
        main_judge[o] = {"beats_hand_r1": te["r1"] >= HAND_TEST["r1"],
                         "beats_hand_r5": te["r5"] >= HAND_TEST["r5"],
                         "pass": te["r1"] >= HAND_TEST["r1"] and te["r5"] >= HAND_TEST["r5"]}

    out = {"protocol": {"selection_rows": "train (693 q / 132 dbs)", "reporting_rows":
                        "test (341 q / 34 dbs)", "labels_in_label_free_objectives": False,
                        "coquery_edges": False, "vocab_cache": "train+test tokens, keyed by token"},
           "space": {"features": list(FEATS), "grid": list(GRID), "alphas": alphas,
                     "aggregations": list(AGGS), "recall_widths": list(KS), "sweeps": SWEEPS},
           "lambda2": round(lam, 4), "n_tables": N, "n_vocab": n_tok,
           "results": results, "references": refs, "dense_reference": dense,
           "main_criterion": {"threshold": HAND_TEST, "reading": main_judge},
           "elapsed_s": round(time.time() - t0, 1)}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({"elapsed_s": out["elapsed_s"],
                      "winners": {o: {"J": results[o]["best"]["J"],
                                      "alpha": results[o]["best"]["alpha"],
                                      "agg": results[o]["best"]["agg"],
                                      "K": results[o]["best"]["K"],
                                      "w": {k: round(v, 2) for k, v in
                                            results[o]["best"]["weights"].items()},
                                      "train": {"r1": results[o]["best"]["r1"],
                                                "r5": results[o]["best"]["r5"]},
                                      "test": results[o]["test"],
                                      "rho": results[o]["spearman_J_vs_train_r5"],
                                      "rho_r1": results[o]["spearman_J_vs_train_r1"]}
                              for o in OBJECTIVES},
                      "hand": {"train": hand_tr, "test": hand_te, "archive": HAND_TEST},
                      "bm25_only": refs["bm25_only"], "constant": refs["constant"],
                      "dense": dense, "main": main_judge}, indent=1, ensure_ascii=False))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
