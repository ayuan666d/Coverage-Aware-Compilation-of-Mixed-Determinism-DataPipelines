# -*- coding: utf-8 -*-
"""A3b: white-box adversarial outputs against the judgment layer.

The adversary is the model, not the OCR text: take the clean outputs from the
API run, mutate them so that a weaker guard would accept, and re-judge with the
same E7 closure judge. No API calls.

Mutations: drop, forge-big, subtotal-as-total, global 10x scale, negate, zero,
first-item-as-total.
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

E7_PATH = Path(r"E:\vldb2027_pipeline_safety\05_代码\runner\e7_receipts.py")
sys.path.insert(0, str(E7_PATH.parent))
spec = importlib.util.spec_from_file_location("e7", str(E7_PATH))
e7 = importlib.util.module_from_spec(spec)
sys.modules["e7"] = e7
spec.loader.exec_module(e7)

IN = Path(r"E:\vldb2027_pipeline_safety\06_结果\a3_injection.json")
OUT = Path(r"E:\vldb2027_pipeline_safety\06_结果\a3b_mutations.json")


def scale(v, k):
    return None if v is None else int(v * k)


def mutate(name, m):
    d = dict(m)
    d["items"] = list(m.get("items") or [])
    if name == "drop_total":
        d["total"] = None
    elif name == "forge_big":
        d["total"] = 999999
    elif name == "subtotal_as_total":
        d["total"] = m.get("subtotal")
    elif name == "scale10":
        for k in ("total", "subtotal", "tax", "service", "discount"):
            d[k] = scale(m.get(k), 10)
        d["items"] = [scale(x, 10) for x in d["items"]]
    elif name == "negate":
        d["total"] = -m["total"] if m.get("total") is not None else None
    elif name == "zero":
        d["total"] = 0
    elif name == "first_item":
        d["total"] = d["items"][0] if d["items"] else None
    return d


def main():
    data = json.loads(IN.read_text(encoding="utf-8"))
    clean = [r for r in data["rows"] if r["cond"] == "clean" and r["model"].get("total") is not None]
    names = ["drop_total", "forge_big", "subtotal_as_total", "scale10", "negate", "zero", "first_item"]
    out = {"n": len(clean), "by_mutation": {}}
    for name in names:
        rows = []
        for r in clean:
            mut = mutate(name, r["model"])
            j = e7.judge(mut, {"total": r["gold_total"], "subtotal": None}, r["text"])
            t = j["final_total"]
            digits = e7.ocr_digits(r["text"])
            rows.append({"verdict": j["verdict"], "total_correct": j["total_correct"],
                         "violations": j["violations"], "unknowns": j["unknowns"],
                         "final_total": t,
                         "role": j["checks"].get("total_role"),
                         "exact_grounded": (t is not None and str(int(t)) in digits)})
        n = len(rows)
        acc = [x for x in rows if x["verdict"] in ("accept", "fill")]
        fp = sum(1 for x in acc if x["total_correct"] is False)
        # hardened variants: closure + one extra independent condition
        h_role = [x for x in acc if x["role"] is True]
        h_exact = [x for x in acc if x["exact_grounded"]]
        h_both = [x for x in acc if x["role"] is True and x["exact_grounded"]]
        out["by_mutation"][name] = {
            "n": n,
            "accept": sum(1 for x in rows if x["verdict"] == "accept"),
            "fill": sum(1 for x in rows if x["verdict"] == "fill"),
            "review": sum(1 for x in rows if x["verdict"] == "review"),
            "reject": sum(1 for x in rows if x["verdict"] == "reject"),
            "guard_accept_rate": round(len(acc) / n, 4),
            "false_pass": fp,
            "false_pass_rate": round(fp / n, 4),
            "accept_precision": round((len(acc) - fp) / len(acc), 4) if acc else None,
            "hard_role": {
                "accept_rate": round(len(h_role) / n, 4),
                "false_pass": sum(1 for x in h_role if x["total_correct"] is False),
            },
            "hard_exact": {
                "accept_rate": round(len(h_exact) / n, 4),
                "false_pass": sum(1 for x in h_exact if x["total_correct"] is False),
            },
            "hard_both": {
                "accept_rate": round(len(h_both) / n, 4),
                "false_pass": sum(1 for x in h_both if x["total_correct"] is False),
            },
        }
        print(name, json.dumps(out["by_mutation"][name], ensure_ascii=False))
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print("wrote", OUT)


if __name__ == "__main__":
    main()
