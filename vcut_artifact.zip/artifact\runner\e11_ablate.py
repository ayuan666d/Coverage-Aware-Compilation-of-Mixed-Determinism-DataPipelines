"""E11 ablations: which relation layer carries what, and how to weight bands.

Run on the merged Spider catalog and on the BIRD control.  Layer ablations drop
one relation from the fusion; band ablations compare no down-weighting, the
fixed quantile rule from E9, an idf rule, and the per-dataset oracle.
"""
from __future__ import annotations

import json
import math
import sys
from collections import Counter
from itertools import combinations
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
OUT = REPO / "06_结果" / "e11_ablation.json"

LAYERS = ["name", "value", "fk", "coquery", "alias"]


def band_weights(cases, rule, qdf, hi, q90):
    def f(q):
        if rule == "none":
            return None
        w = {}
        for x in q:
            if rule == "fixed":
                w[x] = 0.15 if qdf[x] >= hi else 1.0
            elif rule == "idf":
                w[x] = 0.3 if qdf[x] >= q90 else 1.0
        return w
    return f


def run(name, cat, cases, gold_of):
    qdf = Counter()
    for c in cases:
        qdf.update(set(toks(c["question"])))
    vals = sorted(qdf.values())
    hi = float(np.quantile(vals, 0.8))
    q90 = float(np.quantile(vals, 0.9))
    variants = {}
    for rule in ("none", "fixed", "idf"):
        variants[f"typed_{rule}"] = ("typed", None, rule)
    for drop in LAYERS[1:]:
        keep = [x for x in LAYERS if x != drop]
        variants[f"typed_no_{drop}"] = ("typed", keep, "fixed")
    variants["typed_isolated"] = ("isolated", None, "fixed")
    variants["ppr"] = ("union", None, "fixed")
    variants["bm25"] = ("bm25", None, None)

    acc = {k: [] for k in variants}
    per_case = []
    for c in cases:
        q = toks(c["question"])
        gold = gold_of(c)
        row = {"qid": c["qid"]}
        for key, (kind, keep, rule) in variants.items():
            bw = band_weights(cases, rule, qdf, hi, q90)(q) if rule else None
            if kind == "bm25":
                s = g.bm25(cat, q)
            elif kind == "union":
                s = g.single_ppr(cat, q, band_weight=bw)
            elif kind == "isolated":
                s = g.fuse(cat, q, band_weight=bw, mode="isolated")
            else:
                s = g.fuse(cat, q, weights={k: 1.0 for k in (keep or LAYERS)},
                           band_weight=bw, mode="view")
            m = g.metrics(g.rank(s, cat), gold)
            acc[key].append(m)
            row[key] = m
        per_case.append(row)
    out = {"set": name, "n": len(cases),
           "metrics": {k: g.mean_metrics(v) for k, v in acc.items() if v},
           "bands": {"head_q80": hi, "q90": q90}}
    return out, per_case


def agg_rows(rows):
    keys = [k for k, v in rows[0].items() if isinstance(v, dict) and "recall@5" in v]
    return {k: g.mean_metrics([r[k] for r in rows]) for k in keys}


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    res = {}

    # BIRD control
    by = {}
    for c in data["bird"]:
        by.setdefault(c["db_id"], []).append(c)
    rows = []
    for db, cs in by.items():
        cat = g.Catalog([dict(t, db=db) for t in cache["bird"][db]["tables"]],
                        cache["bird"][db]["fks"], prefix_db=False)
        o, pc = run(f"bird:{db}", cat, cs, lambda c: set(c["gold"]))
        rows += pc
    res["bird"] = {"n": len(rows), "metrics": agg_rows(rows)}

    # Spider merged catalog
    test = [c for c in data["spider"] if c["split"] == "test"]
    train = [c for c in data["spider"] if c["split"] == "train"]
    tables, fks = [], []
    for db, s in cache["spider"].items():
        tables += [dict(t, db=db) for t in s["tables"]]
        have = {t["name"] for t in s["tables"]}
        fks += [[f"{db}::{a}", ca, f"{db}::{b}", cb] for a, ca, b, cb in s["fks"]
                if a in have and b in have]
    pc = Counter()
    for c in train:
        for a, b in combinations(sorted(c["gold"]), 2):
            pc[(f"{c['db_id']}::{a}", f"{c['db_id']}::{b}")] += 1
            pc[(f"{c['db_id']}::{b}", f"{c['db_id']}::{a}")] += 1
    coq = Counter({k: math.log(1 + v) for k, v in pc.items()})
    cat = g.Catalog(tables, fks, coquery=coq, prefix_db=True)
    o, pcases = run("spider_merged", cat, test,
                    lambda c: {f"{c['db_id']}::{t}" for t in c["gold"]})
    res["spider_merged"] = {"n": len(pcases), "metrics": agg_rows(pcases)}
    json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for k, v in res.items():
        print(k, v["n"])
        for m, mm in sorted(v["metrics"].items(), key=lambda x: -x[1]["recall@5"]):
            print("  ", m, mm["recall@1"], mm["recall@5"], mm["mrr"])
    print("wrote", OUT)


if __name__ == "__main__":
    main()
