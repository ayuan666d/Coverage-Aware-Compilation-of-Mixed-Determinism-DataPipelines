"""E11-DIAG3: is the "no lexical bridge" bin world knowledge, or our own
tokeniser and our own 6-value sample?

For every test question, re-open the real SQLite file and classify the query's
relationship to the gold table by where the evidence lives:

  exact      : a query token equals a schema-document token (what the operators see)
  compound   : no exact token, but a query token is a substring of a document token
               (or vice versa) -- snake_case compounds like contestant_name vs
               "contestant".  Our tokeniser's fault, free to fix.
  fullvalue  : no name evidence, but a query token occurs in the table's ACTUAL cell
               values -- the value is in the database, just not in the <=6 values
               that were sampled into the document.  The catalogue was lossy, not
               the operator.
  foreign    : evidence is in another table of the same db (FK reach), not the gold doc
  none       : nothing at the character level anywhere in the database: real world
               knowledge gap.

Then report graph / BM25 / dense R@5 per class, which splits the 40-point gap into
"our implementation", "our sampling", and "the model has to know things".
"""
from __future__ import annotations

import json
import sqlite3
import sys
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
DBDIR = Path("D:/vldb2027_e11/spider/database")
CASES = REPO / "06_结果" / "e11_cases.json"
DIAG = REPO / "06_结果" / "e11_diag.json"
OUT = REPO / "06_结果" / "e11_evidence.json"
MIN_SUB = 4


def cell_tokens(con, table) -> tuple[set[str], set[str]]:
    """(exact cell tokens, character substrings of every cell)."""
    exact, subs = set(), set()
    try:
        cols = [r[1] for r in con.execute(f'PRAGMA table_info("{table}")')]
    except sqlite3.Error:
        return exact, subs
    for c in cols:
        try:
            rows = con.execute(f'SELECT DISTINCT "{c}" FROM "{table}" LIMIT 3000').fetchall()
        except sqlite3.Error:
            continue
        for (v,) in rows:
            if v is None:
                continue
            s = str(v).strip().lower()
            if not s:
                continue
            exact.update(toks(s))
            w = s.replace("_", " ")
            for part in w.split():
                if len(part) >= MIN_SUB:
                    subs.add(part)
    return exact, subs


def main():
    data = json.load(open(CASES, encoding="utf-8"))
    dg = {r["qid"]: r for r in json.load(open(DIAG, encoding="utf-8"))["rows"]}
    test = [c for c in data["spider"] if c["split"] == "test"]

    conns, vtok, class_rows = {}, {}, []
    for n, c in enumerate(test):
        db, golds = c["db_id"], c["gold"]
        if db not in conns:
            p = DBDIR / db / f"{db}.sqlite"
            conns[db] = sqlite3.connect(p) if p.exists() else None
        con = conns[db]
        if con is None:
            continue
        q = toks(c["question"])
        qt = set(q)
        cls = "none"
        detail = {}
        all_exact, all_subs, name_ok, compound_ok = set(), set(), False, False
        for t in golds:
            tabs = [x for x in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
            have = {x[0] for x in tabs}
            real = next((x for x in have if x.lower() == t.lower()), None)
            if real is None:
                continue
            r = con.execute(f'SELECT * FROM "{real}" LIMIT 1')
            cols = [d[0] for d in r.description] if r.description else []
            nt = set()
            for col in cols:
                nt |= set(toks(real)) | set(toks(col))
            if qt & nt:
                name_ok = True
            for a in qt:
                for b in nt:
                    if min(len(a), len(b)) >= MIN_SUB and (a in b or b in a):
                        compound_ok = True
            ex, sb = cell_tokens(con, real)
            all_exact |= ex
            all_subs |= sb
        # same-database evidence (FK reach): the token is somewhere else in the db
        foreign = False
        tabs = [x[0] for x in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        for tb in tabs:
            if tb.lower() in {t.lower() for t in golds}:
                continue
            ex, _ = cell_tokens(con, tb)
            if qt & ex:
                foreign = True
                break

        if name_ok:
            cls = "exact"
        elif compound_ok:
            cls = "compound"
        elif qt & all_exact:
            cls = "fullvalue"
        elif qt & all_subs:
            cls = "fullvalue_substr"
        elif foreign:
            cls = "foreign"
        detail = {"qid": c["qid"], "class": cls, "question": c["question"],
                  "gold": golds, "oov": sorted(qt - all_exact)[:10]}
        class_rows.append(detail)
        if (n + 1) % 50 == 0:
            print(n + 1, Counter(x["class"] for x in class_rows), flush=True)

    # join with measured recall
    by = {}
    for d in class_rows:
        r = dg.get(d["qid"])
        if not r:
            continue
        by.setdefault(d["class"], []).append(r)
    res = {}
    for k, v in by.items():
        mean = lambda f: round(float(np.mean([x[f] for x in v])), 4)  # noqa: E731
        res[k] = {"n": len(v), "bm25_r5": mean("bm25_r5"), "graph_r5": mean("ppr_band_r5"),
                  "typed_r5": mean("typed_band_r5"), "dense_r5": mean("dense_r5"),
                  "graph_hit5": sum(1 for x in v if x["ppr_band_r5"] > 0),
                  "dense_hit5": sum(1 for x in v if x["dense_r5"] > 0),
                  "bm25_hit5": sum(1 for x in v if x["bm25_r5"] > 0)}
    out = {"counts": {k: v["n"] for k, v in res.items()},
           "by_class": res,
           "gap_share": {k: round((v["dense_r5"] - v["graph_r5"]) * v["n"] / len(class_rows), 4)
                         for k, v in res.items()},
           "rows": class_rows}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
