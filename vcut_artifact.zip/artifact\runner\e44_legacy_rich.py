"""E44：目录局部性测量 —— 同目录三基线的 rank 级明细。

为什么要有这个实验（推翻 E43 之后的一个假设）：

E43 之后我们曾把「位级不变性」当成解释规模退化的地基。但把三条基线的分数
逐个看，这个地基不成立：

    dense   S = cos(E(q), E(t))                与目录完全无关  → κ = 0
    FORGE   S = w^T phi(q,t)，w 只在 951 上拟合  与目录完全无关  → κ = 0（β=0 时）
    BM25    idf 依赖当前语料                    与目录有关      → κ > 0

也就是说 dense 和 FORGE 在「分数随目录漂移」上完全一样（都是 0），
但退化幅度差 2.5 倍（-13.2% vs -5.4%）。**不变性不能解释退化。**

真正区分两者的量是「判别余量」：金标分数相对 top-k 边界有多厚。
余量厚的系统要挤掉一张金标需要更强的干扰表；余量薄的系统随时被翻盘。
本期只测一件事：把 margin / 槽位占用 / rank 三者按目录规模打出来。

关键的理论对照（在 e45_analyze.py 里算）：
  若干扰表相对于真实表**随机插入**（无指纹目录的性质），则金标在 N 张表里的
  排名服从 r + X，X ~ Binomial(M, r/(n_real+1))。由此可得一条**只依赖 951 目录
  rank 分布**的解析预测曲线 R@k(N)，不需要重跑任何大规模实验。
  实测 − 解析预测 = 「局部性收益」：系统把干扰表压到随机水平之下的幅度。
  这条差值是本论文的关键量，而不是「不变性」。

目录构造直接 import e43，逐字复用（保证与 E41/E43 同一套 doc_hash）。
输出：D:\\vldb2027_e11\\e44_legacy_rich.json + e44_legacy_rich_{tag}_perq.jsonl
"""
from __future__ import annotations

import gc
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
os.environ.setdefault("E43_SIZE", "951,10000")
import e11_graph as g  # noqa: E402
import e43_legacy_baselines as base  # noqa: E402

WORK = Path(r"D:\vldb2027_e11")
OUT = Path(os.environ.get("E44_OUT", str(WORK / "e44_legacy_rich.json")))
SIZES = sorted(int(x) for x in os.environ.get("E44_SIZE", "951,10000").split(","))
EPS = 1e-6


def zs(S):
    return (S - S.mean()) / (S.std() + 1e-9)


def rich(S, order, gold_ix, n_real):
    """rank 级明细。S 为原始分数，order 为全目录降序 index。

    gpos       : 每个金标在全目录的位置（0 起）——含干扰表竞争
    gpos_real  : 每个金标在**真实表子集内**的位置——纯排序质量，去掉槽位竞争
    top20_real : top20 的真伪掩码（1=真实表）——槽位占用的直接读数
    margin5    : z 分数下「最高分金标 − top5 边界」——判别余量，负值=金标已出界
    first_bad  : 最高名次的干扰表位置，-1 表示 top20 内无干扰表
    """
    N = len(order)
    inv = np.empty(N, np.int64)
    inv[order] = np.arange(N)
    gpos = sorted(int(inv[j]) for j in gold_ix)
    # 真实表子集内的位置：把干扰表从序列里剔掉，保持真实表的相对序
    real_order = order[order < n_real]
    inv_r = np.empty(len(real_order), np.int64)
    inv_r[real_order] = np.arange(len(real_order))
    gpos_real = sorted(int(inv_r[j]) for j in gold_ix if j < n_real)
    Z = zs(S)
    gmax = float(Z[max(gold_ix, key=lambda j: Z[j])]) if gold_ix else -1e18
    border = float(Z[order[min(4, N - 1)]])
    bad = [p for p, i in enumerate(order[:20]) if int(i) >= n_real]
    return dict(gpos=gpos, gpos_real=gpos_real,
                top20_real=[1 if int(i) < n_real else 0 for i in order[:20]],
                margin5=gmax - border, first_bad=(bad[0] if bad else -1))


def main():
    all_tabs, fks, n_real, cases, test = base.build_catalog()
    doc_ids = [base.fid(t["db"], t["name"]) for t in all_tabs]
    id2ix = {d: i for i, d in enumerate(doc_ids)}
    golds = [{base.fid(c["db_id"], x) for x in c["gold"]} for c in test]
    qsets = [set(g.toks(c["question"])) for c in test]
    print(f"[catalog] N={len(all_tabs)} n_real={n_real} q={len(test)}", flush=True)

    from sentence_transformers import SentenceTransformer
    t0 = time.perf_counter()
    _seed = os.environ.get("LEGACY_SEED", "40")
    # 缓存 key 必须含 seed **与评估集**（问集决定 Q，donor 池随 test_dbs 漂移决定 D）
    import hashlib
    _tag = hashlib.md5(f"{_seed}|{base.CASES}".encode()).hexdigest()[:6]
    cache = WORK / f"e44_vision_cache_{_tag}.npz"
    if cache.exists():
        z = np.load(cache)
        Q, D = z["Q"], z["D"]
        print(f"[dense] 复用缓存 {Q.shape} {D.shape}", flush=True)
    else:
        model = SentenceTransformer(str(WORK / "models" / "Qwen3-Embedding-0.6B"),
                                    device="cuda")
        model.max_seq_length = 128
        Q = model.encode([c["question"] for c in test], batch_size=32,
                         convert_to_numpy=True, normalize_embeddings=True,
                         prompt_name="query", show_progress_bar=False)
        D = model.encode([base.doc_text(t) for t in all_tabs], batch_size=32,
                         convert_to_numpy=True, normalize_embeddings=True,
                         show_progress_bar=False)
        np.savez(cache, Q=Q, D=D)
        print(f"[dense] 编码 {time.perf_counter()-t0:.0f}s（已缓存）", flush=True)

    res = json.load(open(OUT, encoding="utf-8")) if OUT.exists() else {}
    for n in SIZES:
        tag = "951" if n == 951 else f"{n // 1000}k-syn"
        t1 = time.perf_counter()
        sub = all_tabs[:n]
        cat = g.Catalog(sub, fks, coquery=None, prefix_db=True)
        N = len(cat.tables)
        toks = sorted({w for qs in qsets for w in qs if ("token", w) in cat.idx})
        tok, idf = {}, {}
        for w in toks:
            x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
            s = cat.table_scores(x)
            mx = float(s.max())
            tok[w] = s / mx if mx > 0 else s
        idf = {w: math.log(1 + (N - cat.token_df.get(w, 0) + 0.5) /
                           (cat.token_df.get(w, 0) + 0.5)) for w in tok}

        S_all = Q @ D[:n].T
        pq = []
        for qi, (c, qs, gold) in enumerate(zip(test, qsets, golds)):
            gi = [id2ix[x] for x in gold if x in id2ix]
            # ---- BM25 ----
            b = g.bm25(cat, qs)
            ob = np.argsort(-b, kind="stable")
            rec_b = rich(b, ob, gi, n_real)
            # ---- fuse（与 e43 同实现：PPR 图重排 top30）----
            ws = [w for w in qs if w in tok]
            if ws:
                M = np.stack([tok[w] for w in ws])
                iw = np.array([idf[w] for w in ws])[:, None]
                graph = np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
            else:
                graph = np.zeros(N, dtype=np.float32)
            top = ob[:30]
            mixed = b.copy()
            basev = float(b[top[-1]])
            for k, idx in enumerate(top[np.argsort(-graph[top])]):
                mixed[idx] = basev + (30 - k) * 1e-6
            rec_f = rich(mixed, np.argsort(-mixed, kind="stable"), gi, n_real)
            # ---- dense ----
            Sh = S_all[qi]
            rec_d = rich(Sh, np.argsort(-Sh, kind="stable"), gi, n_real)

            row = {"tag": tag, "qid": c["qid"], "db": c["db_id"],
                   "n_gold": len(gold)}
            for name, rec in (("bm25", rec_b), ("fuse", rec_f), ("dense", rec_d)):
                row[name] = rec
            pq.append(row)

        agg = {}
        for name in ("bm25", "fuse", "dense"):
            subs = pq                      # 保留 n_gold（问级字段）
            g5 = [len([p for p in r[name]["gpos"] if p < 5]) for r in subs]
            gr5 = [len([p for p in r[name]["gpos_real"] if p < 5]) for r in subs]
            agg[name] = dict(
                synth5=float(np.mean([5 - r[name]["top20_real"][:5].count(1)
                                      for r in subs])),
                hit5=float(np.mean([1.0 if x > 0 else 0.0 for x in g5])),
                R5=float(np.mean([x / r["n_gold"] for x, r in zip(g5, subs)])),
                hit5_real=float(np.mean([1.0 if x > 0 else 0.0 for x in gr5])),
                R5_real=float(np.mean([x / r["n_gold"] for x, r in zip(gr5, subs)])),
                # 金标前面有几张干扰表：辨别力的直接反量（中位=0 表示过半金标
                # 前面一张干扰表都没有，则 R@5 的损失全部来自长尾）
                bad_before=float(np.mean([np.mean([p - q for p, q in
                                                   zip(r[name]["gpos"],
                                                       r[name]["gpos_real"])])
                                          for r in subs])),
                bad_before_med=float(np.median([p - q for r in subs
                                                for p, q in zip(r[name]["gpos"],
                                                                r[name]["gpos_real"])])),
                margin5_mean=float(np.mean([r[name]["margin5"] for r in subs])),
                margin5_neg=float(np.mean([1.0 if r[name]["margin5"] < 0 else 0.0
                                           for r in subs])),
                bad_in_top5=float(np.mean([1.0 if r[name]["first_bad"] in range(5)
                                           else 0.0 for r in subs])),
                mrr=float(np.mean([1.0 / (min(r[name]["gpos"]) + 1) for r in subs])),
            )
        res[tag] = dict(N=n, n_real=n_real, n_synth=n - n_real, **agg)
        json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        for name in ("bm25", "fuse", "dense"):
            a = agg[name]
            print(f"[{tag}][{name:5s}] R5={a['R5']*100:5.2f} (真实表内 "
                  f"{a['R5_real']*100:5.2f}) synth5={a['synth5']:.2f} "
                  f"金标前干扰={a['bad_before']:.1f}(中位{a['bad_before_med']:.0f}) "
                  f"margin5={a['margin5_mean']:+.3f} 负余量={a['margin5_neg']*100:.1f}% "
                  f"MRR={a['mrr']:.4f} ({time.perf_counter()-t1:.0f}s)", flush=True)

        with open(OUT.with_name(f"{OUT.stem}_{tag}_perq.jsonl"), "w",
                  encoding="utf-8") as f:
            for rec in pq:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        del cat
        gc.collect()


if __name__ == "__main__":
    main()
