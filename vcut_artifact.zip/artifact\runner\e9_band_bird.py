"""E9: band-aware semantic retrieval over a database's explicit schema graph.

Questions:
  (1) Does a zero-training explicit graph (BM25 / PPR over schema+values) retrieve
      gold tables as well as a local 4B model?
  (2) Is the utility of a token inverted-U in its frequency (head/middle/tail)?
  (3) Does down-weighting head tokens improve PPR?

Outputs a JSON with metrics and bucket tables.  No model training.
"""
from __future__ import annotations

import json
import math
import re
import sqlite3
import sys
from collections import Counter, defaultdict
from pathlib import Path

import networkx as nx
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

REPO = Path(__file__).resolve().parents[2]
BIRD = REPO / "04_数据" / "external" / "bird"
GOLD = BIRD / "mini_dev_sqlite_2025.json"
DB_ROOT = BIRD / "minidev" / "MINIDEV" / "dev_databases"
LOCAL = REPO / "06_结果" / "e7v_schema_recall.json"
OUT = REPO / "06_结果" / "e9_band_bird.json"

STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us""".split())
TOK = re.compile(r"[a-z0-9_]+")


def toks(s: str) -> list[str]:
    return [t for t in TOK.findall(str(s).lower()) if len(t) >= 2 and t not in STOP]


def gold_tables(sql: str) -> set[str]:
    return set(re.findall(r"(?:from|join)\s+[\"`]?([A-Za-z_][A-Za-z0-9_]*)", sql, re.I))


def schema_of(db: Path):
    con = sqlite3.connect(db)
    cur = con.cursor()
    tables = [r[0] for r in cur.execute(
        "select name from sqlite_master where type='table' and name not like 'sqlite_%'")]
    cols = {}
    docs = {}
    values = {}
    fks = []
    for t in tables:
        cs = [r[1] for r in cur.execute(f'pragma table_info("{t}")')]
        cols[t] = cs
        parts = toks(t)
        for c in cs:
            parts += toks(c)
        # top distinct values (schema metadata, not gold labels)
        for c in cs[:12]:
            try:
                vals = [str(r[0]) for r in cur.execute(
                    f'select distinct "{c}" from "{t}" where "{c}" is not null limit 12')]
            except Exception:
                vals = []
            values[(t, c)] = vals
            for v in vals:
                parts += toks(v)[:3]
        docs[t] = parts
        for fk in cur.execute(f'pragma foreign_key_list("{t}")'):
            ref_t = fk[2]
            if ref_t in tables:
                fks.append((t, ref_t))
    con.close()
    return tables, cols, docs, values, fks


def bm25_scores(query, docs, k1=1.2, b=0.75):
    N = len(docs)
    avgdl = sum(len(d) for d in docs.values()) / max(1, N)
    df = Counter()
    for d in docs.values():
        for t in set(d):
            df[t] += 1
    scores = {}
    for name, d in docs.items():
        tf = Counter(d)
        s = 0.0
        for q in set(query):
            if q not in tf:
                continue
            idf = math.log(1 + (N - df[q] + 0.5) / (df[q] + 0.5))
            s += idf * tf[q] * (k1 + 1) / (tf[q] + k1 * (1 - b + b * len(d) / avgdl))
        scores[name] = s
    return scores


def tfidf_scores(query, docs):
    names = list(docs)
    vec = TfidfVectorizer(analyzer=lambda x: x, lowercase=False)
    X = vec.fit_transform([docs[n] for n in names])
    q = vec.transform([query])
    sim = (X @ q.T).toarray().ravel()
    return dict(zip(names, sim))


def build_graph(tables, cols, docs, fks):
    G = nx.Graph()
    for t in tables:
        G.add_node("T:" + t, kind="table", name=t)
        for c in cols[t]:
            G.add_node(f"C:{t}.{c}", kind="column", name=c)
            G.add_edge("T:" + t, f"C:{t}.{c}", weight=1.0)
        for tok in set(docs[t]):
            G.add_node("W:" + tok, kind="token", name=tok)
            G.add_edge("T:" + t, "W:" + tok, weight=1.0)
        for c in cols[t]:
            for tok in toks(c):
                G.add_edge(f"C:{t}.{c}", "W:" + tok, weight=1.0)
    for a, b in fks:
        if "T:" + a in G and "T:" + b in G:
            G.add_edge("T:" + a, "T:" + b, weight=0.3)
    return G


def ppr_scores(G, query, weights=None):
    seeds = {}
    for q in query:
        n = "W:" + q
        if n in G:
            seeds[n] = seeds.get(n, 0.0) + (weights.get(q, 1.0) if weights else 1.0)
    if not seeds:
        return {}
    pr = nx.pagerank(G, alpha=0.85, personalization=seeds, weight="weight",
                     max_iter=200, tol=1e-8)
    return {n[2:]: s for n, s in pr.items() if n.startswith("T:")}


def metrics(ranked, gold):
    out = {}
    for k in (1, 3, 5):
        hit = sum(1 for t in ranked[:k] if t in gold)
        out[f"recall@{k}"] = hit / max(1, len(gold))
    out["exact@5"] = set(ranked[:5]) == gold
    rr = 0.0
    for i, t in enumerate(ranked[:10], 1):
        if t in gold:
            rr = 1.0 / i
            break
    out["mrr"] = rr
    return out


def avg(ms):
    keys = [k for k, v in ms[0].items() if isinstance(v, (int, float))]
    return {k: round(sum(m[k] for m in ms) / len(ms), 4) for k in keys}


def main():
    cases = json.load(open(GOLD, encoding="utf-8"))
    schemes = {}
    for db_id in sorted({c["db_id"] for c in cases}):
        db = DB_ROOT / db_id / f"{db_id}.sqlite"
        schemes[db_id] = schema_of(db)

    qdf = Counter()
    per_case = []
    for c in cases:
        q = toks(c["question"])
        for t in set(q):
            qdf[t] += 1
        per_case.append((c, q))

    # band by question-token document frequency
    freqs = sorted(qdf.values())
    hi = np.quantile(freqs, 0.80)
    lo = np.quantile(freqs, 0.20)
    def band(t):
        f = qdf[t]
        if f >= hi:
            return "head"
        if f <= lo:
            return "tail"
        return "middle"

    methods = {k: [] for k in ("bm25", "tfidf", "ppr", "ppr_band")}
    rows = []
    for c, q in per_case:
        db = c["db_id"]
        tables, cols, docs, values, fks = schemes[db]
        gt = gold_tables(c["SQL"])
        G = build_graph(tables, cols, docs, fks)
        b = bm25_scores(q, docs)
        t = tfidf_scores(q, docs)
        p = ppr_scores(G, q)
        w = {x: (0.15 if band(x) == "head" else 1.0) for x in q}
        pb = ppr_scores(G, q, w)
        scores = {
            "bm25": sorted(tables, key=lambda x: -b.get(x, 0)),
            "tfidf": sorted(tables, key=lambda x: -t.get(x, 0)),
            "ppr": sorted(tables, key=lambda x: -p.get(x, 0)),
            "ppr_band": sorted(tables, key=lambda x: -pb.get(x, 0)),
        }
        row = {"qid": c["question_id"], "db": db, "gold": sorted(gt),
               "bands": {x: band(x) for x in set(q)}}
        for m, ranked in scores.items():
            met = metrics(ranked, gt)
            methods[m].append(met)
            row[m] = {"top5": ranked[:5], **met}
        rows.append(row)

    # token-level utility by frequency bucket
    token_stat = defaultdict(lambda: [0, 0])  # token -> [occ, hit]
    for c, q in per_case:
        db = c["db_id"]
        tables, cols, docs, values, fks = schemes[db]
        gt = gold_tables(c["SQL"])
        gold_tokens = set()
        for t in gt:
            gold_tokens |= set(docs.get(t, []))
        for x in set(q):
            token_stat[x][0] += 1
            if x in gold_tokens:
                token_stat[x][1] += 1
    base = sum(h for _, h in token_stat.values()) / max(1, sum(n for n, _ in token_stat.values()))
    bins = [(1, 1), (2, 3), (4, 7), (8, 15), (16, 31), (32, 10**9)]
    bucket = []
    for a, b in bins:
        toks_in = [(x, n, h) for x, (n, h) in token_stat.items() if a <= n <= b]
        occ = sum(n for _, n, _ in toks_in)
        hit = sum(h for _, _, h in toks_in)
        bucket.append({"range": f"{a}-{'' if b > 10**8 else b}", "tokens": len(toks_in),
                       "occurrences": occ, "precision": round(hit / max(1, occ), 4),
                       "lift": round((hit / max(1, occ)) / base, 3) if occ else None})

    # local 4B on the same first 100 questions
    local = json.load(open(LOCAL, encoding="utf-8"))
    local_by_q = {r["question_id"]: r["recall"] for r in local["rows"]}
    first100 = [r for r in rows if r["qid"] in local_by_q]
    local_recall = sum(local_by_q[r["qid"]] for r in first100) / max(1, len(first100))

    out = {
        "n": len(rows),
        "base_token_precision": round(base, 4),
        "bands": {"head_df_ge": float(hi), "tail_df_le": float(lo)},
        "methods_all": {m: avg(v) for m, v in methods.items()},
        "methods_first100": {m: avg([r[m] for r in first100]) for m in methods},
        "local4b_first100_recall": round(local_recall, 4),
        "token_utility_by_frequency": bucket,
        "rows": rows,
    }
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k != "rows"},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
