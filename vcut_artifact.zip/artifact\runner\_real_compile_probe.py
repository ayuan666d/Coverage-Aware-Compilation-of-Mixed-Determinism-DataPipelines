# -*- coding: utf-8 -*-
"""在真实 permit-platform 环境里编译一条 spec，输出 JSON。

由 runner/e1b_real_false_safety.py 调用；不修改被调仓库。
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

REAL = Path("D:/prod/permit-platform")
sys.path.insert(0, str(REAL))

from src.assembly.compiler import CompileError, compile_pipeline  # noqa: E402
from src.assembly.registry import load_pipeline, load_registry  # noqa: E402

SERVICES = ("nats", "duckdb", "zen-engine", "llm.chat", "postgres")
SCOPES = ("tenant:default",)


def main() -> int:
    spec_path = sys.argv[1]
    spec = load_pipeline(spec_path)
    registry = load_registry(REAL / "contracts" / "registry.yaml")
    try:
        frozen = compile_pipeline(
            spec, registry,
            available_services=SERVICES, available_scopes=SCOPES,
        )
        out = {
            "ok": True,
            "problems": [],
            "warnings": list(frozen.warnings),
            "sink_coverage": {
                s: {"ok": c.ok, "verdicts": list(c.verdicts)}
                for s, c in frozen.sink_coverage.items()
            },
        }
    except CompileError as exc:
        out = {
            "ok": False,
            "problems": list(exc.problems),
            "warnings": list(exc.warnings),
        }
    print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
