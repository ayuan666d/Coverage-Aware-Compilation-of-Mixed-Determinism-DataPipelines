"""E7v: a local 4B model as the recall stage of a SQL pipeline.

Instead of writing SQL (which it cannot), the local model selects candidate
tables from the schema.  The cloud model then writes SQL over the candidates.
We measure table recall, candidate-set size, and exact match on 100 BIRD
questions.
"""
from __future__ import annotations

import json
import re
import sqlite3
import time
import urllib.request
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
BIRD = REPO / "04_数据" / "external" / "bird"
GOLD = BIRD / "mini_dev_sqlite_2025.json"
DB_ROOT = BIRD / "minidev" / "MINIDEV" / "dev_databases"
OUT = REPO / "06_结果" / "e7v_schema_recall.json"
N = 100


def table_names(db):
    con = sqlite3.connect(db)
    ts = [r[0] for r in con.execute(
        "select name from sqlite_master where type='table' and name not like 'sqlite_%'")]
    con.close()
    return ts


def gold_tables(sql):
    return set(re.findall(r"(?:from|join)\s+[\"`]?([A-Za-z_][A-Za-z0-9_]*)", sql, re.I))


def ask(question, db_id, tables):
    prompt = (f"Tables in database {db_id}:\n" + "\n".join(tables)
              + f"\n\nQuestion: {question}\nWhich tables are needed? Return JSON "
                "{\"tables\": [names]} with at most 6 names, exact spelling.")
    body = json.dumps({"model": "qwen3:4b",
                       "messages": [{"role": "user", "content": prompt}],
                       "stream": False, "think": False, "format": "json",
                       "options": {"temperature": 0, "num_predict": 120,
                                   "num_ctx": 8192}}).encode()
    req = urllib.request.Request("http://127.0.0.1:11434/api/chat", data=body,
                                 headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=120) as r:
        d = json.loads(r.read())
    try:
        return set(json.loads(d["message"]["content"]).get("tables") or [])
    except Exception:
        return set()


def main():
    cases = json.load(open(GOLD, encoding="utf-8"))[:N]
    rows = []
    t0 = time.perf_counter()
    for c in cases:
        db = DB_ROOT / c["db_id"] / f"{c['db_id']}.sqlite"
        tabs = table_names(db)
        gt = gold_tables(c["SQL"])
        got = ask(c["question"], c["db_id"], tabs)
        rows.append({"question_id": c["question_id"], "db_id": c["db_id"],
                     "difficulty": c["difficulty"], "gold": sorted(gt),
                     "got": sorted(got), "n_tables": len(tabs),
                     "recall": round(len(gt & got) / max(1, len(gt)), 4)})
        if len(rows) % 20 == 0:
            print(f"{len(rows)}/{N} {time.perf_counter()-t0:.0f}s", flush=True)

    n = len(rows)
    summary = {
        "n": n,
        "mean_recall": round(sum(r["recall"] for r in rows) / n, 4),
        "exact": sum(1 for r in rows if r["recall"] == 1),
        "zero_recall": sum(1 for r in rows if r["recall"] == 0),
        "mean_gold_tables": round(sum(len(r["gold"]) for r in rows) / n, 2),
        "mean_got_tables": round(sum(len(r["got"]) for r in rows) / n, 2),
        "mean_all_tables": round(sum(r["n_tables"] for r in rows) / n, 2),
        "seconds": round(time.perf_counter() - t0, 1),
    }
    json.dump({"summary": summary, "rows": rows}, open(OUT, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
