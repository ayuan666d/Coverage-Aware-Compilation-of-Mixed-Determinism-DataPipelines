"""E12 leg 2: closed-form spectral retrieval (LSA over the compiled matrices).

Query = mean of its term vectors in each space; score = cosine; the only
free parameters are the word/ngram fusion weights, tuned on TRAIN-database
questions and frozen before touching the test split.  A same-tokenizer BM25
is computed as the lexical anchor.  Catalog = merged 876 tables.
"""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from pathlib import Path

import numpy as np

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
CASES = REPO / "06_结果" / "e11_cases.json"
CACHE = WORK / "schema_cache.json"
NPZ = WORK / "e12_spectral.npz"
OUT = REPO / "06_结果" / "e12_spectral.json"

WORD = re.compile(r"[a-z0-9]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us list show give find return
number names name""".split())


def wtoks(s):
    return [t for t in WORD.findall(s.lower()) if t not in STOP]


def ngrams(word, ns=(3, 4, 5)):
    w = f"<{word}>"
    return {w[i:i + n] for n in ns for i in range(len(w) - n + 1)} if len(w) >= 3 else set()


def metrics(top5, gold):
    g = set(gold)
    r = {k: 0.0 for k in (1, 3, 5)}
    mrr = 0.0
    for i, t in enumerate(top5[:5]):
        if t in g:
            mrr = max(mrr, 1.0 / (i + 1))
            for k in r:
                if i < k:
                    r[k] += 1.0 / len(g)
    out = {f"recall@{k}": v for k, v in r.items()}
    out["mrr"] = mrr
    return out


def agg(rows, key):
    ms = [m[key] for m in rows]
    return {k: round(sum(m[k] for m in ms) / len(ms), 4) for k in ms[0]}


def main():
    z = np.load(NPZ, allow_pickle=True)
    doc_ids = [str(x) for x in z["doc_ids"]]
    D = len(doc_ids)
    word_vocab = {t: i for i, t in enumerate(z["word_vocab"])}
    gram_vocab = {t: i for i, t in enumerate(z["gram_vocab"])}
    term_word, term_gram = z["term_word"], z["term_gram"]
    doc_word, doc_gram = z["doc_word"], z["doc_gram"]
    doc_word_n = doc_word / np.maximum(np.linalg.norm(doc_word, axis=1, keepdims=True), 1e-9)
    doc_gram_n = doc_gram / np.maximum(np.linalg.norm(doc_gram, axis=1, keepdims=True), 1e-9)

    cache = json.load(open(CACHE, encoding="utf-8"))["spider"]
    doc_tok = {}
    for db, s in cache.items():
        for t in s["tables"]:
            fid = f"{db}::{t['name'].lower()}"
            ts = list(wtoks(t["name"])) * 2
            for c in t["columns"]:
                ts += wtoks(c["name"])
                for v in (c.get("values") or [])[:12]:
                    ts += wtoks(str(v))
            doc_tok[fid] = ts
    df = Counter()
    for ts in doc_tok.values():
        df.update(set(ts))
    N = len(doc_tok)
    doc_lists = [doc_tok[f] for f in doc_ids]
    tf = np.zeros((D, len(df)), dtype=np.float32)
    tidx = {t: i for i, t in enumerate(sorted(df))}
    for j, ts in enumerate(doc_lists):
        for t, c in Counter(ts).items():
            tf[j, tidx[t]] = c
    dlen = tf.sum(axis=1)

    def bm25_top5(q_tokens, k1=1.2, b=0.75):
        s = np.zeros(D, dtype=np.float32)
        for t, qc in Counter(q_tokens).items():
            if t not in tidx:
                continue
            idf = math.log(1 + (N - df[t] + 0.5) / (df[t] + 0.5))
            col = tf[:, tidx[t]]
            s += qc * idf * (col * (k1 + 1)) / (col + k1 * (1 - b + b * dlen / (dlen.mean() + 1e-9)))
        return [doc_ids[i] for i in np.argsort(-s)[:5]]

    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    gold_all = {c["qid"]: [f"{c['db_id']}::{g.lower()}" for g in c["gold"]] for c in cases}
    qtext = {c["qid"]: c["question"] for c in cases}
    split = {c["qid"]: c["split"] for c in cases}
    qids = sorted(qtext, key=lambda q: int(q[2:]))

    def project(tokens):
        wv, gv = [], []
        for t in tokens:
            if t in word_vocab:
                wv.append(term_word[word_vocab[t]])
            for g in ngrams(t):
                if g in gram_vocab:
                    gv.append(term_gram[gram_vocab[g]])
        wv = np.mean(wv, axis=0) if wv else None
        gv = np.mean(gv, axis=0) if gv else None
        if wv is not None:
            wv = wv / max(np.linalg.norm(wv), 1e-9)
        if gv is not None:
            gv = gv / max(np.linalg.norm(gv), 1e-9)
        return wv, gv

    qvecs = {q: project(wtoks(qtext[q])) for q in qids}

    def spectral_top5(q, alpha, beta):
        wv, gv = qvecs[q]
        s = np.zeros(D, dtype=np.float32)
        if wv is not None and alpha > 0:
            s += alpha * doc_word_n @ wv
        if gv is not None and beta > 0:
            s += beta * doc_gram_n @ gv
        return [doc_ids[i] for i in np.argsort(-s)[:5]]

    grid = [(a / 4, b / 4) for a in range(5) for b in range(5) if a + b > 0]
    train_q = [q for q in qids if split[q] == "train"]
    test_q = [q for q in qids if split[q] == "test"]

    best, best_r5 = None, -1
    for a, b in grid:
        rows = [metrics(spectral_top5(q, a, b), gold_all[q]) for q in train_q]
        r5 = sum(r["recall@5"] for r in rows) / len(rows)
        if r5 > best_r5:
            best_r5, best = r5, (a, b)
    a, b = best
    print(f"tuned on train(n={len(train_q)}): alpha={a} beta={b} R@5={best_r5:.4f}")

    out_rows = []
    for tag, qs in (("train", train_q), ("test", test_q)):
        for q in qs:
            g = gold_all[q]
            rec = {"qid": q, "db": q.split("::")[0] if "::" in q else
                   next(c["db_id"] for c in cases if c["qid"] == q), "gold": g}
            rec["bm25"] = {"top5": bm25_top5(wtoks(qtext[q])), **metrics(bm25_top5(wtoks(qtext[q])), g)}
            rec["word"] = {"top5": spectral_top5(q, 1, 0), **metrics(spectral_top5(q, 1, 0), g)}
            rec["gram"] = {"top5": spectral_top5(q, 0, 1), **metrics(spectral_top5(q, 0, 1), g)}
            rec["fused"] = {"top5": spectral_top5(q, a, b), **metrics(spectral_top5(q, a, b), g)}
            out_rows.append(rec)

    summary = {}
    for tag in ("train", "test"):
        sub = [r for r in out_rows if (tag == "train") == (split[r["qid"]] == "train")]
        summary[tag] = {}
        for m in ("bm25", "word", "gram", "fused"):
            ms = [r[m] for r in sub]
            keys = [k for k in ms[0] if k != "top5"]
            summary[tag][m] = {k: round(sum(x[k] for x in ms) / len(ms), 4) for k in keys}

    json.dump({"alpha": a, "beta": b, "k": 256, "n_train": len(train_q), "n_test": len(test_q),
               "summary": summary, "rows": out_rows},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    for tag in ("test",):
        print(tag, json.dumps(summary[tag]["fused"]), "bm25", json.dumps(summary[tag]["bm25"]))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
