# -*- coding: utf-8 -*-
"""E6: is a low-level (columnar) rule engine worth building?

Three numbers:
  1. Python dict loop vs NumPy columnar on 100k permits;
  2. verdict mismatch (the vectorized plan must be exact);
  3. Amdahl: if rules are 1% / 10% / 30% of end-to-end time, how much does a
     faster rule engine actually save?

The point is to decide before building. If rules are microseconds and the model
is seconds, a 100x faster rule engine is invisible end-to-end.
"""

from __future__ import annotations

import json
import random
import sys
import time
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "05_代码"))

from checker.decision_table import load_table  # noqa: E402

TABLE_PATH = REPO / "04_数据" / "gb30871" / "decision_table_v0.2.yaml"
OUT = REPO / "06_结果" / "E6_列式算子.json"

WORK = ["hot", "confined", "blind", "lifting", "electric", "excavation", "road", "height"]
FIRE = ["special", "first", "second", "none"]
APPROVAL = ["team", "department", "company"]
HOURS = [4, 8, 12, 24, 48, 72, 96]
LEL = [0, 5, 10, 15, 20, 25, 30, 40]
O2 = [17.0, 18.5, 19.0, 19.5, 20.9, 21.0, 23.0, 23.5, 24.0, 25.0]


def gen_docs(n: int, seed: int = 20261031):
    rng = random.Random(seed)
    docs = []
    for i in range(n):
        hot = rng.random() < 0.25
        fire = rng.choice(["special", "first", "second"]) if hot else "none"
        pre = {
            "work_type": "hot" if hot else rng.choice([w for w in WORK if w != "hot"]),
            "fire_level": fire,
            "valid_hours": rng.choice(HOURS),
            "approval_level": rng.choice(APPROVAL),
            "multi_permit": rng.random() < 0.2,
            "multi_permits_ok": rng.random() < 0.85,
            "approver_authorized": rng.random() < 0.9,
            "guardian_certified": rng.random() < 0.9,
            "gas_before_approval": rng.random() < 0.9,
        }
        post = {
            "measures_done": rng.random() < 0.85,
            "lel": rng.choice(LEL),
            "o2": rng.choice(O2),
            "isolated": rng.random() < 0.85,
            "cleanup": rng.random() < 0.85,
        }
        docs.append({"id": f"b{i:06d}", "pre": pre, "post_true": post,
                     "text": "", "true_verdict": ""})
    return docs


def python_eval(docs, table):
    out = []
    for d in docs:
        out.append(table.evaluate({**d["pre"], **d["post_true"]}).verdict)
    return out


def encode(docs):
    """dict list -> column arrays (this is the cost of not having Arrow already)."""
    wi = {w: i for i, w in enumerate(WORK)}
    fi = {f: i for i, f in enumerate(FIRE)}
    ai = {a: i for i, a in enumerate(APPROVAL)}
    return {
        "work": np.array([wi[d["pre"]["work_type"]] for d in docs], dtype=np.int8),
        "fire": np.array([fi[d["pre"]["fire_level"]] for d in docs], dtype=np.int8),
        "hours": np.array([d["pre"]["valid_hours"] for d in docs], dtype=np.int16),
        "approval": np.array([ai[d["pre"]["approval_level"]] for d in docs], dtype=np.int8),
        "multi": np.array([d["pre"]["multi_permit"] for d in docs], dtype=np.bool_),
        "multi_ok": np.array([d["pre"]["multi_permits_ok"] for d in docs], dtype=np.bool_),
        "auth": np.array([d["pre"]["approver_authorized"] for d in docs], dtype=np.bool_),
        "guard": np.array([d["pre"]["guardian_certified"] for d in docs], dtype=np.bool_),
        "gas": np.array([d["pre"]["gas_before_approval"] for d in docs], dtype=np.bool_),
        "measures": np.array([d["post_true"]["measures_done"] for d in docs], dtype=np.bool_),
        "lel": np.array([d["post_true"]["lel"] for d in docs], dtype=np.int16),
        "o2": np.array([d["post_true"]["o2"] for d in docs], dtype=np.float32),
        "isolated": np.array([d["post_true"]["isolated"] for d in docs], dtype=np.bool_),
        "cleanup": np.array([d["post_true"]["cleanup"] for d in docs], dtype=np.bool_),
    }


def columnar_eval(c):
    hot = c["work"] == 0
    special_first = (c["fire"] == 0) | (c["fire"] == 1)
    second = c["fire"] == 2
    none = c["fire"] == 3
    p2 = hot & ~(special_first | second)
    p3 = (special_first & (c["hours"] > 8)) | (second & (c["hours"] > 72)) | (none & (c["hours"] > 72))
    p4 = special_first & (c["approval"] == 0)
    p5 = c["multi"] & ~c["multi_ok"]
    p6 = ~c["auth"]
    p7 = ~c["guard"]
    p8 = ~c["gas"]
    pre_reject = p2 | p3 | p4 | p5 | p6 | p7 | p8
    q1 = ~c["measures"]
    q2 = c["lel"] > 25
    q3 = (c["o2"] < 19.5) | (c["o2"] > 23.5)
    q4 = ~c["isolated"]
    q5 = ~c["cleanup"]
    post_reject = q1 | q2 | q3 | q4 | q5
    verdict = np.where(pre_reject | post_reject, "reject", "pass")
    return verdict, int(pre_reject.sum()), int(post_reject.sum())


def amdahl(speedup: float, shares=(0.01, 0.10, 0.30)):
    out = {}
    for s in shares:
        gain = 1.0 / ((1.0 - s) + s / speedup) - 1.0
        out[str(s)] = round(100 * gain, 2)
    return out


def main() -> None:
    n = 100_000
    table = load_table(TABLE_PATH)
    docs = gen_docs(n)

    t0 = time.perf_counter()
    py = python_eval(docs, table)
    t_py = time.perf_counter() - t0

    t0 = time.perf_counter()
    c = encode(docs)
    t_enc = time.perf_counter() - t0

    t0 = time.perf_counter()
    vec, pre_rej, post_rej = columnar_eval(c)
    t_vec = time.perf_counter() - t0

    mism = sum(1 for a, b in zip(py, vec) if a != b)
    speed_pre = t_py / t_vec if t_vec else None
    speed_all = t_py / (t_enc + t_vec) if (t_enc + t_vec) else None

    # Amdahl at the measured speedup
    amd = amdahl(speed_pre or 1.0)
    # End-to-end with model latency: rules per doc vs model per doc
    rule_us = 1e6 * t_vec / n
    model_ms = [500, 1000, 2000]
    e2e = {}
    for ms in model_ms:
        share = (rule_us / 1000) / (ms + rule_us / 1000)
        e2e[str(ms)] = {"rule_share_pct": round(100 * share, 6),
                        "gain_from_100x_rules_pct": round(100 * (1 - (1 - share) / (1 - share + share / 100)), 6)}

    out = {
        "n": n,
        "python_eval_s": round(t_py, 4),
        "encode_s": round(t_enc, 4),
        "columnar_eval_s": round(t_vec, 4),
        "speedup_preencoded": round(speed_pre, 1) if speed_pre else None,
        "speedup_with_encode": round(speed_all, 1) if speed_all else None,
        "mismatches": mism,
        "pre_reject": pre_rej,
        "post_reject": post_rej,
        "verdict_counts": {"pass": int((vec == "pass").sum()),
                           "reject": int((vec == "reject").sum())},
        "amdahl_100x_pct": amd,
        "rule_us_per_doc": round(rule_us, 3),
        "end_to_end": e2e,
    }
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
