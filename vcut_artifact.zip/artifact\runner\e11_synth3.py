"""E11-SYNTH3: is the searched operator's win real, and does the certificate survive it?

e11_synth2.py found three label-free operators that read above the hand-written arm on the frozen
test questions (test recall@1 73.31/73.90/73.90 vs 72.73, recall@5 83.82/82.21/82.16 vs 81.62),
and a supervised search that reads 73.02/81.77.  Small differences on 341 questions: one recall@1
point is 3.4 questions.  Two things have to be settled before this is a result.

(1) Is the margin bigger than question-level noise?  Paired bootstrap over questions (10 000
    resamples, identical resample for both arms) gives the 95% interval of the difference, and
    McNemar's exact binomial on the discordant first-hit pairs gives a p-value.  Both compare arms
    question by question, so the lake's composition is not a source of variance.

(2) The line's own acceptance condition: the certificate must not get worse.  The ranked answer is
    what the certificate attests, so changing the ranker changes what is certified.  Re-read, with
    alpha = 0.05 unchanged and the same catalogue-side nulls (e11_cotype.docs_by_type +
    chance_tail), for every arm: word, name, col, word&name, word&col -- coverage, false passes,
    precision.  Also re-read the older frozen hand rule (support k>=3 & rarest-anchor df<=2) so the
    archive's headline numbers are compared on the same footing.

Reported together with a dense reference so nothing here is claimed to beat the model.
"""
from __future__ import annotations

import json
import math
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_col import col_index  # noqa: E402
from e11_cotype import docs_by_type, incidence  # noqa: E402
from e11_surprise import chance_tail  # noqa: E402
import e11_synth2 as s2  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
OUT = R / "e11_synth3.json"
ALPHA = 0.05
K_FROZEN, M_FROZEN = 3, 2
BOOT = 10_000
LAYERS = ("word", "name", "col", "word&name", "word&col", "word&col&name")


def paired(rA, rB):
    """Paired bootstrap of mean(A)-mean(B) plus McNemar on discordant binary pairs."""
    a, b = np.asarray(rA, float), np.asarray(rB, float)
    d = a - b
    n = len(d)
    rng = np.random.default_rng(11)
    idx = rng.integers(0, n, size=(BOOT, n))
    bs = d[idx].mean(axis=1)
    lo, hi = np.percentile(bs, [2.5, 97.5])
    wins = int((d > 0).sum())
    losses = int((d < 0).sum())
    p = 1.0
    if wins + losses > 0:
        k = min(wins, losses)
        p = min(1.0, sum(math.comb(wins + losses, i) * 0.5 ** (wins + losses)
                         for i in range(k + 1)) * 2)
    return {"delta": round(float(d.mean()), 4), "ci95": [round(float(lo), 4), round(float(hi), 4)],
            "arm_better": wins, "other_better": losses, "mcnemar_p": round(float(p), 4)}


def main():
    t0 = time.time()
    g.SPLIT_IDENT = True
    cache = json.load(open(s2.CACHE, encoding="utf-8"))
    data = json.load(open(s2.CASES, encoding="utf-8"))
    te_cases = [c for c in data["spider"] if c["split"] == "test"]
    tr_cases = [c for c in data["spider"] if c["split"] == "train"]
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += [dict(t, db=db) for t in cache["spider"][db]["tables"]]
        have = {t["name"] for t in cache["spider"][db]["tables"]}
        fks += [[f"{db}::{a}", ca, f"{db}::{b}", cb] for a, ca, b, cb in cache["spider"][db]["fks"]
                if a in have and b in have]
    cat = g.Catalog(tabs, fks, coquery=None, prefix_db=True)
    N = len(cat.tables)
    colnodes, cdocs, starts, ends = col_index(cat)
    lam = s2.lambda2(cat)
    alphas = [0.80, 0.85, 0.90, round(lam, 3)]
    vocab = sorted({w for c in tr_cases + te_cases for w in toks(c["question"])
                    if ("token", w) in cat.idx})
    tid = {w: i for i, w in enumerate(vocab)}
    n_tok = len(vocab)
    idf = np.array([math.log(1 + (N - cat.token_df.get(w, 0) + 0.5)
                             / (cat.token_df.get(w, 0) + 0.5)) for w in vocab], dtype=np.float32)

    namehit = np.zeros((n_tok, N), dtype=np.float32)
    valhit = np.zeros((n_tok, N), dtype=np.float32)
    name_df, val_df = Counter(), Counter()
    nm_toks, vl_toks = [], []
    for j, t in enumerate(cat.tables):
        nm = set(toks(t["name"]))
        for c in t["columns"]:
            nm |= set(toks(c["name"]))
        vl = set()
        for c in t["columns"]:
            for v in c.get("values", [])[:6]:
                vl |= set(toks(v)[:3])
        nm_toks.append(nm)
        vl_toks.append(vl)
        name_df.update(nm)
        val_df.update(vl)
        for w in nm:
            i = tid.get(w)
            if i is not None:
                namehit[i, j] = 1.0
        for w in vl:
            i = tid.get(w)
            if i is not None:
                valhit[i, j] = 1.0
    nbr = [[] for _ in range(N)]
    for a, ca, b, cb in cat.fks:
        ja, jb = cat.table_pos.get(a), cat.table_pos.get(b)
        if ja is not None and jb is not None:
            nbr[ja].append(jb)
            nbr[jb].append(ja)
    fkhit = np.zeros((n_tok, N), dtype=np.float32)
    for j in range(N):
        s = set()
        for k in nbr[j]:
            s |= nm_toks[k] | vl_toks[k]
        for w in s:
            i = tid.get(w)
            if i is not None:
                fkhit[i, j] = 1.0
    diff = {}
    for a in alphas:
        td = np.zeros((n_tok, N), dtype=np.float32)
        cd = np.zeros((n_tok, N), dtype=np.float32)
        for w in vocab:
            x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, a, s2.ITERS)
            st = np.asarray(cat.table_scores(x), dtype=np.float32)
            mx = float(st.max())
            if mx > 0:
                td[tid[w]] = st / mx
            cv = np.asarray(x)[colnodes].astype(np.float32)
            cmx = float(cv.max())
            if cmx > 0:
                cv = cv / cmx
            cd[tid[w]] = np.maximum.reduceat(cv, starts)
        diff[a] = (td, cd)
    docs = [g.table_doc(t) for t in cat.tables]
    dl = np.array([len(d) for d in docs], dtype=np.float32)
    avgdl = float(dl.mean())
    dfc = Counter()
    for d in docs:
        dfc.update(set(d))
    tf = np.zeros((n_tok, N), dtype=np.float32)
    for i, w in enumerate(vocab):
        for j, d in enumerate(docs):
            if w in d:
                tf[i, j] = d.count(w)
    k1, bb = 1.2, 0.75
    TS = (idf[:, None] * tf * (k1 + 1.0)
          / (tf + k1 * (1.0 - bb + bb * dl[None, :] / avgdl))).astype(np.float32)
    FM = {"namehit": namehit, "valhit": valhit, "fkhit": fkhit, "bm25": TS}

    def prep(cases):
        rows = []
        for c in cases:
            q = sorted(set(toks(c["question"])))
            idx = np.array([tid[w] for w in q if w in tid], dtype=np.int64)
            gold = {f"{c['db_id']}::{t}".lower() for t in c["gold"]}
            pos = {cat.table_ids.index(t) for t in
                   {f"{c['db_id']}::{t}" for t in c["gold"]} if t in cat.table_pos}
            rows.append({"qid": c["qid"], "db": c["db_id"], "q": q, "idx": idx, "iw": idf[idx],
                         "b": TS[idx].sum(0), "gold": gold, "goldpos": pos,
                         "ngold": max(1, len(gold))})
        return rows

    test = prep(te_cases)

    def rank_rows(rec, w, alpha, agg, K):
        td, cd = diff[alpha]
        idx, iw = rec["idx"], rec["iw"]
        acc = np.zeros((idx.size, N), dtype=np.float32)
        for name in s2.FEATS:
            if w[name] <= 0:
                continue
            M = (td if name == "tabdiff" else cd if name == "coldiff" else FM[name])[idx]
            acc += w[name] * M
        base = np.log(acc + s2.EPS) if agg == "geo" else acc
        m = (iw @ base) / max(float(iw.sum()), 1e-6) if idx.size else np.zeros(N)
        cands = np.argsort(-rec["b"])[:K] if K < N else np.arange(N)
        return cands[np.argsort(-m[cands])]

    syn = json.load(open(R / "e11_synth2.json", encoding="utf-8"))
    arms = {"hand": dict(s2.HAND)}
    for o in ("cover_doc", "cover_name", "soft", "sup"):
        b = syn["results"][o]["best"]
        arms[f"synth_{o}"] = {"weights": b["weights"], "alpha": b["alpha"],
                              "agg": b["agg"], "K": b["K"]}
    arms["bm25_only"] = {"weights": {f: 0.0 for f in s2.FEATS} | {"bm25": 1.0},
                         "alpha": 0.85, "agg": "lin", "K": 876}

    # ---- certificate statistics: identical corpora and nulls as e11_cotype, alpha untouched ----
    corpora = docs_by_type(cat)
    incs = {k: incidence(d) for k, d in corpora.items()}
    dfs = {k: Counter() for k in corpora}
    for k, d in corpora.items():
        for doc in d:
            dfs[k].update({w: 1 for w in set(doc)})
    col_of_table = [(int(s), int(e)) for s, e in zip(starts, ends)]
    stats = {}
    for rec in test:
        q = set(rec["q"])
        vec, curve = {}, {}
        for k in ("word", "name", "value"):
            inc = incs[k]
            s = np.zeros(N, dtype=np.float32)
            qd = []
            for w in q:
                v = inc.get(w)
                if v is None:
                    continue
                s += v
                qd.append(dfs[k].get(w, 0))
            vec[k] = s
            curve[k] = [chance_tail(qd, N, x)[1] for x in range(0, len(q) + 2)]
        inc = incs["col"]
        qcols = [(w, inc[w], dfs["col"].get(w, 0)) for w in q if w in inc]
        s = np.zeros(N, dtype=np.float32)
        if qcols:
            per_col = np.zeros(len(corpora["col"]), dtype=np.int32)
            for _, v, _ in qcols:
                per_col += v.astype(np.int32)
            for i, (a, b) in enumerate(col_of_table):
                s[i] = per_col[a:b].max() if b > a else 0
        vec["col"] = s
        curve["col"] = [chance_tail([d for _, _, d in qcols], len(corpora["col"]), x)[1]
                        for x in range(0, len(q) + 2)]
        stats[rec["qid"]] = {"vec": vec, "curve": curve}
    print(f"catalogue, caches and certificate nulls in {time.time()-t0:.0f}s", flush=True)

    # support certificate needs the rarest-anchor df of the query (the frozen hand rule)
    out = {"alpha": ALPHA, "n_test": len(test), "n_tables": N,
           "lambda2": round(lam, 4), "arms": {}, "per_question": {}}
    for name, cfg in arms.items():
        r1, r5, acc_lay, fp_lay, cov_r5, drop_ok = [], [], Counter(), Counter(), Counter(), Counter()
        acc_sup, fp_sup, cov_r5_sup = 0, 0, 0.0
        top1s = []
        n = 0
        for rec in test:
            order = rank_rows(rec, cfg["weights"], cfg["alpha"], cfg["agg"], cfg["K"])
            t1 = int(order[0])
            top1s.append(cat.table_ids[t1])
            gset = rec["gold"]
            ok = cat.table_ids[t1].lower() in gset
            r1.append(1.0 if ok else 0.0)
            r5.append(sum(1 for t in order[:5] if cat.table_ids[t].lower() in gset) / rec["ngold"])
            st = stats[rec["qid"]]
            pv = {}
            for k in ("word", "name", "col"):
                s_ = int(st["vec"][k][t1])
                pv[k] = st["curve"][k][min(s_, len(st["curve"][k]) - 1)] <= ALPHA
            for tag in LAYERS:
                if all(pv[t] for t in tag.split("&")):
                    acc_lay[tag] += 1
                    cov_r5[tag] += r5[-1]
                    if not ok:
                        fp_lay[tag] += 1
                elif ok:
                    drop_ok[tag] += 1
            shared = len(set(rec["q"]) & set(g.table_doc(cat.tables[t1])))
            rarest = min([cat.token_df.get(w, 10 ** 9) for w in rec["q"]], default=10 ** 9)
            if shared >= K_FROZEN and rarest <= M_FROZEN:
                acc_sup += 1
                cov_r5_sup += r5[-1]
                if not ok:
                    fp_sup += 1
            n += 1
        out["arms"][name] = {
            "cfg": cfg, "r1": round(float(np.mean(r1)), 4), "r5": round(float(np.mean(r5)), 4),
            "layers": {tag: {"accepted": acc_lay[tag], "cov": round(acc_lay[tag] / n, 4),
                             "false_pass": fp_lay[tag],
                             "precision": round(1 - fp_lay[tag] / acc_lay[tag], 4)
                             if acc_lay[tag] else None,
                             "acc_r5_on_accepted": round(cov_r5[tag] / acc_lay[tag], 4)
                             if acc_lay[tag] else None,
                             "dropped_correct": drop_ok[tag]} for tag in LAYERS},
            "frozen_support_rule": {"accepted": acc_sup, "cov": round(acc_sup / n, 4),
                                    "false_pass": fp_sup,
                                    "precision": round(1 - fp_sup / acc_sup, 4) if acc_sup else None,
                                    "acc_r5_on_accepted": round(cov_r5_sup / acc_sup, 4)
                                    if acc_sup else None}}
        out["per_question"][name] = {"r1": r1, "r5": r5}
        print(f"{name}: r1={out['arms'][name]['r1']} r5={out['arms'][name]['r5']} "
              f"word&name accepted={out['arms'][name]['layers']['word&name']['accepted']} "
              f"fp={out['arms'][name]['layers']['word&name']['false_pass']} "
              f"({time.time()-t0:.0f}s)", flush=True)

    # dense reference, per question, on the same rows -- ranked in id space exactly as the
    # archived reading did, so the paired bootstrap compares like with like
    z = np.load(s2.EMB, allow_pickle=True)
    ids_d = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}
    r1d, r5d = [], []
    for rec in test:
        if rec["qid"] not in qpos:
            r1d.append(0.0)
            r5d.append(0.0)
            continue
        sim = Dm @ Qm[qpos[rec["qid"]]]
        order = [ids_d[i].lower() for i in np.argsort(-sim)]
        gset = rec["gold"]
        r1d.append(1.0 if order and order[0] in gset else 0.0)
        r5d.append(sum(1 for t in order[:5] if t in gset) / rec["ngold"])
    out["per_question"]["dense"] = {"r1": r1d, "r5": r5d}
    out["arms"]["dense"] = {"cfg": "cached Qwen embedding, full ranking",
                            "r1": round(float(np.mean(r1d)), 4),
                            "r5": round(float(np.mean(r5d)), 4)}

    boots = {}
    for name in arms:
        if name == "hand":
            continue
        boots[name] = {"vs_hand": {"r1": paired(out["per_question"][name]["r1"],
                                               out["per_question"]["hand"]["r1"]),
                                   "r5": paired(out["per_question"][name]["r5"],
                                                out["per_question"]["hand"]["r5"])},
                       "vs_dense": {"r1": paired(out["per_question"][name]["r1"], r1d),
                                    "r5": paired(out["per_question"][name]["r5"], r5d)}}
    boots["hand_vs_dense"] = {"r1": paired(out["per_question"]["hand"]["r1"], r1d),
                              "r5": paired(out["per_question"]["hand"]["r5"], r5d)}
    out["bootstrap"] = boots
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    show = {k: {"r1": v["r1"], "r5": v["r5"],
                "word&name": v["layers"]["word&name"], "word": v["layers"]["word"],
                "frozen_support_rule": v.get("frozen_support_rule")}
            for k, v in out["arms"].items() if "layers" in v}
    print(json.dumps({"arms": show, "bootstrap": boots,
                      "elapsed_s": round(time.time() - t0, 1)}, indent=1, ensure_ascii=False))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
