"""E46 理论容纳性检验：渗透-容量模型。

核心：不再用"排序不变性"解释退化（dense 反例已推翻），改用
      单张干扰表超越金标的概率 pi_g。
      X_g ~ Binomial(M, pi_g)，hit@k <=> r_g + X_g <= k-1。
"""
import json
import sys
import numpy as np
from scipy import stats

D = "D:/vldb2027_e11"


def L(p):
    return [json.loads(l) for l in open(f"{D}/{p}", encoding="utf-8")]


def rows(p, M):
    """展平成逐金标记录 (qid, r_real, X, M)。"""
    out = []
    for q in L(p):
        for r, g in zip(q["gpos_real"], q["gpos"]):
            out.append((q["qid"], r, g - r, M))
    return out


def summarize(name, recs):
    M = recs[0][3]
    r = np.array([x[1] for x in recs], float)
    X = np.array([x[2] for x in recs], float)
    pi = X / max(M, 1)
    print(f"  {name:8s} n={len(recs):5d} M={M:5d} | r: med={np.median(r):5.1f} "
          f"mean={r.mean():7.2f} | X: med={np.median(X):5.0f} mean={X.mean():8.2f} "
          f"p90={np.percentile(X,90):6.0f} | pi={pi.mean():.5f}")
    return r, X, pi, M


print("=" * 78)
print("【1】逐金标 rank 分布：真实表内 r 与全目录多出的 X")
print("=" * 78)
F = {
    "951": rows("e44_forge_rich_951-leg_perq.jsonl", 0),
    "4k": rows("e44_forge_rich_4k-syn-leg_perq.jsonl", 3049),
    "10k": rows("e44_forge_rich_10k-syn-leg_perq.jsonl", 9049),
}
Fb = {
    "4k": rows("e45_forge_beta0_rich_4k-syn-leg_perq.jsonl", 3049),
    "10k": rows("e45_forge_beta0_rich_10k-syn-leg_perq.jsonl", 9049),
}

print("\n[FORGE beta=0.3]")
sF = {t: summarize("beta.3 " + t, F[t]) for t in ("951", "4k", "10k")}
print("\n[FORGE beta=0]")
sB = {t: summarize("beta0 " + t, Fb[t]) for t in ("4k", "10k")}

print("\n" + "=" * 78)
print("【2】渗透率 pi 的规模不变性（关键假设）")
print("=" * 78)
for tag, S, M4, M10 in [("beta=0.3", F, 3049, 9049), ("beta=0", Fb, 3049, 9049)]:
    a = {(q, i): (r, x) for q, r, x, _ in S["4k"]
         for i in [0]}  # 占位，改为按序对齐
    # 按 (qid, 序号) 对齐
    def keyed(recs):
        d = {}
        for q, r, x, _ in recs:
            d.setdefault(q, []).append((r, x))
        return d
    k4, k10 = keyed(S["4k"]), keyed(S["10k"])
    pairs = []
    for q in k4:
        if q not in k10:
            continue
        for i in range(min(len(k4[q]), len(k10[q]))):
            pairs.append((k4[q][i], k10[q][i]))
    x4 = np.array([p[0][1] for p in pairs], float)
    x10 = np.array([p[1][1] for p in pairs], float)
    dr = np.array([p[1][0] - p[0][0] for p in pairs], float)
    print(f"\n  {tag}: 配对数 {len(pairs)}")
    print(f"    聚合: E[X] 4k={x4.mean():7.2f} -> 10k={x10.mean():7.2f} "
          f"比={x10.mean()/x4.mean():.3f} (线性应 {M10/M4:.3f})")
    if x4.mean() > 0:
        print(f"    pi:  4k={x4.mean()/M4:.5f} 10k={x10.mean()/M10:.5f} "
              f"相对差={abs(x10.mean()/M10-x4.mean()/M4)/(x4.mean()/M4)*100:5.2f}%")
    print(f"    r 漂移: 完全一致={np.mean(dr==0)*100:5.1f}%  平均|dr|={np.abs(dr).mean():.3f}")
    # 分桶检验线性
    print("    分桶（按 X_4k）:")
    edges = [0, 0.5, 2, 5, 20, 100, 1000, 1e9]
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (x4 >= lo) & (x4 < hi)
        if m.sum() < 10:
            continue
        print(f"      X4 in [{lo:6.1f},{hi:7.1f}): n={m.sum():4d} "
              f"X4均值={x4[m].mean():8.2f} X10均值={x10[m].mean():9.2f} "
              f"比={x10[m].mean()/max(x4[m].mean(),1e-9):6.2f}")

print("\n" + "=" * 78)
print("【3】用 4k 预测 10k：(r, pi) 二项模型的外推能力")
print("=" * 78)


def predict(S4, S10, alpha=0.5):
    def keyed(recs):
        d = {}
        for q, r, x, _ in recs:
            d.setdefault(q, []).append((r, x))
        return d
    k4, k10 = keyed(S4), keyed(S10)
    M4, M10 = 3049, 9049
    G = []  # (r4, pi_hat, r10, X10)
    for q in k4:
        if q not in k10:
            continue
        for i in range(min(len(k4[q]), len(k10[q]))):
            r4, x4 = k4[q][i]
            r10, x10 = k10[q][i]
            pi = (x4 + alpha) / (M4 + alpha)   # 平滑后的 MLE
            G.append((r4, pi, r10, x10))
    G = np.array(G, float)
    print(f"  配对金标 {len(G)}")
    ks = [1, 3, 5, 10, 20, 50, 100]
    print(f"  {'k':>5} {'实测hit@k':>11} {'预测hit@k':>11} {'误差':>8}")
    for k in ks:
        obs = np.mean(G[:, 2] + G[:, 3] < k)
        # 预测：用 r4 与 pi_hat，X ~ Binom(M10, pi)
        pr = []
        for r4, pi, _, _ in G:
            need = k - 1 - r4
            pr.append(1.0 if need < 0 else stats.binom.cdf(need, M10, pi))
        pred = np.mean(pr)
        print(f"  {k:5d} {obs*100:11.2f} {pred*100:11.2f} {(pred-obs)*100:+8.2f}")
    return G


print("\n[FORGE beta=0.3] 用 4k 的 (r, pi) 推 10k")
G3 = predict(F["4k"], F["10k"])
print("\n[FORGE beta=0] 用 4k 的 (r, pi) 推 10k")
G0 = predict(Fb["4k"], Fb["10k"])

print("\n" + "=" * 78)
print("【4】四条方法的 pi 对比：为什么 dense 退化最重")
print("=" * 78)
import collections

def base_rows(p, M):
    out = {}
    for q in L(p):
        for m in ("bm25", "fuse", "dense"):
            for i, (r, g) in enumerate(zip(q[m]["gpos_real"], q[m]["gpos"])):
                out.setdefault(m, []).append((q["qid"], r, g - r))
    return out

B9 = base_rows("e44_legacy_rich_951_perq.jsonl", 0)
B10 = base_rows("e44_legacy_rich_10k-syn_perq.jsonl", 9049)
M10 = 9049

print(f"  {'方法':7s} {'R@5_type':>9} {'R@5_all':>8} {'Δtype':>7} {'Δinst':>8} "
      f"{'π均值':>9} {'π中位':>8} {'X中位':>6} {'X均值':>8}")
def stat(name, recs9, recs10):
    r9 = np.array([x[1] for x in recs9], float)
    r10 = np.array([x[1] for x in recs10], float)
    X = np.array([x[2] for x in recs10], float)
    rt9 = np.mean(r9 < 5)
    rt10 = np.mean(r10 < 5)
    rall = np.mean(r10 + X < 5)
    pi = X / M10
    print(f"  {name:7s} {rt10*100:9.2f} {rall*100:8.2f} {(rt10-rt9)*100:+7.2f} "
          f"{(rall-rt10)*100:+8.2f} {pi.mean():9.5f} {np.median(pi):8.5f} "
          f"{np.median(X):6.0f} {X.mean():8.1f}")
    return pi, X

piF, XF = stat("FORGE", [(q, r, 0) for q, r, x in
                         [(x[0], x[1], x[2]) for x in F["951"]]],
               [(q, r, x) for q, r, x, _ in F["10k"]])
for m in ("dense", "fuse", "bm25"):
    stat(m, B9[m], B10[m])

print("\n  注：R@5_type = 真实表内 recall@5；R@5_all = 全目录；Δinst = 槽位损失")

print("\n" + "=" * 78)
print("【5】pi 的异质性：零膨胀与长尾（解释 k<=50 优势区间）")
print("=" * 78)
for name, X in [("FORGE", np.array([x[2] for x, _ in zip(
                    [(a[1], a[2]) for a in F["10k"]], [0])], float)
                 if False else np.array([a[2] for a in F["10k"]], float)),
                ("dense", np.array([a[2] for a in B10["dense"]], float)),
                ("bm25", np.array([a[2] for a in B10["bm25"]], float))]:
    z = np.mean(X == 0) * 100
    print(f"  {name:6s} X=0 占比 {z:5.1f}% | 分位 p50={np.percentile(X,50):5.0f} "
          f"p75={np.percentile(X,75):5.0f} p90={np.percentile(X,90):6.0f} "
          f"p95={np.percentile(X,95):7.0f} p99={np.percentile(X,99):7.0f} max={X.max():6.0f}")
    # 淹没组 vs 干净组
    for thr, lbl in [(5, "X<5 (可保)"), (100, "5<=X<100"), (10**9, "X>=100")]:
        pass
    a = np.mean(X < 5) * 100
    b = np.mean((X >= 5) & (X < 100)) * 100
    c = np.mean(X >= 100) * 100
    print(f"         分组: X<5 {a:5.1f}% | 5<=X<100 {b:5.1f}% | X>=100 {c:5.1f}%")

print("\n" + "=" * 78)
print("【6】pi 与 r 的相关性（分解是否可加）")
print("=" * 78)
for name, recs in [("FORGE", [(a[1], a[2]) for a in F["10k"]]),
                   ("dense", [(a[1], a[2]) for a in B10["dense"]]),
                   ("bm25", [(a[1], a[2]) for a in B10["bm25"]])]:
    r = np.array([x[0] for x in recs], float)
    X = np.array([x[1] for x in recs], float)
    sp = stats.spearmanr(r, X)
    print(f"  {name:6s} Spearman(r, X) = {sp.statistic:+.4f} (p={sp.pvalue:.3g})")
    # 按 r 分桶看 X
    for lo, hi in [(0, 1), (1, 5), (5, 20), (20, 10**9)]:
        m = (r >= lo) & (r < hi)
        if m.sum() < 20:
            continue
        print(f"         r in [{lo},{hi if hi<10**9 else 'inf'}): n={m.sum():4d} "
              f"X中位={np.median(X[m]):5.0f} X均值={X[m].mean():8.1f} "
              f"π={X[m].mean()/M10:.5f}")
