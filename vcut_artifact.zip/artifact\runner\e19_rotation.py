"""E19: rotation-constrained readout — unit complex / unit quaternion weights.

Hypothesis: the unconstrained Fisher weights overfit the source catalog; the
failure of second-order transfer is a freedom problem, not an information
problem.  Constrain the weight vector to the rotation manifold:

  real       : w_k arbitrary (baseline, E16 transfer_first)
  complex    : z_k = r_k e^{i theta_k}, w_k = e^{i phi_k}   (U(1), |w|=1)
  quaternion : q_k = r_k (1 + a_k), w_k unit quaternion      (SU(2), |w|=1)

theta_k / a_k are fixed evidence-type phases.  Training uses only the phase of
the positive-minus-negative mean (closed form, no gradient).  Query score is
the real part of the complex / quaternion inner product.

Same 9 primitives, same Spider->BIRD transfer protocol as E16.
"""
from __future__ import annotations

import json
import sys

import numpy as np

sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码\runner")
import e14_db_anchor as e14  # noqa: E402
import e16_transfer as e16  # noqa: E402
from e15_objective import fit_fisher  # noqa: E402

OUT = e14.REPO / "06_结果" / "e19_rotation.json"
KEEP = e16.KEEP


def qmul(a, b):
    w1, x1, y1, z1 = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
    w2, x2, y2, z2 = b[..., 0], b[..., 1], b[..., 2], b[..., 3]
    return np.stack([w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
                     w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
                     w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
                     w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2], axis=-1)


def qreal(a, b):
    return a[..., 0] * b[..., 0] - a[..., 1] * b[..., 1] - a[..., 2] * b[..., 2] - a[..., 3] * b[..., 3]


def main():
    meta = e14.load()
    print("Spider features…", flush=True)
    Ft = meta["build_F"](meta["train_q"])[:, :, KEEP]
    mu = Ft.reshape(-1, 9).mean(0)
    sd = Ft.reshape(-1, 9).std(0) + 1e-9
    Xt = ((Ft - mu) / sd).reshape(-1, 9)
    Y = np.zeros((len(meta["train_q"]), meta["D"]), dtype=np.float32)
    for qi, q in enumerate(meta["train_q"]):
        for f in meta["gold_all"][q]:
            j = meta["didx"].get(f)
            if j is not None:
                Y[qi, j] = 1.0
    y = Y.reshape(-1)
    pos, neg = Xt[y > 0.5], Xt[y <= 0.5]
    delta = pos.mean(0) - neg.mean(0)

    theta = np.arange(9) * 2 * np.pi / 9
    w_c = np.exp(1j * np.angle(delta * np.exp(1j * theta)))

    axes = np.zeros((9, 3))
    for k in range(9):
        axes[k] = [np.cos(theta[k]), np.sin(theta[k]), 0.3 * np.sin(2 * theta[k])]
    axes /= np.maximum(np.linalg.norm(axes, axis=1, keepdims=True), 1e-9)

    def to_q(r):
        return np.concatenate([r[..., None], r[..., None] * axes[None, :, :]], axis=-1)

    qpos = to_q(pos)
    qneg = to_q(neg)
    dq = qpos.mean(0) - qneg.mean(0)
    w_q = dq / np.maximum(np.linalg.norm(dq, axis=1, keepdims=True), 1e-9)

    w_real = fit_fisher(Xt, y, 0.1)
    print("weights: real", np.round(w_real, 3).tolist(), flush=True)
    print("complex phase", np.round(np.angle(w_c), 3).tolist(), flush=True)

    # spider test (same protocol as E16)
    Fte = ((meta["build_F"](meta["test_q"])[:, :, KEEP] - mu) / sd).reshape(
        len(meta["test_q"]), meta["D"], 9)
    arms = {
        "real": Fte @ w_real,
        "complex": np.real(Fte @ w_c),
        "quaternion": np.sum(qreal(w_q[None, None, :, :], to_q(Fte)), axis=-1),
    }
    spi = {}
    for name, sc in arms.items():
        rows = []
        for qi, q in enumerate(meta["test_q"]):
            order = np.argsort(-sc[qi])[:5]
            top = [meta["doc_ids"][i] for i in order]
            r, m = e14.metrics_top(top, meta["gold_all"][q])
            rows.append((r[1], r[3], r[5], m))
        spi[name] = {k: round(float(np.mean([r[i] for r in rows]), ), 4)
                     for i, k in enumerate(("recall@1", "recall@3", "recall@5", "mrr"))}
        print("spider", name, json.dumps(spi[name]), flush=True)

    cache = json.load(open(e14.CACHE, encoding="utf-8"))["bird"]
    cases = json.load(open(e14.CASES, encoding="utf-8"))["bird"]
    by_db = {}
    for c in cases:
        by_db.setdefault(c["db_id"], []).append(c)

    rows = []
    for db, cs in sorted(by_db.items()):
        F9, doc_ids = e16.build_bird_db(cache[db], cs)
        Q = F9.reshape(-1, 9)
        mub = Q.mean(0)
        sdb = Q.std(0) + 1e-9
        Z = ((Q - mub) / sdb).reshape(len(cs), len(doc_ids), 9)
        sc = {"real": Z @ w_real,
              "complex": np.real(Z @ w_c),
              "quaternion": np.sum(qreal(w_q[None, None, :, :], to_q(Z)), axis=-1)}
        for qi, c in enumerate(cs):
            gold = {g.lower() for g in c["gold"]}
            for name in ("real", "complex", "quaternion"):
                order = np.argsort(-sc[name][qi])[:5]
                top = [doc_ids[i] for i in order]
                r, m = e14.metrics_top(top, gold)
                rows.append({"qid": c["qid"], "db": db, "arm": name,
                             "recall@1": r[1], "recall@3": r[3], "recall@5": r[5], "mrr": m})

    bird = {}
    for name in ("real", "complex", "quaternion"):
        sub = [r for r in rows if r["arm"] == name]
        bird[name] = {k: round(sum(r[k] for r in sub) / len(sub), 4)
                      for k in ("recall@1", "recall@3", "recall@5", "mrr")}
        print("bird", name, json.dumps(bird[name]), flush=True)

    json.dump({"spider": spi, "bird": bird,
               "reference": {"bird_transfer_first_real_r5": 0.9362,
                             "bird_transfer_second_real_r5": 0.6868},
               "weights": {"real": w_real.tolist(), "complex_phase": np.angle(w_c).tolist(),
                           "quaternion": w_q.tolist()},
               "rows": rows},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
