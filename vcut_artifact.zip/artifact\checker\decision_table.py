# -*- coding: utf-8 -*-
"""GB 30871 决策表 —— 可执行的 pre/post 编码（v0.2 骨架）

规则语义：每条规则是一个“违规条件”；命中即 reject。
pre  = 只依赖结构化字段（模型之前）；
post = 依赖模型抽取字段。

缺失字段一律走 review（保守兜底），避免“字段没抽到 → 规则不命中 → 放行”。
"""

from __future__ import annotations

from dataclasses import dataclass, field as dc_field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

import yaml

CONSERVATIVE = frozenset({"reject", "review"})

MISSING = object()


def _get(fields: Mapping[str, Any], name: str) -> Any:
    return fields.get(name, MISSING)


def eval_cond(cond: Mapping[str, Any], fields: Mapping[str, Any]) -> bool:
    """递归求值：all / any / not / 叶子条件。"""
    if "all" in cond:
        return all(eval_cond(c, fields) for c in cond["all"])
    if "any" in cond:
        return any(eval_cond(c, fields) for c in cond["any"])
    if "not" in cond:
        return not eval_cond(cond["not"], fields)

    name = cond["field"]
    op = cond["op"]
    actual = _get(fields, name)
    val = cond.get("value")

    if actual is MISSING:
        # 缺失时：只有“否定型”条件返回 True（把缺失视为违规），其余 False。
        return op in ("not_in", "ne", "is_false")

    if op == "eq":
        return actual == val
    if op == "ne":
        return actual != val
    if op == "in":
        return actual in (val or [])
    if op == "not_in":
        return actual not in (val or [])
    if op == "lt":
        return actual < val
    if op == "le":
        return actual <= val
    if op == "gt":
        return actual > val
    if op == "ge":
        return actual >= val
    if op == "is_true":
        return actual is True
    if op == "is_false":
        return actual is False
    raise ValueError(f"未知 op: {op}")


def _collect_fields(cond: Mapping[str, Any]) -> Iterable[str]:
    if "all" in cond:
        for c in cond["all"]:
            yield from _collect_fields(c)
    elif "any" in cond:
        for c in cond["any"]:
            yield from _collect_fields(c)
    elif "not" in cond:
        yield from _collect_fields(cond["not"])
    else:
        yield cond["field"]


@dataclass(frozen=True)
class Decision:
    verdict: str                 # pass / reject / review
    rule_id: str | None
    phase: str                   # pre / post / fallback / missing
    missing: Tuple[str, ...] = ()
    certified: bool = False      # 仅对 fallback=pass 有意义：默认区域是否被认证覆盖

    @property
    def judged(self) -> bool:
        return (
            self.rule_id is not None
            or self.verdict in CONSERVATIVE
            or (self.verdict == "pass" and self.certified)
        )

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "rule_id": self.rule_id,
            "phase": self.phase,
            "missing": list(self.missing),
            "certified": self.certified,
            "judged": self.judged,
        }


@dataclass
class DecisionTable:
    pre: List[dict]
    post: List[dict]
    fallback: str = "reject"
    source: str = ""
    # 默认区域认证：true 表示“没命中任何违规规则”的输入被规则集显式认定为合规。
    # 这是规则表作者的责任声明，不是语法性质；有洞的表必须设 false。
    certified_default: bool = False
    _pre_fields: Tuple[str, ...] = dc_field(init=False)
    _post_fields: Tuple[str, ...] = dc_field(init=False)

    def __post_init__(self) -> None:
        pf = set()
        for r in self.pre:
            pf.update(_collect_fields(r["when"]))
        qf = set()
        for r in self.post:
            qf.update(_collect_fields(r["when"]))
        self._pre_fields = tuple(sorted(pf))
        self._post_fields = tuple(sorted(qf))

    # ── 结构信息 ──
    @property
    def t_pre(self) -> int:
        return len(self.pre)

    @property
    def t_post(self) -> int:
        return len(self.post)

    @property
    def pre_fields(self) -> Tuple[str, ...]:
        return self._pre_fields

    @property
    def post_fields(self) -> Tuple[str, ...]:
        return self._post_fields

    # ── 判定 ──
    def _missing(self, fields: Mapping[str, Any], names: Sequence[str]) -> Tuple[str, ...]:
        return tuple(n for n in names if n not in fields or fields[n] is None)

    def pre_decision(self, fields: Mapping[str, Any]) -> Decision | None:
        """None 表示 pre 全部通过、需要进入模型；否则返回终局 decision。"""
        missing = self._missing(fields, self._pre_fields)
        if missing:
            return Decision("review", None, "missing", missing)
        for r in self.pre:
            if eval_cond(r["when"], fields):
                return Decision("reject", r["id"], "pre")
        return None

    def post_decision(self, fields: Mapping[str, Any]) -> Decision:
        missing = self._missing(fields, self._post_fields)
        if missing:
            return Decision("review", None, "missing", missing)
        for r in self.post:
            if eval_cond(r["when"], fields):
                return Decision("reject", r["id"], "post")
        return Decision(
            self.fallback, None, "fallback",
            certified=(self.fallback == "pass" and self.certified_default),
        )

    # ── 部分求值（BOSS 式 partial evaluation） ──
    # 只要一条违规规则的字段都已知且条件为真，就可以立刻 reject；
    # 其余字段缺失不影响这个结论。pass 仍然要求所有字段已知。
    def partial_pre_decision(self, fields: Mapping[str, Any]) -> Decision | None:
        missing = self._missing(fields, self._pre_fields)
        known = set(self._pre_fields) - set(missing)
        for r in self.pre:
            rf = set(_collect_fields(r["when"]))
            if rf <= known and eval_cond(r["when"], fields):
                return Decision("reject", r["id"], "pre")
        if missing:
            return Decision("review", None, "missing", missing)
        return None

    def partial_post_decision(self, fields: Mapping[str, Any]) -> Decision:
        missing = self._missing(fields, self._post_fields)
        known = set(self._post_fields) - set(missing)
        for r in self.post:
            rf = set(_collect_fields(r["when"]))
            if rf <= known and eval_cond(r["when"], fields):
                return Decision("reject", r["id"], "post")
        if missing:
            return Decision("review", None, "missing", missing)
        return Decision(
            self.fallback, None, "fallback",
            certified=(self.fallback == "pass" and self.certified_default),
        )

    def partial_evaluate(self, fields: Mapping[str, Any]) -> Decision:
        """先 pre 后 post 的部分求值；能 reject 就 reject，不能则 review/pass。"""
        d = self.partial_pre_decision(fields)
        if d is not None:
            return d
        return self.partial_post_decision(fields)

    def evaluate(self, fields: Mapping[str, Any]) -> Decision:
        d = self.pre_decision(fields)
        if d is not None:
            return d
        return self.post_decision(fields)


def load_table(path: str | Path) -> DecisionTable:
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    return DecisionTable(
        pre=list(data.get("pre") or []),
        post=list(data.get("post") or []),
        fallback=data.get("fallback", "reject"),
        source=data.get("source", ""),
        certified_default=bool(data.get("certified_default", False)),
    )
