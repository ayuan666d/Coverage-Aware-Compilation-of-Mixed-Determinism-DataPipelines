"""E11-ZEROLABEL: the second half of the cold-start test -- no labelled questions.

The other arm on this line (and the parallel GA arm) buys its weights with 693
human-annotated question/table pairs.  The claim "we build the database AS a
model" only survives review if the thing works with zero such pairs: supervision
must come from what the database already is -- names, values, types, keys, and
its ability to answer a query about itself.

Audit first: the ranker used here (identifier split + per-token idf-weighted
geometric fusion + BM25-recall-then-graph-rerank) reads no labels at all -- its
only inputs are the catalogue's own document frequencies.  So what has to be
replaced is the *certificate*, which until now was a hand-set threshold
(support>=3 & rarest anchor df<=2) chosen by looking at labelled train data.

Four certificates, all computable without a single label, all reported (the
selection rule is stated in advance: highest coverage whose precision reaches
95%; no cherry-picking after the fact):

  C1 count      : the answer's own document contains >=3 of the question's words
                  (the frozen threshold, kept as reference -- it did use labels)
  C2 executes   : at least one of the question's literal words is a real cell
                  value of the answer table, confirmed by asking the database
  C3 unique     : such a value exists AND it selects exactly one row (a verified
                  key-like witness, the fix for the E11 section-5 collapse)
  C4 count|exec : C1 or C2
"""
from __future__ import annotations

import json
import math
import re
import sqlite3
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_run_spider import coquery_map, fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = WORK / "e11_emb_spider.npz"
DBDIR = WORK / "spider" / "database"
OUT = REPO / "06_结果" / "e11_zerolabel.json"
EPS = 1e-6
NUM = re.compile(r"^\d{3,}$")


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    train = [c for c in data["spider"] if c["split"] == "train"]
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    cat = g.Catalog(tabs, fks, coquery=None, prefix_db=True)      # zero history
    N = len(cat.tables)
    z = np.load(EMB, allow_pickle=True)
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}

    tok = {}
    for w in sorted({w for c in test for w in g.toks(c["question"])}):
        if ("token", w) not in cat.idx:
            continue
        x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
        s = cat.table_scores(x)
        mx = float(s.max())
        tok[w] = s / mx if mx > 0 else s
    idf = {w: math.log(1 + (N - cat.token_df.get(w, 0) + 0.5) / (cat.token_df.get(w, 0) + 0.5))
           for w in tok}

    # ---- ask the database about itself, once per (db, table): distinct values
    conns, valcache = {}, {}

    def open_db(db):
        if db not in conns:
            p = DBDIR / db / f"{db}.sqlite"
            conns[db] = sqlite3.connect(p) if p.exists() else None
        return conns[db]

    def table_values(db, table):
        key = (db, table.lower())
        if key in valcache:
            return valcache[key]
        con = open_db(db)
        out = {"exact": set(), "cols": []}
        if con is None:
            valcache[key] = out
            return out
        have = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        real = next((h for h in have if h.lower() == table.lower()), None)
        if real is None:
            valcache[key] = out
            return out
        cols = [r[1] for r in con.execute(f'PRAGMA table_info("{real}")')]
        for c in cols:
            try:
                vals = [r[0] for r in con.execute(
                    f'SELECT DISTINCT "{c}" FROM "{real}" LIMIT 20000')]
            except sqlite3.Error:
                vals = []
            sv = {str(v).strip().lower() for v in vals if v is not None}
            out["cols"].append((c, sv))
            out["exact"] |= sv
        valcache[key] = out
        return out

    t0 = time.time()
    rows = []
    for c in test:
        q = g.toks(c["question"])
        gold = {f"{c['db_id']}::{t}".lower() for t in c["gold"]}
        ws = [w for w in set(q) if w in tok]
        if ws:
            M = np.stack([tok[w] for w in ws])
            iw = np.array([idf[w] for w in ws])[:, None]
            graph = np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
        else:
            graph = np.zeros(N, dtype=np.float32)
        b = g.bm25(cat, q)
        top = np.argsort(-b)[:30]
        mixed = b.copy()
        base = float(b[top[-1]])
        for i, idx in enumerate(top[np.argsort(-graph[top])]):
            mixed[idx] = base + (30 - i) * 1e-6
        order = np.argsort(-mixed)
        ranked = [cat.table_ids[i].lower() for i in order]
        m = g.metrics(ranked, gold)
        pos = int(order[0])
        t = cat.tables[pos]
        doc = set(g.toks(t["name"]))
        for col in t["columns"]:
            doc |= set(g.toks(col["name"]))
            for v in (col.get("values") or [])[:12]:
                doc |= set(g.toks(v))
        k = len(set(q) & doc)
        rarest = min([cat.token_df.get(w, 10 ** 9) for w in ws], default=10 ** 9)
        # C2/C3 need the real database, not the sample
        tv = table_values(t["db"], t["name"])
        qwords = {w for w in set(q) if len(w) >= 2}
        lit = {w for w in qwords if NUM.match(w) or len(w) >= 3}
        hit_words = sorted(lit & tv["exact"])
        c2 = bool(hit_words)
        c3 = False
        if c2:
            con = open_db(t["db"])
            real = t["name"]
            if con is not None:
                have = {r[0] for r in con.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'")}
                real = next((h for h in have if h.lower() == t["name"].lower()), t["name"])
                for w in hit_words:
                    for col, sv in tv["cols"]:
                        if w not in sv:
                            continue
                        try:
                            n = con.execute(
                                f'SELECT count(*) FROM (SELECT 1 FROM "{real}" '
                                f'WHERE lower("{col}") = ? LIMIT 2)', (w,)).fetchone()[0]
                        except sqlite3.Error:
                            continue
                        if n == 1:
                            c3 = True
                            break
                    if c3:
                        break
        rec = {"qid": c["qid"], "db": c["db_id"], "top1": ranked[0], "correct": float(ranked[0] in gold),
               "r1": round(m["recall@1"], 4), "r5": round(m["recall@5"], 4),
               "mrr": round(m["mrr"], 4), "k": k, "rarest_df": rarest,
               "C1": float(k >= 3 and rarest <= 2), "C2": float(c2), "C3": float(c3),
               "C4": float((k >= 3 and rarest <= 2) or c2),
               "dense_r1": None, "dense_hit": None, "hit_words": hit_words[:6]}
        d = Dm @ Qm[qpos[c["qid"]]]
        dranked = [list(z["ids"])[i].lower() for i in np.argsort(-d)]
        rec["dense_hit"] = float(dranked[0] in gold)
        rec["dense_r1"] = round(g.metrics(dranked, gold)["recall@1"], 4)
        rows.append(rec)
    print(f"{len(rows)} questions in {time.time()-t0:.0f}s", flush=True)

    mean = lambda k: round(float(np.mean([r[k] for r in rows])), 4)  # noqa: E731
    certs = {}
    for name in ("C1", "C2", "C3", "C4"):
        sel = [r for r in rows if r[name] > 0]
        cov = len(sel) / len(rows)
        prec = float(np.mean([r["correct"] for r in sel])) if sel else None
        certs[name] = {"coverage": round(cov, 4),
                       "precision_top1": round(prec, 4) if prec is not None else None,
                       "false_pass": int(sum(1 for r in sel if r["correct"] == 0)),
                       "dense_precision_same_subset": round(
                           float(np.mean([r["dense_hit"] for r in sel])), 4) if sel else None,
                       "arm_r1_on_subset": round(float(np.mean([r["r1"] for r in sel])), 4) if sel else None,
                       "dense_r1_on_subset": round(float(np.mean([r["dense_r1"] for r in sel])), 4) if sel else None}
    # the pre-stated selection rule
    elig = [(n, c) for n, c in certs.items() if c["precision_top1"] and c["precision_top1"] >= 0.95]
    chosen = max(elig, key=lambda kv: kv[1]["coverage"])[0] if elig else None
    out = {"n": len(rows), "labels_used_by_ranker": 0,
           "ranker_no_labels": {"r1": mean("r1"), "r5": mean("r5"), "mrr": mean("mrr"),
                                "top1_hit": mean("correct")},
           "dense_reference": {"r1": mean("dense_r1"), "top1_hit": mean("dense_hit")},
           "certificates": certs, "chosen_by_pre_stated_rule": chosen,
           "value_hit_rate": round(float(np.mean([1 if r["hit_words"] else 0 for r in rows])), 4)}
    json.dump({**out, "rows": rows}, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps(out, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
