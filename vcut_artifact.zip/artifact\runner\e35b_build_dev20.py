"""E35b：Spider 官方口径评估集（test = dev 全 20 库 / 1034 问）。

为什么需要这一版
    `e35_cases.json` 用 166 库的 80/20 分库划出 33 个 test 库（1681 问），
    协议自洽但**不是文献口径**——其中 27 个 test 库来自 train 的 140 库，
    是我们自己划到 test 侧的。审稿人认的是 Spider 官方 dev。

    本脚本给出零争议口径：
        test  = dev.json   20 库 / 1034 问（Spider 官方 dev 全量）
        train = train_spider.json 140 库 / 7000 问

    已核验：dev 的 20 库与 train 的 140 库**交集为 0**，因此按库隔离天然成立，
    不存在同库泄漏，也不需要任何 80/20 划分——split 直接由数据集归属决定。

    相对旧协议（341 问 / 6 库）的收益：
        · 库数 6 → 20（3.3×）
        · 问数 341 → 1034（3.0×）
        · 单问粒度 0.2933 → 0.0967 pt
        · 编译集 693 → 7000 问（10×）
        · 口径与 Spider 论文/公开榜一致，可直接对外比较

产出
    06_结果/e35_dev20_cases.json
    D:/vldb2027_e11/e35_dev20_meta.json
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e11_data import canon_gold, parse_gold_tables  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
SQL = REPO / "04_数据" / "external" / "sql"
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
OUT = REPO / "06_结果" / "e35_dev20_cases.json"
META = WORK / "e35_dev20_meta.json"


def main() -> None:
    cache = json.load(open(CACHE, encoding="utf-8"))
    schema = cache["spider"]

    dev = json.load(open(SQL / "dev.json", encoding="utf-8"))
    train = json.load(open(SQL / "train_spider.json", encoding="utf-8"))

    dev_dbs = {c["db_id"] for c in dev}
    train_dbs = {c["db_id"] for c in train}
    overlap = dev_dbs & train_dbs
    assert not overlap, f"dev 与 train 库重叠，按库隔离不成立：{sorted(overlap)[:5]}"

    cases: list[dict] = []
    stats = {}

    for tag, rows, split in (("dev", dev, "test"), ("train_spider", train, "train")):
        kept = skipped_noschema = skipped_empty = 0
        for i, c in enumerate(rows):
            db = c["db_id"]
            if db not in schema:
                skipped_noschema += 1
                continue
            gt = canon_gold(schema[db]["tables"], parse_gold_tables(c["query"]))
            if not gt:
                skipped_empty += 1
                continue
            cases.append({
                "qid": f"dv{i}" if tag == "dev" else f"ts{i}",
                "db_id": db, "question": c["question"],
                "sql": c["query"], "gold": gt, "split": split, "src": tag,
            })
            kept += 1
        stats[tag] = {"raw": len(rows), "kept": kept,
                      "no_schema": skipped_noschema, "gold_empty": skipped_empty}

    tr = [c for c in cases if c["split"] == "train"]
    te = [c for c in cases if c["split"] == "test"]

    qids = [c["qid"] for c in cases]
    assert len(qids) == len(set(qids)), "qid 冲突"
    assert not ({c["db_id"] for c in tr} & {c["db_id"] for c in te}), "库泄漏"

    meta = {
        "protocol": "Spider 官方 dev 全量 / train_spider 全量，库不相交",
        "per_source": stats,
        "n_cases": len(cases),
        "n_train": len(tr), "n_train_db": len({c["db_id"] for c in tr}),
        "n_test": len(te), "n_test_db": len({c["db_id"] for c in te}),
        "granularity_pt": 100.0 / max(len(te), 1),
        "db_overlap": 0,
    }

    old = json.load(open(REPO / "06_结果" / "e11_cases.json", encoding="utf-8"))
    out = {
        "bird": old["bird"],
        "spider": cases,
        "spider_train_dbs": sorted({c["db_id"] for c in tr}),
        "spider_test_dbs": sorted({c["db_id"] for c in te}),
        "spider_missing_dbs": [],
    }
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(meta, open(META, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    print(f"dev   {stats['dev']['kept']}/{stats['dev']['raw']} 问（gold 空 "
          f"{stats['dev']['gold_empty']}）")
    print(f"train {stats['train_spider']['kept']}/{stats['train_spider']['raw']} 问（gold 空 "
          f"{stats['train_spider']['gold_empty']}）")
    print(f"\ntest  {len(te)} 问 / {meta['n_test_db']} 库   ← 官方 dev 口径")
    print(f"train {len(tr)} 问 / {meta['n_train_db']} 库")
    print(f"单问粒度 {meta['granularity_pt']:.4f} pt（旧协议 0.2933 pt）")
    print(f"库交集 {len(overlap)}，按库隔离成立")
    print(f"\n→ {OUT}\n→ {META}")


if __name__ == "__main__":
    main()
