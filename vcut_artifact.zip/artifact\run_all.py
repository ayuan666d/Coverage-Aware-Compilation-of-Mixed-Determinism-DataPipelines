# -*- coding: utf-8 -*-
"""一键复现：E0 → 单测 → E1 → E2 → E3 → E4。

用法：
    python run_all.py            # 快速：E0 2k、E3 pilot
    python run_all.py --full     # 全量：E0 2×10k、E3 1500 条
    python run_all.py --with-real  # 追加 E1b（需要外部 permit-platform 源码）

所有子进程强制 UTF-8；避免 Windows GBK 控制台在打印 ✓/✗ 时崩掉。
E1b 依赖 D:/prod/permit-platform，默认跳过。
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "06_结果"


def run(cmd: list[str]) -> None:
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    print("\n$ " + " ".join(cmd), flush=True)
    p = subprocess.run(cmd, cwd=str(HERE), env=env)
    if p.returncode != 0:
        raise SystemExit(f"命令失败（退出码 {p.returncode}）：{' '.join(cmd)}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--full", action="store_true")
    ap.add_argument("--with-real", action="store_true",
                    help="追加 E1b，需要外部 permit-platform 源码")
    args = ap.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    py = sys.executable
    if args.full:
        run([py, "e0_selfcheck.py", "--n", "10000", "--seed", "0"])
        run([py, "e0_selfcheck.py", "--n", "10000", "--seed", "1"])
    else:
        run([py, "e0_selfcheck.py", "--n", "2000", "--seed", "0"])

    run([py, "-m", "unittest", "discover", "-s", "tests"])
    run([py, "runner/e1.py", "--out", str(OUT / "e1_summary.json")])
    if args.with_real:
        run([py, "runner/e1b_real_false_safety.py"])
    run([py, "runner/e2.py", "--mock", "--n", "500" if args.full else "200"])
    run([py, "runner/e3.py"] + (["--out", str(OUT / "e3_summary.json")] if args.full else ["--pilot", "--out", str(OUT / "e3_pilot.json")]))
    run([py, "runner/e4.py", "--out", str(OUT / "e4_summary.json")])
    print("\n全部完成，结果写入 " + str(OUT))
    return 0


if __name__ == "__main__":
    sys.exit(main())
