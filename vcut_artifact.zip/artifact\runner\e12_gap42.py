"""E12: decompose the matched-supervision gap — the questions the fine-tuned
0.6B retriever repairs over FORGE (gp_ex), by mechanism class.

Population: the 164 (dense-correct & E11-graph-wrong). Output per class:
gp_ex right/wrong, dense_ft right/wrong, and the gap set (ft right & gp_ex wrong).
"""
import json
import re
from collections import Counter
from pathlib import Path

REPO = Path("E:/vldb2027_pipeline_safety")
verd = json.load(open(REPO / "06_结果" / "e12_verdict.json", encoding="utf-8"))
classes = verd["classes"]
gp = json.load(open(REPO / "06_结果" / "e12_gp.json", encoding="utf-8"))
gpx = {r["qid"]: r for r in gp["rows"]["gp_ex"]}
ft = {r["qid"]: r for r in json.load(open(REPO / "06_结果" / "e12_ft.json", encoding="utf-8"))["rows"]}
e11m = {r["qid"]: r for r in json.load(open(REPO / "06_结果" / "e11_spider_merged.json", encoding="utf-8"))["rows"]}


def hit(top5, gold):
    gl = {g.lower() for g in gold}
    return bool(gl & {top5[0].lower()})


rows = []
for q, c in classes.items():
    gold = set(e11m[q]["gold"])
    rows.append({
        "qid": q, "class": c["class"],
        "gp_ex": hit(gpx[q]["top5"], gold),
        "dense_ft": hit(ft[q]["top5"], gold),
    })

tab = {}
for r in rows:
    c = r["class"]
    t = tab.setdefault(c, {"n": 0, "gp_only": 0, "both": 0, "ft_only": 0, "neither": 0})
    t["n"] += 1
    if r["gp_ex"] and r["dense_ft"]:
        t["both"] += 1
    elif r["gp_ex"]:
        t["gp_only"] += 1
    elif r["dense_ft"]:
        t["ft_only"] += 1
    else:
        t["neither"] += 1

gap = [r for r in rows if r["dense_ft"] and not r["gp_ex"]]
gapc = Counter(r["class"] for r in gap)
total = {"gap_total": len(gap), "gap_by_class": dict(gapc),
         "ft_residue": sum(1 for r in rows if not r["dense_ft"]),
         "gp_residue": sum(1 for r in rows if not r["gp_ex"])}
print(json.dumps({"per_class": tab, **total}, indent=1))
json.dump({"per_class": tab, **total, "gap_qids": [r["qid"] for r in gap]},
          open(REPO / "06_结果" / "e12_gap42.json", "w", encoding="utf-8"), indent=1)
print("wrote 06_结果/e12_gap42.json")
