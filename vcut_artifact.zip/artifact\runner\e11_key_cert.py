"""E11: turn path support into a witness the database computes itself.

A sample value only proves that a value appears somewhere in the schema excerpt.
Here every candidate is sent back to the real SQLite file: if a query token
selects exactly one row of a table, the database has computed an identifying
witness and the answer is accepted.  If it selects several rows, or several of
the proposed tables have such a witness, the query stays in review.

  propose : the ranker's top-1, no certificate
  top1    : accept top-1 only if one of its columns has a unique hit
  select  : accept when exactly one table among the top-5 has a unique hit

The existence check is ``LIMIT 2``, so it never scans more than two matching
rows: one row means unique, two means not.
"""
from __future__ import annotations

import json
import re
import sqlite3
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e11_data import toks  # noqa: E402
from e7j_label_synth import num as parse_num  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
SPIDER_DB = Path("D:/vldb2027_e11/spider/database")
BIRD_DB = REPO / "04_数据" / "external" / "bird" / "minidev" / "MINIDEV" / "dev_databases"
OUT = REPO / "06_结果" / "e11_key_cert.json"


def q(name):
    return '"' + str(name).replace('"', '""') + '"'


def value_forms(tok):
    out = [tok]
    if re.fullmatch(r"\d+", tok):
        out += [int(tok), float(tok)]
    return out


def is_unique(con, table, col, value):
    try:
        n = con.execute(
            f"select count(*) from (select 1 from {q(table)} where {q(col)} = ? limit 2)",
            (value,)).fetchone()[0]
    except Exception:
        return False
    return n == 1


def certified_tables(db_path, table_map, names, qtoks):
    """Tables among `names` that contain a query token selecting exactly one row."""
    out = {}
    try:
        con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except Exception:
        return out
    try:
        for nm in names:
            t = table_map.get(nm)
            if t is None:
                continue
            hits = []
            for c in t["columns"]:
                cname = c["name"]
                name_hit = bool(set(toks(cname)) & qtoks)
                samples = {str(v).strip().lower() for v in c.get("values", [])}
                val_hit = bool(qtoks & samples)
                if not (name_hit or val_hit):
                    continue
                for tok in qtoks:
                    for value in value_forms(tok):
                        if is_unique(con, nm, cname, value):
                            hits.append((cname, str(value)))
                            break
                    if hits:
                        break
                if len(hits) >= 1:
                    break
            if hits:
                out[nm] = hits
    finally:
        con.close()
    return out


def load_cases(kind):
    data = json.load(open(CASES, encoding="utf-8"))
    if kind == "bird":
        return data["bird"], BIRD_DB
    return [c for c in data["spider"] if c["split"] == "test"], SPIDER_DB


def run(kind, path, method):
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    d = json.load(open(path, encoding="utf-8"))
    cases = data["bird"] if kind == "bird" else [c for c in data["spider"] if c["split"] == "test"]
    tokmap = {c["qid"]: set(toks(c["question"])) for c in cases}
    root = BIRD_DB if kind == "bird" else SPIDER_DB
    stats = {"propose": [0, 0], "top1": [0, 0], "select": [0, 0]}
    t0 = time.time()
    n = 0
    for r in d["rows"]:
        db = r["db"]
        db_path = root / db / f"{db}.sqlite"
        if not db_path.exists():
            g = list(root.glob(f"*/{db}.sqlite"))
            if not g:
                continue
            db_path = g[0]
        key = "bird" if kind == "bird" else "spider"
        tables = cache[key][db]["tables"]
        tmap = {t["name"]: t for t in tables}
        v = r[method] if method in r else r
        names = [t.split("::")[-1] for t in v["top5"]]
        gold = {t.split("::")[-1] for t in r["gold"]}
        qtoks = tokmap.get(r["qid"], set())
        if not names:
            continue
        n += 1
        cert = certified_tables(db_path, tmap, names, qtoks)
        stats["propose"][0] += 1
        stats["propose"][1] += int(names[0] in gold)
        if names[0] in cert:
            stats["top1"][0] += 1
            stats["top1"][1] += int(names[0] in gold)
        if len(cert) == 1:
            chosen = next(iter(cert))
            stats["select"][0] += 1
            stats["select"][1] += int(chosen in gold)
    res = {}
    for k, (a, ok) in stats.items():
        res[k] = {"coverage": round(a / n, 4), "precision": round(ok / a, 4) if a else None,
                 "false_pass_rate": round((a - ok) / n, 4), "n": n}
    print(kind, Path(path).name, method, json.dumps(res, ensure_ascii=False),
          f"{time.time() - t0:.1f}s", flush=True)
    return res


def main():
    R = REPO / "06_结果"
    out = {}
    out["bird_graph"] = run("bird", R / "e11_bird.json", "ppr_band")
    out["bird_dense"] = run("bird", Path("D:/vldb2027_e11/e11_dense_bird.json"), "dense")
    out["spider_graph"] = run("spider_known", R / "e11_spider_known.json", "ppr_band")
    out["spider_dense"] = run("spider_known", R / "e11_spider_known_dense.json", "dense")
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
