"""E7u: two-way verification between a local 4B reader and the cloud model.

The local model is asked one narrow question (final total only), not the full
schema.  The script records where the two models agree and what that agreement
is worth against gold, plus the cost of routing only disagreements to the cloud.
"""
from __future__ import annotations

import json
import re
import sys
import time
import urllib.request
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e7_receipts import amount_match, gold_of, num, tokens_text  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
DATA = REPO / "04_数据" / "external" / "cord" / "train.parquet"
CLOUD = REPO / "06_结果" / "e7_receipts.json"
OUT = REPO / "06_结果" / "e7u_two_way.json"
HOST = "http://127.0.0.1:11434/api/chat"
SYS = ("Read the OCR tokens of a receipt. Return JSON {\"total\": integer|null} "
       "where total is the final amount due. Remove thousand separators. "
       "Use null if absent. Do not explain.")
AMT = re.compile(r'"total"\s*:\s*"?(-?[0-9][0-9.,]*)')


def ask(text, timeout=120):
    body = json.dumps({
        "model": "qwen3:4b",
        "messages": [{"role": "system", "content": SYS}, {"role": "user", "content": text}],
        "stream": False, "think": False, "format": "json",
        "options": {"temperature": 0, "num_predict": 200, "num_ctx": 8192},
    }).encode()
    req = urllib.request.Request(HOST, data=body, headers={"Content-Type": "application/json"},
                                 method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        d = json.loads(r.read())
    s = (d.get("message") or {}).get("content", "")
    try:
        v = json.loads(s).get("total")
        return num(v), "json"
    except Exception:
        m = AMT.search(s)
        return (num(m.group(1)) if m else None), "regex"


def main():
    df = pd.read_parquet(DATA)
    cloud = {r["file"]: r for r in json.load(open(CLOUD, encoding="utf-8"))["rows"]}
    rows = []
    t0 = time.perf_counter()
    for i, (_, r) in enumerate(df.iterrows()):
        text = tokens_text(r["ocr_text"])
        gold = gold_of(r["ocr_kie"])["total"]
        local = err = None
        try:
            local, how = ask(text)
        except Exception as e:  # noqa: BLE001
            err = f"{type(e).__name__}: {e}"
        c = cloud.get(r["file_name"], {})
        rows.append({
            "file": r["file_name"], "gold": gold,
            "local": local, "how": how if not err else None, "error": err,
            "cloud": (c.get("model") or {}).get("total"),
            "local_ok": amount_match(local, gold),
            "cloud_ok": amount_match((c.get("model") or {}).get("total"), gold),
            "agree": amount_match(local, (c.get("model") or {}).get("total")),
        })
        if (i + 1) % 100 == 0:
            print(f"{i+1}/{len(df)} {time.perf_counter()-t0:.0f}s", flush=True)

    n = len(rows)

    def m(pred, name):
        acc = [r for r in rows if pred(r)]
        known = [r for r in acc if r["local_ok"] is not None]
        # judge agreement against gold using local_ok (cloud and local equal here)
        fp = sum(1 for r in known if r["local_ok"] is False)
        return {"name": name, "accept": len(acc), "automation": round(len(acc) / n, 4),
                "false_pass": fp, "false_pass_rate": round(fp / n, 4),
                "precision": round((len(known) - fp) / len(known), 4) if known else None}

    summary = {
        "n": n,
        "local_returned": sum(1 for r in rows if r["local"] is not None),
        "local_accuracy_all": round(sum(1 for r in rows if r["local_ok"]) / n, 4),
        "local_accuracy_returned": round(
            sum(1 for r in rows if r["local_ok"]) /
            max(1, sum(1 for r in rows if r["local"] is not None)), 4),
        "cloud_returned": sum(1 for r in rows if r["cloud"] is not None),
        "agreement": m(lambda r: r["agree"] is True, "local == cloud"),
        "local_only": m(lambda r: r["local"] is not None, "local only"),
        "disagree_or_missing": sum(1 for r in rows if r["agree"] is not True),
        "errors": sum(1 for r in rows if r["error"]),
        "seconds": round(time.perf_counter() - t0, 1),
    }
    json.dump({"summary": summary, "rows": rows}, open(OUT, "w", encoding="utf-8"),
              ensure_ascii=False)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
