"""E11 cost accounting: build time, query latency and incremental update.

The essay this experiment answers claims the operators over the database are
"free".  They are not: the graph has to be built, normalised and refreshed.
BM25 is measured with precomputed collection statistics, which is the honest
comparison for a search engine.
"""
from __future__ import annotations

import json
import math
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
OUT = REPO / "06_结果" / "e11_cost.json"


class BM25Index:
    def __init__(self, cat):
        self.docs = [g.table_doc(t) for t in cat.tables]
        self.tf = [Counter(d) for d in self.docs]
        self.df = Counter()
        for d in self.docs:
            self.df.update(set(d))
        self.N = len(self.docs)
        self.avgdl = sum(len(d) for d in self.docs) / max(1, self.N)
        self.idf = {t: math.log(1 + (self.N - n + 0.5) / (n + 0.5)) for t, n in self.df.items()}

    def scores(self, query, k1=1.2, b=0.75):
        qs = set(query)
        out = np.zeros(self.N, dtype=np.float32)
        for i, tf in enumerate(self.tf):
            dl = len(self.docs[i])
            s = 0.0
            for q in qs:
                f = tf.get(q, 0)
                if not f:
                    continue
                s += self.idf[q] * f * (k1 + 1) / (f + k1 * (1 - b + b * dl / self.avgdl))
            out[i] = s
        return out


def build(cat_tables, fks, coq):
    return g.Catalog(cat_tables, fks, coquery=coq, prefix_db=True)


def timed(fn, reps=1):
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        r = fn()
        ts.append(time.perf_counter() - t0)
    return min(ts), sum(ts) / len(ts), r


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    npz = np.load(EMB, allow_pickle=True)
    Q = {str(q): v for q, v in zip([str(x) for x in npz["qids"]], npz["Q"].astype(np.float32))}
    D = npz["D"].astype(np.float32)

    tables, fks = [], []
    for db, s in cache["spider"].items():
        tables += [dict(t, db=db) for t in s["tables"]]
        have = {t["name"] for t in s["tables"]}
        fks += [[f"{db}::{a}", ca, f"{db}::{b}", cb] for a, ca, b, cb in s["fks"]
                if a in have and b in have]
    coq = Counter()
    for c in data["spider"]:
        if c["split"] != "train":
            continue
        for a in c["gold"]:
            for b in c["gold"]:
                if a != b:
                    coq[(f"{c['db_id']}::{a}", f"{c['db_id']}::{b}")] += 1
    coq = Counter({k: math.log(1 + v) for k, v in coq.items()})

    queries = [toks(c["question"]) for c in test]

    def measure(cat, Dl, label, extra_tables_note=""):
        qmin, qmean, bm = timed(lambda: BM25Index(cat))
        pmin, pmean, _ = timed(lambda: g.single_ppr(cat, queries[0]))
        tmin, tmean, _ = timed(lambda: g.fuse(cat, queries[0]))
        lat = {"bm25": [], "ppr": [], "typed": [], "dense": []}
        for q in queries[:120]:
            t0 = time.perf_counter(); bm.scores(q); lat["bm25"].append(time.perf_counter() - t0)
            t0 = time.perf_counter(); g.single_ppr(cat, q); lat["ppr"].append(time.perf_counter() - t0)
            t0 = time.perf_counter(); g.fuse(cat, q); lat["typed"].append(time.perf_counter() - t0)
            if Dl is not None and len(Dl) == len(cat.tables):
                qv = np.zeros(Dl.shape[1], dtype=np.float32)
                t0 = time.perf_counter(); Dl @ qv; lat["dense"].append(time.perf_counter() - t0)
        bmin, bmean, _ = timed(lambda: build(tables, fks, coq), reps=1) if label == "real" else (None, None, None)
        # incremental: append one new sample value per 1% of columns and rebuild
        changed = max(1, len(cat.tables) // 100)
        t0 = time.perf_counter()
        upd = [dict(t, columns=list(t["columns"]) + [{"name": f"newcol{i}", "type": "TEXT",
                                                     "values": ["x"] * 3}])
               for i, t in enumerate(tables[:changed])]
        build(upd + tables[changed:], fks, coq)
        updat = time.perf_counter() - t0
        r = {"label": label, "n_tables": len(cat.tables), "n_nodes": len(cat.idx),
             "build_s": bmean, "bm25_index_s": qmean,
             "query_p50_ms": {k: round(1000 * float(np.percentile(v, 50)), 2) for k, v in lat.items() if v},
             "query_p95_ms": {k: round(1000 * float(np.percentile(v, 95)), 2) for k, v in lat.items() if v},
             "update_1pct_s": round(updat, 2)}
        print(label, r["n_tables"], r["query_p95_ms"], flush=True)
        return r

    cat_real = build(tables, fks, coq)
    res = [measure(cat_real, D, "real")]

    # synthetic scale-up by duplicating tables with distinct names
    for N in (2000, 5000):
        big, bigfk = [], []
        k = math.ceil(N / len(tables))
        for rep in range(k):
            for t in tables:
                tt = dict(t)
                tt["name"] = f"{t['name']}_r{rep}"
                big.append(tt)
        big = big[:N]
        seen = {f"{t['db']}::{t['name']}" for t in big}
        bigfk = [x for x in fks if x[0] in seen and x[2] in seen]
        cat = build(big, bigfk, Counter())
        res.append(measure(cat, None, f"scaled_{len(cat.tables)}"))

    json.dump({"runs": res}, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
