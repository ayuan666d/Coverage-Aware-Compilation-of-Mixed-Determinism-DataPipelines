# -*- coding: utf-8 -*-
"""A8: guard ladder on the full 800-receipt cache (no API).

Rungs:
  P0 passthrough            accept any non-null total
  P1 schema guard           presence/positivity/order/grounding, no arithmetic
  P2 closure                E7 arithmetic judge (accept/fill)
  P3 closure + layout agree (v2 reader)

This is the "what does each layer buy" table: each rung adds one kind of check.
"""
from __future__ import annotations

import importlib.util
import json
import re
import sys
from pathlib import Path

RUN = Path(r"E:\vldb2027_pipeline_safety\05_代码\runner")
sys.path.insert(0, str(RUN))


def load(name, fname):
    spec = importlib.util.spec_from_file_location(name, str(RUN / fname))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


e7 = load("e7", "e7_receipts.py")
e7k = load("e7k", "e7k_independent_witness.py")

RAW = Path(r"E:\vldb2027_pipeline_safety\06_结果\e7_receipts.json")
LAY = Path(r"E:\vldb2027_pipeline_safety\06_结果\a5_layout_v2.json")
OUT = Path(r"E:\vldb2027_pipeline_safety\06_结果\a8_ladder.json")


def schema_ok(m, text):
    T, S = m.get("total"), m.get("subtotal")
    if T is None or S is None or T <= 0 or S < 0:
        return False
    if T < S or T > 3 * S:
        return False
    for k in ("tax", "service", "discount"):
        v = m.get(k)
        if v is not None and v < 0:
            return False
    items = m.get("items") or []
    if any(x is None or x <= 0 for x in items):
        return False
    toks = set(re.findall(r"[0-9][0-9.,]*", text))
    nums = set()
    for t in toks:
        v = e7k.num(t)
        if v is not None:
            nums.add(v)
    for v in [T, S, m.get("tax"), m.get("service"), m.get("discount")] + list(items):
        if v is not None and v not in nums:
            return False
    return True


def main():
    raw = json.loads(RAW.read_text(encoding="utf-8"))["rows"]
    lay = {r["file"]: r["total"] for r in
           json.loads(LAY.read_text(encoding="utf-8"))["rows"]}
    rows = []
    for r in raw:
        m = r.get("model") or {}
        g = (r.get("gold") or {}).get("total")
        if g is None:
            continue
        j = e7.judge(m, {"total": g, "subtotal": None}, r["text"])
        T = m.get("total")
        B = lay.get(r["file"])
        rows.append({
            "file": r["file"], "gold": g, "total": T,
            "correct": j["total_correct"],
            "p0": T is not None,
            "p1": schema_ok(m, r["text"]),
            "p2": j["verdict"] in ("accept", "fill"),
            "p3": j["verdict"] in ("accept", "fill") and T is not None
                  and B is not None and e7k.match(T, B) is True,
        })
    n = len(rows)
    out = {"n": n}
    for p in ("p0", "p1", "p2", "p3"):
        acc = [r for r in rows if r[p]]
        fp = sum(1 for r in acc if r["correct"] is False)
        out[p] = {"accept": len(acc), "automation": round(len(acc) / n, 4),
                  "false_pass": fp, "false_pass_rate": round(fp / n, 4),
                  "precision": round((len(acc) - fp) / len(acc), 4) if acc else None}
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
