"""E30：规模退化的归因诊断——候选池大小是不是瓶颈。

e11_zerolabel / e28 的零标签排序器是"BM25 top-30 + 池内图重排"。
本实验在 4k / 10k 合成目录上拆开两件事：
1) BM25 top-K 的池覆盖率（K=20..1000）：金标到底还在不在池里；
2) 把池 K 放大后重排的 R@1/R@5：图重排还能不能把金标拉回前 5。

若放大 K 能找回大部分读数，退化就是"池常数 30 不适配大目录"，不是打分器失效。
"""
from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
import e28_scale as s28  # noqa: E402

WORK = Path(r"D:\vldb2027_e11")
CASES = Path(r"E:\vldb2027_pipeline_safety\06_结果\e11_cases.json")
OUT = WORK / "e30_pool_diag.json"
EPS = 1e-9
KS = (20, 30, 50, 100, 200, 500, 1000)


def pooled(S, qs, gold, ids, k):
    order = np.argsort(-S)[:k]
    top = [ids[i].lower() for i in order]
    return (len(set(top[:1]) & gold) / len(gold),
            len(set(top[:5]) & gold) / len(gold))


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(WORK / "schema_cache.json", encoding="utf-8"))
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    test = [c for c in cases if c["split"] == "test"]
    test_dbs = {c["db_id"] for c in test}

    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += s28.tables_of(cache, db, prefix=True)
        fks += s28.fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    bird = []
    for db, s in cache["bird"].items():
        bird += [dict(t, db=db) for t in s["tables"]]
    donors = [t for t in tabs if t["db"] not in test_dbs] + bird

    targets = [int(x) for x in sys.argv[1].split(",")] if len(sys.argv) > 1 else [4000, 10000]
    res = json.load(open(OUT, encoding="utf-8")) if OUT.exists() else {}

    for n_target in targets:
        base = tabs + bird
        extra = s28.synth_tables(donors, n_target - len(base))
        all_tabs = base + extra
        cat = g.Catalog(all_tabs, fks, coquery=None, prefix_db=True)
        N = len(cat.tables)
        qsets = [set(g.toks(c["question"])) for c in test]
        toks = sorted({w for qs in qsets for w in qs if ("token", w) in cat.idx})
        tok = {}
        for w in toks:
            x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
            s = cat.table_scores(x)
            mx = float(s.max())
            tok[w] = s / mx if mx > 0 else s
        idf = {w: math.log(1 + (N - cat.token_df.get(w, 0) + 0.5) /
                           (cat.token_df.get(w, 0) + 0.5)) for w in tok}

        rows = {f"bm25@{k}": [] for k in KS}
        rows.update({f"fuse@{k}": [] for k in KS})
        t0 = time.perf_counter()
        for c, qs in zip(test, qsets):
            gold = {f"{c['db_id']}::{t}".lower() for t in c["gold"]}
            b = g.bm25(cat, qs)
            b_order = np.argsort(-b)
            b_rank = [cat.table_ids[i].lower() for i in b_order]
            ws = [w for w in qs if w in tok]
            if ws:
                M = np.stack([tok[w] for w in ws])
                iw = np.array([idf[w] for w in ws])[:, None]
                graph = np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
            else:
                graph = np.zeros(N, dtype=np.float32)
            for k in KS:
                top = b_order[:k]
                mixed = b.copy()
                basev = float(b[top[-1]])
                for j, idx in enumerate(top[np.argsort(-graph[top])]):
                    mixed[idx] = basev + (k - j) * 1e-6
                fused = [cat.table_ids[i].lower() for i in np.argsort(-mixed)]
                rows[f"bm25@{k}"].append(pooled(b, qs, gold, cat.table_ids, k))
                rows[f"fuse@{k}"].append((len(set(fused[:1]) & gold) / len(gold),
                                          len(set(fused[:5]) & gold) / len(gold)))
        # 逐问聚合
        agg = {}
        for name, vals in rows.items():
            agg[name] = {"R1": float(np.mean([v[0] for v in vals])),
                         "R5": float(np.mean([v[1] for v in vals]))}
        res[str(n_target)] = {"N": N, "agg": agg,
                              "query_s": (time.perf_counter() - t0) / len(test)}
        print(f"N={N} | " + " ".join(
            f"{k}: bm25 R5={agg[f'bm25@{k}']['R5']*100:5.2f} "
            f"fuse R1={agg[f'fuse@{k}']['R1']*100:5.2f}/{agg[f'fuse@{k}']['R5']*100:5.2f}"
            for k in KS), flush=True)
        json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        del cat


if __name__ == "__main__":
    main()
