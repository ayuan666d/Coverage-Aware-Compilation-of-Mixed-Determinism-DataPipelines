"""E7j: synthesize the OCR label vocabulary from historical receipts.

Candidate labels are all text tokens that occur in OCR.  On the training half,
a label is admitted if, when we take the amounts printed within five tokens of
it, at least 90% of the receipts it fires on yield a value matching the gold
total, with at least eight such receipts.  The frozen vocabulary is then used as
an independent witness on the test half.  This removes the hand-picked label
list from E7f.
"""
from __future__ import annotations

import json
import random
import re
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e7_receipts as e7  # noqa: E402

REPO = e7.REPO
RAW = REPO / "06_结果" / "e7_receipts.json"
HAND = REPO / "06_结果" / "e7f_ocr_total.json"
OUT = REPO / "06_结果" / "e7j_label_synth.json"

HAND_LABELS = {"total", "grand total", "netto", "due", "tl", "paid", "payment",
               "debit", "amount due", "total due"}


def num(s):
    if s is None:
        return None
    s = str(s).strip().replace(" ", "")
    s = re.sub(r"[^0-9,.\-]", "", s)
    if not s or s in "-":
        return None
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        p = s.split(",")
        s = "".join(p) if len(p) > 1 and all(len(x) == 3 for x in p[1:]) else s.replace(",", ".")
    elif "." in s:
        p = s.split(".")
        if len(p) > 1 and all(len(x) == 3 for x in p[1:]):
            s = "".join(p)
    try:
        return int(round(float(s)))
    except Exception:
        return None


def match(a, b):
    if a is None or b is None:
        return None
    for scale, frac in ((1, 0.005), (1000, 0.05)):
        target = b * scale
        if abs(a - target) <= max(2, frac * abs(target)):
            return True
    return False


def labels_of(text):
    toks = [t.strip() for t in text.split("|")]
    out = defaultdict(list)
    for i, t in enumerate(toks):
        lab = re.sub(r"[^a-z ]", "", t.lower()).strip()
        if not lab or len(lab) < 2 or len(lab) > 20:
            continue
        for j in range(max(0, i - 5), min(len(toks), i + 6)):
            if j == i:
                continue
            v = num(toks[j])
            if v is not None and v >= 100:
                out[lab].append(v)
    return out


def choose_rule(r, labels, cache):
    vals = []
    for lab, vs in cache[r["file"]].items():
        if lab in labels:
            vals.extend(vs)
    return Counter(vals).most_common(1)[0][0] if vals else None


def metrics(test, base, labels, cache):
    acc = fp = known = 0
    for r in test:
        b, c = base[r["file"]]
        rt = choose_rule(r, labels, cache)
        agree = match(rt, r["model"].get("total")) is True
        if b or agree:
            acc += 1
            if c is not None:
                known += 1
                if c is False:
                    fp += 1
    return {
        "n": len(test), "accept": acc,
        "automation": round(acc / len(test), 4),
        "false_pass": fp,
        "false_pass_rate": round(fp / len(test), 4),
        "precision": round((known - fp) / known, 4) if known else None,
    }


def main():
    rows = list(json.load(open(RAW, encoding="utf-8"))["rows"])
    hand = {r["file"]: r for r in json.load(open(HAND, encoding="utf-8"))["rows"]}
    cache = {r["file"]: labels_of(r["text"]) for r in rows}
    base = {}
    for r in rows:
        j = e7.judge(r["model"], r["gold"], r["text"])
        base[r["file"]] = (bool(j["checks"].get("components_close") and j["checks"].get("total_grounded")), j["total_correct"])

    runs = []
    for seed in range(10):
        rnd = random.Random(seed)
        idx = list(range(len(rows)))
        rnd.shuffle(idx)
        cut = len(idx) // 2
        train = [rows[i] for i in idx[:cut]]
        test = [rows[i] for i in idx[cut:]]
        stat = defaultdict(lambda: [0, 0])
        for r in train:
            for lab, vals in cache[r["file"]].items():
                stat[lab][0] += 1
                if any(match(v, r["gold"]["total"]) for v in vals):
                    stat[lab][1] += 1
        labels = {lab for lab, (n, m) in stat.items() if n >= 8 and m / n >= 0.9}
        syn = metrics(test, base, labels, cache)
        hand_m = metrics(test, base, HAND_LABELS, cache)
        runs.append({"seed": seed, "labels": sorted(labels), "synth": syn, "hand": hand_m})
        print(seed, len(labels), syn, hand_m)

    def agg(key, field):
        return {
            "mean": round(statistics.mean(r[key][field] for r in runs), 4),
            "min": round(min(r[key][field] for r in runs), 4),
            "max": round(max(r[key][field] for r in runs), 4),
        }
    summary = {
        "seeds": 10,
        "synth_automation": agg("synth", "automation"),
        "synth_false_pass": agg("synth", "false_pass"),
        "synth_precision": agg("synth", "precision"),
        "hand_automation": agg("hand", "automation"),
        "hand_false_pass": agg("hand", "false_pass"),
        "hand_precision": agg("hand", "precision"),
        "runs": runs,
    }
    json.dump(summary, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in summary.items() if k != "runs"}, ensure_ascii=False, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
