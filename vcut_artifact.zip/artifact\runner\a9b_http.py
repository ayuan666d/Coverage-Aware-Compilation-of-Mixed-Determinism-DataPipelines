# -*- coding: utf-8 -*-
"""A9b: keep-alive HTTP sink benchmark (fixes the HTTP/1.0 port exhaustion)."""
import http.client
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VALUES = ("normal", "normal2", "normal3", "malformed")
ACCEPTS = ("normal", "normal2", "normal3")
OUT = r"E:\vldb2027_pipeline_safety\06_结果\a9_real_io.json"


class Echo(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    count = 0
    lock = threading.Lock()

    def do_POST(self):  # noqa: N802
        n = int(self.headers.get("Content-Length", "0"))
        self.rfile.read(n)
        with Echo.lock:
            Echo.count += 1
        self.send_response(200)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, *a):
        pass


def main():
    srv = ThreadingHTTPServer(("127.0.0.1", 18081), Echo)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    n, threads = 30_000, 4
    lat_all = [[] for _ in range(threads)]
    execu = [0] * threads
    t0 = time.perf_counter()

    def worker(k):
        conn = http.client.HTTPConnection("127.0.0.1", 18081, timeout=10)
        for i in range(k, n, threads):
            s = time.perf_counter_ns()
            v = VALUES[i % 4]
            if v in ACCEPTS:
                conn.request("POST", "/act", body=b"x", headers={"Content-Length": "1"})
                conn.getresponse().read()
                execu[k] += 1
            lat_all[k].append(time.perf_counter_ns() - s)
        conn.close()

    ts = [threading.Thread(target=worker, args=(k,)) for k in range(threads)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    wall = time.perf_counter() - t0
    lat = sorted(x for sub in lat_all for x in sub)
    q = lambda p: lat[min(len(lat) - 1, int(len(lat) * p))] / 1000.0
    res = {"n": n, "wall_s": round(wall, 3),
           "us_per_decision": round(sum(lat) / len(lat) / 1000.0, 2),
           "p50_us": round(q(.50), 2), "p95_us": round(q(.95), 2), "p99_us": round(q(.99), 2),
           "decisions_per_s": int(n / wall),
           "executed": sum(execu), "server_count": Echo.count}
    srv.shutdown()
    d = json.load(open(OUT, encoding="utf-8"))
    d["modes"]["http_30k_4t"] = res
    json.dump(d, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(res, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
