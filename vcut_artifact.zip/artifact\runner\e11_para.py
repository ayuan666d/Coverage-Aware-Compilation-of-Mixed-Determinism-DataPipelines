"""E11 paraphrase set: three rewrites per Spider test question.

The rewrite must preserve the answerable meaning and must not mention table or
column names (otherwise lexical retrieval gets a free schema hint).  Leaked
rewrites are dropped and counted; the original question is kept as the
reference.
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CASES = REPO / "06_结果" / "e11_cases.json"
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
WORK = Path("D:/vldb2027_e11")
OUT = REPO / "06_结果" / "e11_paraphrase.json"
KEY = os.environ.get("DEEPSEEK_API_KEY", "")
URL = "https://api.deepseek.com/chat/completions"

PROMPT = """Rewrite each database question in three ways:
1. "synonym": replace content words with synonyms, keep the structure.
2. "colloquial": how a non-technical person would ask it.
3. "expert": how a data analyst would ask it, with precise but different wording.
Rules:
- Preserve the exact meaning and all constraints (numbers, dates, comparisons).
- Never use the words in each item's "avoid" list; paraphrase around them.
- Do not add or remove conditions.
Return JSON: {"items":[{"id":"...","synonym":"...","colloquial":"...","expert":"..."}]}.
Questions:
"""


def call(batch):
    body = {"model": "deepseek-chat",
            "messages": [{"role": "user", "content": PROMPT + json.dumps(batch, ensure_ascii=False)}],
            "temperature": 0.7, "max_tokens": 1800,
            "response_format": {"type": "json_object"}}
    for attempt in range(3):
        try:
            r = requests.post(URL, headers={"Authorization": f"Bearer {KEY}",
                                            "Content-Type": "application/json"},
                              json=body, timeout=90)
            if r.status_code == 200:
                txt = r.json()["choices"][0]["message"]["content"]
                return json.loads(txt).get("items", [])
            time.sleep(2 + attempt * 2)
        except Exception:
            time.sleep(2 + attempt * 2)
    return []


def banned_tokens(db_tabs, col_df):
    """Schema hints that a rewrite must not leak.

    Table names always; column-name tokens only when they are distinctive
    (rare across the catalog), because ordinary words like ``name`` or ``date``
    cannot be excluded from a natural paraphrase.
    """
    out = set()
    for t in db_tabs:
        out |= set(toks(t["name"]))
        for c in t["columns"]:
            for x in toks(c["name"]):
                if col_df.get(x, 99) <= 5:
                    out.add(x)
    return out


def main():
    if not KEY:
        raise SystemExit("DEEPSEEK_API_KEY not set")
    data = json.load(open(CASES, encoding="utf-8"))
    cache = json.load(open(CACHE, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    test = test[:300]
    gold_ban = {c["qid"]: sorted(set(t for g in c["gold"] for t in toks(g))) for c in test}
    raw_path = WORK / "para_raw2.json"
    if raw_path.exists():
        got = json.load(open(raw_path, encoding="utf-8"))
    else:
        batches = [test[i:i + 10] for i in range(0, len(test), 10)]
        payload = [[{"id": str(c["qid"]), "q": c["question"], "avoid": gold_ban[c["qid"]]}
                    for c in b] for b in batches]
        items = []
        with ThreadPoolExecutor(max_workers=6) as ex:
            for res in ex.map(call, payload):
                items += res
        got = {str(x.get("id")): x for x in items if x.get("id")}
        json.dump(got, open(raw_path, "w", encoding="utf-8"), ensure_ascii=False)
    col_df = Counter()
    for s in cache["spider"].values():
        for t in s["tables"]:
            for c in t["columns"]:
                col_df.update(set(toks(c["name"])))
    out = []
    dropped = 0
    for c in test:
        x = got.get(str(c["qid"]), {})
        banned = set(gold_ban[c["qid"]])
        rec = {"qid": c["qid"], "db": c["db_id"], "orig": c["question"],
               "gold": c["gold"]}
        ok = True
        for style in ("synonym", "colloquial", "expert"):
            s = (x.get(style) or "").strip()
            if not s:
                ok = False
                continue
            if set(toks(s)) & banned:
                ok = False
                continue
            rec[style] = s
        if not ok or any(s not in rec for s in ("synonym", "colloquial", "expert")):
            dropped += 1
            for style in ("synonym", "colloquial", "expert"):
                rec.setdefault(style, rec["orig"])
            rec["fallback"] = True
        out.append(rec)
    json.dump({"n": len(out), "dropped": dropped, "rows": out},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("n", len(out), "dropped", dropped, "wrote", OUT)


if __name__ == "__main__":
    main()
