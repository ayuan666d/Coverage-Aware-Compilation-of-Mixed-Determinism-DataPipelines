"""E11-SURPRISE: a certificate whose threshold the catalogue gives itself.

Everything before this (2.8, 2.11) accepted a query when support >= 3 and the rarest
anchor had df <= 2.  The first integer is a hand constant, the second was frozen on the
train labels -- and 2.12 showed that train half is contaminated by co-query edges built
from its own gold pairs.  So the certificate still carries two numbers the database did
not ask for.

Replace them with one quantity the catalogue computes for every query: how much support
does the table we are about to return have, compared with every other comparable table
in the same catalogue?  Score = number of query words occurring in the table document
(and the idf-weighted version).  The null is not simulated, it is the catalogue: every
table whose document length is within [0.75x, 1.33x] of the returned one (length
matching, because support grows with document size; if fewer than 20 comparable tables
exist the whole catalogue is the null and n_null is reported).  p = fraction of
comparable tables scoring >= the observed score, ties included, leave-one-out.

Pre-registered before the run: alpha = 0.05 for every rule in every setting, no
retuning; a rule "works" on the merged cold catalogue if precision >= 95% at coverage
>= 20%; the same rule then transfers unchanged to BIRD and known-DB.  The labelled rule
is additionally RE-frozen on the cold train half, because its original freezing ate the
leak.  No accept-decision in this script reads a label; labels only score the decision
afterwards.

Two nulls are computed and both are reported.  The first is table-side (support of the
returned table vs comparable-length tables in the same catalogue) and it FAILS, for a
reason worth naming: the answer was selected because it carries the most support, so it
beats its own catalogue almost always -- a selection-biased null certifies nothing
(coverage 81-99%, precision 69-78%).  The second is the one that can work: chance level
for the best of N tables, from the catalogue's own document frequencies alone
(Poisson-binomial support of one table, Sidak-corrected over the catalogue).
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_col import col_index, gm  # noqa: E402
from e11_run_spider import fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
E11 = Path("D:/vldb2027_e11")
OUT = REPO / "06_结果" / "e11_surprise.json"
EPS, ALPHA_PPR, ITERS, TOPK = 1e-6, 0.85, 20, 30
ALPHA = 0.05              # pre-registered, never tuned
K_FROZEN, M_FROZEN = 3, 2  # the hand rule being replaced
MIN_NULL = 20
ARMS = ("v0_table_gm", "c3_tokmaxpool_gm")


def build_cache(cat, cases, colnodes, prefix):
    """Per-token table/column diffusion + catalogue-side idf, for these questions."""
    N = len(cat.tables)
    tok_tab, tok_col, idf_of = {}, {}, {}
    for w in sorted({w for c in cases for w in toks(c["question"])}):
        k = ("token", w)
        if k not in cat.idx:
            continue
        x = g.ppr(cat.union, {cat.idx[k]: 1.0}, ALPHA_PPR, ITERS)
        st = cat.table_scores(x)
        mx = float(st.max())
        if mx <= 0:
            continue
        tok_tab[w] = (st / mx).astype(np.float32)
        idf_of[w] = math.log(1 + (N - cat.token_df.get(w, 0) + 0.5)
                             / (cat.token_df.get(w, 0) + 0.5))
        cv = np.asarray(x)[colnodes].astype(np.float32)
        cmx = float(cv.max())
        tok_col[w] = cv / cmx if cmx > 0 else cv
    return tok_tab, tok_col, idf_of


def run_arm(cat, cases, tok_tab, tok_col, idf_of, starts, prefix):
    """Two rerank keys over one BM25 recall stage, plus the empirical-null p-values."""
    N = len(cat.tables)
    docs = [g.table_doc(t) for t in cat.tables]
    dl = np.array([len(d) for d in docs], dtype=np.float32)
    inc = {}
    for i, d in enumerate(docs):
        for w in set(d):
            v = inc.get(w)
            if v is None:
                v = inc[w] = np.zeros(N, dtype=np.float32)
            v[i] = 1.0
    out = []
    for c in cases:
        q = toks(c["question"])
        gold = ({f"{c['db_id']}::{t}" for t in c["gold"]} if prefix else set(c["gold"]))
        ws = sorted({w for w in q if w in tok_tab})
        b = g.bm25(cat, q)
        top = np.argsort(-b)[:min(TOPK, N)]
        base = float(b[top[-1]])
        keys = {}
        if ws:
            iw = np.array([idf_of[w] for w in ws], dtype=np.float32)[:, None]
            keys["v0_table_gm"] = gm(np.stack([tok_tab[w] for w in ws]), iw)
            Tt = np.maximum.reduceat(np.stack([tok_col[w] for w in ws]), starts, axis=1)
            keys["c3_tokmaxpool_gm"] = gm(Tt, iw)
        else:
            keys = {k: np.zeros(N, dtype=np.float32) for k in ARMS}
        cs = np.zeros(N, dtype=np.float32)
        cw = np.zeros(N, dtype=np.float32)
        for w in set(q):
            v = inc.get(w)
            if v is None:
                continue
            cs += v
            cw += v * idf_of.get(w, 0.0)
        rarest = min([cat.token_df.get(w, 10 ** 9) for w in ws], default=10 ** 9)
        dfs_present = [cat.token_df.get(w, 0) for w in set(q) if w in inc]
        rec = {"qid": c["qid"], "db": c["db_id"], "n_tables": N,
               "split": c.get("_split", "test"), "m_q": int(rarest),
               "dfs": [int(d) for d in dfs_present]}
        for name, sc in keys.items():
            mixed = b.copy()
            for i, idx in enumerate(top[np.argsort(-sc[top])]):
                mixed[idx] = base + (len(top) - i) * 1e-6
            r = g.rank(mixed, cat)
            t1 = cat.table_pos[r[0]]
            mm = g.metrics(r, gold)
            srt = np.sort(cs)[::-1]
            is_peak = bool(cs[t1] == srt[0] and srt[0] > (srt[1] if srt.size > 1 else -1))
            L = dl[t1]
            mask = (dl >= 0.75 * L) & (dl <= 1.33 * L)
            mask[t1] = False
            thin = bool(int(mask.sum()) < MIN_NULL)
            if thin:
                mask = np.ones(N, dtype=bool)
                mask[t1] = False
            idx = np.where(mask)[0]
            p_c = (float(np.sum(cs[idx] >= cs[t1])) + 1.0) / (idx.size + 1.0)
            p_w = (float(np.sum(cw[idx] >= cw[t1])) + 1.0) / (idx.size + 1.0)
            rec[name] = {"r1": round(mm["recall@1"], 4), "r5": round(mm["recall@5"], 4),
                         "k": int(cs[t1]), "wk": round(float(cw[t1]), 3),
                         "p_count": round(p_c, 4), "p_w": round(p_w, 4),
                         "n_cmp": int(idx.size), "null_thin": thin, "peak": is_peak,
                         "top1": r[0], "correct": bool(r[0] in gold)}
        if c.get("dense"):
            rec["dense"] = c["dense"]
        out.append(rec)
    return out


def pb_pmf(ps):
    """Poisson-binomial pmf over the number of successes (DP, exact)."""
    pmf = np.array([1.0])
    for p in ps:
        pmf = np.convolve(pmf, [1.0 - p, p])
    return pmf


def chance_tail(dfs, N, s):
    """P(no table reaches support s by chance) under independent placement.

    Each query word w lands in a given table with probability df_w / N -- the
    catalogue's own document frequencies, nothing else.  The support of one table is
    then Poisson-binomial; the support of the BEST of N tables is corrected with a
    Sidak factor, which is exactly the question the certificate has to answer: not
    "is this much support unusual for a table" (the answer was chosen for having the
    most support, so it always is) but "is this much support more than some table in
    a catalogue this size gets by accident".
    """
    ps = [min(0.999, max(1e-9, d / N)) for d in dfs]
    pmf = pb_pmf(ps)
    tail = float(pmf[max(0, int(s) - 1):].sum()) if s > 0 else 1.0
    return tail, 1.0 - (1.0 - tail) ** N if tail < 1.0 else 1.0


def attach_null(rows, cat, cases, S=0):
    N = len(cat.tables)
    for r in rows:
        dfs = r["dfs"]
        tail, p_max = chance_tail(dfs, N, 1)
        for arm in ARMS:
            obs = int(r[arm]["k"])
            t, pm = chance_tail(dfs, N, obs)
            r[arm]["p_beyond_chance"] = round(pm, 6)
            r[arm]["p_raw_tail"] = round(t, 6)
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", choices=["merged", "bird", "known"], default="merged")
    ap.add_argument("--shuffles", type=int, default=200)
    args = ap.parse_args()
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    allc = json.load(open(CASES, encoding="utf-8"))
    t0 = time.time()

    emb = E11 / ("e11_emb_bird.npz" if args.kind == "bird" else "e11_emb_spider.npz")
    dl_ = None
    if emb.exists():
        z = np.load(emb, allow_pickle=True)
        dl_ = (list(z["ids"]), z["D"].astype(np.float32), z["Q"].astype(np.float32),
               {q: i for i, q in enumerate(list(z["qids"]))})

    def dense_for(c, within_db):
        if dl_ is None or c["qid"] not in dl_[3]:
            return None
        ids, Dm, Qm, qpos = dl_
        v = Qm[qpos[c["qid"]]]
        if within_db:
            cand = [i for i, t in enumerate(ids) if t.split("::")[0] == c["db_id"]]
            order = [ids[cand[i]].split("::", 1)[1] for i in np.argsort(-(Dm[cand] @ v))]
            gold = set(c["gold"])
        else:
            order = [ids[i] for i in np.argsort(-(Dm @ v))]
            gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
        return {"r1": round(sum(1 for t in order[:1] if t in gold) / max(1, len(gold)), 4),
                "r5": round(sum(1 for t in order[:5] if t in gold) / max(1, len(gold)), 4)}

    rows = []
    if args.kind == "merged":
        train = [c for c in allc["spider"] if c["split"] == "train"]
        test = [c for c in allc["spider"] if c["split"] == "test"]
        tabs, fks = [], []
        for db in cache["spider"]:
            tabs += tables_of(cache, db, prefix=True)
            fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
        cat = g.Catalog(tabs, fks, coquery=None, prefix_db=True)   # cold, on purpose
        colnodes, cdocs, starts, ends = col_index(cat)
        cases = train + test
        for c in cases:
            c["_split"] = "train" if c in train else "test"
            c["dense"] = dense_for(c, within_db=False)
        tok_tab, tok_col, idf_of = build_cache(cat, cases, colnodes, True)
        print(f"cold merged catalogue {len(cat.tables)} tables, {len(tok_tab)} tokens, "
              f"{len(cases)} questions", flush=True)
        rows = run_arm(cat, cases, tok_tab, tok_col, idf_of, starts, prefix=True)
        attach_null(rows, cat, cases, args.shuffles)
        print(f"max-statistic null done: {args.shuffles} shuffles, "
              f"{time.time()-t0:.0f}s", flush=True)
    else:
        cases_all = allc["bird"] if args.kind == "bird" else \
            [c for c in allc["spider"] if c["split"] == "test"]
        dbs = cache["bird"] if args.kind == "bird" else cache["spider"]
        for db, s in sorted(dbs.items()):
            cs = [c for c in cases_all if c["db_id"] == db]
            if not cs:
                continue
            tabs = [dict(t, db=db) for t in s["tables"]]
            cat = g.Catalog(tabs, s["fks"], prefix_db=False)
            colnodes, cdocs, starts, ends = col_index(cat)
            for c in cs:
                c["_split"] = "test"
                c["dense"] = dense_for(c, within_db=True)
            tok_tab, tok_col, idf_of = build_cache(cat, cs, colnodes, False)
            rr = run_arm(cat, cs, tok_tab, tok_col, idf_of, starts, prefix=False)
            for r in rr:
                r["n_tables"] = len(cat.tables)
            attach_null(rr, cat, cs, args.shuffles)
            rows.extend(rr)
            print(f"{db}: {len(rr)} q / {len(cat.tables)} tables "
                  f"({time.time()-t0:.0f}s)", flush=True)

    rules = {
        "frozen_k3_df2": lambda r, a: r[a]["k"] >= K_FROZEN and r["m_q"] <= M_FROZEN,
        "surprise_count": lambda r, a: r[a]["p_count"] <= ALPHA,
        "surprise_idf": lambda r, a: r[a]["p_w"] <= ALPHA,
        "surprise_either": lambda r, a: min(r[a]["p_count"], r[a]["p_w"]) <= ALPHA,
        "maxnull_count": lambda r, a: r[a]["p_beyond_chance"] <= ALPHA,
        "maxnull_raw": lambda r, a: r[a]["p_raw_tail"] <= ALPHA,
        "maxnull_count_peak": lambda r, a: r[a]["p_beyond_chance"] <= ALPHA and r[a]["peak"],
        "maxnull_and_frozen": lambda r, a: r[a]["p_beyond_chance"] <= ALPHA and (
            r[a]["k"] >= K_FROZEN and r["m_q"] <= M_FROZEN),
    }

    def read(sel, arm, subset):
        acc = [r for r in subset if sel(r, arm)]
        rej = [r for r in subset if not sel(r, arm)]
        if not acc:
            return {"arm": arm, "n": len(subset), "cov": 0.0, "precision": None}
        d = {"arm": arm, "n": len(subset), "cov": round(len(acc) / len(subset), 4),
             "precision": round(float(np.mean([r[arm]["correct"] for r in acc])), 4),
             "false_pass": sum(1 for r in acc if not r[arm]["correct"]),
             "acc_r5": round(float(np.mean([r[arm]["r5"] for r in acc])), 4),
             "acc_r1": round(float(np.mean([r[arm]["r1"] for r in acc])), 4),
             "null_thin_share": round(float(np.mean([r[arm]["null_thin"] for r in acc])), 4),
             "peak_share": round(float(np.mean([r[arm]["peak"] for r in acc])), 4)}
        if all(r.get("dense") for r in subset):
            d["hybrid_r5"] = round((sum(r[arm]["r5"] for r in acc)
                                    + sum(r["dense"]["r5"] for r in rej)) / len(subset), 4)
            d["hybrid_top1"] = round((sum(1 for r in acc if r[arm]["correct"])
                                      + sum(1 for r in rej if r["dense"]["r1"] > 0)) / len(subset), 4)
            d["dense_top1_all"] = round(float(np.mean([r["dense"]["r1"] > 0 for r in subset])), 4)
            d["dense_r5_all"] = round(float(np.mean([r["dense"]["r5"] for r in subset])), 4)
            d["arm_top1_all"] = round(float(np.mean([r[arm]["correct"] for r in subset])), 4)
        return d

    res = {}
    for arm in ARMS:
        for rn, sel in rules.items():
            res[f"{arm}|{rn}"] = read(sel, arm, rows)
    grid = {}
    if args.kind == "merged":
        tr = [r for r in rows if r["split"] == "train"]
        te = [r for r in rows if r["split"] == "test"]
        for arm in ARMS:
            for rn, sel in rules.items():
                res[f"{arm}|{rn}|test_only"] = read(sel, arm, te)
        for k in (1, 2, 3, 4):
            for m in (1, 2, 5, 10 ** 9):
                acc = [r for r in tr if r["c3_tokmaxpool_gm"]["k"] >= k and r["m_q"] <= m]
                if not acc:
                    continue
                grid[f"k{k}_m{m}"] = {"cov": round(len(acc) / len(tr), 4),
                                      "prec": round(float(np.mean(
                                          [r["c3_tokmaxpool_gm"]["correct"] for r in acc])), 4),
                                      "r5": round(float(np.mean(
                                          [r["c3_tokmaxpool_gm"]["r5"] for r in acc])), 4)}
        ok = {k: v for k, v in grid.items() if v["cov"] >= 0.35}
        chosen = max(ok, key=lambda k: ok[k]["r5"]) if ok else None
        kf = mf = None
        if chosen:
            kf, mf = int(chosen.split("_")[0][1:]), int(chosen.split("_")[1][1:])
        res["refrozen_on_cold_train"] = {
            "grid": grid, "chosen": chosen,
            "test_reading": read(lambda r, a: r[a]["k"] >= (kf or 0)
                                 and r["m_q"] <= (mf or 0), "c3_tokmaxpool_gm", te)
            if chosen else None}
    op = Path(str(OUT).replace(".json", f"_{args.kind}.json"))
    json.dump({"kind": args.kind, "n": len(rows), "alpha": ALPHA, "rules": res,
               "rows": rows}, open(op, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps(res, indent=1, ensure_ascii=False))
    print("wrote", op, f"in {time.time()-t0:.0f}s")


if __name__ == "__main__":
    main()
