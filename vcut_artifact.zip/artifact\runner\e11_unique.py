"""E11-UNIQUE: a certificate must name a UNIQUE witness, or it has certified nothing.

Corrected reading of 2.14.  Two mistakes are being undone here, both mine:

  (1) the cross-arm harness compared identifiers case-sensitively.  The schema stores
      VOTES, the other line's arms emit votes, so ~30% of their top-1 answers read as
      "table not in the catalogue" and their accuracies came out 15-20 points too low.
      Fixed in e11_surprise2.py; the numbers below are the corrected ones.
  (2) that run then looked like operator-boundedness ("1 false pass on six foreign arms").
      It is one question answered wrong by ten rankers: sp245, returned flight_4::airlines,
      gold flight_2::airlines.  Same query words written in both tables.

The first clone guard (identifiers + column names equal) does not fire: the two airline
tables have different column sets.  The right object is at the level of the evidence the
certificate itself uses: two tables carry the SAME set of query words, so that evidence
identifies no table, and a stamp on it attests "some table with these words" rather than
"this table".  That is the key property, computed from the data, at query time, no label:

  UNIQUEWITNESS = no other table in the catalogue has exactly the same subset of the
                  query's words inside its document.

Pre-registered: pooled false passes over the 11 arms must go 7 -> 0; every accepted answer
that the clause removes is reported (a clause that buys soundness by silencing the
certificate is not a contribution), and the correct/wrong split of the removed set is
reported so the cost is not hidden.
"""
from __future__ import annotations

import json
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
CASES = R / "e11_cases.json"
SURP2 = R / "e11_surprise2.json"
OUT = R / "e11_unique.json"
ALPHA = 0.05


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    tabs = []
    for db, s in cache["spider"].items():
        tabs += [dict(t, db=db) for t in s["tables"]]
    cat = g.Catalog(tabs, [], prefix_db=True)
    N = len(cat.tables)
    lowmap = {tid.lower(): i for i, tid in enumerate(cat.table_ids)}
    doctok = [set(g.table_doc(t)) for t in cat.tables]
    # bit masks over the whole catalogue vocabulary are unnecessary: per query, encode the
    # subset of ITS words that each table document contains, as a bitmask.
    t0 = time.time()
    per_q = {}
    for c in test:
        q = sorted(set(toks(c["question"])))
        if len(q) > 20:
            q = q[:20]
        idx = {w: i for i, w in enumerate(q)}
        codes = np.zeros(N, dtype=np.int64)
        for j, d in enumerate(doctok):
            m = 0
            for w in d:
                i = idx.get(w)
                if i is not None:
                    m |= (1 << i)
            codes[j] = m
        cnt = Counter(codes.tolist())
        pop = np.array([bin(int(c)).count("1") for c in codes], dtype=np.int32)
        maxp = int(pop.max())
        per_q[c["qid"]] = {"codes": codes, "cnt": cnt, "pop": pop, "maxp": maxp,
                           "n_at_max": int((pop == maxp).sum()), "nwords": len(q),
                           "gold": {f"{c['db_id']}::{t}".lower() for t in c["gold"]}}
    print(f"per-query support-set codes for {len(per_q)} questions in {time.time()-t0:.0f}s",
          flush=True)

    surp = json.load(open(SURP2, encoding="utf-8"))
    arms = defaultdict(list)
    for r in surp["rows"]:
        arms[r["arm"]].append(r)

    res = {}
    pooled = Counter()
    removed = Counter()
    for arm, rs in arms.items():
        d = {"n": len(rs), "cert": 0, "cert_fp": 0, "cert_unique": 0, "cert_unique_fp": 0,
             "nonunique_kept": 0, "nonunique_correct": 0,
             "v1": 0, "v1_fp": 0, "v1_drop_correct": 0, "v2": 0, "v2_fp": 0,
             "v2_drop_correct": 0, "v12": 0, "v12_fp": 0, "v12_drop_correct": 0}
        for r in rs:
            st = per_q.get(r["qid"])
            pos = lowmap.get(str(r["top1"]).lower())
            if st is None or pos is None:
                continue
            if r["p_beyond"] > ALPHA:
                continue
            d["cert"] += 1
            d["cert_fp"] += (not r["correct"])
            code = st["codes"][pos]
            uniq = st["cnt"][code] == 1
            if uniq:
                d["cert_unique"] += 1
                d["cert_unique_fp"] += (not r["correct"])
            else:
                d["nonunique_kept"] += 1
                d["nonunique_correct"] += bool(r["correct"])
            c0 = code
            other = np.delete(st["codes"], pos)
            opop = np.delete(st["pop"], pos)
            # V1 unique maximum: my word count equals the lake's best and nobody else has it
            v1 = (st["pop"][pos] == st["maxp"]) and (st["n_at_max"] == 1)
            # V2 superset-free: no other table carries every word my table carries
            v2 = not bool(np.any((other & c0) == c0))
            for tag, keep in (("v1", v1), ("v2", v2), ("v12", v1 and v2)):
                if keep:
                    d[tag] += 1
                    d[tag + "_fp"] += (not r["correct"])
                else:
                    d[tag + "_drop_correct"] += bool(r["correct"])
        pooled["cert"] += d["cert"]
        pooled["cert_fp"] += d["cert_fp"]
        pooled["cert_unique"] += d["cert_unique"]
        pooled["cert_unique_fp"] += d["cert_unique_fp"]
        pooled["nonunique"] += d["nonunique_kept"]
        pooled["nonunique_correct"] += d["nonunique_correct"]
        for tag in ("v1", "v2", "v12"):
            pooled[tag] += d[tag]
            pooled[tag + "_fp"] += d[tag + "_fp"]
            pooled[tag + "_drop_correct"] += d[tag + "_drop_correct"]
        d["precision_cert"] = round(1 - d["cert_fp"] / d["cert"], 4) if d["cert"] else None
        d["precision_unique"] = (round(1 - d["cert_unique_fp"] / d["cert_unique"], 4)
                                 if d["cert_unique"] else None)
        d["cov_cert"] = round(d["cert"] / d["n"], 4)
        d["cov_unique"] = round(d["cert_unique"] / d["n"], 4)
        res[arm] = d
    for tag in ("v1", "v2", "v12"):
        for a, d in res.items():
            d[tag + "_precision"] = (round(1 - d[tag + "_fp"] / d[tag], 4) if d[tag] else None)
            d[tag + "_cov"] = round(d[tag] / d["n"], 4)
    out = {"alpha": ALPHA, "arms": res, "pooled": dict(pooled),
           "verdict": ("UNIQUE-WITNESS clause: pooled false passes %d -> %d, accepted %d -> %d "
                       "(%d accepted answers removed, of which %d were CORRECT)" %
                       (pooled["cert_fp"], pooled["cert_unique_fp"], pooled["cert"],
                        pooled["cert_unique"], pooled["nonunique"], pooled["nonunique_correct"]))}
    how_many_share = Counter()
    for qid, st in per_q.items():
        for code, n in st["cnt"].items():
            if n > 1:
                how_many_share[n] += 1
    out["lake_duplication"] = {"queries": len(per_q),
                               "support_patterns_shared_by_k_tables": dict(how_many_share)}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(out["pooled"], ensure_ascii=False))
    print(out["verdict"])
    for a, d in res.items():
        print("%-12s cert %3d/%d fp | V1 %3d/%d fp p=%-6s cov=%.3f drop_ok=%3d | "
              "V2 %3d/%d fp p=%-6s cov=%.3f drop_ok=%3d | V1&V2 %3d/%d fp p=%-6s cov=%.3f "
              "drop_ok=%3d" % (a, d["cert"], d["cert_fp"],
                               d["v1"], d["v1_fp"], d["v1_precision"], d["v1_cov"], d["v1_drop_correct"],
                               d["v2"], d["v2_fp"], d["v2_precision"], d["v2_cov"], d["v2_drop_correct"],
                               d["v12"], d["v12_fp"], d["v12_precision"], d["v12_cov"],
                               d["v12_drop_correct"]))
    print("lake duplication", json.dumps(out["lake_duplication"], ensure_ascii=False)[:300])
    print("wrote", OUT)


if __name__ == "__main__":
    main()
