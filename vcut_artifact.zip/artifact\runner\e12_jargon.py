"""E12 addendum: the jargon-perturbation experiment (vocabulary privatization).

Thesis under test: the pretrained retriever's advantage is CONDITIONAL on the
database vocabulary being inside its corpus distribution. Rename the entire
catalog with a deterministic letter-shift cipher (airlines -> bjnmfoft; morpho-
logical consistency preserved: airline -> bjnmfoe shares the 4-char stem), keep
values unchanged, and measure degradation for BM25 / FORGE / dense 0.6B.

Two question modes:
  natural  — original questions (legacy-database scenario: schema speaks jargon,
             the analyst speaks English)
  jargon   — schema tokens inside the question are ciphered the same way (the
             private-company steady state: employees speak the jargon)

FORGE is re-compiled on the ciphered catalog (P0 rebuild + GA re-fit on its own
693 train questions — the true per-database pipeline); dense re-encodes the
ciphered documents on GPU. Reference L0 numbers come from the frozen runs.
"""
from __future__ import annotations

import json
import math
import os
import re
from collections import Counter
from pathlib import Path

import numpy as np

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
CASES = REPO / "06_结果" / "e11_cases.json"
CACHE = WORK / "schema_cache.json"
EMB = WORK / "e11_emb_spider.npz"
MODEL = WORK / "models" / "Qwen3-Embedding-0.6B"
GP = REPO / "06_结果" / "e12_gp.json"
OUT = REPO / "06_结果" / "e12_jargon.json"

WORD = re.compile(r"[a-z0-9]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us""".split())

TRANS = str.maketrans("abcdefghijklmnopqrstuvwxyz", "bcdefghijklmnopqrstuvwxyza")


def cipher_token(t):
    return t.translate(TRANS)


def cipher_text(s, vocab_map):
    """Cipher every alphabetic token of s that is a known schema token."""
    toks = re.findall(r"[A-Za-z0-9]+", s)
    out = []
    for t in toks:
        lt = t.lower()
        out.append(vocab_map.get(lt, cipher_token(lt)) if False else t)
    return out


def wtoks(s):
    return [t for t in WORD.findall(s.lower()) if t not in STOP]


def ngrams(w, ns=(3, 4, 5)):
    pad = f"<{w}>"
    return {pad[i:i + n] for n in ns for i in range(len(pad) - n + 1)} if len(pad) >= 3 else set()


def stem4(w):
    return w[:4] if len(w) >= 4 else w


def metrics_top(top_ids, gold_set):
    r = {1: 0.0, 5: 0.0}
    mrr = 0.0
    for i, d in enumerate(top_ids[:5]):
        if d in gold_set:
            mrr = max(mrr, 1.0 / (i + 1))
            for k in r:
                if i < k:
                    r[k] += 1.0 / len(gold_set)
    return r, mrr


def randomized_svd(A, k, oversample=16, iters=4, seed=0):
    rng = np.random.default_rng(seed)
    m, n = A.shape
    Q = min(k + oversample, min(m, n))
    Omega = rng.standard_normal((n, Q)).astype(np.float32)
    Y = A @ Omega
    Y -= Y.mean(axis=0, keepdims=True)
    for _ in range(iters):
        Y = A @ (A.T @ Y)
        Y -= Y.mean(axis=0, keepdims=True)
    Qu, _ = np.linalg.qr(Y.astype(np.float64))
    B = Qu.T @ A
    Ub, S, Vt = np.linalg.svd(B, full_matrices=False)
    return (Qu @ Ub[:, :k])[:, :k].astype(np.float32), S[:k].astype(np.float32), \
        Vt[:k, :].astype(np.float32)


def build_latent(doc_tokens, k, seed):
    per_doc = [set(t) for t in doc_tokens]
    df = Counter()
    for ts in per_doc:
        df.update(ts)
    vocab = sorted(df)
    vidx = {t: i for i, t in enumerate(vocab)}
    Dn = len(doc_tokens)
    C = np.zeros((len(vocab), Dn), dtype=np.float32)
    for j, ts in enumerate(per_doc):
        for t in ts:
            C[vidx[t], j] = 1.0
    dlen = np.array([len(ts) for ts in per_doc], dtype=np.float64)
    total = C.sum()
    p_t = C.sum(axis=1, keepdims=True) / total
    p_d = dlen[np.newaxis, :] ** 0.75
    p_d = p_d / p_d.sum()
    pmi = np.log((C * total) / np.maximum(p_t @ p_d * total, 1e-12) / math.log(2))
    M = np.maximum(pmi, 0.0).astype(np.float32)
    U, S, Vt = randomized_svd(M.T, k, seed=seed)
    return U, (Vt.T * S).astype(np.float32), vocab


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))["spider"]
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    gp = json.load(open(GP, encoding="utf-8"))
    w_frozen = np.array(gp["arms"]["gp"]["weights"], dtype=np.float32)  # 10-feature L0 arm
    qtext = {c["qid"]: c["question"] for c in cases}
    split = {c["qid"]: c["split"] for c in cases}
    gold_of = {c["qid"]: {f"{c['db_id']}::{g.lower()}" for g in c["gold"]} for c in cases}
    qids = sorted(qtext, key=lambda q: int(q[2:]))
    train_q = [q for q in qids if split[q] == "train"]
    test_q = [q for q in qids if split[q] == "test"]

    # ---- ciphered catalog: tables/columns ciphered, values kept ----
    tables, doc_ids = [], []
    for db, s in sorted(cache.items()):
        for t in s["tables"]:
            nm = cipher_token(t["name"].lower())
            cols = [(cipher_token(c["name"].lower()), c) for c in t["columns"]]
            fid = f"{db}::{nm}"
            tables.append({"db": db, "name": nm, "cols": cols,
                           "fid": fid, "orig_name": t["name"].lower(),
                           "orig_cols": [c["name"].lower() for c in t["columns"]]})
            doc_ids.append(fid)
    didx = {t["fid"]: i for i, t in enumerate(tables)}
    D = len(tables)

    # schema-token vocabulary from ORIGINAL names (for jargon mode question rewriting)
    schema_tokens = set()
    for t in tables:
        schema_tokens |= set(WORD.findall(t["orig_name"]))
        schema_tokens |= set(WORD.findall(" ".join(t["orig_cols"])))
    tok_map = {t: cipher_token(t) for t in schema_tokens}

    def jargonize(q):
        toks = re.findall(r"[A-Za-z0-9]+", q)
        rep = {t: tok_map.get(t.lower(), t) for t in toks}
        out = q
        for t, r in rep.items():
            if t != r:
                out = re.sub(rf"\b{re.escape(t)}\b", r, out, flags=re.I)
        return out

    gold_c = {q: {f"{g.split('::')[0]}::{cipher_token(g.split('::')[1])}"
                  for g in gold_of[q]} for q in qids}

    def doc_tokens(t):
        ts = list(wtoks(t["name"])) * 2
        for c, cc in t["cols"]:
            ts += wtoks(c)
            for v in (cc.get("values") or [])[:12]:
                ts += wtoks(str(v))
        return ts

    doc_toks = [doc_tokens(t) for t in tables]
    df = Counter()
    for ts in doc_toks:
        df.update(set(ts))
    N = D
    idf = {t: math.log(1 + (N - df[t] + 0.5) / (df[t] + 0.5)) for t in df}
    tf = np.zeros((D, len(df)), dtype=np.float32)
    tidx = {t: i for i, t in enumerate(sorted(df))}
    for j, ts in enumerate(doc_toks):
        for t, c in Counter(ts).items():
            tf[j, tidx[t]] = c
    dlr = tf.sum(axis=1)
    gram_toks = [sorted({g for w in ts if len(w) >= 4 for g in ngrams(w)}) for ts in doc_toks]
    Uw, Tw, vw = build_latent(doc_toks, 256, seed=11)
    Ug, Tg, vg = build_latent(gram_toks, 256, seed=12)
    vwi = {t: i for i, t in enumerate(vw)}
    vgi = {t: i for i, t in enumerate(vg)}
    Uwn = Uw / np.maximum(np.linalg.norm(Uw, axis=1, keepdims=True), 1e-9)
    Ugn = Ug / np.maximum(np.linalg.norm(Ug, axis=1, keepdims=True), 1e-9)

    # ---- dense: re-encode ciphered docs (GPU) ----
    import torch
    from sentence_transformers import SentenceTransformer
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    print("dense device:", dev, flush=True)
    model = SentenceTransformer(str(MODEL), device=dev)
    model.max_seq_length = 128
    dtext = []
    for t in tables:
        parts = [f"{t['db']} :: {t['name']}", "columns: " + ", ".join(c for c, _ in t["cols"])]
        vals = [str(v) for _, c in [(0, cc) for cc in t["cols"]] for v in
                (dict(t["cols"])[c].get("values") or [])[:12]] if False else []
        for c, cc in t["cols"]:
            vals += [str(v) for v in (cc.get("values") or [])[:12]]
        if vals:
            parts.append("values: " + ", ".join(vals))
        dtext.append(" | ".join(parts))
    Ddoc = model.encode(dtext, batch_size=32, convert_to_numpy=True,
                        normalize_embeddings=True, show_progress_bar=False).astype(np.float32)

    modes = {"natural": {q: qtext[q] for q in qids},
             "jargon": {q: jargonize(qtext[q]) for q in qids}}
    Qenc = {}
    qpos = {q: i for i, q in enumerate(qids)}
    for mode, qs in modes.items():
        Qenc[mode] = model.encode([qs[q] for q in qids], batch_size=32,
                                  convert_to_numpy=True, normalize_embeddings=True,
                                  show_progress_bar=False, prompt_name="query").astype(np.float32)
        print(f"encoded {mode} queries", flush=True)

    # ---- FORGE features on the ciphered catalog (10 primitives) ----
    def features(qs, qmap):
        F = np.zeros((len(qs), D, 10), dtype=np.float32)
        for qi, q in enumerate(qs):
            qt = wtoks(qmap[q])
            qset = set(qt)
            qstem = {stem4(w) for w in qt if len(w) >= 4}
            wv = q_latent(qt, vwi, Tw)
            gv = q_latent([g for w in qt for g in ngrams(w)], vgi, Tg)
            if wv is not None:
                F[qi, :, 4] = Uwn @ wv
            if gv is not None:
                F[qi, :, 5] = Ugn @ gv
            s = np.zeros(D, dtype=np.float32)
            for t, qc in Counter(qt).items():
                if t not in tidx:
                    continue
                col = tf[:, tidx[t]]
                s += qc * idf[t] * (col * 2.2) / (col + 1.2 * (0.25 + 0.75 * dlr / (dlr.mean() + 1e-9)))
            F[qi, :, 3] = s
            for j, t in enumerate(tables):
                dset = set(doc_toks[j])
                inter = qset & dset
                F[qi, j, 0] = len(inter)
                F[qi, j, 1] = sum(idf.get(x, 0.0) for x in inter)
                F[qi, j, 2] = len(qstem & {stem4(x) for x in dset if len(x) >= 4})
                F[qi, j, 6] = len(qset & (set(wtoks(t["name"])) & set()))
                nm = set(wtoks(t["name"]))
                cl = set(wtoks(" ".join(c for c, _ in t["cols"])))
                vl = set(wtoks(" ".join(str(v) for c, cc in t["cols"]
                                        for v in (cc.get("values") or [])[:12])))
                F[qi, j, 6] = len(qset & nm)
                F[qi, j, 7] = len(qset & cl)
                F[qi, j, 8] = len(qset & vl)
            F[:, :, 9] = 0
        F[:, :, 9] = np.log1p(F[:, :, 6]) * np.log1p(F[:, :, 7]) * np.log1p(F[:, :, 8])
        return F

    def q_latent(tokens, vocab_i, T):
        vs = [T[vocab_i[t]] for t in set(tokens) if t in vocab_i]
        if not vs:
            return None
        v = np.mean(vs, axis=0)
        return v / max(np.linalg.norm(v), 1e-9)

    def bm25_top(q):
        s = np.zeros(D, dtype=np.float32)
        for t, qc in Counter(wtoks(q)).items():
            if t not in tidx:
                continue
            col = tf[:, tidx[t]]
            s += qc * idf[t] * (col * 2.2) / (col + 1.2 * (0.25 + 0.75 * dlr / (dlr.mean() + 1e-9)))
        return [tables[j]["fid"] for j in np.argsort(-s)[:5]]

    gold_map = {"natural": gold_c, "jargon": gold_c}  # catalog is ciphered in both modes

    def eval_rankings(rows):
        n = len(test_q)
        out = {}
        for m, vals in rows.items():
            out[m] = {"top1": round(float(np.mean(vals["top1"])), 4),
                      "r5": round(float(np.mean(vals["r5"])), 4)}
        return out

    results = {}
    for mode in ("natural", "jargon"):
        qmap = modes[mode]
        goldm = gold_map[mode]
        Ft = features(train_q, qmap)
        mu = Ft.reshape(-1, Ft.shape[-1]).mean(0)
        sd = Ft.reshape(-1, Ft.shape[-1]).std(0) + 1e-9
        Fn = (Ft - mu) / sd
        gold_tr = [goldm[q] for q in train_q]

        def fitness(W, chunk=120):
            P = W.shape[0]
            out = np.zeros(P)
            for s0 in range(0, len(train_q), chunk):
                e = min(s0 + chunk, len(train_q))
                sc = Fn[s0:e] @ W.T
                for p in range(P):
                    part = np.argpartition(-sc[:, :, p], 8, axis=1)[:, :8]
                    for qi in range(e - s0):
                        loc = part[qi]
                        order = loc[np.argsort(-sc[qi, loc, p])]
                        g = gold_tr[s0 + qi]
                        out[p] += sum(1.0 / len(g) for di in order[:5]
                                      if tables[di]["fid"] in g)
            return out / len(train_q)

        rng = np.random.default_rng(7)
        P, G = 80, 60
        pop = rng.uniform(-0.5, 1.5, (P, 10))
        for gen in range(G):
            fit = fitness(pop)
            elite = pop[np.argsort(-fit)[:2]].copy()
            new = [elite[0], elite[1]]
            while len(new) < P:
                i, j = rng.integers(0, P, 2)
                a, b = (pop[i], pop[j]) if fit[i] >= fit[j] else (pop[j], pop[i])
                lam = rng.uniform(-0.25, 1.25, 10)
                child = a + lam * (b - a)
                child += (rng.random(10) < 0.25) * rng.normal(0, 0.2, 10)
                new.append(np.clip(child, -3, 3))
            pop = np.array(new)
        fit = fitness(pop)
        w_refit = pop[int(np.argmax(fit))]
        print(f"[{mode}] GA refit train R@5={fit.max():.4f}", flush=True)

        Fte = (features(test_q, qmap) - mu) / sd
        scores = {
            "bm25": [bm25_top(qmap[q]) for q in test_q],
            "forge_frozen": [[doc_ids[i] for i in np.argsort(-(Fte[qi] @ w_frozen))[:5]]
                             for qi, q in enumerate(test_q)],
            "forge_refit": [[tables[j]["fid"] for j in np.argsort(-(Fte[qi] @ w_refit))[:5]]
                            for qi, q in enumerate(test_q)],
            "dense": [[doc_ids[i] for i in np.argsort(-(Ddoc @ Qenc[mode][qpos[q]]))[:5]]
                      for q in test_q],
        }
        agg = {}
        for mname, ranks in scores.items():
            t1 = r5 = 0.0
            for qi, q in enumerate(test_q):
                g = goldm[q]
                r, mrrv = metrics_top(ranks[qi], g)
                t1 += r[1]
                r5 += r[5]
            agg[mname] = {"top1": round(t1 / len(test_q), 4), "r5": round(r5 / len(test_q), 4)}
        results[mode] = agg
        print(mode, json.dumps(agg), flush=True)

    json.dump(results, open(OUT, "w", encoding="utf-8"), indent=1)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
