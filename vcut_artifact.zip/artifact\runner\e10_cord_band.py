"""E10: the inverted-U on real receipts.

For every OCR token type we measure two different utilities against the gold
total:
  - semantic utility: P(the token sits within 3 tokens of the gold total)
  - instance utility: P(the token itself equals the gold total)
and bucket both by document frequency (head / middle / tail).  The first is
expected to be inverted-U; the second is expected to need exact keys, not
frequency.
"""
from __future__ import annotations

import json
import re
import sys
from collections import defaultdict
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e7_receipts import gold_of, amount_match, num, tokens_text  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
DATA = REPO / "04_数据" / "external" / "cord" / "train.parquet"
OUT = REPO / "06_结果" / "e10_cord_band.json"
TOK = re.compile(r"[a-z0-9]+")


def norm(t: str) -> str:
    return t.strip().lower()


def nearby(amounts, i, gold, w=3):
    for j in range(max(0, i - w), min(len(amounts), i + w + 1)):
        if amount_match(amounts[j], gold):
            return True
    return False


def main():
    df = pd.read_parquet(DATA)
    stat = defaultdict(lambda: {"occ": 0, "near": 0, "exact": 0,
                                "receipts": set(), "numeric": 0})
    for _, r in df.iterrows():
        text = tokens_text(r["ocr_text"])
        toks = [t.strip() for t in text.split("|")]
        amounts = [num(t) for t in toks]
        gold = gold_of(r["ocr_kie"])["total"]
        if gold is None:
            continue
        for i, t in enumerate(toks):
            key = norm(t)
            if not key:
                continue
            s = stat[key]
            s["occ"] += 1
            s["receipts"].add(r["file_name"])
            near = nearby(amounts, i, gold)
            exact = amounts[i] is not None and amount_match(amounts[i], gold)
            if amounts[i] is not None:
                s["numeric"] += 1
            s["near"] += bool(near)
            s["exact"] += bool(exact)

    rows = []
    for t, s in stat.items():
        n = s["occ"]
        rows.append({"token": t, "df": len(s["receipts"]), "occ": n,
                     "numeric_occ": s["numeric"],
                     "near_precision": round(s["near"] / n, 4),
                     "exact_precision": round(s["exact"] / max(1, s["numeric"]), 4),
                     "exact_rate": round(s["exact"] / n, 4)})

    for x in rows:
        x["kind"] = "numeric" if re.fullmatch(r"[0-9.,]+", x["token"]) else "alpha"
    bins = [(1, 1), (2, 3), (4, 7), (8, 15), (16, 31), (32, 10**9)]
    buckets = {"alpha": [], "numeric": [], "all": []}
    for kind in ("alpha", "numeric", "all"):
        for a, b in bins:
            sub = [x for x in rows if a <= x["df"] <= b and (kind == "all" or x["kind"] == kind)]
            occ = sum(x["occ"] for x in sub)
            near = sum(x["near_precision"] * x["occ"] for x in sub)
            num_occ = sum(x["numeric_occ"] for x in sub)
            exact = sum(x["exact_precision"] * x["numeric_occ"] for x in sub)
            buckets[kind].append({
                "df_range": f"{a}-{'' if b > 10**8 else b}",
                "types": len(sub), "occurrences": occ,
                "near_precision": round(near / max(1, occ), 4),
                "exact_precision": round(exact / max(1, num_occ), 4),
                "exact_coverage": round(exact / max(1, occ), 4),
            })

    top = sorted(rows, key=lambda x: -x["df"])[:25]
    out = {"n_receipts": int(len(df)), "n_types": len(rows),
           "buckets": buckets, "top_tokens": top, "types": rows}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in out.items() if k != "types"},
                     ensure_ascii=False, indent=2)[:5000])


if __name__ == "__main__":
    main()
