"""E11 control run on the 11 BIRD databases.

Compares lexical retrieval, single-graph PPR and typed multi-layer diffusion on
the same schema documents.  This is the control for the large-schema Spider
experiments; it should reproduce the E9 ordering (PPR > BM25) and show whether
relation layers help when the schema is small.
"""
from __future__ import annotations

import json
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
OUT = REPO / "06_结果" / "e11_bird.json"


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))
    cases = json.load(open(CASES, encoding="utf-8"))["bird"]
    qdf = Counter()
    for c in cases:
        qdf.update(set(toks(c["question"])))
    vals = sorted(qdf.values())
    hi = float(np.quantile(vals, 0.80))
    lo = float(np.quantile(vals, 0.20))
    band = lambda t: 0.15 if qdf[t] >= hi else 1.0

    by_db = {}
    for c in cases:
        by_db.setdefault(c["db_id"], []).append(c)

    rows = []
    t_build = 0.0
    for db, cs in sorted(by_db.items()):
        tables = [dict(t, db=db) for t in cache["bird"][db]["tables"]]
        t0 = time.time()
        cat = g.Catalog(tables, cache["bird"][db]["fks"], prefix_db=False)
        t_build += time.time() - t0
        for c in cs:
            q = toks(c["question"])
            gold = set(c["gold"])
            bw = {x: band(x) for x in q}
            scores = {
                "bm25": g.bm25(cat, q),
                "tfidf": g.tfidf(cat, q),
                "ppr": g.single_ppr(cat, q),
                "ppr_band": g.single_ppr(cat, q, band_weight=bw),
                "typed": g.fuse(cat, q),
                "typed_band": g.fuse(cat, q, band_weight=bw),
            }
            row = {"qid": c["qid"], "db": db, "gold": sorted(gold)}
            for name, s in scores.items():
                r = g.rank(s, cat)
                row[name] = {"top5": r[:5], **g.metrics(r, gold),
                             "cert": g.certify(cat, s, q, gold)}
            rows.append(row)

    methods = ["bm25", "tfidf", "ppr", "ppr_band", "typed", "typed_band"]
    agg = {m: g.mean_metrics([r[m] for r in rows]) for m in methods}
    out = {"n": len(rows), "build_s": round(t_build, 2),
           "bands": {"head_df_ge": hi, "tail_df_le": lo},
           "methods": agg, "rows": rows}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
