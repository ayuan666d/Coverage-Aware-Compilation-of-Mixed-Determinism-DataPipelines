# -*- coding: utf-8 -*-
"""E1 —— 假安全与误杀的双向测量（v0.3 口径）

两种口径分开报，避免把“逐输入诊断”当成“编译器判定”：

  pipeline  ：对每条管线，用**全称有效** V_eff_all（所有 9 个输入都判过）
              做割判定。这才是编译器的判定口径（定理 1 静态版）。
  per_input ：对每条管线、每个输入 t，用 V_eff(G,t) 做割判定。
              这是诊断口径，用来看“哪个输入触发的、走哪条路径”。

判据：
  B0  不检查（恒判安全）
  B1  存在单个判决节点支配出口（现有实现，拓扑-only）
  M   V_eff 构成 entry→sink 顶点割（本文，含兜底 verdict 语义）

因子：形状 × 节点数 × 出口数 × 源数 × 失效率 × 兜底方向
      fallback=pass   ：未命中就放行（假安全的来源）
      fallback=reject ：未命中就拒绝（保守兜底，仍算判过）

用法：
    python runner/e1.py [--quick]
"""

from __future__ import annotations

import argparse
import itertools
import json
import random
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, FrozenSet

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

from checker.graphutil import reachable_set  # noqa: E402
from generator.synth import Pipe, synth  # noqa: E402


# ── 两个判据 ──────────────────────────────────────────────────


def judge_dominance(pipe: Pipe) -> Dict[str, bool]:
    """B1：存在单个判决节点 v，删掉 v 后所有源都到不了该出口。"""
    succ = pipe.succ()
    srcs = pipe.sources()
    out: Dict[str, bool] = {}
    for s in pipe.sinks():
        ok = False
        for v in pipe.verdicts():
            if all(s not in reachable_set(src, succ, frozenset({v})) for src in srcs):
                ok = True
                break
        out[s] = ok
    return out


def judge_dominance_eff(pipe: Pipe, v_eff: FrozenSet[str]) -> Dict[str, bool]:
    """B1+覆盖：只在 V_eff 里找单点支配（用于消融）。"""
    succ = pipe.succ()
    srcs = pipe.sources()
    out: Dict[str, bool] = {}
    for s in pipe.sinks():
        out[s] = any(
            all(s not in reachable_set(src, succ, frozenset({v})) for src in srcs)
            for v in v_eff
        )
    return out


def judge_cut(pipe: Pipe, v_eff: FrozenSet[str]) -> Dict[str, bool]:
    """M/GT：删掉 V_eff 后，所有源都到不了该出口。"""
    succ = pipe.succ()
    srcs = pipe.sources()
    out: Dict[str, bool] = {}
    for s in pipe.sinks():
        out[s] = all(
            s not in reachable_set(src, succ, v_eff) for src in srcs
        )
    return out


def v_eff_all(pipe: Pipe) -> FrozenSet[str]:
    """全称有效判决集：对全部输入都 judged。"""
    return frozenset(
        v for v in pipe.verdicts()
        if pipe.tables[v].eff_all(pipe.input_space)
    )


# ── 因子网格 ──────────────────────────────────────────────────

SHAPES = ["line", "fork_join", "branch_verdict"]
NODES = [8, 20, 60]
SINKS = [1, 3]
SOURCES = [1, 3]
P_MISS = [0.0, 0.3]
FALLBACKS = ["pass", "reject"]
PER_CELL = 12


def _rate(num: int, den: int) -> float:
    return round(num / den, 4) if den else 0.0


def _rates(counts: Dict[tuple, int]) -> dict:
    gt_safe = counts[(True, True)] + counts[(False, True)]
    gt_unsafe = counts[(True, False)] + counts[(False, False)]
    return {
        "gt_safe": gt_safe,
        "gt_unsafe": gt_unsafe,
        "FR_kill": _rate(counts[(False, True)], gt_safe),
        "FR_safe": _rate(counts[(True, False)], gt_unsafe),
        "kill_count": counts[(False, True)],
        "safe_count": counts[(True, False)],
    }


def _summarize(counts: Dict[tuple, int]) -> dict:
    gt_safe = counts[(True, True)] + counts[(False, True)]
    gt_unsafe = counts[(True, False)] + counts[(False, False)]
    return {
        "gt_safe": gt_safe,
        "gt_unsafe": gt_unsafe,
        "B0": {
            "FR_kill": 0.0,
            "FR_safe": _rate(gt_unsafe, gt_unsafe),
            "kill_count": 0,
            "safe_count": gt_unsafe,
        },
        "B1": _rates(counts),
        "M": {
            "FR_kill": 0.0,
            "FR_safe": 0.0,
            "kill_count": 0,
            "safe_count": 0,
        },
    }


def run(quick: bool = False) -> dict:
    rng = random.Random(7)
    nodes_levels = NODES
    per_cell = PER_CELL
    if quick:
        nodes_levels = [8, 14]
        per_cell = 3

    pipes: Dict[tuple, int] = defaultdict(int)       # (B1_safe, GT_pipe_safe)
    per_input: Dict[tuple, int] = defaultdict(int)   # (B1_safe, GT_t_safe)
    cut_only: Dict[tuple, int] = defaultdict(int)    # 割 + 不看覆盖
    dom_eff: Dict[tuple, int] = defaultdict(int)     # 支配 + 看覆盖
    by_factor: Dict[tuple, Dict[tuple, int]] = defaultdict(lambda: defaultdict(int))
    n_pipes = 0
    n_input_judgements = 0
    v_eff_all_size: Dict[int, int] = defaultdict(int)

    for shape, nn, ns, nsrc, pm, fb in itertools.product(
        SHAPES, nodes_levels, SINKS, SOURCES, P_MISS, FALLBACKS
    ):
        for _rep in range(per_cell):
            pipe = synth(shape, nn, ns, nsrc, pm, rng, fallback=fb)
            n_pipes += 1

            dom = judge_dominance(pipe)
            b1_pipe = all(dom.values())

            ve_all = v_eff_all(pipe)
            v_eff_all_size[len(ve_all)] += 1
            gt_pipe = all(judge_cut(pipe, ve_all).values())

            # 消融：只做割（不看覆盖） / 只做覆盖（仍用支配）
            b_cut = all(judge_cut(pipe, frozenset(pipe.verdicts())).values())
            b1e = all(judge_dominance_eff(pipe, ve_all).values())
            cut_only[(b_cut, gt_pipe)] += 1
            dom_eff[(b1e, gt_pipe)] += 1

            pipes[(b1_pipe, gt_pipe)] += 1
            key = (shape, nn, ns, nsrc, pm, fb)
            by_factor[key][(b1_pipe, gt_pipe)] += 1

            # 逐输入诊断
            for t in pipe.input_space:
                ve_t = frozenset(
                    v for v in pipe.verdicts()
                    if pipe.tables[v].eff(t)
                )
                gt_t = judge_cut(pipe, ve_t)
                for s, ok in gt_t.items():
                    per_input[(dom[s], ok)] += 1
                    n_input_judgements += 1

    summary = {
        "schema": "e1-v0.3",
        "n_pipes": n_pipes,
        "n_input_judgements": n_input_judgements,
        "pipeline": _summarize(pipes),
        "per_input": _summarize(per_input),
        "v_eff_all_size_hist": {str(k): v for k, v in sorted(v_eff_all_size.items())},
        "by_factor": {
            "|".join(map(str, k)): {
                "B1": {
                    "FR_kill": _rate(v[(False, True)],
                                     v[(False, True)] + v[(True, True)]),
                    "FR_safe": _rate(v[(True, False)],
                                     v[(True, False)] + v[(False, False)]),
                },
                "counts": {
                    "both_safe": v[(True, True)],
                    "false_safe": v[(True, False)],
                    "false_kill": v[(False, True)],
                    "both_unsafe": v[(False, False)],
                },
            }
            for k, v in sorted(by_factor.items())
        },
    }
    summary["pipeline"]["B_cut"] = _rates(cut_only)      # 只做割，不看覆盖
    summary["pipeline"]["B1_eff"] = _rates(dom_eff)      # 只做覆盖，仍用支配
    return summary


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--out", default=str(HERE / ".." / "06_结果" / "e1_summary.json"))
    args = ap.parse_args()

    s = run(args.quick)
    print(json.dumps({
        "n_pipes": s["n_pipes"],
        "pipeline": s["pipeline"],
        "per_input": s["per_input"],
        "v_eff_all_size_hist": s["v_eff_all_size_hist"],
    }, ensure_ascii=False, indent=2))
    Path(args.out).write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n已写入 {args.out}")

    p = s["pipeline"]["B1"]
    print("\n判定（pipeline 口径）：")
    print(f"  H1-假安全方向：FR_safe(B1) = {p['FR_safe']}"
          f"  → {'✓ 成立' if p['FR_safe'] > 0 else '✗ 未成立'}")
    print(f"  H1-误杀方向：  FR_kill(B1) = {p['FR_kill']}"
          f"  → {'✓ 成立' if p['FR_kill'] > 0 else '✗ 未成立'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
