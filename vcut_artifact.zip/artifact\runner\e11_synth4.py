"""E11-SYNTH4: transfer the synthesized operator, frozen, to the small-schema settings.

e11_synth2/3 searched on the 876-table lake (train questions only) and the label-free winner read
above the hand arm on lake test: recall@5 +2.20 points, paired-bootstrap CI [+0.29, +4.11],
McNemar p = 0.005 (23 wins / 7 losses), while the supervised search of the same space gained
+0.15 with p = 0.12.  Three different label-free objectives independently converged on the SAME
weight vector -- every catalogue channel at equal weight, idf geometric mean over query words --
and differed only in alpha and the recall width.  (Relative weights are what the objective sees:
scaling all weights by c leaves both aggregations' ranking unchanged, so "0.5 everywhere" and
"1.0 everywhere" are one operator.)

A lake of 876 tables is where a six-channel conjunction has room to matter, so the honest test is
to freeze that operator and run it where the hand pipeline was validated: BIRD's 11 databases and
Spider's 34 known test databases, each with its own cold catalogue, no re-tuning, no re-search, no
labels.  Report per setting: recall@1/@5 for the frozen operator vs the hand arm vs dense, the
question-paired bootstrap, and the same three certificate readings (word, word&name, and the
frozen support rule) to check that certifiability transfers with the operator.

Every quantity is computed inside the database's own catalogue; the diffusion cache is keyed by
token, so no test-only vocabulary restriction can cripple the operator.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_col import col_index  # noqa: E402
from e11_cotype import docs_by_type, incidence  # noqa: E402
from e11_surprise import chance_tail  # noqa: E402
import e11_synth2 as s2  # noqa: E402
from e11_synth3 import paired  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
CASES = R / "e11_cases.json"
ALPHA_CERT = 0.05
K_FROZEN, M_FROZEN = 3, 2
LAYERS = ("word", "name", "col", "word&name", "word&col")
HAND = {"weights": {f: 0.0 for f in s2.FEATS} | {"coldiff": 1.0},
        "alpha": 0.85, "agg": "geo", "K": 30}
SYNTH = {"weights": {f: 1.0 for f in s2.FEATS}, "alpha": 0.85, "agg": "geo", "K": 30}
ARMS = {"hand": HAND, "synth": SYNTH}
SENS = [{"alpha": a, "K": k} for a in (0.80, 0.85, 0.90) for k in (20, 30)]


def build(cat, vocab, tid, idf, alphas):
    N = len(cat.tables)
    n_tok = len(vocab)
    namehit = np.zeros((n_tok, N), dtype=np.float32)
    valhit = np.zeros((n_tok, N), dtype=np.float32)
    nm_toks, vl_toks = [], []
    for j, t in enumerate(cat.tables):
        nm = set(toks(t["name"]))
        for c in t["columns"]:
            nm |= set(toks(c["name"]))
        vl = set()
        for c in t["columns"]:
            for v in c.get("values", [])[:6]:
                vl |= set(toks(v)[:3])
        nm_toks.append(nm)
        vl_toks.append(vl)
        for w in nm:
            i = tid.get(w)
            if i is not None:
                namehit[i, j] = 1.0
        for w in vl:
            i = tid.get(w)
            if i is not None:
                valhit[i, j] = 1.0
    nbr = [[] for _ in range(N)]
    for a, ca, b, cb in cat.fks:
        ja, jb = cat.table_pos.get(a), cat.table_pos.get(b)
        if ja is not None and jb is not None:
            nbr[ja].append(jb)
            nbr[jb].append(ja)
    fkhit = np.zeros((n_tok, N), dtype=np.float32)
    for j in range(N):
        s = set()
        for k in nbr[j]:
            s |= nm_toks[k] | vl_toks[k]
        for w in s:
            i = tid.get(w)
            if i is not None:
                fkhit[i, j] = 1.0
    colnodes, cdocs, starts, ends = col_index(cat)
    diff = {}
    for a in alphas:
        td = np.zeros((n_tok, N), dtype=np.float32)
        cd = np.zeros((n_tok, N), dtype=np.float32)
        for w in vocab:
            x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, a, s2.ITERS)
            st = np.asarray(cat.table_scores(x), dtype=np.float32)
            mx = float(st.max())
            if mx > 0:
                td[tid[w]] = st / mx
            cv = np.asarray(x)[colnodes].astype(np.float32)
            cmx = float(cv.max())
            if cmx > 0:
                cv = cv / cmx
            cd[tid[w]] = np.maximum.reduceat(cv, starts)
        diff[a] = (td, cd)
    docs = [g.table_doc(t) for t in cat.tables]
    dl = np.array([len(d) for d in docs], dtype=np.float32)
    avgdl = float(dl.mean()) or 1.0
    tf = np.zeros((n_tok, N), dtype=np.float32)
    for i, w in enumerate(vocab):
        for j, d in enumerate(docs):
            if w in d:
                tf[i, j] = d.count(w)
    k1, bb = 1.2, 0.75
    TS = (idf[:, None] * tf * (k1 + 1.0)
          / (tf + k1 * (1.0 - bb + bb * dl[None, :] / avgdl))).astype(np.float32)
    FM = {"namehit": namehit, "valhit": valhit, "fkhit": fkhit, "bm25": TS}
    return diff, FM, TS, (colnodes, starts, ends)


def rank_rows(rec, cfg, diff, FM, N):
    w, alpha, agg, K = cfg["weights"], cfg["alpha"], cfg["agg"], cfg["K"]
    td, cd = diff[alpha]
    idx, iw = rec["idx"], rec["iw"]
    acc = np.zeros((idx.size, N), dtype=np.float32)
    for name in s2.FEATS:
        if w[name] <= 0:
            continue
        M = (td if name == "tabdiff" else cd if name == "coldiff" else FM[name])[idx]
        acc += w[name] * M
    base = np.log(acc + s2.EPS) if agg == "geo" else acc
    m = (iw @ base) / max(float(iw.sum()), 1e-6) if idx.size else np.zeros(N)
    cands = np.argsort(-rec["b"])[:min(K, N)] if K < N else np.arange(N)
    return cands[np.argsort(-m[cands])]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", choices=["bird", "known"], required=True)
    args = ap.parse_args()
    t0 = time.time()
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    allc = json.load(open(CASES, encoding="utf-8"))
    if args.kind == "bird":
        cases_all, dbs = allc["bird"], cache["bird"]
        emb = Path("D:/vldb2027_e11/e11_emb_bird.npz")
    else:
        cases_all = [c for c in allc["spider"] if c["split"] == "test"]
        dbs = cache["spider"]
        emb = Path("D:/vldb2027_e11/e11_emb_spider.npz")
    z = np.load(emb, allow_pickle=True)
    ids = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}

    per_q = {}
    for c in cases_all:
        per_q.setdefault(c["db_id"], []).append(c)
    alphas = sorted({c["alpha"] for c in SENS} | {HAND["alpha"], SYNTH["alpha"]})
    rows = []
    for db, cs in sorted(per_q.items()):
        if db not in dbs:
            continue
        tabs = [dict(t, db=db) for t in dbs[db]["tables"]]
        cat = g.Catalog(tabs, dbs[db]["fks"], prefix_db=False)
        N = len(cat.tables)
        qtok = {w for c in cs for w in toks(c["question"])}
        vocab = sorted(w for w in qtok if ("token", w) in cat.idx)
        if not vocab:
            vocab = ["."]
        tid = {w: i for i, w in enumerate(vocab)}
        idf = np.array([math.log(1 + (N - cat.token_df.get(w, 0) + 0.5)
                                 / (cat.token_df.get(w, 0) + 0.5)) for w in vocab],
                       dtype=np.float32)
        diff, FM, TS, (colnodes, starts, ends) = build(cat, vocab, tid, idf, alphas)
        corpora = docs_by_type(cat)
        incs = {k: incidence(d) for k, d in corpora.items()}
        dfs = {k: Counter() for k in corpora}
        for k, d in corpora.items():
            for doc in d:
                dfs[k].update({w: 1 for w in set(doc)})
        for rec_c in cs:
            q = sorted(set(toks(rec_c["question"])))
            idx = np.array([tid[w] for w in q if w in tid], dtype=np.int64)
            gold = {t.lower() for t in rec_c["gold"]}
            rec = {"qid": rec_c["qid"], "q": q, "idx": idx, "iw": idf[idx] if idx.size else np.zeros(0),
                   "b": TS[idx].sum(0) if idx.size else np.zeros(N)}
            st_vec, curve = {}, {}
            for k in ("word", "name", "value"):
                inc = incs[k]
                s = np.zeros(N, dtype=np.float32)
                qd = []
                for w in q:
                    v = inc.get(w)
                    if v is None:
                        continue
                    s += v
                    qd.append(dfs[k].get(w, 0))
                st_vec[k] = s
                curve[k] = [chance_tail(qd, N, x)[1] for x in range(0, len(q) + 2)]
            inc = incs["col"]
            qcols = [(w, inc[w], dfs["col"].get(w, 0)) for w in q if w in inc]
            s = np.zeros(N, dtype=np.float32)
            if qcols:
                per_col = np.zeros(len(corpora["col"]), dtype=np.int32)
                for _, v, _ in qcols:
                    per_col += v.astype(np.int32)
                for i, (a, b) in enumerate(zip(starts, ends)):
                    s[i] = per_col[a:b].max() if b > a else 0
            st_vec["col"] = s
            curve["col"] = [chance_tail([d for _, _, d in qcols], len(corpora["col"]), x)[1]
                            for x in range(0, len(q) + 2)]
            if idx.size:
                for name, cfg in ARMS.items():
                    order = rank_rows(rec, cfg, diff, FM, N)
                    t1 = cat.tables[int(order[0])]["name"]
                    ok = t1.lower() in gold
                    pv = {}
                    for k in ("word", "name", "col"):
                        sv = int(st_vec[k][int(order[0])])
                        pv[k] = curve[k][min(sv, len(curve[k]) - 1)] <= ALPHA_CERT
                    ws = [w for w in q if ("token", w) in cat.idx]
                    shared = len(set(q) & set(g.table_doc(cat.tables[cat.table_pos[t1]]))) if t1 in cat.table_pos else 0
                    rarest = min([cat.token_df.get(w, 10 ** 9) for w in ws], default=10 ** 9)
                    rows.append({"db": db, "qid": rec_c["qid"], "arm": name, "n_tables": N,
                                 "r1": 1.0 if ok else 0.0,
                                 "r5": sum(1 for t in [cat.tables[int(i)]["name"] for i in order[:5]]
                                           if t.lower() in gold) / max(1, len(gold)),
                                 "acc": {"word": pv["word"], "name": pv["name"], "col": pv["col"],
                                         "word&name": pv["word"] and pv["name"],
                                         "word&col": pv["word"] and pv["col"],
                                         "frozen": shared >= K_FROZEN and rarest <= M_FROZEN},
                                 "correct": ok})
            for cfg in (SENS if idx.size else []):
                order = rank_rows(rec, {"weights": SYNTH["weights"], "alpha": cfg["alpha"],
                                        "agg": "geo", "K": cfg["K"]}, diff, FM, N)
                t1n = cat.tables[int(order[0])]["name"]
                rows.append({"db": db, "qid": rec_c["qid"],
                             "arm": f"synth_a{cfg['alpha']}_K{cfg['K']}", "n_tables": N,
                             "r1": 1.0 if t1n.lower() in gold else 0.0,
                             "r5": sum(1 for t in [cat.tables[int(i)]["name"] for i in order[:5]]
                                       if t.lower() in gold) / max(1, len(gold))})
            cand = [i for i, t in enumerate(ids) if t.split("::")[0] == db]
            if cand and rec_c["qid"] in qpos:
                sim = Dm[cand] @ Qm[qpos[rec_c["qid"]]]
                order = [ids[cand[i]] for i in np.argsort(-sim)]
                gset = {f"{db}::{t}".lower() for t in rec_c["gold"]}
                rows.append({"db": db, "qid": rec_c["qid"], "arm": "dense", "n_tables": N,
                             "r1": 1.0 if order and order[0].lower() in gset else 0.0,
                             "r5": sum(1 for t in order[:5] if t.lower() in gset)
                             / max(1, len(gset))})
    print(f"{args.kind}: {len(rows)} arm-rows in {time.time()-t0:.0f}s", flush=True)

    def summ(arm):
        rs = [r for r in rows if r["arm"] == arm]
        out = {"n": len(rs), "r1": round(float(np.mean([r["r1"] for r in rs])), 4),
               "r5": round(float(np.mean([r["r5"] for r in rs])), 4)}
        if "acc" in rs[0]:
            for tag in LAYERS + ("frozen",):
                sel = [r for r in rs if r["acc"][tag]]
                out[tag] = {"accepted": len(sel), "cov": round(len(sel) / len(rs), 4),
                            "false_pass": sum(1 for r in sel if not r["correct"]),
                            "precision": round(1 - sum(1 for r in sel if not r["correct"])
                                               / len(sel), 4) if sel else None}
        return out

    by_qid = {}
    for r in rows:
        by_qid.setdefault(r["arm"], {})[(r["db"], r["qid"])] = r
    common = set(by_qid.get("hand", {})) & set(by_qid.get("synth", {}))
    # dense covers every question; the graph arms can only be scored where the query has a token
    # the catalogue knows.  Report dense twice: on all rows and on the paired subset, so the
    # model-vs-graph comparison is never made on a different denominator.
    drows = by_qid.get("dense", {})
    dens = {"r1": round(float(np.mean([drows[k]["r1"] for k in sorted(common)])), 4),
            "r5": round(float(np.mean([drows[k]["r5"] for k in sorted(common)])), 4),
            "n_paired": len(common), "n_all": len(drows)} if drows else None
    boot = {"r1": paired([by_qid["synth"][k]["r1"] for k in sorted(common)],
                         [by_qid["hand"][k]["r1"] for k in sorted(common)]),
            "r5": paired([by_qid["synth"][k]["r5"] for k in sorted(common)],
                         [by_qid["hand"][k]["r5"] for k in sorted(common)])}
    out = {"kind": args.kind, "operator": {"weights": SYNTH["weights"], "alpha": SYNTH["alpha"],
           "agg": SYNTH["agg"], "K": SYNTH["K"], "frozen_from": "lake train (no re-tuning)"},
           "arms": {a: summ(a) for a in list(ARMS) + [f"synth_a{c['alpha']}_K{c['K']}" for c in SENS]
                    + ["dense"]},
           "dense_on_paired_subset": dens,
           "bootstrap_synth_vs_hand": boot,
           "bootstrap_synth_vs_dense": {
               m: paired([by_qid["synth"][k][m] for k in sorted(common)],
                         [drows[k][m] for k in sorted(common)])
               for m in ("r1", "r5")} if drows else None,
           "bootstrap_hand_vs_dense": {
               m: paired([by_qid["hand"][k][m] for k in sorted(common)],
                         [drows[k][m] for k in sorted(common)])
               for m in ("r1", "r5")} if drows else None,
           "n_questions": len(common)}
    json.dump(out, open(R / f"e11_synth4_{args.kind}.json", "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(json.dumps(out, indent=1, ensure_ascii=False))


if __name__ == "__main__":
    main()
