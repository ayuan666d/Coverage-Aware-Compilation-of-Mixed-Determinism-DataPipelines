"""E12 addendum 1: dissect the weak-class residue.

Populations (within the 164 dense-correct/graph-wrong):
  A = gp_ex wrong  (52 questions) — what the searched DB-native scorer misses
  B = dense_ft ALSO wrong (subset of A) — the hard core nothing fixes

Per question we record, for gold vs the failing method's top1:
  typed lexical evidence (name/col/value hits, idf sum),
  FK-sibling evidence: idf overlap between the question and the FK-neighbours'
  documents of gold (does the evidence live next door?),
  dense margins: cos(q,gold) vs cos(q,failing top1) from the ZERO-SHOT model
  (the external prior instrument).
Aggregate: how much of A/B is explainable by (i) FK-sibling evidence the DSL
lacks, (ii) pure association (dense confident, lexical identical), (iii) hard
lexical tie.
"""
from __future__ import annotations

import json
import math
import os
import re
from collections import Counter
from pathlib import Path

import numpy as np

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
MODEL = WORK / "models" / "Qwen3-Embedding-0.6B"
EMB = WORK / "e11_emb_spider.npz"

WORD = re.compile(r"[a-z0-9]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us list show give find return
number names name""".split())


def wtoks(s):
    return [t for t in WORD.findall(s.lower()) if t not in STOP]


def main():
    cache = json.load(open(WORK / "schema_cache.json", encoding="utf-8"))["spider"]
    all_t = {}
    typed = {}
    for db, s in cache.items():
        nb = {}
        have = {t["name"].lower() for t in s["tables"]}
        for t in s["tables"]:
            fid = f"{db}::{t['name'].lower()}"
            nm = wtoks(t["name"]) * 2
            cl, vl = [], []
            for c in t["columns"]:
                cl += wtoks(c["name"])
                for v in (c.get("values") or [])[:12]:
                    vl += wtoks(str(v))
            all_t[fid] = set(nm) | set(cl) | set(vl)
            typed[fid] = {"name": set(nm), "col": set(cl), "val": set(vl)}
        nb_pairs = [(a.lower(), b.lower()) for a, ca, b, cb in s.get("fks", [])
                    if a.lower() in have and b.lower() in have]
        for a, b in nb_pairs:
            nb.setdefault(f"{db}::{a}", set()).add(f"{db}::{b}")
            nb.setdefault(f"{db}::{b}", set()).add(f"{db}::{a}")
        globals().setdefault("_NB", {})
        globals()["_NB"].update(nb)
    nbr = globals()["_NB"]
    df = Counter()
    for ts in all_t.values():
        df.update(ts)
    idf = {t: math.log(1 + 875 / (df[t] + 0.5)) for t in df}

    cases = json.load(open(REPO / "06_结果" / "e11_cases.json", encoding="utf-8"))["spider"]
    qtext = {c["qid"]: c["question"] for c in cases}
    verd = json.load(open(REPO / "06_结果" / "e12_verdict.json", encoding="utf-8"))
    classes = verd["classes"]
    gp = json.load(open(REPO / "06_结果" / "e12_gp.json", encoding="utf-8"))
    gpx = {r["qid"]: r for r in gp["rows"]["gp_ex"]}
    ftd = {r["qid"]: r for r in json.load(open(REPO / "06_结果" / "e12_ft.json", encoding="utf-8"))["rows"]}

    # zero-shot dense cosines for test questions
    z = np.load(EMB, allow_pickle=True)
    ids = [str(x) for x in z["ids"]]
    Dm = z["D"].astype(np.float32)
    dpos = {f.lower(): i for i, f in enumerate(ids)}
    import torch
    from sentence_transformers import SentenceTransformer
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    model = SentenceTransformer(str(MODEL), device=dev)
    model.max_seq_length = 128
    test_q = sorted(classes, key=lambda q: int(q[2:]))
    Q = model.encode([qtext[q] for q in test_q], batch_size=32, convert_to_numpy=True,
                     normalize_embeddings=True, show_progress_bar=False, prompt_name="query")
    COS = Q.astype(np.float32) @ Dm.T
    print(f"encoded {len(test_q)} queries on {dev}", flush=True)

    def ev_profile(qset, fid):
        p = {}
        for k in ("name", "col", "val"):
            p[k] = len(qset & typed[fid][k])
        p["idf"] = round(sum(idf.get(t, 0.0) for t in (qset & all_t[fid])), 2)
        return p

    def fk_signal(qset, gold_fid):
        s = 0.0
        best = None
        for u in nbr.get(gold_fid, ()):  # neighbours may have upper-case names
            u = u.lower()
            if u in all_t:
                v = sum(idf.get(t, 0.0) for t in (qset & all_t[u]))
                if v > s:
                    s, best = v, u
        return round(s, 2), best

    rows = []
    for q in test_q:
        c = classes[q]
        if c["class"] != "weak":
            continue
        gold = set(next(r["gold"] for r in gp["rows"]["gp_ex"] if r["qid"] == q))
        gfid = sorted(gold)[0].lower()
        gfid = gfid if gfid in all_t else gfid
        qset = set(wtoks(qtext[q]))
        g1 = gpx[q]["top5"][0]
        cos_gold = float(max(COS[test_q.index(q), dpos[f.lower()]] for f in gold if f.lower() in dpos))
        cos_top1 = float(COS[test_q.index(q), dpos[g1]]) if g1 in dpos else 0.0
        fk_sum, fk_best = fk_signal(qset, gfid)
        own_idf = ev_profile(qset, gfid)["idf"]
        rows.append({
            "qid": q, "gp_top1": g1,
            "gold_prof": ev_profile(qset, gfid), "top1_prof": ev_profile(qset, g1),
            "fk_sib_idf": fk_sum, "fk_sib_best": fk_best, "own_idf": own_idf,
            "cos_gold": round(cos_gold, 4), "cos_top1": round(cos_top1, 4),
            "dense_ft_right": bool(set(ftd[q]["top5"][:1]) & gold),
            "gp_right": bool(set(gpx[q]["top5"][:1]) & gold),
        })

    A = [r for r in rows if not r["gp_right"]]
    B = [r for r in A if not r["dense_ft_right"]]
    def pct(x, n):
        return f"{x}/{n} ({x/max(n,1):.0%})"
    fkA = sum(1 for r in A if r["fk_sib_idf"] >= r["own_idf"] and r["fk_sib_idf"] > 0)
    fkB = sum(1 for r in B if r["fk_sib_idf"] >= r["own_idf"] and r["fk_sib_idf"] > 0)
    assocA = sum(1 for r in A if r["cos_gold"] - r["cos_top1"] > 0.10 and
                 r["gold_prof"]["idf"] <= r["top1_prof"]["idf"])
    tieA = sum(1 for r in A if abs(r["cos_gold"] - r["cos_top1"]) <= 0.02)
    marg = sorted(r["cos_gold"] - r["cos_top1"] for r in A)
    print(f"weak residue A (gp_ex wrong): {len(A)}; hard core B (dense_ft also wrong): {len(B)}")
    print(f"  FK-sibling evidence >= own evidence: A {pct(fkA, len(A))}  B {pct(fkB, len(B))}")
    print(f"  pure association (dense margin>0.10 & lex tie): A {pct(assocA, len(A))}")
    print(f"  dense sees no difference (|margin|<=0.02): A {pct(tieA, len(A))}")
    print(f"  dense margin median={marg[len(marg)//2] if marg else 0:.3f}")
    json.dump({"A_gp_ex_residue": A, "B_hard_core": [r["qid"] for r in B],
               "summary": {"A": len(A), "B": len(B), "fkA": fkA, "fkB": fkB,
                            "assocA": assocA, "tieA": tieA}},
              open(REPO / "06_结果" / "e12_dissect.json", "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print("wrote 06_结果/e12_dissect.json")


if __name__ == "__main__":
    main()
