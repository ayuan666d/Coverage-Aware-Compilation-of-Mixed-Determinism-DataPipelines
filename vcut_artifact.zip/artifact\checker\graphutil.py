# -*- coding: utf-8 -*-
"""图论基元 —— checker 的地基

设计纪律（见 03_实验/实验方案_v1.0.md §2.1）：
    本模块提供**算法实现**（B 组）。E0 里与之对拍的 A 组必须走不同代码路径
    （穷举），不得调用这里的任何函数。共用实现等于没验。

约定：图是 DAG。所有函数对无环图正确；有环图的行为未定义，调用前须自检。
"""

from __future__ import annotations

from collections import deque
from typing import Dict, FrozenSet, Iterable, List, Mapping, Sequence, Set, Tuple

INF = 10**9


# ── 可达性 ────────────────────────────────────────────────────


def reachable_set(
    start: str,
    succ: Mapping[str, Sequence[str]],
    blocked: FrozenSet[str] = frozenset(),
) -> Set[str]:
    """从 start 出发，避开 blocked，能到达的节点集（含 start 自身）。"""
    if start in blocked:
        return set()
    seen = {start}
    stack = [start]
    while stack:
        n = stack.pop()
        for k in succ.get(n, ()):
            if k not in seen and k not in blocked:
                seen.add(k)
                stack.append(k)
    return seen


def coreachable_set(
    target: str,
    pred: Mapping[str, Sequence[str]],
    blocked: FrozenSet[str] = frozenset(),
) -> Set[str]:
    """能到达 target 的节点集（反向可达），避开 blocked，含 target 自身。"""
    if target in blocked:
        return set()
    seen = {target}
    stack = [target]
    while stack:
        n = stack.pop()
        for k in pred.get(n, ()):
            if k not in seen and k not in blocked:
                seen.add(k)
                stack.append(k)
    return seen


def find_offender_path(
    sources: Sequence[str],
    target: str,
    succ: Mapping[str, Sequence[str]],
    blocked: FrozenSet[str] = frozenset(),
) -> List[str] | None:
    """找一条 sources→target 且完全避开 blocked 的路径。无则返回 None。

    用于报错时给出具体见证，而不只是"不安全"三个字。
    """
    parent: Dict[str, str | None] = {s: None for s in sources if s not in blocked}
    q = deque(parent)
    while q:
        n = q.popleft()
        if n == target:
            path, cur = [], n
            while cur is not None:
                path.append(cur)
                cur = parent[cur]
            return list(reversed(path))
        for k in succ.get(n, ()):
            if k not in blocked and k not in parent:
                parent[k] = n
                q.append(k)
    return None


# ── 路径枚举（小图专用，A 组用）──────────────────────────────


def enumerate_paths(
    sources: Sequence[str],
    sinks: Set[str],
    succ: Mapping[str, Sequence[str]],
    cap: int = 1_000_000,
) -> List[List[str]]:
    """穷举所有 source→sink 简单路径。**指数最坏，只用于小图。**"""
    out: List[List[str]] = []
    stack: List[Tuple[str, List[str]]] = [(s, [s]) for s in sources]
    while stack:
        node, path = stack.pop()
        if node in sinks:
            out.append(path)
            if len(out) > cap:
                raise RuntimeError(f"路径数超过 {cap}，图过大，改用算法实现")
            continue
        for nxt in succ.get(node, ()):
            if nxt in path:
                continue
            stack.append((nxt, path + [nxt]))
    return out


# ── 最大流（Dinic）───────────────────────────────────────────


class _Dinic:
    def __init__(self, n: int) -> None:
        self.n = n
        self.g: List[List[List[int]]] = [[] for _ in range(n)]  # [to, cap, rev]

    def add(self, u: int, v: int, cap: int) -> None:
        self.g[u].append([v, cap, len(self.g[v])])
        self.g[v].append([u, 0, len(self.g[u]) - 1])

    def _bfs(self, s: int, t: int) -> List[int]:
        level = [-1] * self.n
        level[s] = 0
        q = deque([s])
        while q:
            u = q.popleft()
            for v, cap, _ in self.g[u]:
                if cap > 0 and level[v] < 0:
                    level[v] = level[u] + 1
                    q.append(v)
        return level

    def _dfs(self, u: int, t: int, f: int, level: List[int], it: List[int]) -> int:
        if u == t:
            return f
        while it[u] < len(self.g[u]):
            e = self.g[u][it[u]]
            v, cap, rev = e
            if cap > 0 and level[v] == level[u] + 1:
                d = self._dfs(v, t, min(f, cap), level, it)
                if d > 0:
                    e[1] -= d
                    self.g[v][rev][1] += d
                    return d
            it[u] += 1
        return 0

    def maxflow(self, s: int, t: int) -> int:
        flow = 0
        while True:
            level = self._bfs(s, t)
            if level[t] < 0:
                return flow
            it = [0] * self.n
            while True:
                f = self._dfs(s, t, INF, level, it)
                if f == 0:
                    break
                flow += f


def max_vertex_disjoint_paths(
    src: str,
    dst: str,
    nodes: Iterable[str],
    succ: Mapping[str, Sequence[str]],
    blocked: FrozenSet[str] = frozenset(),
) -> int:
    """单源版本。内部实现委托给多源版本。"""
    return max_vertex_disjoint_paths_multi(
        [src], dst, nodes, succ, blocked
    )


def max_vertex_disjoint_paths_multi(
    sources: Sequence[str],
    dst: str,
    nodes: Iterable[str],
    succ: Mapping[str, Sequence[str]],
    blocked: FrozenSet[str] = frozenset(),
) -> int:
    """多源 → 单汇 的最大顶点不相交路径数（= 最小内部顶点割规模，Menger）。

    关键：必须加**超级源**一次求整体割，不能各源分别求再相加。
    反例：s1→x→t 与 s2→x→t，割 {x} 一处即可；分别求会得 1+1=2。

    节点分裂 v → (v_in, v_out)：
        · 源与汇容量 INF（不可被割——割掉源或汇没有工程意义）
        · 其余节点容量 1
        · 边 u→v 变成 u_out → v_in，容量 INF
    """
    live = [n for n in nodes if n not in blocked]
    idx = {n: i for i, n in enumerate(live)}
    srcs = [s for s in sources if s in idx]
    if dst not in idx or not srcs:
        return 0
    if dst in srcs:
        return INF

    n_nodes = len(live)
    S = 2 * n_nodes                      # 超级源
    din = _Dinic(2 * n_nodes + 1)
    vin = lambda n: 2 * idx[n]
    vout = lambda n: 2 * idx[n] + 1

    keep = set(srcs) | {dst}
    for n in live:
        cap = INF if n in keep else 1
        din.add(vin(n), vout(n), cap)
    for u in live:
        for v in succ.get(u, ()):
            if v in idx:
                din.add(vout(u), vin(v), INF)
    for s in srcs:
        din.add(S, vin(s), INF)

    return din.maxflow(S, vin(dst))


def is_vertex_cut(
    src: str,
    dst: str,
    succ: Mapping[str, Sequence[str]],
    cut: FrozenSet[str],
) -> bool:
    """cut 是否构成 src→dst 的顶点割（cut 中节点被移除后 dst 不可达）。"""
    if src == dst:
        return True
    return dst not in reachable_set(src, succ, cut)


# ── 边割（v0.3 修复模型：在边上串判决）────────────────────────


def _build_edge_network(
    sources: Sequence[str],
    dst: str,
    nodes: Iterable[str],
    succ: Mapping[str, Sequence[str]],
    blocked: FrozenSet[str],
):
    """建边容量网络。返回 (Dinic, idx, S, original_edges) 或 None。"""
    live = [n for n in nodes if n not in blocked]
    idx = {n: i for i, n in enumerate(live)}
    srcs = [s for s in sources if s in idx]
    if dst not in idx or not srcs:
        return None
    n = len(live)
    S = n                                  # 超级源
    din = _Dinic(n + 1)
    original = []
    for u in live:
        for v in succ.get(u, ()):
            if v in idx:
                din.add(idx[u], idx[v], 1)
                original.append((u, v))
    for s in srcs:
        din.add(S, idx[s], INF)            # 源不可割
    return din, idx, S, original


def max_edge_disjoint_paths_multi(
    sources: Sequence[str],
    dst: str,
    nodes: Iterable[str],
    succ: Mapping[str, Sequence[str]],
    blocked: FrozenSet[str] = frozenset(),
) -> int:
    """多源 → 单汇 的最大边不相交路径数（= 最小边割规模，Menger 对偶）。

    修复动作是“在边上串一个判决”，所以容量落在边上：
        · 每条原始边容量 1（可作为修复位置，含源出边与汇入边）
        · 超级源到各源 INF（源不可割）
    """
    built = _build_edge_network(sources, dst, nodes, succ, blocked)
    if built is None:
        return 0
    din, _idx, S, _orig = built
    if dst in set(sources):
        return INF
    return din.maxflow(S, _idx[dst])


def min_edge_cut_multi(
    sources: Sequence[str],
    dst: str,
    nodes: Iterable[str],
    succ: Mapping[str, Sequence[str]],
    blocked: FrozenSet[str] = frozenset(),
) -> List[Tuple[str, str]]:
    """返回一个最小边割（具体边位置）。空列表表示源即汇/不可达。"""
    built = _build_edge_network(sources, dst, nodes, succ, blocked)
    if built is None:
        return []
    din, idx, S, original = built
    if dst in set(sources):
        return []
    din.maxflow(S, idx[dst])

    # 残余图从 S 可达的节点
    seen = {S}
    stack = [S]
    while stack:
        u = stack.pop()
        for v, cap, _ in din.g[u]:
            if cap > 0 and v not in seen:
                seen.add(v)
                stack.append(v)
    # 原始边中，从可达侧跨到不可达侧的，就是最小割边
    cut = [(u, v) for (u, v) in original
           if idx[u] in seen and idx[v] not in seen]
    return cut


def is_edge_cut(
    sources: Sequence[str],
    dst: str,
    succ: Mapping[str, Sequence[str]],
    cut_edges: Sequence[Tuple[str, str]],
) -> bool:
    """cut_edges 是否构成所有 sources→dst 的边割。"""
    cut = set(cut_edges)
    blocked_succ = {u: [v for v in succ.get(u, ()) if (u, v) not in cut]
                    for u in succ}
    for s in sources:
        if dst in reachable_set(s, blocked_succ, frozenset()):
            return False
    return True


# ── 图健康检查 ───────────────────────────────────────────────


def has_cycle(nodes: Iterable[str], succ: Mapping[str, Sequence[str]]) -> bool:
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {n: WHITE for n in nodes}
    for start in list(color):
        if color[start] != WHITE:
            continue
        stack: List[Tuple[str, int]] = [(start, 0)]
        color[start] = GRAY
        while stack:
            n, i = stack[-1]
            kids = succ.get(n, ())
            if i < len(kids):
                stack[-1] = (n, i + 1)
                m = kids[i]
                if color.get(m, BLACK) == GRAY:
                    return True
                if color.get(m, WHITE) == WHITE:
                    color[m] = GRAY
                    stack.append((m, 0))
            else:
                color[n] = BLACK
                stack.pop()
    return False
