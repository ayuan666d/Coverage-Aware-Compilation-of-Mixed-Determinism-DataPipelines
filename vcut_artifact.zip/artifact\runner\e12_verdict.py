"""E12 leg 5: acceptance table — which failure classes does each method fix?

Population: the 164 merged-test questions where dense is correct and the E11
explicit graph is wrong (our failure attribution).  Each question carries a
mechanism class (partition, priority order):
  semantic  — no 4-char stem overlap between question and gold schema text
  form      — stem overlap but zero exact word overlap (conductors/conductor)
  trap      — graph top1 supported only by rare (df<=3) tokens
  ambig     — top1's word overlap >= gold's (lexical tie unresolved)
  weak      — 0 < top1 overlap < gold overlap
Plus the exact-SQL split of ambig into value-distinguishable vs not.

For every method we report overall test metrics and, inside the 164, how many
it gets right per class.  Reference rows (E11 graph / E11 bm25 / dense) come
from the E11 JSONs; E12 methods from their own outputs.
"""
from __future__ import annotations

import json
import re
import sqlite3
from collections import Counter
from pathlib import Path

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
SPIDER_DB = WORK / "spider" / "database"

WORD = re.compile(r"[a-z0-9]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us list show give find return
number names name""".split())
QUOTED = re.compile(r'"([^"]+)"|\'([^\']+)\'')
CAPSEQ = re.compile(r"\b([A-Z][a-zA-Z0-9]*(?:\s+[A-Z][a-zA-Z0-9]*)*)\b")
ACRO = re.compile(r"\b([A-Z]{2,}[0-9]*)\b")
NUM = re.compile(r"\b(\d{3,4})\b")


def wtoks(s):
    return [t for t in WORD.findall(s.lower()) if t not in STOP]


def stem4(w):
    return w[:4] if len(w) >= 4 else w


def value_strings(q):
    out = []
    for m in QUOTED.finditer(q):
        v = (m.group(1) or m.group(2)).strip()
        if v:
            out.append(v)
    seen = set()
    for v in [m.group(1) for m in CAPSEQ.finditer(q)] + \
             [m.group(1) for m in ACRO.finditer(q)] + \
             [m.group(1) for m in NUM.finditer(q)]:
        if v.strip() and v.strip().lower() not in seen:
            seen.add(v.strip().lower())
            out.append(v.strip())
    return out


def has_value(db, table_lower, value, handles):
    h = handles.get(db)
    if h is None:
        p = SPIDER_DB / db / f"{db}.sqlite"
        if not p.exists():
            handles[db] = False
            return False
        con = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
        cols = {}
        for (t,) in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"):
            cols[t.lower()] = [c[1] for c in con.execute(f'PRAGMA table_info("{t}")')
                               if c[2] and any(x in c[2].lower() for x in ("text", "char", "varchar"))]
        handles[db] = con, cols
        h = handles[db]
    if h is False:
        return False
    con, cols = h
    v = value.strip().strip("'\"")
    if not v or table_lower not in cols:
        return False
    for col in cols[table_lower]:
        try:
            if con.execute(f'SELECT 1 FROM "{table_lower}" WHERE "{col}" = ? COLLATE NOCASE LIMIT 1',
                           (v,)).fetchone():
                return True
            if len(v) >= 3 and v.isalpha() and con.execute(
                    f'SELECT 1 FROM "{table_lower}" WHERE "{col}" LIKE ? COLLATE NOCASE LIMIT 1',
                    (f"%{v}%",)).fetchone():
                return True
        except sqlite3.Error:
            continue
    return False


def main():
    cache = json.load(open(WORK / "schema_cache.json", encoding="utf-8"))["spider"]
    all_t, stem_t = {}, {}
    for db, s in cache.items():
        for t in s["tables"]:
            fid = f"{db}::{t['name'].lower()}"
            ts = list(wtoks(t["name"])) * 2
            for c in t["columns"]:
                ts += wtoks(c["name"])
                for v in (c.get("values") or [])[:12]:
                    ts += wtoks(str(v))
            all_t[fid] = set(ts)
            stem_t[fid] = {stem4(x) for x in all_t[fid] if len(x) >= 4}
    df = Counter()
    for ts in all_t.values():
        df.update(ts)

    cases = json.load(open(REPO / "06_结果" / "e11_cases.json", encoding="utf-8"))["spider"]
    qtext = {c["qid"]: c["question"] for c in cases}
    e11m = {r["qid"]: r for r in json.load(open(REPO / "06_结果" / "e11_spider_merged.json", encoding="utf-8"))["rows"]}
    e11d = {r["qid"]: r for r in json.load(open(REPO / "06_结果" / "e11_spider_dense.json", encoding="utf-8"))["rows"]}
    spec = {r["qid"]: r for r in json.load(open(REPO / "06_结果" / "e12_spectral.json", encoding="utf-8"))["rows"]}
    gp = json.load(open(REPO / "06_结果" / "e12_gp.json", encoding="utf-8"))
    gp_rows = {r["qid"]: r for r in gp["rows"]["gp"]}
    gpx_rows = {r["qid"]: r for r in gp["rows"]["gp_ex"]}
    ft_path = REPO / "06_结果" / "e12_ft.json"
    ft_rows = {r["qid"]: r for r in json.load(open(ft_path, encoding="utf-8"))["rows"]} if ft_path.exists() else None
    tree_path = REPO / "06_结果" / "e12_tree.json"
    tree_rows = {r["qid"]: r for r in json.load(open(tree_path, encoding="utf-8"))["rows"]} if tree_path.exists() else None

    qids = sorted(qtext, key=lambda q: int(q[2:]))
    test_q = [q for q in qids if next(c["split"] for c in cases if c["qid"] == q) == "test"]

    # taxonomy
    pop164, classes = [], {}
    for q in test_q:
        r = e11m[q]
        gold = set(r["gold"])
        gl = {g.lower() for g in gold}
        g1 = r["ppr_band"]["top5"][0]
        d1 = e11d[q]["dense"]["top5"][0]
        if gl.isdisjoint({d1.lower()}) or (gl & {g1.lower()}):
            continue
        pop164.append(q)
        qset = set(wtoks(qtext[q]))
        qstem = {stem4(w) for w in qset if len(w) >= 4}
        ov_gold = len(qset & all_t[sorted(gold)[0].lower()])
        ov_top1 = len(qset & all_t.get(g1, set()))
        stem_ov = len(qstem & stem_t.get(sorted(gold)[0].lower(), set()))
        shared_top1 = qset & all_t.get(g1, set())
        trap = bool(shared_top1) and all(df[t] <= 3 for t in shared_top1)
        if stem_ov == 0:
            c = "semantic"
        elif ov_gold == 0:
            c = "form"
        elif trap:
            c = "trap"
        elif ov_top1 >= ov_gold:
            c = "ambig"
        else:
            c = "weak"
        classes[q] = {"class": c, "ov_gold": ov_gold, "ov_top1": ov_top1,
                      "stem_ov": stem_ov, "trap_flag": trap, "dense_top1": d1}

    # exact-SQL split of ambig into value-distinguishable or not
    handles = {}
    vdist = {}
    for q in pop164:
        vals = value_strings(qtext[q])
        if not vals:
            vdist[q] = None
            continue
        db = q.split("::")[0] if "::" in q else next(c["db_id"] for c in cases if c["qid"] == q)
        gold = set(e11m[q]["gold"])
        gtab = sorted(gold)[0].split("::", 1)[1]
        d1 = classes[q]["dense_top1"]
        gev = any(has_value(db, gtab, v, handles) for v in vals)
        dtab = d1.split("::", 1)[1]
        ddb = d1.split("::", 1)[0]
        dev = any(has_value(ddb, dtab, v, handles) for v in vals)
        vdist[q] = bool(gev and not dev)
    for q in pop164:
        classes[q]["value_distinguishable"] = vdist[q]

    methods = {
        "e11_graph": {q: e11m[q]["ppr_band"]["top5"] for q in test_q},
        "e11_bm25": {q: e11m[q]["bm25"]["top5"] for q in test_q},
        "dense06b": {q: e11d[q]["dense"]["top5"] for q in test_q},
        "bm25_mine": {q: spec[q]["bm25"]["top5"] for q in test_q},
        "spectral": {q: spec[q]["fused"]["top5"] for q in test_q},
        "gp": {q: gp_rows[q]["top5"] for q in test_q},
        "gp_ex": {q: gpx_rows[q]["top5"] for q in test_q},
    }
    if ft_rows:
        methods["dense_ft"] = {q: ft_rows[q]["top5"] for q in test_q}
    if tree_rows:
        methods["tree_gp"] = {q: tree_rows[q]["top5"] for q in test_q}

    def top1_hit(top5, gold):
        gl = {g.lower() for g in gold}
        return bool(gl & {top5[0].lower()})

    table = {}
    for m, tops in methods.items():
        g_all = [set(e11m[q]["gold"]) for q in test_q]
        r1 = sum(top1_hit(tops[q], g) for q, g in zip(test_q, g_all)) / len(test_q)
        in164 = [q for q in pop164]
        fix_total = sum(top1_hit(tops[q], set(e11m[q]["gold"])) for q in in164)
        by_class = Counter()
        for q in in164:
            if top1_hit(tops[q], set(e11m[q]["gold"])):
                by_class[classes[q]["class"]] += 1
        cnt = Counter(classes[q]["class"] for q in in164)
        vd = sum(1 for q in in164 if vdist[q])
        fixed_vd = sum(1 for q in in164 if vdist[q] and top1_hit(tops[q], set(e11m[q]["gold"])))
        table[m] = {"top1_hit_all": round(r1, 4), "fixed_in_164": fix_total,
                    "by_class": dict(by_class), "class_sizes": dict(cnt),
                    "value_distinguishable": vd, "fixed_value_distinguishable": fixed_vd}

    out = {"n164": len(pop164), "classes": classes, "table": table}
    json.dump(out, open(REPO / "06_结果" / "e12_verdict.json", "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(f"population: dense-correct & graph-wrong = {len(pop164)}")
    print("class sizes:", json.dumps(table["gp"]["class_sizes"]))
    print(f"value-distinguishable among 164: {table['gp']['value_distinguishable']}")
    hdr = f"{'method':12s} {'top1@341':>8s} {'fix164':>7s} " + " ".join(f"{c:>8s}" for c in ("semantic", "form", "trap", "ambig", "weak"))
    print(hdr)
    for m, t in table.items():
        bc = t["by_class"]
        print(f"{m:12s} {t['top1_hit_all']:8.1%} {t['fixed_in_164']:7d} " +
              " ".join(f"{bc.get(c, 0):8d}" for c in ("semantic", "form", "trap", "ambig", "weak")) +
              f"   fixVD {t['fixed_value_distinguishable']}/{t['value_distinguishable']}")
    # head-to-head: where gp_ex wrong but dense right inside 164 = dense's irreplaceable residue
    residue = [q for q in pop164 if not top1_hit(methods["gp_ex"][q], set(e11m[q]["gold"]))]
    rc = Counter(classes[q]["class"] for q in residue)
    print("dense-irreplaceable residue (gp_ex wrong, dense right):", dict(rc))


if __name__ == "__main__":
    main()
