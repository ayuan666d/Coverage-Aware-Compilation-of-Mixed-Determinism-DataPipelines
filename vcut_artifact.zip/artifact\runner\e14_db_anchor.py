"""E14: one new primitive — database-level anchor.

E13 showed the second-order closed form beats GA (85.7 vs 82.2 R@5) but loses
R@1 (48.2 vs 51.2).  The missing class is cross-database ambiguity (ambig, 19
questions; GA repairs 3-4, dense repairs 18-19).  The 11 E12 primitives contain
no database-level signal.  This arm adds exactly one:

  f11 = question-token overlap with the database name (digits stripped)

Everything else is frozen bit-for-bit against e13 (same documents, same
standardization, same second-order closure).  One primitive, one delta.
"""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from pathlib import Path

import numpy as np

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
CASES = REPO / "06_结果" / "e11_cases.json"
CACHE = WORK / "schema_cache.json"
NPZ = WORK / "e12_spectral.npz"
EXACT = REPO / "06_结果" / "e12_exact.json"
OUT = REPO / "06_结果" / "e14_db_anchor.json"

WORD = re.compile(r"[a-z0-9]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us list show give find return
number names name""".split())


def wtoks(s):
    return [t for t in WORD.findall(s.lower()) if t not in STOP]


def ngrams(w, ns=(3, 4, 5)):
    pad = f"<{w}>"
    return {pad[i:i + n] for n in ns for i in range(len(pad) - n + 1)} if len(pad) >= 3 else set()


def stem4(w):
    return w[:4] if len(w) >= 4 else w


def metrics_top(top_ids, gold_set):
    r = {1: 0.0, 3: 0.0, 5: 0.0}
    mrr = 0.0
    for i, d in enumerate(top_ids[:5]):
        if d in gold_set:
            mrr = max(mrr, 1.0 / (i + 1))
            for k in r:
                if i < k:
                    r[k] += 1.0 / len(gold_set)
    return r, mrr


def load():
    z = np.load(NPZ, allow_pickle=True)
    doc_ids = [str(x) for x in z["doc_ids"]]
    didx = {f: i for i, f in enumerate(doc_ids)}
    D = len(doc_ids)
    doc_wn = z["doc_word"] / np.maximum(np.linalg.norm(z["doc_word"], axis=1, keepdims=True), 1e-9)
    doc_gn = z["doc_gram"] / np.maximum(np.linalg.norm(z["doc_gram"], axis=1, keepdims=True), 1e-9)

    cache = json.load(open(CACHE, encoding="utf-8"))["spider"]
    name_t, col_t, val_t, all_t, stem_t, db_t = {}, {}, {}, {}, {}, {}
    for db, s in cache.items():
        dbname = re.sub(r"\d+$", "", db)
        for t in s["tables"]:
            fid = f"{db}::{t['name'].lower()}"
            nm = list(wtoks(t["name"]))
            cl, vl = [], []
            for c in t["columns"]:
                cl += wtoks(c["name"])
                for v in (c.get("values") or [])[:12]:
                    vl += wtoks(str(v))
            name_t[fid], col_t[fid], val_t[fid] = set(nm), set(cl), set(vl)
            all_t[fid] = set(nm) | set(cl) | set(vl)
            stem_t[fid] = {stem4(x) for x in all_t[fid] if len(x) >= 4}
            db_t[fid] = set(wtoks(dbname))

    df = Counter()
    for ts in all_t.values():
        df.update(ts)
    N = D
    idf = {t: math.log(1 + (N - df[t] + 0.5) / (df[t] + 0.5)) for t in df}
    tf = np.zeros((D, len(df)), dtype=np.float32)
    tidx = {t: i for i, t in enumerate(sorted(df))}
    for j, f in enumerate(doc_ids):
        for t in all_t[f]:
            tf[j, tidx[t]] = 1.0
    dlr = tf.sum(axis=1)

    exact = {r["qid"]: r for r in json.load(open(EXACT, encoding="utf-8"))}
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    gold_all = {c["qid"]: {f"{c['db_id']}::{g.lower()}" for g in c["gold"]} for c in cases}
    qtext = {c["qid"]: c["question"] for c in cases}
    split = {c["qid"]: c["split"] for c in cases}
    qids = sorted(qtext, key=lambda q: int(q[2:]))
    train_q = [q for q in qids if split[q] == "train"]
    test_q = [q for q in qids if split[q] == "test"]

    wv_vocab = {t: i for i, t in enumerate(z["word_vocab"])}
    gr_vocab = {t: i for i, t in enumerate(z["gram_vocab"])}
    term_w, term_g = z["term_word"], z["term_gram"]

    def q_latent(tokens, vocab, term):
        vs = [term[vocab[t]] for t in set(tokens) if t in vocab]
        if not vs:
            return None
        v = np.mean(vs, axis=0)
        return v / max(np.linalg.norm(v), 1e-9)

    def build_F(qs):
        nf = 12
        F = np.zeros((len(qs), D, nf), dtype=np.float32)
        for qi, q in enumerate(qs):
            qt = wtoks(qtext[q])
            qset = set(qt)
            qstem = {stem4(w) for w in qt if len(w) >= 4}
            wv = q_latent(qt, wv_vocab, term_w)
            gv = q_latent([g for w in qt for g in ngrams(w)], gr_vocab, term_g)
            if wv is not None:
                F[qi, :, 4] = doc_wn @ wv
            if gv is not None:
                F[qi, :, 5] = doc_gn @ gv
            s = np.zeros(D, dtype=np.float32)
            for t, qc in Counter(qt).items():
                if t not in tidx:
                    continue
                col = tf[:, tidx[t]]
                s += qc * idf[t] * (col * 2.2) / (col + 1.2 * (0.25 + 0.75 * dlr / (dlr.mean() + 1e-9)))
            F[qi, :, 3] = s
            ex = F[qi, :, 10]
            if q in exact:
                for fid, ev in zip(exact[q]["pool"], exact[q]["evidence"]):
                    j = didx.get(fid)
                    if j is not None:
                        ex[j] = ev
            for j, f in enumerate(doc_ids):
                inter = qset & all_t[f]
                F[qi, j, 0] = len(inter)
                F[qi, j, 1] = sum(idf.get(t, 0.0) for t in inter)
                F[qi, j, 2] = len(qstem & stem_t[f])
                F[qi, j, 6] = len(qset & name_t[f])
                F[qi, j, 7] = len(qset & col_t[f])
                F[qi, j, 8] = len(qset & val_t[f])
                F[qi, j, 11] = len(qset & db_t[f])
        F[:, :, 9] = np.log1p(F[:, :, 6]) * np.log1p(F[:, :, 7]) * np.log1p(F[:, :, 8])
        return F

    return dict(doc_ids=doc_ids, didx=didx, D=D, cases=cases, gold_all=gold_all,
                train_q=train_q, test_q=test_q, build_F=build_F)


def quad(X, idx):
    out = np.empty((X.shape[0], len(idx)), dtype=np.float32)
    for k, (i, j) in enumerate(idx):
        out[:, k] = X[:, i] * X[:, j]
    return out


def fit(Fn, y, lam):
    A = Fn.T @ Fn + lam * np.eye(Fn.shape[1], dtype=np.float32)
    b = Fn.T @ y
    return np.linalg.solve(A.astype(np.float64), b.astype(np.float64)).astype(np.float32)


def evaluate(meta, Fte, w):
    rows = []
    for qi, q in enumerate(meta["test_q"]):
        sc = Fte[qi] @ w
        order = np.argsort(-sc)[:5]
        top = [meta["doc_ids"][i] for i in order]
        r, m = metrics_top(top, meta["gold_all"][q])
        db = next(c["db_id"] for c in meta["cases"] if c["qid"] == q)
        rows.append({"qid": q, "db": db, "gold": sorted(meta["gold_all"][q]),
                     "top5": top, "recall@1": r[1], "recall@3": r[3],
                     "recall@5": r[5], "mrr": m})
    n = len(rows)
    summ = {k: round(sum(r[k] for r in rows) / n, 4)
            for k in ("recall@1", "recall@3", "recall@5", "mrr")}
    return summ, rows


def main():
    meta = load()
    print("building train features (12 primitives)…", flush=True)
    Ft = meta["build_F"](meta["train_q"])
    mu = Ft.reshape(-1, Ft.shape[-1]).mean(0)
    sd = Ft.reshape(-1, Ft.shape[-1]).std(0) + 1e-9
    Fn = ((Ft - mu) / sd).reshape(-1, Ft.shape[-1])
    Y = np.zeros((len(meta["train_q"]), meta["D"]), dtype=np.float32)
    for qi, q in enumerate(meta["train_q"]):
        for f in meta["gold_all"][q]:
            j = meta["didx"].get(f)
            if j is not None:
                Y[qi, j] = 1.0
    y = Y.reshape(-1)

    w1 = fit(Fn, y, lam=1.0)
    Fte1 = ((meta["build_F"](meta["test_q"]) - mu) / sd)
    s1, rows1 = evaluate(meta, Fte1, w1)
    print("e14 first-order:", json.dumps(s1), flush=True)

    idx = [(i, j) for i in range(12) for j in range(i, 12)]
    Fq = quad(Fn, idx)
    Fn2 = np.concatenate([Fn, Fq], axis=1)
    del Fq
    w2 = fit(Fn2, y, lam=10.0)
    Fq_te = quad(Fte1.reshape(-1, 12), idx)
    Fte2 = np.concatenate([Fte1.reshape(-1, 12), Fq_te], axis=1).reshape(
        len(meta["test_q"]), meta["D"], -1)
    s2, rows2 = evaluate(meta, Fte2, w2)
    print("e14 second-order:", json.dumps(s2), flush=True)

    json.dump({"first_order": {"test": s1, "weights": w1.tolist(), "rows": rows1},
               "second_order": {"test": s2, "weights": w2.tolist(), "rows": rows2},
               "features": {"first": 12, "second": len(idx)},
               "delta_vs_e13": {"r1": round(s2["recall@1"] - 0.4819, 4),
                                "r5": round(s2["recall@5"] - 0.8568, 4)},
               "reference": {"e13_cf2_r1": 0.4819, "e13_cf2_r5": 0.8568,
                             "ga_gp_ex_r1": 0.5122, "ga_gp_ex_r5": 0.8216,
                             "dense_zero_r1": 0.586, "dense_zero_r5": 0.8793}},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
