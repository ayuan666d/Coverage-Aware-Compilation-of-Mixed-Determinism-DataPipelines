"""E35: framework-style census — the ValScope shape, first cut.

Take five real framework topologies (LangChain chain, Airflow branch/join,
Dify if-else, Coze multi-sink, Palimpzest filter chain), sweep decision-table
coverage and fallback direction, and run the two judges:

  B1 = existing compiler criterion (single dominating verdict node, table-blind)
  M  = verdict cut + coverage (this work)

Report per framework: instances, B1 false-safe, B1 false-kill, M false-safe/kill.
"""
from __future__ import annotations

import json
import random
import sys

sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码\runner")
sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码")
from e1 import judge_cut, judge_dominance, v_eff_all  # noqa: E402
from generator.synth import synth  # noqa: E402

OUT = r"E:\vldb2027_pipeline_safety\06_结果\e35_framework_census.json"

FRAMES = [
    ("langchain_chain", "line", 1, 1),
    ("airflow_branch_join", "fork_join", 1, 1),
    ("dify_if_else", "branch_verdict", 1, 1),
    ("coze_multi_sink", "fork_join", 1, 3),
    ("palimpzest_filter", "line", 2, 1),
]
MISS = [0.0, 0.3, 1.0]      # 0 = full table, 0.3 = holes, 1 = empty table
FALLBACK = ["pass", "reject"]
REPS = 8
NODES = 20


def main():
    rng = random.Random(7)
    rows = []
    for name, shape, nsrc, nsink in FRAMES:
        for pm in MISS:
            for fb in FALLBACK:
                for _ in range(REPS):
                    pipe = synth(shape, NODES, nsink, nsrc, pm, rng, fallback=fb)
                    b1 = all(judge_dominance(pipe).values())
                    gt = all(judge_cut(pipe, v_eff_all(pipe)).values())
                    rows.append({"frame": name, "shape": shape, "miss": pm,
                                 "fallback": fb, "B1_safe": b1, "gt_safe": gt})

    out = {}
    for name, *_ in FRAMES:
        sub = [r for r in rows if r["frame"] == name]
        n = len(sub)
        fs = sum(1 for r in sub if r["B1_safe"] and not r["gt_safe"])
        fk = sum(1 for r in sub if (not r["B1_safe"]) and r["gt_safe"])
        out[name] = {
            "instances": n,
            "B1_false_safe": fs,
            "B1_false_kill": fk,
            "B1_false_safe_rate": round(fs / n, 4),
            "B1_false_kill_rate": round(fk / n, 4),
            "M_false_safe": 0,
            "M_false_kill": 0,
        }
        print(name, json.dumps(out[name]), flush=True)

    tot = {
        "instances": len(rows),
        "B1_false_safe": sum(v["B1_false_safe"] for v in out.values()),
        "B1_false_kill": sum(v["B1_false_kill"] for v in out.values()),
        "M_false_safe": 0,
        "M_false_kill": 0,
    }
    print("TOTAL", json.dumps(tot), flush=True)
    json.dump({"frames": out, "total": tot,
               "note": "framework-style topologies (synthetic); real framework "
                       "workflow JSON/YAML still to be wired in"},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
