"""E37: entry matrix — which trigger entry can reach a high-risk sink without
passing the before_tool_call approval hook.

Static first cut.  For each entry module, check whether its code path mentions
the approval hook (or imports the tool adapter that installs it) and whether it
can reach a high-risk action (send/exec/write/apply/spawn/delete).

A row with high_risk=True and hook_in_path=False is an uncovered entry: an
approval that is not a cut over all entries.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

BASE = Path(r"D:\dev\openclaw\src")
OUT = Path(r"E:\vldb2027_pipeline_safety\06_结果\e37_entry_matrix.json")

ENTRIES = [
    ("agent_tool_adapter", "agents/agent-tool-definition-adapter.ts"),
    ("cron_tool", "agents/tools/cron-tool.ts"),
    ("heartbeat", "agents/tools/heartbeat-response-tool.ts"),
    ("embedded_gateway", "agents/tools/embedded-gateway-stub.ts"),
    ("sessions_spawn", "agents/tools/sessions-spawn-tool.ts"),
    ("sessions_send", "agents/tools/sessions-send-tool.ts"),
    ("sessions_send_a2a", "agents/tools/sessions-send-tool.a2a.ts"),
    ("skill_workshop", "agents/tools/skill-workshop-tool.ts"),
    ("gateway_tool", "agents/tools/gateway-tool.ts"),
    ("subagents_tool", "agents/tools/subagents-tool.ts"),
]

HOOK = re.compile(r"beforeToolCall|runBeforeToolCallHook|before_tool_call|"
                  r"hookBeforeToolCall|agent-tool-definition-adapter", re.I)
HIGH = re.compile(r"\b(send|exec|write|apply|spawn|command|delete)\b", re.I)


def main():
    rows = []
    for name, rel in ENTRIES:
        p = BASE / rel
        if not p.exists():
            rows.append({"entry": name, "exists": False})
            continue
        txt = p.read_text(encoding="utf-8", errors="ignore")
        hook = bool(HOOK.search(txt))
        high = bool(HIGH.search(txt))
        rows.append({"entry": name, "exists": True, "hook_in_path": hook,
                     "high_risk": high, "uncovered": high and not hook,
                     "loc": len(txt)})

    out = {
        "entries": rows,
        "uncovered": [r["entry"] for r in rows if r.get("uncovered")],
        "note": "static first cut: hook_in_path is textual evidence, not a call graph",
    }
    print(json.dumps(out, ensure_ascii=False, indent=1), flush=True)
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
