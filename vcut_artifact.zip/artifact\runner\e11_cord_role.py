"""E11: does a typed relation layer separate role from proximity?

Each CORD receipt is a token sequence.  The query is the word ``total``; the
candidates are the numeric tokens.  The single-layer operator sees only
adjacency, so ``cash`` (often printed next to the total amount) is a strong
distractor.  The typed operator adds role edges from total/payment/subtotal
labels to nearby amounts.

This is the falsification test for the claim that one undirected Laplacian is
enough: on receipts where the nearest amount to ``total`` is a payment amount,
the single operator should fail and the typed one should not.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import numpy as np
from scipy import sparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e7j_label_synth as e7j  # noqa: E402
from e11_graph import ppr, rownorm  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
RAW = REPO / "06_结果" / "e7_receipts.json"
OUT = REPO / "06_结果" / "e11_cord_role.json"

TOTAL = {"total", "grand total", "netto", "due", "amount due", "total due", "tl", "paid"}
PAY = {"cash", "change", "gopay", "debit", "card", "credit", "kupon", "voucher", "t-cash", "qris"}
SUB = {"subtotal", "sub total", "sub-total"}
DISC = {"discount", "diskon", "potongan", "saving", "savings"}


def label_role(tok: str) -> str:
    t = re.sub(r"[^a-z ]", " ", tok.lower()).strip()
    t = re.sub(r"\s+", " ", t)
    if t in TOTAL:
        return "total"
    if t in PAY:
        return "pay"
    if t in SUB:
        return "sub"
    if t in DISC:
        return "disc"
    return "other"


def build(text: str):
    toks = [t.strip() for t in text.split("|")]
    n = len(toks)
    nums = [(i, e7j.num(t)) for i, t in enumerate(toks)]
    nums = [(i, v) for i, v in nums if v is not None and v >= 100]
    labels = [(i, label_role(t)) for i, t in enumerate(toks) if label_role(t) != "other"]

    # adjacency: window of 5 tokens, decaying with distance
    r, c, w = [], [], []
    for i in range(n):
        for d in range(1, 6):
            j = i + d
            if j >= n:
                break
            ww = 1.0 / d
            r += [i, j]; c += [j, i]; w += [ww, ww]
    adj = sparse.coo_matrix((w, (r, c)), shape=(n, n)).tocsr()

    # typed role edges: label -> nearby amount
    rr, cc, ww = [], [], []
    role_w = {"total": 3.0, "sub": 0.6, "pay": 0.15, "disc": 0.3}
    for i, role in labels:
        for j, v in nums:
            d = abs(i - j)
            if 0 < d <= 5:
                wt = role_w[role] / d
                rr += [i, j]; cc += [j, i]; ww += [wt, wt]
    role = sparse.coo_matrix((ww, (rr, cc)), shape=(n, n)).tocsr()
    return toks, nums, labels, adj, role


def pick(scores, nums):
    best = {}
    for i, v in nums:
        if scores[i] > best.get(v, -1):
            best[v] = scores[i]
    if not best:
        return None, None
    v = max(best, key=best.get)
    return v, best[v]


def match(a, b):
    return e7j.match(a, b) is True


def main():
    rows = json.load(open(RAW, encoding="utf-8"))["rows"]
    out, trap = [], []
    for r in rows:
        gold = r.get("gold", {}).get("total")
        if gold is None:
            continue
        text = r.get("text") or ""
        toks, nums, labels, adj, role = build(text)
        if not nums:
            continue
        total_seeds = {i: 1.0 for i, x in labels if x == "total"}
        if not total_seeds:
            total_seeds = {i: 1.0 for i, t in enumerate(toks) if "total" in t.lower()}
        if not total_seeds:
            continue
        # All-label query: the untyped operator cannot tell a total label from
        # a cash/change label, which is the E10 role trap.
        all_seeds = {}
        seed_w = {"total": 1.0, "sub": 1.0, "pay": 1.0, "disc": 1.0}
        for i, x in labels:
            all_seeds[i] = all_seeds.get(i, 0.0) + seed_w[x]
        Ps = rownorm(adj)
        Pt = rownorm(adj + 2.0 * role)
        xs, _ = pick(ppr(Ps, total_seeds, alpha=0.85, iters=30), nums)
        xt, _ = pick(ppr(Pt, total_seeds, alpha=0.85, iters=30), nums)
        xsa, _ = pick(ppr(Ps, all_seeds, alpha=0.85, iters=30), nums)
        xta, _ = pick(ppr(Pt, all_seeds, alpha=0.85, iters=30), nums)
        vs, vt, vsa, vta = xs, xt, xsa, xta
        # A layout trap: the numeric token nearest to a total label is even
        # nearer to a payment label (cash/change/gopay/...).  The single
        # adjacency operator has no way to prefer the total edge.
        tot = [i for i, x in labels if x == "total"]
        pay = [i for i, x in labels if x == "pay"]
        is_trap = False
        for i in tot:
            near = min(nums, key=lambda x: abs(x[0] - i))
            d_tot = abs(near[0] - i)
            d_pay = min((abs(near[0] - j) for j in pay), default=999)
            if d_pay < d_tot:
                is_trap = True
                break
        row = {"file": r["file"], "gold": gold,
               "single": vs, "typed": vt,
               "single_all": vsa, "typed_all": vta,
               "single_ok": match(vs, gold), "typed_ok": match(vt, gold),
               "single_all_ok": match(vsa, gold), "typed_all_ok": match(vta, gold),
               "trap": is_trap, "n_nums": len(nums)}
        out.append(row)
        if is_trap:
            trap.append(row)

    def agg(rs):
        n = len(rs)
        return {"n": n,
                "single_acc": round(sum(x["single_ok"] for x in rs) / n, 4),
                "typed_acc": round(sum(x["typed_ok"] for x in rs) / n, 4),
                "single_all_acc": round(sum(x["single_all_ok"] for x in rs) / n, 4),
                "typed_all_acc": round(sum(x["typed_all_ok"] for x in rs) / n, 4),
                "fixed": sum((not x["single_ok"]) and x["typed_ok"] for x in rs),
                "broke": sum(x["single_ok"] and (not x["typed_ok"]) for x in rs),
                "all_fixed": sum((not x["single_all_ok"]) and x["typed_all_ok"] for x in rs),
                "all_broke": sum(x["single_all_ok"] and (not x["typed_all_ok"]) for x in rs)}
    res = {"all": agg(out), "trap": agg(trap) if trap else None,
           "rows": out}
    json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in res.items() if k != "rows"}, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
