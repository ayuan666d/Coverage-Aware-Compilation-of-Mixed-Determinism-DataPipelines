"""E13: closed-form readout vs searched readout.

Hypothesis: the linear readout that the GA searches for is a covariance ratio,
obtainable in closed form by ridge regression over (question, table) evidence
pairs.  Two arms:
  cf1  -- first-order closed form (11 primitives, one solve)
  cf2  -- second-order closed form (+ 66 interaction/square terms)
Same features, documents, split and metric as e12_gp.py.
Reference: GA gp_ex test R@5 = 82.2.
"""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from pathlib import Path

import numpy as np

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
CASES = REPO / "06_结果" / "e11_cases.json"
CACHE = WORK / "schema_cache.json"
NPZ = WORK / "e12_spectral.npz"
EXACT = REPO / "06_结果" / "e12_exact.json"
OUT = REPO / "06_结果" / "e13_closed_form.json"

WORD = re.compile(r"[a-z0-9]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us list show give find return
number names name""".split())


def wtoks(s):
    return [t for t in WORD.findall(s.lower()) if t not in STOP]


def ngrams(w, ns=(3, 4, 5)):
    pad = f"<{w}>"
    return {pad[i:i + n] for n in ns for i in range(len(pad) - n + 1)} if len(pad) >= 3 else set()


def stem4(w):
    return w[:4] if len(w) >= 4 else w


def metrics_top(top_ids, gold_set):
    r = {1: 0.0, 3: 0.0, 5: 0.0}
    mrr = 0.0
    for i, d in enumerate(top_ids[:5]):
        if d in gold_set:
            mrr = max(mrr, 1.0 / (i + 1))
            for k in r:
                if i < k:
                    r[k] += 1.0 / len(gold_set)
    return r, mrr


def load():
    z = np.load(NPZ, allow_pickle=True)
    doc_ids = [str(x) for x in z["doc_ids"]]
    didx = {f: i for i, f in enumerate(doc_ids)}
    D = len(doc_ids)
    doc_wn = z["doc_word"] / np.maximum(np.linalg.norm(z["doc_word"], axis=1, keepdims=True), 1e-9)
    doc_gn = z["doc_gram"] / np.maximum(np.linalg.norm(z["doc_gram"], axis=1, keepdims=True), 1e-9)

    cache = json.load(open(CACHE, encoding="utf-8"))["spider"]
    name_t, col_t, val_t, all_t, stem_t = {}, {}, {}, {}, {}
    for db, s in cache.items():
        for t in s["tables"]:
            fid = f"{db}::{t['name'].lower()}"
            nm = list(wtoks(t["name"]))
            cl, vl = [], []
            for c in t["columns"]:
                cl += wtoks(c["name"])
                for v in (c.get("values") or [])[:12]:
                    vl += wtoks(str(v))
            name_t[fid], col_t[fid], val_t[fid] = set(nm), set(cl), set(vl)
            all_t[fid] = set(nm) | set(cl) | set(vl)
            stem_t[fid] = {stem4(x) for x in all_t[fid] if len(x) >= 4}

    df = Counter()
    for ts in all_t.values():
        df.update(ts)
    N = D
    idf = {t: math.log(1 + (N - df[t] + 0.5) / (df[t] + 0.5)) for t in df}
    tf = np.zeros((D, len(df)), dtype=np.float32)
    tidx = {t: i for i, t in enumerate(sorted(df))}
    for j, f in enumerate(doc_ids):
        for t in all_t[f]:
            tf[j, tidx[t]] = 1.0
    dlr = tf.sum(axis=1)

    exact = {r["qid"]: r for r in json.load(open(EXACT, encoding="utf-8"))}
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    gold_all = {c["qid"]: {f"{c['db_id']}::{g.lower()}" for g in c["gold"]} for c in cases}
    qtext = {c["qid"]: c["question"] for c in cases}
    split = {c["qid"]: c["split"] for c in cases}
    qids = sorted(qtext, key=lambda q: int(q[2:]))
    train_q = [q for q in qids if split[q] == "train"]
    test_q = [q for q in qids if split[q] == "test"]

    wv_vocab = {t: i for i, t in enumerate(z["word_vocab"])}
    gr_vocab = {t: i for i, t in enumerate(z["gram_vocab"])}
    term_w, term_g = z["term_word"], z["term_gram"]

    def q_latent(tokens, vocab, term):
        vs = [term[vocab[t]] for t in set(tokens) if t in vocab]
        if not vs:
            return None
        v = np.mean(vs, axis=0)
        return v / max(np.linalg.norm(v), 1e-9)

    def build_F(qs):
        nf = 11
        F = np.zeros((len(qs), D, nf), dtype=np.float32)
        for qi, q in enumerate(qs):
            qt = wtoks(qtext[q])
            qset = set(qt)
            qstem = {stem4(w) for w in qt if len(w) >= 4}
            wv = q_latent(qt, wv_vocab, term_w)
            gv = q_latent([g for w in qt for g in ngrams(w)], gr_vocab, term_g)
            if wv is not None:
                F[qi, :, 4] = doc_wn @ wv
            if gv is not None:
                F[qi, :, 5] = doc_gn @ gv
            s = np.zeros(D, dtype=np.float32)
            for t, qc in Counter(qt).items():
                if t not in tidx:
                    continue
                col = tf[:, tidx[t]]
                s += qc * idf[t] * (col * 2.2) / (col + 1.2 * (0.25 + 0.75 * dlr / (dlr.mean() + 1e-9)))
            F[qi, :, 3] = s
            ex = F[qi, :, 10]
            if q in exact:
                for fid, ev in zip(exact[q]["pool"], exact[q]["evidence"]):
                    j = didx.get(fid)
                    if j is not None:
                        ex[j] = ev
            for j, f in enumerate(doc_ids):
                inter = qset & all_t[f]
                F[qi, j, 0] = len(inter)
                F[qi, j, 1] = sum(idf.get(t, 0.0) for t in inter)
                F[qi, j, 2] = len(qstem & stem_t[f])
                F[qi, j, 6] = len(qset & name_t[f])
                F[qi, j, 7] = len(qset & col_t[f])
                F[qi, j, 8] = len(qset & val_t[f])
        F[:, :, 9] = np.log1p(F[:, :, 6]) * np.log1p(F[:, :, 7]) * np.log1p(F[:, :, 8])
        return F

    return dict(doc_ids=doc_ids, didx=didx, D=D, cases=cases, gold_all=gold_all,
                train_q=train_q, test_q=test_q, build_F=build_F)


def quad(X, idx):
    out = np.empty((X.shape[0], len(idx)), dtype=np.float32)
    for k, (i, j) in enumerate(idx):
        out[:, k] = X[:, i] * X[:, j]
    return out


def fit(Fn, y, lam):
    A = Fn.T @ Fn + lam * np.eye(Fn.shape[1], dtype=np.float32)
    b = Fn.T @ y
    return np.linalg.solve(A.astype(np.float64), b.astype(np.float64)).astype(np.float32)


def evaluate(meta, Fte, w):
    rows = []
    for qi, q in enumerate(meta["test_q"]):
        sc = Fte[qi] @ w
        order = np.argsort(-sc)[:5]
        top = [meta["doc_ids"][i] for i in order]
        r, m = metrics_top(top, meta["gold_all"][q])
        db = next(c["db_id"] for c in meta["cases"] if c["qid"] == q)
        rows.append({"qid": q, "db": db, "gold": sorted(meta["gold_all"][q]),
                     "top5": top, "recall@1": r[1], "recall@3": r[3],
                     "recall@5": r[5], "mrr": m})
    n = len(rows)
    summ = {k: round(sum(r[k] for r in rows) / n, 4)
            for k in ("recall@1", "recall@3", "recall@5", "mrr")}
    return summ, rows


def main():
    meta = load()
    print("building train features…", flush=True)
    Ft = meta["build_F"](meta["train_q"])
    mu = Ft.reshape(-1, Ft.shape[-1]).mean(0)
    sd = Ft.reshape(-1, Ft.shape[-1]).std(0) + 1e-9
    Fn = ((Ft - mu) / sd).reshape(-1, Ft.shape[-1])
    Y = np.zeros((len(meta["train_q"]), meta["D"]), dtype=np.float32)
    for qi, q in enumerate(meta["train_q"]):
        for f in meta["gold_all"][q]:
            j = meta["didx"].get(f)
            if j is not None:
                Y[qi, j] = 1.0
    y = Y.reshape(-1)
    print("train pairs:", Fn.shape, "positives:", float(y.sum()), flush=True)

    w1 = fit(Fn, y, lam=1.0)
    Fte1 = ((meta["build_F"](meta["test_q"]) - mu) / sd)
    s1, rows1 = evaluate(meta, Fte1, w1)
    print("cf1:", json.dumps(s1), flush=True)

    idx = [(i, j) for i in range(11) for j in range(i, 11)]
    print("second-order terms:", len(idx), flush=True)
    Fq = quad(Fn, idx)
    Fn2 = np.concatenate([Fn, Fq], axis=1)
    del Fq
    w2 = fit(Fn2, y, lam=10.0)
    Fq_te = quad(Fte1.reshape(-1, 11), idx)
    Fte2 = np.concatenate([Fte1.reshape(-1, 11), Fq_te], axis=1).reshape(
        len(meta["test_q"]), meta["D"], -1)
    s2, rows2 = evaluate(meta, Fte2, w2)
    print("cf2:", json.dumps(s2), flush=True)

    sweep = {}
    for lam in (0.3, 3.0, 30.0, 100.0):
        w = fit(Fn2, y, lam=lam)
        ss, _ = evaluate(meta, Fte2, w)
        sweep[str(lam)] = ss["recall@5"]
    print("cf2 lambda sweep:", sweep, flush=True)

    json.dump({"cf1": {"lambda": 1.0, "test": s1, "weights": w1.tolist(), "rows": rows1},
               "cf2": {"lambda": 10.0, "test": s2, "weights": w2.tolist(),
                       "lambda_sweep": sweep, "rows": rows2},
               "features": {"first": 11, "second": len(idx)},
               "reference": {"ga_gp_ex_r5": 0.8216, "ga_gp_r5": 0.8172,
                             "bm25_r5": 0.5924, "dense_zero_r5": 0.8793}},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
