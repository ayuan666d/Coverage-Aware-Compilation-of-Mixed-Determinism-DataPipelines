"""E7f: a purely deterministic total reader from OCR tokens.

No model call: find the total label ("total", "grand total", "netto", "due",
"tl", ...) and take the amount printed next to it.  This is the "database can
compute it itself" baseline.  We compare it with the model total and the gold
total, and measure whether agreement between the two witnesses certifies the
answer on the E7e 500-receipt run.
"""
from __future__ import annotations

import difflib
import json
import re
from collections import Counter
from pathlib import Path

import pandas as pd

REPO = Path(__file__).resolve().parents[2]
DATA = REPO / "04_数据" / "external" / "cord" / "train.parquet"
E7E = REPO / "06_结果" / "e7_receipts.json"
OUT = REPO / "06_结果" / "e7f_ocr_total.json"

TOTAL_KEYS = ("grand total", "total", "amount due", "total due", "due",
              "netto", "net", "paid", "payment", "debit", "tl")


def num(s):
    if s is None:
        return None
    s = str(s).strip().replace(" ", "")
    s = re.sub(r"[^0-9,.\-]", "", s)
    if not s or s in "-":
        return None
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        parts = s.split(",")
        if len(parts) > 1 and all(len(p) == 3 for p in parts[1:]):
            s = "".join(parts)
        else:
            s = s.replace(",", ".")
    elif "." in s:
        parts = s.split(".")
        if len(parts) > 1 and all(len(p) == 3 for p in parts[1:]):
            s = "".join(parts)
    try:
        return int(round(float(s)))
    except Exception:
        return None


def is_total_label(t: str) -> bool:
    t = t.strip().lower()
    if not t:
        return False
    if any(k in t for k in ("subtotal", "sub total", "sub-total", "total item", "total qty")):
        return False
    for k in TOTAL_KEYS:
        if k == "tl":
            if t == "tl":
                return True
            continue
        if t == k or t.startswith(k + " ") or t.endswith(" " + k) or k in t:
            return True
        if k == "total" and len(t) <= 7 and difflib.SequenceMatcher(None, t, "total").ratio() >= 0.8:
            return True
    return False


def candidates(tokens: list[str]) -> list[int]:
    out = []
    for i, t in enumerate(tokens):
        if not is_total_label(t):
            continue
        for j in range(max(0, i - 3), min(len(tokens), i + 6)):
            if j == i:
                continue
            v = num(tokens[j])
            if v is not None and v >= 100:
                out.append(v)
    return out


def amount_match(a, b) -> bool | None:
    if a is None or b is None:
        return None
    for scale, frac in ((1, 0.005), (1000, 0.05)):
        target = b * scale
        if abs(a - target) <= max(2, frac * abs(target)):
            return True
    return False


def gold_of(raw: str):
    try:
        k = json.loads(raw)
    except Exception:
        k = {}
    tot = k.get("total") or {}
    if not isinstance(tot, dict):
        tot = {}
    st = k.get("sub_total") or {}
    if not isinstance(st, dict):
        st = {}
    t = tot.get("total_price")
    if t is None:
        m = re.search(r'"total_price"\s*:\s*"([^"]*)"', raw)
        t = m.group(1) if m else None
    return num(t)


def main():
    df = pd.read_parquet(DATA)
    e7e = json.load(open(E7E, encoding="utf-8"))
    by_file = {r["file"]: r for r in e7e["rows"]}
    rows = []
    for i, (_, r) in enumerate(df.iterrows()):
        text = by_file.get(r["file_name"], {}).get("text", "")
        try:
            toks = json.loads(r["ocr_text"])
        except Exception:
            toks = []
        if not isinstance(toks, list):
            toks = []
        cand = candidates([str(x) for x in toks])
        # prefer the last candidate near a strong label; take the most common
        rule_total = None
        if cand:
            rule_total = Counter(cand).most_common(1)[0][0]
        gold = gold_of(r["ocr_kie"])
        model = by_file.get(r["file_name"])
        model_total = model["model"]["total"] if model else None
        rows.append({
            "file": r["file_name"], "gold": gold, "rule": rule_total,
            "model": model_total, "cands": cand,
            "rule_ok": amount_match(rule_total, gold),
            "model_ok": amount_match(model_total, gold),
            "agree": amount_match(rule_total, model_total),
            "verdict": model["verdict"] if model else None,
        })
    n = len(rows)
    found = [r for r in rows if r["rule"] is not None]
    known = [r for r in found if r["rule_ok"] is not None]
    both = [r for r in rows if r["rule"] is not None and r["model"] is not None]
    agree = [r for r in both if r["agree"]]
    agree_known = [r for r in agree if r["rule_ok"] is not None]
    summary = {
        "n": n,
        "rule_found": len(found),
        "rule_found_rate": round(len(found) / n, 4),
        "rule_accuracy": round(sum(r["rule_ok"] for r in known) / len(known), 4) if known else None,
        "both_found": len(both),
        "agree": len(agree),
        "agree_rate": round(len(agree) / len(both), 4) if both else None,
        "agree_accuracy": round(sum(r["rule_ok"] for r in agree_known) / len(agree_known), 4) if agree_known else None,
        "disagree": len(both) - len(agree),
        "review_total": sum(1 for r in rows if r["verdict"] == "review"),
        "review_found": sum(1 for r in rows if r["verdict"] == "review" and r["rule"] is not None),
        "review_agree_model": sum(1 for r in rows if r["verdict"] == "review" and r["agree"]),
        "review_rule_ok": sum(1 for r in rows if r["verdict"] == "review" and r["rule_ok"]),
        "review_model_ok": sum(1 for r in rows if r["verdict"] == "review" and r["model_ok"]),
        "verdict_by_agree": {f"{v}|{a}": c for (v, a), c in Counter((r["verdict"], r["agree"]) for r in rows).items()},
    }
    json.dump({"summary": summary, "rows": rows}, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
