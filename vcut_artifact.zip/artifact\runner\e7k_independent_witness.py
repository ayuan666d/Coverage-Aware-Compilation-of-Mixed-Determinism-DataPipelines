"""E7k: an independent witness from OCR components only.

The arithmetic closure in E7e used the model's own subtotal/tax/service, so a
model that misreads all three consistently still closes.  Here the components
and the total are read from the OCR text by deterministic label rules; the
model is not consulted.  Certified means: OCR finds a total and the OCR
components close within 1%.  This is the honest "certified" set; model agreement
is reported separately as corroboration.
"""
from __future__ import annotations

import difflib
import json
import re
import sys
from collections import Counter
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
RAW = REPO / "06_结果" / "e7_receipts.json"
OUT = REPO / "06_结果" / "e7k_independent_witness.json"

SUB_KEYS = ("subtotal", "sub total", "sub-total", "subttl", "subtoial", "sub total",
            "subar total", "sub-tot", "sub total:")
TAX_KEYS = ("pb1", "pb 1", "pb-1", "ppn", "tax", "vat", "pajak", "p.rest", "pajak restoran")
SVC_KEYS = ("service", "svc", "service charge", "svc chrg", "service 7%", "service 6%")
DISC_KEYS = ("discount", "diskon", "disc", "disc.", "potongan", "saving", "hemat", "disk")
TOTAL_KEYS = ("grand total", "grandtotal", "total", "amount due", "total due", "due",
              "netto", "net", "paid", "payment", "debit", "tl")


def num(s):
    if s is None:
        return None
    s = str(s).strip().replace(" ", "")
    s = re.sub(r"[^0-9,.\-]", "", s)
    if not s or s in "-":
        return None
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        p = s.split(",")
        s = "".join(p) if len(p) > 1 and all(len(x) == 3 for x in p[1:]) else s.replace(",", ".")
    elif "." in s:
        p = s.split(".")
        if len(p) > 1 and all(len(x) == 3 for x in p[1:]):
            s = "".join(p)
    try:
        return int(round(float(s)))
    except Exception:
        return None


def match(a, b):
    if a is None or b is None:
        return None
    for scale, frac in ((1, 0.005), (1000, 0.05)):
        target = b * scale
        if abs(a - target) <= max(2, frac * abs(target)):
            return True
    return False


def label_of(tok: str) -> str:
    return re.sub(r"[^a-z ]", " ", tok.lower()).strip()


def is_label(tok: str, keys) -> bool:
    t = label_of(tok)
    t = re.sub(r"\s+", " ", t)
    if not t:
        return False
    for k in keys:
        if k == "tl":
            if t == "tl":
                return True
            continue
        if t == k or t.startswith(k + " ") or t.endswith(" " + k) or k in t:
            return True
        if k in ("total", "subtotal", "discount", "service") and len(t) <= 12:
            if difflib.SequenceMatcher(None, t, k).ratio() >= 0.8:
                return True
    return False


def amounts(text: str, keys) -> list[int]:
    toks = [t.strip() for t in text.split("|")]
    out = []
    for i, t in enumerate(toks):
        if not is_label(t, keys):
            continue
        v = num(t)
        if v is not None and v >= 100:
            out.append(v)
            continue
        for d in range(1, 6):
            for j in (i + d, i - d):
                if 0 <= j < len(toks):
                    v = num(toks[j])
                    if v is not None and v >= 100:
                        out.append(v)
                        break
            else:
                continue
            break
    return out


def pick(vals: list[int]):
    return Counter(vals).most_common(1)[0][0] if vals else None


def main():
    rows = list(json.load(open(RAW, encoding="utf-8"))["rows"])
    out = []
    for r in rows:
        text = r["text"]
        sub = pick(amounts(text, SUB_KEYS))
        tax = pick(amounts(text, TAX_KEYS))
        svc = pick(amounts(text, SVC_KEYS))
        disc = pick(amounts(text, DISC_KEYS))
        total = pick(amounts(text, TOTAL_KEYS))
        derived = None
        if sub is not None:
            derived = sub + (tax or 0) + (svc or 0) - (disc or 0)
        close = (derived is not None and total is not None
                 and abs(derived - total) <= max(2, 0.01 * abs(total)))
        certified = bool(close)
        model = r["model"].get("total")
        out.append({
            "file": r["file"], "gold": r["gold"]["total"], "model": model,
            "ocr": {"sub": sub, "tax": tax, "svc": svc, "disc": disc, "total": total},
            "derived": derived, "certified": certified,
            "ocr_correct": match(total, r["gold"]["total"]),
            "model_correct": match(model, r["gold"]["total"]),
            "agree": match(total, model) is True,
        })

    n = len(out)
    cert = [r for r in out if r["certified"]]
    cert_known = [r for r in cert if r["ocr_correct"] is not None]
    fp = sum(1 for r in cert_known if r["ocr_correct"] is False)
    model_cert = [r for r in cert if r["model_correct"] is True]
    model_wrong_cert = [r for r in cert if r["model_correct"] is False]
    # policy: accept model if certified and OCR agrees; fill OCR total if certified and differs
    accepted = [r for r in cert if r["agree"]]
    acc_known = [r for r in accepted if r["ocr_correct"] is not None]
    acc_fp = sum(1 for r in acc_known if r["ocr_correct"] is False)
    summary = {
        "n": n,
        "certified": len(cert), "certified_rate": round(len(cert) / n, 4),
        "certified_ocr_correct": len(cert_known) - fp,
        "certified_fp": fp,
        "certified_fp_rate": round(fp / n, 4),
        "certified_precision": round((len(cert_known) - fp) / len(cert_known), 4) if cert_known else None,
        "certified_model_correct": len(model_cert),
        "certified_model_wrong": len(model_wrong_cert),
        "ocr_total_found": sum(1 for r in out if r["ocr"]["total"] is not None),
        "ocr_total_found_rate": round(sum(1 for r in out if r["ocr"]["total"] is not None) / n, 4),
        "ocr_total_precision": round(sum(1 for r in out if r["ocr_correct"]) /
                                     max(1, sum(1 for r in out if r["ocr_correct"] is not None)), 4),
        "accept_model_if_ocr_agrees": len(accepted),
        "accept_rate": round(len(accepted) / n, 4),
        "accept_fp": acc_fp,
        "accept_fp_rate": round(acc_fp / n, 4),
        "accept_precision": round((len(acc_known) - acc_fp) / len(acc_known), 4) if acc_known else None,
        "components_found": {
            "sub": sum(1 for r in out if r["ocr"]["sub"] is not None),
            "tax": sum(1 for r in out if r["ocr"]["tax"] is not None),
            "svc": sum(1 for r in out if r["ocr"]["svc"] is not None),
            "disc": sum(1 for r in out if r["ocr"]["disc"] is not None),
        },
    }
    json.dump({"summary": summary, "rows": out}, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
