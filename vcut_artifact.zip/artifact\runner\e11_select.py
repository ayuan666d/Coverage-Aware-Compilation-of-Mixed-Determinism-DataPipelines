"""E11: pick the graph operator on held-in data, not on the test set.

Two fusion geometries are compared on a validation slice of the Spider training
databases (co-query edges are built from a disjoint slice), and the winner is
the configuration reported for the test databases.
"""
from __future__ import annotations

import json
import math
import random
import sys
from collections import Counter
from itertools import combinations
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
OUT = REPO / "06_结果" / "e11_select.json"


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    train = [c for c in data["spider"] if c["split"] == "train"]
    rnd = random.Random(3)
    rnd.shuffle(train)
    src, val = train[:int(len(train) * 0.8)], train[int(len(train) * 0.8):]
    val = val[:150]

    tables, fks = [], []
    for db, s in cache["spider"].items():
        tables += [dict(t, db=db) for t in s["tables"]]
        have = {t["name"] for t in s["tables"]}
        fks += [[f"{db}::{a}", ca, f"{db}::{b}", cb] for a, ca, b, cb in s["fks"]
                if a in have and b in have]
    pc = Counter()
    for c in src:
        for a, b in combinations(sorted(c["gold"]), 2):
            pc[(f"{c['db_id']}::{a}", f"{c['db_id']}::{b}")] += 1
            pc[(f"{c['db_id']}::{b}", f"{c['db_id']}::{a}")] += 1
    coq = Counter({k: math.log(1 + v) for k, v in pc.items()})
    cat = g.Catalog(tables, fks, coquery=coq, prefix_db=True)

    qdf = Counter()
    for c in val:
        qdf.update(set(toks(c["question"])))
    hi = float(np.quantile(sorted(qdf.values()), 0.8))
    acc = {}
    for c in val:
        q = toks(c["question"])
        gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
        bw = {x: (0.15 if qdf[x] >= hi else 1.0) for x in q}
        for key, s in [("view", g.fuse(cat, q, band_weight=bw, mode="view")),
                       ("view_noband", g.fuse(cat, q, mode="view")),
                       ("isolated", g.fuse(cat, q, band_weight=bw, mode="isolated")),
                       ("isolated_noband", g.fuse(cat, q, mode="isolated")),
                       ("union_ppr", g.single_ppr(cat, q, band_weight=bw))]:
            acc.setdefault(key, []).append(g.metrics(g.rank(s, cat), gold))
    res = {k: g.mean_metrics(v) for k, v in acc.items()}
    best = max(res, key=lambda k: res[k]["recall@5"])
    out = {"n_val": len(val), "metrics": res, "selected": best}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(out, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
