"""E11-SURPRISE2: is the chance-null certificate a layer, or is it glued to my ranker?

2.13 gave the first accept-rule with zero false passes -- but on one arm.  The archive
already holds the opposite warning: the hand rule (support>=3 & rarest df<=2) REVERSED
when it was put on top of the E12 genetic-programming arm, i.e. certificates have been
operator-bound before.  This is the decisive test, and it is cheap: the certificate is a
statement about the data (how much of the query is written into the table it is about to
return, measured against what an 876-table catalogue hands out by chance), so it should
apply to whatever produced the answer.

Scope: every per-question arm that exists on the 876-table merged lake.  Ours (table-level,
column-level), the parallel line's lexical/spectral embeddings (BM25, PPMI-word, char-gram,
fused), its searched operators (GP, GP+exact, expression tree), its trained 0.6B
fine-tune, and the dense reference.

Pre-registered verdict, written before running:
  * GENERAL: the Sidak-corrected rule yields 0 false passes on at least two arms that are
    not ours, each with >=10 accepted answers;
  * OPERATOR-BOUND: it produces >=1 false pass on any foreign arm, or fires <10 times;
  * the hand rule is reported on the same arms as the contrast that motivated this test.
The certificate is computed on the E11 catalogue documents for every arm, including arms
whose own document construction differs -- a certificate must be a property of the data,
not of the ranker that queried it.
"""
from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_surprise import chance_tail  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
CASES = R / "e11_cases.json"
SURP = R / "e11_surprise_merged.json"
EMB = WORK / "e11_emb_spider.npz"
OUT = R / "e11_surprise2.json"
ALPHA = 0.05
K_FROZEN, M_FROZEN = 3, 2


def load_arms():
    arms = {}
    gp = json.load(open(R / "e12_gp.json", encoding="utf-8"))["rows"]
    for k in ("gp", "gp_ex"):
        arms[f"E12_{k}"] = gp[k]
    sp = json.load(open(R / "e12_spectral.json", encoding="utf-8"))["rows"]
    for m in ("bm25", "word", "gram", "fused"):
        arms[f"E12_{m}"] = [dict(qid=r["qid"], db=r["db"], gold=r[m], top5=r[m]["top5"])
                            for r in sp]
    arms["E12_tree"] = json.load(open(R / "e12_tree.json", encoding="utf-8"))["rows"]
    arms["E12_ft0.6B"] = json.load(open(R / "e12_ft.json", encoding="utf-8"))["rows"]
    surp = json.load(open(SURP, encoding="utf-8"))
    te = [r for r in surp["rows"] if r["split"] == "test"]
    for a, name in (("v0_table_gm", "E11_table"), ("c3_tokmaxpool_gm", "E11_column")):
        arms[name] = [dict(qid=r["qid"], db=r["db"], top5=[r[a]["top1"]],
                           gold={"recall@1": r[a]["r1"], "recall@5": r[a]["r5"],
                                 "top5": [r[a]["top1"]]}, qgold=None) for r in te]
    return arms, te


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    tabs = []
    for db in cache["spider"]:
        tabs += [dict(t, db=db) for t in cache["spider"][db]["tables"]]
    cat = g.Catalog(tabs, [], prefix_db=True)          # cold, no fk needed for support
    N = len(cat.tables)
    docs = [set(g.table_doc(t)) for t in cat.tables]
    inc = {}
    for j, d in enumerate(docs):
        for w in d:
            inc.setdefault(w, []).append(j)
    lowmap = {tid.lower(): i for i, tid in enumerate(cat.table_ids)}

    def pos_of(tid):
        return cat.table_pos.get(tid, lowmap.get(str(tid).lower()))

    z = np.load(EMB, allow_pickle=True)
    ids = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}

    per_q = {}
    t0 = time.time()
    for c in test:
        q = toks(c["question"])
        gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
        cs = np.zeros(N, dtype=np.float32)
        dfs = []
        for w in set(q):
            js = inc.get(w)
            if not js:
                continue
            cs[js] += 1.0
            dfs.append(cat.token_df.get(w, 0))
        rarest = min(dfs, default=10 ** 9)
        pcurve = {}
        for s in range(0, len(set(q)) + 2):
            tail, padj = chance_tail(dfs, N, s)
            pcurve[s] = (round(tail, 6), round(padj, 6))
        dtop = None
        if c["qid"] in qpos:
            order = [ids[i] for i in np.argsort(-(Dm @ Qm[qpos[c["qid"]]]))]
            dtop = order[0]
        per_q[c["qid"]] = {"gold": gold, "cs": cs, "rarest": rarest, "pcurve": pcurve,
                           "dense_top1": dtop,
                           "dense_r1": None, "dense_r5": None}
        if dtop:
            per_q[c["qid"]]["dense_r1"] = float(dtop in gold)
            order = [ids[i] for i in np.argsort(-(Dm @ Qm[qpos[c["qid"]]]))]
            per_q[c["qid"]]["dense_r5"] = sum(1 for t in order[:5] if t in gold) / max(1, len(gold))
    print(f"support + null computed for {len(per_q)} questions in {time.time()-t0:.0f}s",
          flush=True)

    arms, surp_te = load_arms()
    # identifiers are stored in the source schema with arbitrary case (VOTES vs votes);
    # every lookup below is case-folded, otherwise a foreign arm's correct answer reads as
    # "table not in the catalogue" and its support scores 0 (this mistake produced one run
    # of this table with the other line's accuracies understated by ~20 points).
    goldmap = {c["qid"]: {f"{c['db_id']}::{t}".lower() for t in c["gold"]} for c in test}
    r5map = {}
    for r in surp_te:
        r5map[("E11_table", r["qid"])] = r["v0_table_gm"]["r5"]
        r5map[("E11_column", r["qid"])] = r["c3_tokmaxpool_gm"]["r5"]

    rows = []
    for name, lst in arms.items():
        for rec in lst:
            qid = rec["qid"]
            if qid not in per_q:
                continue
            t1 = list(rec["top5"])[0] if rec.get("top5") else None
            if t1 is None or pos_of(t1) is None:
                continue
            st = per_q[qid]
            ps = pos_of(t1)
            sup = int(st["cs"][ps]) if ps is not None else 0
            tail, padj = st["pcurve"][min(sup, len(st["pcurve"]) - 1)]
            correct = str(t1).lower() in goldmap[qid]
            m = st["rarest"]
            r5 = st["dense_r5"] if name == "dense" else r5map.get((name, qid))
            if r5 is None:
                gset = goldmap[qid]
                r5 = sum(1 for t in list(rec["top5"])[:5] if str(t).lower() in gset) / max(1, len(gset))
            rows.append({"arm": name, "qid": qid, "top1": t1, "support": sup, "m_q": int(m),
                         "p_raw": tail, "p_beyond": padj, "correct": bool(correct), "r5": round(float(r5), 4)})
    # dense as its own arm
    for qid, st in per_q.items():
        if st["dense_top1"] is None:
            continue
        _dp = pos_of(st["dense_top1"])
        sup = int(st["cs"][_dp]) if _dp is not None else 0
        tail, padj = st["pcurve"][min(sup, len(st["pcurve"]) - 1)]
        rows.append({"arm": "dense_0.6B", "qid": qid, "top1": st["dense_top1"],
                     "support": sup, "m_q": int(st["rarest"]), "p_raw": tail, "p_beyond": padj,
                     "correct": bool(str(st["dense_top1"]).lower() in goldmap[qid]),
                     "r5": round(float(st["dense_r5"]), 4)})

    rules = {"hand_k3_df2": lambda r: r["support"] >= K_FROZEN and r["m_q"] <= M_FROZEN,
             "tail": lambda r: r["p_raw"] <= ALPHA,
             "chance_null": lambda r: r["p_beyond"] <= ALPHA}
    out = {"n_questions": len(per_q), "n_rows": len(rows), "alpha": ALPHA, "arms": {}}
    by_arm = {}
    for r in rows:
        by_arm.setdefault(r["arm"], []).append(r)
    for arm, rs in sorted(by_arm.items()):
        d = {"n": len(rs), "top1_acc": round(float(np.mean([r["correct"] for r in rs])), 4),
             "r5": round(float(np.mean([r["r5"] for r in rs])), 4), "errors": sum(1 for r in rs if not r["correct"])}
        for rn, sel in rules.items():
            acc = [r for r in rs if sel(r)]
            fp = sum(1 for r in acc if not r["correct"])
            d[rn] = {"cov": round(len(acc) / len(rs), 4), "n_acc": len(acc), "false_pass": fp,
                     "precision": round(1 - fp / len(acc), 4) if acc else None,
                     "acc_r5": round(float(np.mean([r["r5"] for r in acc])), 4) if acc else None}
        out["arms"][arm] = d
    verdict = "UNTESTED"
    foreign = [a for a in out["arms"] if a not in ("E11_table", "E11_column")]
    gen = [a for a in foreign
           if out["arms"][a]["chance_null"]["n_acc"] >= 10
           and out["arms"][a]["chance_null"]["false_pass"] == 0]
    broke = [a for a in foreign if out["arms"][a]["chance_null"]["false_pass"] > 0]
    if broke:
        verdict = f"OPERATOR-BOUND ({broke})"
    elif len(gen) >= 2:
        verdict = f"GENERAL (0 false passes on {gen})"
    else:
        verdict = f"TOO SILENT to judge: fired >=10 times with 0 false passes only on {gen}"
    out["pre_registered_verdict"] = verdict
    json.dump({**out, "rows": rows}, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=1, ensure_ascii=False))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
