"""E11: dense retrieval, dense+graph hybrid, and path certificates on top.

The scale curve shows a dense embedding beats every zero-training method on a
cross-domain catalog.  This run keeps that result and asks the question that
matters for certification: can the typed relational graph certify the answer
the embedding gives, at coverage a raw cosine threshold cannot reach?
"""
from __future__ import annotations

import json
import math
import sys
from collections import Counter
from itertools import combinations
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
OUT = REPO / "06_结果" / "e11_spider_dense.json"


def rrf(score_lists, k=60):
    n = len(score_lists[0])
    out = np.zeros(n, dtype=np.float64)
    for s in score_lists:
        order = np.argsort(-s)
        for r, i in enumerate(order, 1):
            out[i] += 1.0 / (k + r)
    return out.astype(np.float32)


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    train = [c for c in data["spider"] if c["split"] == "train"]
    npz = np.load(EMB, allow_pickle=True)
    ids = [str(x) for x in npz["ids"]]
    D = npz["D"].astype(np.float32)
    Q = {str(q): v for q, v in zip([str(x) for x in npz["qids"]], npz["Q"].astype(np.float32))}

    tables, fks = [], []
    for db, s in cache["spider"].items():
        tables += [dict(t, db=db) for t in s["tables"]]
        have = {t["name"] for t in s["tables"]}
        fks += [[f"{db}::{a}", ca, f"{db}::{b}", cb] for a, ca, b, cb in s["fks"]
                if a in have and b in have]
    pc = Counter()
    for c in train:
        for a, b in combinations(sorted(c["gold"]), 2):
            pc[(f"{c['db_id']}::{a}", f"{c['db_id']}::{b}")] += 1
            pc[(f"{c['db_id']}::{b}", f"{c['db_id']}::{a}")] += 1
    coq = Counter({k: math.log(1 + v) for k, v in pc.items()})
    cat = g.Catalog(tables, fks, coquery=coq, prefix_db=True)
    assert [f"{t['db']}::{t['name']}" for t in cat.tables] == ids, "catalog order mismatch"

    qdf = Counter()
    for c in test:
        qdf.update(set(toks(c["question"])))
    hi = float(np.quantile(sorted(qdf.values()), 0.8))

    rows = []
    for c in test:
        q = toks(c["question"])
        gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
        bw = {x: (0.15 if qdf[x] >= hi else 1.0) for x in q}
        dense = D @ Q[c["qid"]]
        typed = g.fuse(cat, q, band_weight=bw)
        bm = g.bm25(cat, q)
        methods = {
            "dense": dense,
            "typed_band": typed,
            "bm25": bm,
            "dense_typed": rrf([dense, typed]),
            "dense_bm25": rrf([dense, bm]),
            "all_three": rrf([dense, typed, bm]),
        }
        row = {"qid": c["qid"], "db": c["db_id"], "gold": sorted(gold)}
        for name, s in methods.items():
            r = g.rank(s, cat)
            row[name] = {"top5": r[:5], **g.metrics(r, gold),
                         "cert": g.certify(cat, s, q, gold)}
        rows.append(row)

    out = {"n": len(rows), "n_tables": len(cat.tables),
           "metrics": {m: g.mean_metrics([r[m] for r in rows]) for m in methods},
           "rows": rows}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({"n": out["n"], "metrics": out["metrics"]}, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
