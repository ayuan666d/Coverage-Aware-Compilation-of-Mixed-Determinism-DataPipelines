"""E11-CLONE: the certificate's only false pass is one question, and it is a clone.

2.14 read "one false pass on six foreign arms" as operator-boundedness.  Wrong reading,
and the archive says so: the seven false passes are the SAME question (sp245) answered by
the SAME wrong table (flight_4::airlines, gold flight_2::airlines) -- the lake contains two
databases with the same schema, so every ranker that reads identifiers gets the same
beyond-chance support on the wrong copy.  One failure mode, ten arms, not ten.

That is a database-native object, not a modelling problem: the catalogue knows its own
duplicates.  This script (a) sizes clone ambiguity over the whole lake and over every arm,
(b) turns the observation into an operator and prices it.

Operator CLONEGUARD, computed at query time with no label:
  accept iff the chance-corrected word certificate fires, AND either
    - the returned table has no clone in the catalogue (unique identifier+column signature), or
    - the returned table carries a VALUE that no clone of it carries, and that value is one of
      the query's words (the data itself breaks the tie between the two copies).

Pre-registered: the guard may not reduce the accepted set by more than the questions it
vetoes, and must bring pooled false passes over the 11 arms from 7 to 0.  Coverage loss is
reported even when the guard works, because a silent certificate is not a useful one.
"""
from __future__ import annotations

import json
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
WORK = Path("D:/vldb2027_e11")
CACHE = WORK / "schema_cache.json"
CASES = R / "e11_cases.json"
SURP2 = R / "e11_surprise2.json"
OUT = R / "e11_clone.json"


def main():
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    test = [c for c in data["spider"] if c["split"] == "test"]
    tabs = []
    for db, s in cache["spider"].items():
        tabs += [dict(t, db=db) for t in s["tables"]]
    cat = g.Catalog(tabs, [], prefix_db=True)
    lowmap = {tid.lower(): i for i, tid in enumerate(cat.table_ids)}

    def pos_of(tid):
        return cat.table_pos.get(tid, lowmap.get(str(tid).lower()))
    N = len(cat.tables)

    sig = {}
    value_sets = {}
    for i, t in enumerate(cat.tables):
        key = (frozenset(g.toks(t["name"])),
               frozenset(w for c in t["columns"] for w in g.toks(c["name"])))
        sig[i] = key
        vals = set()
        for c in t["columns"]:
            for v in c.get("values", []):
                vs = str(v).strip().lower()
                vals.add(vs)
                vals.update(g.toks(vs))
        value_sets[i] = vals
    groups = defaultdict(list)
    for i, k in sig.items():
        groups[k].append(i)
    clone_of = {}
    for k, idxs in groups.items():
        for i in idxs:
            clone_of[i] = [j for j in idxs if j != i]
    n_multi = sum(1 for idxs in groups.values() if len(idxs) > 1)
    tables_in_clone = sum(len(v) for v in groups.values() if len(v) > 1)
    sizes = Counter(len(v) for v in groups.values())
    print(f"catalogue {N} tables, {len(groups)} identifier signatures, "
          f"{n_multi} shared by >1 table, {tables_in_clone} tables inside such a group",
          flush=True)
    print("group size histogram", dict(sorted(sizes.items())[:8]), flush=True)

    surp = json.load(open(SURP2, encoding="utf-8"))
    gold = {c["qid"]: {f"{c['db_id']}::{t}" for t in c["gold"]} for c in test}
    qtok = {c["qid"]: set(toks(c["question"])) for c in test}

    per_arm = {}
    detail = []
    for r in surp["rows"]:
        arm = r["arm"]
        d = per_arm.setdefault(arm, {"n": 0, "acc": 0, "cert": 0, "cert_fp": 0,
                                     "cert_in_clone": 0, "guarded": 0, "guarded_fp": 0,
                                     "clone_acc": 0, "clone_n": 0, "plain_acc": 0, "plain_n": 0})
        pos = pos_of(r["top1"])
        if pos is None:
            continue
        ok = bool(r["correct"])
        is_clone = len(clone_of.get(pos, [])) > 0
        d["n"] += 1
        d["acc"] += ok
        d["clone_n" if is_clone else "plain_n"] += 1
        d["clone_acc" if is_clone else "plain_acc"] += ok
        if r["p_beyond"] <= 0.05:
            d["cert"] += 1
            d["cert_fp"] += (not ok)
            d["cert_in_clone"] += is_clone
            veto = False
            if is_clone:
                own = value_sets[pos]
                # a query word that is a whole cell value here and in no clone of it
                others = set()
                for j in clone_of[pos]:
                    others |= value_sets[j]
                unique = [w for w in qtok[r["qid"]] if w in own and w not in others]
                veto = len(unique) == 0
                if veto:
                    detail.append({"qid": r["qid"], "arm": arm, "top1": r["top1"],
                                   "correct": ok, "support": r["support"],
                                   "n_clones": len(clone_of[pos]),
                                   "reason": "clone table, no query word is a value unique to it"})
            if not veto:
                d["guarded"] += 1
                d["guarded_fp"] += (not ok)
    summary = {}
    for arm, d in per_arm.items():
        summary[arm] = {
            "top1_acc": round(d["acc"] / d["n"], 4),
            "clone_share": round(d["clone_n"] / d["n"], 4),
            "acc_in_clone": round(d["clone_acc"] / d["clone_n"], 4) if d["clone_n"] else None,
            "acc_plain": round(d["plain_acc"] / d["plain_n"], 4) if d["plain_n"] else None,
            "cert": {"accepted": d["cert"], "false_pass": d["cert_fp"],
                     "in_clone": d["cert_in_clone"]},
            "guarded": {"accepted": d["guarded"], "false_pass": d["guarded_fp"]}}
    pooled = {"cert_accepted": sum(s["cert"]["accepted"] for s in summary.values()),
              "cert_false_pass": sum(s["cert"]["false_pass"] for s in summary.values()),
              "guarded_accepted": sum(s["guarded"]["accepted"] for s in summary.values()),
              "guarded_false_pass": sum(s["guarded"]["false_pass"] for s in summary.values())}
    out = {"n_tables": N, "n_signatures": len(groups), "tables_in_clone_group": tables_in_clone,
           "group_size_hist": dict(sorted(sizes.items())), "arms": summary, "pooled": pooled,
           "verdict": ("GUARD WORKS: pooled false passes %d -> %d, accepted %d -> %d" %
                       (pooled["cert_false_pass"], pooled["guarded_false_pass"],
                        pooled["cert_accepted"], pooled["guarded_accepted"]))
                      if pooled["guarded_false_pass"] == 0 else
                       ("GUARD FAILS to reach zero: %d false passes left" %
                        pooled["guarded_false_pass"]),
           "veto_detail": detail}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({"pooled": pooled, "verdict": out["verdict"]}, ensure_ascii=False))
    for arm, s in summary.items():
        print("%-12s top1=%.3f clone_share=%.3f acc_clone=%-7s acc_plain=%-7s cert %d/%d fp "
              "-> guarded %d/%d fp" % (arm, s["top1_acc"], s["clone_share"], s["acc_in_clone"],
                                       s["acc_plain"], s["cert"]["false_pass"], s["cert"]["accepted"],
                                       s["guarded"]["false_pass"], s["guarded"]["accepted"]))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
