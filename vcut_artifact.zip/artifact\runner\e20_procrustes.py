"""E20: orthogonal Procrustes rotation vs plain cosine.

E19 constrained each feature weight to the unit circle, which only flips signs
and throws away evidence strength.  A rotation acts on the whole vector space:
find orthogonal R minimizing ||X R - Y||, closed form R = U V^T from X^T Y = U S V^T.

  X = query vectors (mean word-latent of the question), n x 256
  Y = gold-table vectors (mean doc_word of the gold tables), n x 256
  score = cosine(x R, table), against cosine(x, table) as the control.
"""
from __future__ import annotations

import json
import sys

import numpy as np

sys.path.insert(0, r"E:\vldb2027_pipeline_safety\05_代码\runner")
import e14_db_anchor as e14  # noqa: E402

OUT = e14.REPO / "06_结果" / "e20_procrustes.json"


def l2(v):
    return v / np.maximum(np.linalg.norm(v, axis=-1, keepdims=True), 1e-9)


def main():
    meta = e14.load()
    z = np.load(e14.NPZ, allow_pickle=True)
    doc_ids = [str(x) for x in z["doc_ids"]]
    didx = {f: i for i, f in enumerate(doc_ids)}
    doc = l2(z["doc_word"].astype(np.float32))
    wv = {t: i for i, t in enumerate(z["word_vocab"])}
    term = z["term_word"].astype(np.float32)

    def qvec(q):
        ts = [t for t in e14.wtoks(q) if t in wv]
        if not ts:
            return np.zeros(doc.shape[1], dtype=np.float32)
        return l2(np.mean([term[wv[t]] for t in ts], axis=0))

    train_q, test_q = meta["train_q"], meta["test_q"]
    qtext = {c["qid"]: c["question"] for c in meta["cases"]}
    X = np.stack([qvec(qtext[q]) for q in train_q])
    Y = np.zeros_like(X)
    for i, q in enumerate(train_q):
        ids = [didx[f] for f in meta["gold_all"][q] if f in didx]
        if ids:
            Y[i] = l2(doc[ids].mean(0))
    Xte = np.stack([qvec(qtext[q]) for q in test_q])
    print("X", X.shape, "Y", Y.shape, "test", Xte.shape, flush=True)

    M = X.T @ Y
    U, S, Vt = np.linalg.svd(M, full_matrices=False)
    R = (U @ Vt).astype(np.float32)
    print("rotation spectrum top:", np.round(S[:10], 3).tolist(),
          "energy_total", float(S.sum()), flush=True)

    arms = {"cosine": Xte @ doc.T, "procrustes": (Xte @ R) @ doc.T}
    out = {}
    for name, sc in arms.items():
        rows = []
        for qi, q in enumerate(test_q):
            order = np.argsort(-sc[qi])[:5]
            top = [doc_ids[i] for i in order]
            r, m = e14.metrics_top(top, meta["gold_all"][q])
            rows.append({"qid": q, "recall@1": r[1], "recall@3": r[3],
                         "recall@5": r[5], "mrr": m})
        out[name] = {k: round(sum(r[k] for r in rows) / len(rows), 4)
                     for k in ("recall@1", "recall@3", "recall@5", "mrr")}
        print(name, json.dumps(out[name]), flush=True)

    # rank-truncated rotations: how much rotation is useful
    trunc = {}
    for k in (8, 16, 32, 64, 128, 256):
        Rk = (U[:, :k] @ Vt[:k, :]).astype(np.float32)
        sc = (Xte @ Rk) @ doc.T
        rows = []
        for qi, q in enumerate(test_q):
            order = np.argsort(-sc[qi])[:5]
            top = [doc_ids[i] for i in order]
            r, m = e14.metrics_top(top, meta["gold_all"][q])
            rows.append(r[5])
        trunc[str(k)] = round(float(np.mean(rows)), 4)
        print("rank", k, "r5", trunc[str(k)], flush=True)

    json.dump({"metrics": out, "rank_sweep": trunc,
               "spectrum_top": np.round(S[:20], 4).tolist(),
               "reference": {"spectral_word_only_r5": 0.3724, "fused_r5": 0.6427}},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
