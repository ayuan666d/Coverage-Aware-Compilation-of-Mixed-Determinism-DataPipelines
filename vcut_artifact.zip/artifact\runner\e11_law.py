"""E11 scale law test: is the best diffusion scale predicted by the spectrum?

For every relation layer of every catalog we sweep the restart probability
alpha, take alpha* (best mean recall@5) and define the diffusion scale
t* = 1/(1-alpha*).  The candidate law is t* proportional to 1/gap, where
gap = 1 - lambda_2 of the symmetric normalised adjacency.  We also check whether
using alpha = lambda_2 as a parameter-free setting is competitive.
"""
from __future__ import annotations

import json
import math
import sys
from collections import Counter
from itertools import combinations
from pathlib import Path

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import eigsh

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
OUT = REPO / "06_结果" / "e11_scale_law.json"
ALPHAS = [0.3, 0.5, 0.7, 0.8, 0.85, 0.9, 0.95, 0.98]
LAYERS = ["name", "value", "fk", "coquery", "alias"]


def lambda2(A):
    n = A.shape[0]
    if n < 4:
        return None
    d = np.asarray(A.sum(axis=1)).ravel()
    d[d == 0] = 1.0
    dinv = sparse.diags(1.0 / np.sqrt(d))
    S = (dinv @ A @ dinv).tocsr()
    try:
        w = eigsh(S, k=min(3, n - 2), which="LA", tol=1e-5, maxiter=2000)
        vals = np.sort(w[0])[::-1]
        return float(vals[1]) if len(vals) > 1 else None
    except Exception:
        return None


def sweep(cat, cases, gold_of, band=None):
    out = []
    for layer in LAYERS:
        P = cat.views[layer]
        lam = lambda2(cat.raw[layer] if layer in cat.raw else cat.pure["contain"] + cat.pure[layer])
        rec = {"layer": layer, "lambda2": lam}
        best = (-1, None)
        for a in ALPHAS:
            ms = []
            for c in cases:
                q = toks(c["question"])
                seeds = g.seed_vector(cat, q, band(q) if band else None)
                x = g.ppr(P, seeds, alpha=a, iters=30)
                ms.append(g.metrics(g.rank(cat.table_scores(x), cat), gold_of(c)))
            r5 = float(np.mean([m["recall@5"] for m in ms]))
            rec[f"r@5_a{a}"] = round(r5, 4)
            if r5 > best[0]:
                best = (r5, a)
        rec["alpha_star"] = best[1]
        rec["t_star"] = round(1.0 / (1.0 - best[1]), 3) if best[1] is not None else None
        rec["r5_star"] = round(best[0], 4)
        # parameter-free prediction
        a_pred = None
        if lam is not None:
            a_pred = min(0.98, max(0.3, lam))
            rec["alpha_pred"] = round(a_pred, 3)
            ms = []
            for c in cases:
                q = toks(c["question"])
                seeds = g.seed_vector(cat, q, band(q) if band else None)
                x = g.ppr(P, seeds, alpha=a_pred, iters=30)
                ms.append(g.metrics(g.rank(cat.table_scores(x), cat), gold_of(c)))
            rec["r5_pred"] = round(float(np.mean([m["recall@5"] for m in ms])), 4)
        out.append(rec)
    return out


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    runs = []

    by = {}
    for c in data["bird"]:
        by.setdefault(c["db_id"], []).append(c)
    for db, cs in sorted(by.items()):
        cat = g.Catalog([dict(t, db=db) for t in cache["bird"][db]["tables"]],
                        cache["bird"][db]["fks"], prefix_db=False)
        for r in sweep(cat, cs, lambda c: set(c["gold"])):
            r.update({"set": f"bird:{db}", "n_tables": len(cat.tables)})
        runs += sweep(cat, cs, lambda c: set(c["gold"]))
        print("bird", db, flush=True)

    test = [c for c in data["spider"] if c["split"] == "test"]
    train = [c for c in data["spider"] if c["split"] == "train"]
    tables, fks = [], []
    for db, s in cache["spider"].items():
        tables += [dict(t, db=db) for t in s["tables"]]
        have = {t["name"] for t in s["tables"]}
        fks += [[f"{db}::{a}", ca, f"{db}::{b}", cb] for a, ca, b, cb in s["fks"]
                if a in have and b in have]
    pc = Counter()
    for c in train:
        for a, b in combinations(sorted(c["gold"]), 2):
            pc[(f"{c['db_id']}::{a}", f"{c['db_id']}::{b}")] += 1
            pc[(f"{c['db_id']}::{b}", f"{c['db_id']}::{a}")] += 1
    coq = Counter({k: math.log(1 + v) for k, v in pc.items()})
    cat = g.Catalog(tables, fks, coquery=coq, prefix_db=True)
    qdf = Counter()
    for c in test:
        qdf.update(set(toks(c["question"])))
    hi = float(np.quantile(sorted(qdf.values()), 0.8))
    band = lambda q: {x: (0.15 if qdf[x] >= hi else 1.0) for x in q}
    sub = test[:80]
    runs += [dict(r, set="spider_merged", n_tables=len(cat.tables))
             for r in sweep(cat, sub, lambda c: {f"{c['db_id']}::{t}" for t in c["gold"]}, band)]
    print("spider done", flush=True)

    ok = [r for r in runs if r.get("lambda2") and r.get("alpha_star")]
    gap = np.array([1.0 - r["lambda2"] for r in ok])
    t = np.array([r["t_star"] for r in ok])
    l1 = np.log(np.clip(t, 1.01, None))
    l2 = np.log(1.0 / np.clip(gap, 1e-6, None))
    pear = float(np.corrcoef(l1, l2)[0, 1]) if len(ok) > 3 else None
    r5_pred = np.mean([r["r5_pred"] for r in ok if "r5_pred" in r])
    r5_star = np.mean([r["r5_star"] for r in ok])
    r5_fix = np.mean([r["r@5_a0.85"] for r in ok])
    out = {"n_points": len(ok), "pearson_log_t_vs_inv_gap": None if pear is None else round(pear, 4),
           "mean_r5": {"oracle_alpha": round(float(r5_star), 4),
                       "predicted_alpha": round(float(r5_pred), 4),
                       "fixed_0.85": round(float(r5_fix), 4)},
           "runs": runs}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in out.items() if k != "runs"}, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
