"""Per-column fill analysis: where does text end on each page/column?

Helps find whitespace left by float placement. Two-column ACM layout:
left column x in [50, 300], right column x in [310, 562] approx.
"""
import sys
import pymupdf

LEFT_MAX = 308.0


def analyze(pdf_path: str):
    doc = pymupdf.open(pdf_path)
    print(f"== {pdf_path}  pages={len(doc)}")
    for pno in range(len(doc)):
        page = doc[pno]
        H = page.rect.height
        cols = {0: [], 1: []}
        blocks = page.get_text("dict")["blocks"]
        for b in blocks:
            if b.get("type") != 0:
                continue
            x0, y0, x1, y1 = b["bbox"]
            # skip header/footer bands
            if y1 < 60 or y0 > H - 40:
                continue
            c = 0 if x0 < LEFT_MAX - 20 else 1
            # wide blocks (figures spanning) count for both
            if x0 < 100 and x1 > 450:
                cols[0].append(y1)
                cols[1].append(y1)
            else:
                cols[c].append(y1)
        txt = page.get_text("text").strip().split("\n")
        head = txt[0][:44] if txt else ""
        out = []
        for c in (0, 1):
            ys = cols[c]
            out.append(f"c{c}:{max(ys):6.1f}" if ys else f"c{c}:  --- ")
        # bottom margin reference: text area ends near H-60
        print(f"  p{pno+1:>2}  {out[0]}  {out[1]}   | {head}")


if __name__ == "__main__":
    for p in sys.argv[1:]:
        analyze(p)
