import importlib.util
import json
import sys
import time

spec = importlib.util.spec_from_file_location("a2", "a_scratch/a2_runtime.py")
a2 = importlib.util.module_from_spec(spec)
sys.modules["a2"] = a2
spec.loader.exec_module(a2)

out = []
for nodes in (500, 2000, 10000):
    g = a2.chain(nodes, max(1, nodes // 20), nodes // 10)
    tb = a2.compile_tables(g, 0.3, "pass")
    succ = a2.compile_graph(g)
    reps = []
    for _ in range(5):
        t0 = time.perf_counter()
        for i in range(200):
            a2.run_one(g, succ, tb, {"outcome": a2.VALUES[i % 4]})
        wall = time.perf_counter() - t0
        reps.append(wall / 200 * 1e6)
    reps.sort()
    row = {"nodes": nodes, "us_per_decision_median": round(reps[2], 1),
           "us_reps": [round(x, 1) for x in reps],
           "ns_per_node": round(reps[2] * 1000 / nodes, 1)}
    out.append(row)
    print(row)
json.dump({"scale": out, "decisions_per_rep": 200, "reps": 5},
          open(r"E:\vldb2027_pipeline_safety\06_结果\a2_scale_probe.json", "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
