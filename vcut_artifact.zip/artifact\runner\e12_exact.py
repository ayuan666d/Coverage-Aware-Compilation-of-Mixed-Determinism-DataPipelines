"""E12 leg 3: exact value evidence from the REAL SQLite files.

The 12-value sampling in the E11 catalog is our sampling of the database, not
the database's limit.  This leg asks the actual database: does this candidate
table contain the question's literal values in any text column?  Evidence is
IDF-normalised within the candidate pool (a value that hits many candidates
discriminates nothing).  Used as a reranker over any base ranking, and to
split the cross-DB ambiguity class into value-distinguishable vs not.

Read-only on the databases.  Self-contained.
"""
from __future__ import annotations

import json
import re
import sqlite3
import sys
from pathlib import Path

import numpy as np

REPO = Path("E:/vldb2027_pipeline_safety")
WORK = Path("D:/vldb2027_e11")
SPIDER_DB = WORK / "spider" / "database"
CASES = REPO / "06_结果" / "e11_cases.json"
SPECTRAL = REPO / "06_结果" / "e12_spectral.json"
OUT = REPO / "06_结果" / "e12_exact.json"

QUOTED = re.compile(r'"([^"]+)"|\'([^\']+)\'')
CAPSEQ = re.compile(r"\b([A-Z][a-zA-Z0-9]*(?:\s+[A-Z][a-zA-Z0-9]*)*)\b")
ACRO = re.compile(r"\b([A-Z]{2,}[0-9]*)\b")
NUM = re.compile(r"\b(\d{3,4})\b")


def value_strings(q):
    out = []
    for m in QUOTED.finditer(q):
        v = (m.group(1) or m.group(2)).strip()
        if v:
            out.append(v)
    caps = [m.group(1) for m in CAPSEQ.finditer(q)]
    acros = [m.group(1) for m in ACRO.finditer(q)]
    nums = [m.group(1) for m in NUM.finditer(q)]
    # drop single common capitalized words that start a sentence-ish token? keep all; IDF handles it
    seen = set()
    for v in caps + acros + nums:
        v = v.strip()
        if v and v.lower() not in seen:
            seen.add(v.lower())
            out.append(v)
    return out


class DB:
    def __init__(self, db):
        self.path = SPIDER_DB / db / f"{db}.sqlite"
        self.con = sqlite3.connect(f"file:{self.path}?mode=ro", uri=True) if self.path.exists() else None
        self.text_cols = {}
        if self.con:
            for (t,) in self.con.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"):
                cols = [(c[1], c[2]) for c in self.con.execute(f'PRAGMA table_info("{t}")')]
                self.text_cols[t.lower()] = [c for c, ty in cols
                                             if ty and any(x in ty.lower() for x in ("text", "char", "varchar"))]

    def has_value(self, table_lower, value):
        """Exact/nocase containment of value in any text column of the table."""
        if not self.con or table_lower not in self.text_cols:
            return False
        v = value.strip().strip("'\"")
        if not v:
            return False
        for col in self.text_cols[table_lower]:
            try:
                row = self.con.execute(
                    f'SELECT 1 FROM "{table_lower}" WHERE "{col}" = ? COLLATE NOCASE LIMIT 1', (v,)).fetchone()
                if row:
                    return True
                if len(v) >= 3 and v.isalpha():
                    row = self.con.execute(
                        f'SELECT 1 FROM "{table_lower}" WHERE "{col}" LIKE ? COLLATE NOCASE LIMIT 1',
                        (f"%{v}%",)).fetchone()
                    if row:
                        return True
            except sqlite3.Error:
                continue
        return False


def main():
    cache = json.load(open(WORK / "schema_cache.json", encoding="utf-8"))["spider"]
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    spec = json.load(open(SPECTRAL, encoding="utf-8"))
    qtext = {c["qid"]: c["question"] for c in cases}
    dbs = sorted({c["db_id"] for c in cases})
    _hcache = {}

    def handle(db):
        if db not in _hcache:
            _hcache[db] = DB(db)
        return _hcache[db]

    missing = sorted({d for d in dbs if handle(d).con is None})
    if missing:
        print("WARN no sqlite for:", missing[:10], "…evidence=0 there")

    rows = []
    for i, r in enumerate(spec["rows"]):
        qid = r["qid"]
        vals = value_strings(qtext[qid])
        pool, seen = [], set()
        ranks = {}
        for base, off in (("fused", 0), ("bm25", 0)):
            for rk, fid in enumerate(r[base]["top5"]):
                if fid not in seen:
                    seen.add(fid)
                    pool.append(fid)
                ranks.setdefault(fid, {})[base] = rk
        gold = [f"{r['db']}::{g.lower()}" for g in
                next(c["gold"] for c in cases if c["qid"] == qid)]
        for fid in gold:
            if fid not in seen:
                seen.add(fid)
                pool.append(fid)
                ranks[fid] = {}
        ev = np.zeros(len(pool), dtype=np.float32)
        hits = np.zeros(len(pool), dtype=np.int32)
        for v in vals:
            hitmask = np.zeros(len(pool), dtype=bool)
            for j, fid in enumerate(pool):
                db, tab = fid.split("::", 1)
                hitmask[j] = handle(db).has_value(tab, v)
            nh = int(hitmask.sum())
            if 0 < nh < len(pool):
                ev += hitmask * (1.0 / nh)
            hits += hitmask
        base_rank = [min(ranks[fid].get("fused", 50), ranks[fid].get("bm25", 50)) for fid in pool]
        rows.append({"qid": qid, "vals": vals, "pool": pool,
                     "base_rank": base_rank,
                     "evidence": [round(float(x), 4) for x in ev],
                     "hits": [int(x) for x in hits]})
        if (i + 1) % 150 == 0:
            print(f"  {i+1}/{len(spec['rows'])}", flush=True)
            sys.stdout.flush()
    json.dump(rows, open(OUT, "w", encoding="utf-8"))
    nz = sum(1 for r in rows if r["vals"])
    print(f"questions with value strings: {nz}/{len(rows)}; wrote {OUT}")


if __name__ == "__main__":
    main()
