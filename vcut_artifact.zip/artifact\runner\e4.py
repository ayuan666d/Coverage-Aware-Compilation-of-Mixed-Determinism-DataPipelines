# -*- coding: utf-8 -*-
"""E4 —— 重写必要性：约束是紧的吗？

核心问题（实验方案 §4-E4）：定理 1 的两个条件，是否无论如何都满足、
等于没说？

方法：对 E1 的合成管线施加五类**结构操作**（R1–R4 的结构效应近似），
每类操作独立施加后重验判决安全。统计破坏率。

操作 → 规则的对应（结构效应层面）：
    insert_verdict   出口前插入判决     ≈ R1 合法方向（割只增）
    remove_verdict   删除一个判决       ≈ 非法删除（割收缩）
    move_verdict     判决挪位           ≈ R1/R2 的位置重排
    swap_kinds       两个节点职能互换   ≈ 重排（R2 级联的换位效应）
    add_edge         加一条旁路边       ≈ 侧门（compile.py demo-bypass 同型）

三类判定：
    provable-safe    条件可静态证明成立（insert_verdict）
    provable-unsafe  条件可静态证明不成立（remove_verdict，除非冗余安全）
    must-recheck     只能逐例重验（move/swap/add_edge）

关键度量：
    · 各操作的安全破坏率（无检查直接重写的代价）
    · 「结构上应合法」的操作（insert）破坏率是否为 0 —— 割单调性 sanity check（不是 R1 语义验证）
    · 三类划分的占比 —— 这是 §5.6 论点的数据支撑
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

from checker.graphutil import reachable_set  # noqa: E402
from generator.synth import Pipe, synth, Table, Rule  # noqa: E402

SHAPES = ["line", "fork_join", "branch_verdict"]
NODES = [8, 20]
OPS = ["insert_verdict", "remove_verdict", "move_verdict", "swap_kinds", "add_edge"]
TRIALS_PER_PIPE = 40


# ── 判决安全（结构判定） ──────────────────────────────────────
#
# E4 研究的是**重写的结构效应**：割单调、remove 的割收缩
# 都是结构层面的命题。因此本实验固定 p_miss=0（决策表覆盖全部
# 输入，eff 恒真），此时 V_eff(t) = 全部判决节点（与 t 无关），
# 全称判定 ∀t 退化为单次结构判定，且与 R1 证明的“割只增”层面完全对齐。
# 注意：这里没有实现 R1 的表切分，所以 insert=0% 只验证割单调性，
# 不验证定理 4（R1 的语义条件）。


def struct_safe(pipe: Pipe) -> bool:
    """全部判决视为有效时，每个出口是否都从所有源不可达。"""
    succ = pipe.succ()
    srcs = pipe.sources()
    verdicts = frozenset(pipe.verdicts())
    return all(s not in reachable_set(src, succ, verdicts)
               for s in pipe.sinks() for src in srcs)


# ── 五类结构操作 ───────────────────────────────────────────────


def clone(pipe: Pipe) -> Pipe:
    return Pipe(
        nodes=dict(pipe.nodes),
        edges=list(pipe.edges),
        tables={k: Table(rules=list(v.rules), fallback=v.fallback) for k, v in pipe.tables.items()},
        input_space=list(pipe.input_space),
    )


def op_insert_verdict(pipe: Pipe, rng: random.Random) -> Optional[Pipe]:
    """在某个 (a,b) 边上插入一个新判决节点（合法方向：割只增）。"""
    p = clone(pipe)
    if not p.edges:
        return None
    a, b = rng.choice(p.edges)
    v = f"v_new{rng.randint(0, 10**9)}"
    tbl = rng.choice(list(p.tables.values())) if p.tables else None
    if tbl is None:
        return None
    p.nodes[v] = "rule"
    p.tables[v] = tbl
    p.edges.remove((a, b))
    p.edges += [(a, v), (v, b)]
    return p


def op_remove_verdict(pipe: Pipe, rng: random.Random) -> Optional[Pipe]:
    p = clone(pipe)
    vs = p.verdicts()
    if len(vs) <= 1:          # 至少留一个，避免退化为平凡图
        return None
    v = rng.choice(vs)
    preds = [a for a, b in p.edges if b == v]
    succs = [b for a, b in p.edges if a == v]
    p.edges = [(a, b) for a, b in p.edges if a != v and b != v]
    for a in preds:
        for b in succs:
            p.edges.append((a, b))
    del p.nodes[v]
    p.tables.pop(v, None)
    return p


def op_move_verdict(pipe: Pipe, rng: random.Random) -> Optional[Pipe]:
    """把判决 v 从原位置摘下，插到另一条边上。"""
    p = op_remove_verdict(pipe, rng)
    if p is None:
        return None
    return op_insert_verdict(p, rng)


def op_swap_kinds(pipe: Pipe, rng: random.Random) -> Optional[Pipe]:
    """两个**内部**节点职能互换（kind 跟节点走，边不动）。

    源/汇职能在系统语义里固定（入口/出口不是重写对象）——
    与定理 2 修复位置排除源汇是同一个设计决定。R1–R4 均不动源汇。
    """
    p = clone(pipe)
    inner = [n for n in p.nodes
             if n not in p.sources() and n not in p.sinks()]
    if len(inner) < 2:
        return None
    u, v = rng.sample(inner, 2)
    p.nodes[u], p.nodes[v] = p.nodes[v], p.nodes[u]
    if u in p.tables and v in p.tables:
        p.tables[u], p.tables[v] = p.tables[v], p.tables[u]
    elif u in p.tables:
        p.tables[v] = p.tables.pop(u)
    elif v in p.tables:
        p.tables[u] = p.tables.pop(v)
    return p


def op_add_edge(pipe: Pipe, rng: random.Random) -> Optional[Pipe]:
    """加一条原本不存在的边（潜在侧门），排除会成环的候选（保持 DAG）。

    成环判定：加 a→b 后，若 b 可达 a（a in reachable_set(b)）则成环。
    注意不能写成「b 可达 a」——那会把前向捷径边（真正危险的侧门，
    如 post→sink 绕过判决）全部误排除。
    """
    p = clone(pipe)
    ns = list(p.nodes)
    succ = p.succ()
    existing = set(p.edges)
    candidates = [(a, b) for a in ns for b in ns
                  if a != b and (a, b) not in existing
                  and a not in reachable_set(b, succ, frozenset())]
    if not candidates:
        return None
    a, b = rng.choice(candidates)
    p.edges.append((a, b))
    return p


OPS_IMPL = {
    "insert_verdict": op_insert_verdict,
    "remove_verdict": op_remove_verdict,
    "move_verdict": op_move_verdict,
    "swap_kinds": op_swap_kinds,
    "add_edge": op_add_edge,
}

# 静态可判类：insert 的割单调性由定理 4 的证明结构保证；remove 的割收缩风险由定义给出
PROVABLY_SAFE = {"insert_verdict"}
PROVABLY_RISKY = {"remove_verdict"}
MUST_RECHECK = {"move_verdict", "swap_kinds", "add_edge"}


# ── 主循环 ────────────────────────────────────────────────────


def run() -> dict:
    rng = random.Random(11)
    # (op → 结果计数)；结果 = safe_broken / safe_kept / inapplicable
    stats = {op: defaultdict(int) for op in OPS}
    n_pipes = 0
    base_unsafe_initially = 0
    # 逐因子分解（形状级）
    by_shape = defaultdict(lambda: defaultdict(int))

    for shape in SHAPES:
        for nn in NODES:
            for rep in range(6):
                # p_miss=0：表全覆盖，安全性退化为纯结构判定（见 struct_safe 注释）
                pipe = synth(shape, nn, 1, 1, 0.0, rng)
                n_pipes += 1
                if not struct_safe(pipe):
                    base_unsafe_initially += 1
                    continue          # 只在原本安全的管线上做重写实验

                for op in OPS:
                    fn = OPS_IMPL[op]
                    for _ in range(TRIALS_PER_PIPE):
                        new = fn(pipe, rng)
                        if new is None:
                            stats[op]["inapplicable"] += 1
                            continue
                        if struct_safe(new):
                            stats[op]["safe_kept"] += 1
                            by_shape[shape][op + "_kept"] += 1
                        else:
                            stats[op]["safe_broken"] += 1
                            by_shape[shape][op + "_broken"] += 1

    summary = {"n_pipes": n_pipes, "ops": {}}
    for op in OPS:
        s = stats[op]
        applied = s["safe_kept"] + s["safe_broken"]
        summary["ops"][op] = {
            "applied": applied,
            "inapplicable": s["inapplicable"],
            "broken": s["safe_broken"],
            "kept": s["safe_kept"],
            "break_rate": round(s["safe_broken"] / applied, 4) if applied else None,
            "class": ("provable-safe" if op in PROVABLY_SAFE
                      else "provable-risky" if op in PROVABLY_RISKY
                      else "must-recheck"),
        }
    total_applied = sum(v["applied"] for v in summary["ops"].values())
    summary["class_share"] = {
        cls: round(sum(v["applied"] for v in summary["ops"].values()
                       if v["class"] == cls) / total_applied, 4)
        for cls in ["provable-safe", "provable-risky", "must-recheck"]
    }
    summary["class_break_rate"] = {
        cls: (round(sum(v["broken"] for v in summary["ops"].values()
                        if v["class"] == cls) /
                    sum(v["applied"] for v in summary["ops"].values()
                        if v["class"] == cls), 4)
              if sum(v["applied"] for v in summary["ops"].values()
                     if v["class"] == cls) else None)
        for cls in ["provable-safe", "provable-risky", "must-recheck"]
    }
    summary["base_unsafe_initially"] = base_unsafe_initially
    summary["by_shape"] = {k: dict(v) for k, v in by_shape.items()}
    return summary


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(HERE / ".." / "06_结果" / "e4_summary.json"))
    args = ap.parse_args()

    s = run()
    print(f"参与管线 {s['n_pipes']} 条（其中 {s['base_unsafe_initially']} 条基线即不安全，已排除）")
    print(f"设定：p_miss=0（表全覆盖），安全性 = 纯结构判定（全部判决构成割）\n")
    print(f"{'操作':<18}{'类别':<16}{'施加':>7}{'破坏':>7}{'破坏率':>9}")
    for op, v in s["ops"].items():
        br = v["break_rate"]
        br_s = f"{br*100:.1f}%" if br is not None else "—"
        print(f"{op:<18}{v['class']:<16}{v['applied']:>7}{v['broken']:>7}{br_s:>9}")

    print(f"\n三类划分占比（试验数）：{s['class_share']}")
    print(f"三类破坏率（类内合并）：{s['class_break_rate']}")

    ins = s["ops"]["insert_verdict"]["break_rate"]
    print("\n判定：")
    print(f"  割单调性（insert 恒安全）：破坏率 = {ins} → {'✓ 与理论一致' if ins == 0 else '✗ 违反割单调，checker 或实现有 bug'}")
    print("  （注意：这不是定理 4 / R1 的语义验证；R1 的表切分未实现）")
    rm = s["ops"]["remove_verdict"]["break_rate"]
    print(f"  约束紧性（remove 必须高危）：破坏率 = {rm}"
          f" → {'✓ 约束是紧的' if rm and rm > 0.3 else '✗ 约束可能过松'}")

    Path(args.out).write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n已写入 {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
