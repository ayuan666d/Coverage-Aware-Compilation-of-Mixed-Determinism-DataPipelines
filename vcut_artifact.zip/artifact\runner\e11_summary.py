"""E11 digest: pull every result file into one table set for the report.

Nothing is computed here except formatting, so each number in the write-up can
be traced back to the JSON it came from.
"""
from __future__ import annotations

import json
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
R = REPO / "06_结果"
D = Path("D:/vldb2027_e11")


def load(p):
    return json.load(open(p, encoding="utf-8")) if Path(p).exists() else None


def main():
    bird = load(R / "e11_bird.json")
    known = load(R / "e11_spider_known.json")
    merged = load(R / "e11_spider_merged.json")
    dense_merged = load(R / "e11_spider_dense.json")
    dense_known = load(R / "e11_spider_known_dense.json")
    dense_bird = load(D / "e11_dense_bird.json")
    scale = load(R / "e11_scale.json")
    cert = {k: load(R / f"{k}_cert.json") for k in
            ["e11_bird", "e11_spider_merged", "e11_spider_known",
             "e11_spider_dense", "e11_spider_known_dense"]}
    ent = load(R / "e11_entity.json")
    entc = load(R / "e11_entity_cert.json")
    cord = load(R / "e11_cord_role.json")
    sim = load(R / "e11_sim.json")
    law = load(R / "e11_scale_law.json")
    cost = load(R / "e11_cost.json")
    para = load(R / "e11_paraphrase_eval.json")
    abl = load(R / "e11_ablation.json")
    sel = load(R / "e11_select.json")

    def row(tag, src, m):
        if not src:
            return
        mm = (src.get("metrics") or src.get("methods")).get(m)
        if not mm:
            return
        print(f"{tag:28s} {m:12s} n={src.get('n', 0):4d} "
              f"R@1 {mm['recall@1']:.3f} R@5 {mm['recall@5']:.3f} MRR {mm['mrr']:.3f}")

    print("== retrieval, BIRD (11 dbs)")
    for m in ("bm25", "ppr", "ppr_band", "typed", "typed_band"):
        row("bird", bird, m)
    if dense_bird:
        mm = dense_bird["metrics"]
        print(f"{'bird':28s} {'dense':12s} n={dense_bird['n']:4d} "
              f"R@1 {mm['recall@1']:.3f} R@5 {mm['recall@5']:.3f} MRR {mm['mrr']:.3f}")

    print("== retrieval, Spider per-database (test dbs)")
    for m in ("bm25", "ppr", "ppr_band", "typed", "typed_band"):
        row("spider known", known, m)
    if dense_known:
        for m in ("dense", "dense_plus_typed"):
            mm = dense_known["metrics"][m]
            print(f"{'spider known':28s} {m:12s} n={dense_known['n']:4d} "
                  f"R@1 {mm['recall@1']:.3f} R@5 {mm['recall@5']:.3f} MRR {mm['mrr']:.3f}")

    print("== retrieval, Spider merged catalog (876 tables)")
    for m in ("bm25", "ppr", "ppr_band", "typed", "typed_band"):
        row("spider merged", merged, m)
    if dense_merged:
        for m in ("dense", "bm25", "typed_band", "dense_typed", "dense_bm25", "all_three"):
            mm = dense_merged["metrics"].get(m)
            if mm:
                print(f"{'spider merged':28s} {m:12s} n={dense_merged['n']:4d} "
                      f"R@1 {mm['recall@1']:.3f} R@5 {mm['recall@5']:.3f} MRR {mm['mrr']:.3f}")

    if scale:
        print("== scale curve (recall@5)")
        print(f"{'N tables':>10s} {'bm25':>8s} {'graph':>8s} {'dense':>8s} {'n_q':>6s}")
        for r in scale["runs"]:
            m = r["metrics"]
            print(f"{r['N']:>10d} {m.get('bm25', {}).get('recall@5', float('nan')):>8.3f} "
                  f"{m.get('ppr_band', {}).get('recall@5', float('nan')):>8.3f} "
                  f"{m.get('dense', {}).get('recall@5', float('nan')):>8.3f} {r['n_q']:>6d}")

    print("== certificates (best rule at >=95% precision)")
    for name, c in cert.items():
        if not c:
            continue
        for m, v in c["methods"].items():
            for k in ("key_exact", "strict", "score"):
                b = v.get(k + "_at_95")
                if b:
                    print(f"{name:26s} {m:14s} {k:10s} cov {b['coverage']:.3f} "
                          f"prec {b['precision']:.3f} fp {b['false_pass_rate']:.3f} "
                          f"kept {b['share_of_correct_kept']}")

    kc = load(R / "e11_key_cert.json")
    if kc:
        print("== database-verified uniqueness certificates")
        for k, v in kc.items():
            for rule, x in v.items():
                p = x["precision"]
                print("  {:16s} {:8s} cov {:.3f} prec {} fp {:.3f} n {}".format(
                    k, rule, x["coverage"], "-" if p is None else f"{p:.3f}",
                    x["false_pass_rate"], x["n"]))
    if entc:
        print("== entity certificates")
        for ds, v in entc.items():
            for k, x in v.items():
                if isinstance(x, dict):
                    print("{} {:18s} cov {:.3f} prec {} fp {}".format(
                        ds, k, x["coverage"],
                        "-" if x["precision"] is None else f"{x['precision']:.3f}",
                        "-" if x.get("false_pass_rate") is None else f"{x['false_pass_rate']:.3f}"))

    if cord:
        print("== CORD role separation (n=%d)" % cord["all"]["n"])
        a = cord["all"]
        print(f"  all-label seeds: untyped {a['single_all_acc']:.3f} typed {a['typed_all_acc']:.3f} "
              f"(fixed {a['all_fixed']}, broke {a['all_broke']})")
        print(f"  total-label seeds: untyped {a['single_acc']:.3f} typed {a['typed_acc']:.3f}")

    if sim:
        print("== simulation")
        for r in sim["rho_sweep"]:
            print(f"  rho={r['rho']:.1f} untyped {r['untyped']:.3f} "
                  f"typed-right {r['typed_theme']:.3f} typed-wrong {r['typed_role']:.3f}")
        print("  law pearson", sim.get("law_pearson_log"), "mean_acc", sim.get("mean_acc"))

    if law:
        print("== real-graph scale law")
        print("  points", law["n_points"], "pearson", law["pearson_log_t_vs_inv_gap"],
              law["mean_r5"])

    if cost:
        print("== cost")
        for r in cost["runs"]:
            print(f"  {r['label']:14s} tables {r['n_tables']:5d} nodes {r['n_nodes']:6d} "
                  f"build {r['build_s']} p95 {r['query_p95_ms']} update1% {r['update_1pct_s']}")

    if para:
        print("== paraphrase (clean n=%d)" % para["n_clean"])
        for s, v in para["by_style"].items():
            print(f"  {s:11s} " + " ".join(
                f"{m} {v[m]['recall@5']:.3f}" for m in v))
        print("  expert-minus-orig", para["drop_expert_vs_orig"])

    if ent:
        print("== entity retrieval")
        for ds, v in ent.items():
            for k, x in v["metrics"].items():
                print(f"  {ds:14s} {k:14s} R@1 {x['r@1']:.3f} R@5 {x['r@5']:.3f}")

    if sel:
        print("== operator selection on held-in data (n=%d)" % sel["n_val"])
        for k, v in sel["metrics"].items():
            print(f"  {k:16s} R@5 {v['recall@5']:.3f}  selected: {sel['selected']}")

    if abl:
        print("== ablations")
        for k, v in abl.items():
            print(" ", k)
            for m, mm in sorted(v["metrics"].items(), key=lambda x: -x[1]["recall@5"]):
                print(f"    {m:18s} R@1 {mm['recall@1']:.3f} R@5 {mm['recall@5']:.3f}")


if __name__ == "__main__":
    main()
