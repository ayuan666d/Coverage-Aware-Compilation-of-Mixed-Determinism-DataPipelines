# -*- coding: utf-8 -*-
"""E5 prototype: repair a missing guard by synthesis + exhaustive verification.

Setup
-----
* Base pipeline: the GB 30871 table (P1-P8 / Q1-Q5) on a finite post-field domain.
* Hidden policy H: `lel > 15 AND o2 < 20.5` (a rule the pipeline does not have).
* Ground truth = base table OR H.
* A state is *bad* if H rejects it but the base pipeline passes it (false pass).
* Repair = synthesize a guard g over post fields that rejects every bad state and
  no good state, then verify g on the whole finite domain.

The point: placement is trivial here (linear pipeline); synthesis is the hard part.
A sample-only synthesizer can look perfect on 30 examples and still leak on the
full domain; CEGIS (synthesize -> verify -> counterexample) closes the gap.
"""

from __future__ import annotations

import itertools
import json
import random
import sys
import time
from pathlib import Path
from typing import Callable, Dict, List, Tuple

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "05_代码"))

from checker.decision_table import load_table  # noqa: E402

TABLE_PATH = REPO / "04_数据" / "gb30871" / "decision_table_v0.2.yaml"
OUT = REPO / "06_结果" / "E5_修复合成.json"

PRE = {
    "work_type": "confined", "fire_level": "none", "valid_hours": 8,
    "approval_level": "company", "multi_permit": False, "multi_permits_ok": True,
    "approver_authorized": True, "guardian_certified": True,
    "gas_before_approval": True,
}
LEL = [0, 10, 15, 20, 25, 30, 40]
O2 = [17.0, 18.5, 19.0, 19.5, 20.0, 20.5, 20.9, 21.0, 23.0, 23.5, 24.0, 25.0]
BOOLS = [False, True]


def states() -> List[dict]:
    out = []
    for lel, o2, m, iso, cl in itertools.product(LEL, O2, BOOLS, BOOLS, BOOLS):
        out.append({"measures_done": m, "lel": lel, "o2": o2,
                    "isolated": iso, "cleanup": cl})
    return out


def hidden(s: dict) -> bool:
    return s["lel"] > 15 and s["o2"] < 20.5


# ── DSL ──────────────────────────────────────────────────────
# atom = (name, fn); candidate = expression over atoms
def atoms() -> List[Tuple[str, Callable[[dict], bool]]]:
    out = []
    for c in [5, 10, 15, 20, 25, 30, 35]:
        out.append((f"lel>{c}", lambda s, c=c: s["lel"] > c))
        out.append((f"lel<={c}", lambda s, c=c: s["lel"] <= c))
    for c in [18.0, 19.0, 19.5, 20.0, 20.5, 21.0, 22.0, 23.0, 23.5, 24.0]:
        out.append((f"o2<{c}", lambda s, c=c: s["o2"] < c))
        out.append((f"o2>={c}", lambda s, c=c: s["o2"] >= c))
    out += [
        ("measures_done=False", lambda s: not s["measures_done"]),
        ("isolated=False", lambda s: not s["isolated"]),
        ("cleanup=False", lambda s: not s["cleanup"]),
    ]
    return out


def candidates() -> List[Tuple[str, Callable[[dict], bool], int]]:
    """Single atoms and 2-atom AND/OR; complexity = atom count."""
    A = atoms()
    out = [(n, f, 1) for n, f in A]
    for (n1, f1), (n2, f2) in itertools.combinations(A, 2):
        out.append((f"({n1}) AND ({n2})", lambda s, f1=f1, f2=f2: f1(s) and f2(s), 2))
        out.append((f"({n1}) OR ({n2})", lambda s, f1=f1, f2=f2: f1(s) or f2(s), 2))
    return out


def evaluate_candidate(pred, U, bad: set, good: set):
    fp = sum(1 for i in bad if not pred(U[i]))       # bad not rejected -> false pass
    fk = sum(1 for i in good if pred(U[i]))          # good rejected -> false kill
    return fp, fk


def synth_candidates(cands, sample, U):
    """Candidates consistent with the current sample (reject all bad, no good)."""
    out = []
    for name, pred, size in cands:
        ok = all(pred(U[i]) for i in sample["bad"]) and not any(
            pred(U[i]) for i in sample["good"])
        if ok:
            out.append((name, pred, size))
    return out


def cegis(U, bad: set, good: set, rng: random.Random, max_rounds: int = 12):
    cands = candidates()
    sample = {
        "bad": rng.sample(sorted(bad), min(2, len(bad))),
        "good": rng.sample(sorted(good), min(8, len(good))),
    }
    history = []
    for rnd in range(1, max_rounds + 1):
        consistent = synth_candidates(cands, sample, U)
        history.append({"round": rnd, "consistent": len(consistent),
                        "sample_bad": len(sample["bad"]), "sample_good": len(sample["good"])})
        if not consistent:
            return None, history
        # prefer simplest; among same size, first
        name, pred, size = min(consistent, key=lambda x: (x[2], len(x[0])))
        fp, fk = evaluate_candidate(pred, U, bad, good)
        if fp == 0 and fk == 0:
            return {"guard": name, "size": size, "false_pass": 0,
                    "false_kill": 0, "rounds": rnd}, history
        # add counterexamples
        new_bad = [i for i in bad if not pred(U[i])]
        new_good = [i for i in good if pred(U[i])]
        if new_bad:
            sample["bad"] = sorted(set(sample["bad"]) | set(new_bad[:16]))
        if new_good:
            sample["good"] = sorted(set(sample["good"]) | set(new_good[:16]))
    return None, history


def sweep(U, bad: set, good: set, n: int = 30) -> dict:
    """Compare sample-only synthesis with CEGIS over n random samples."""
    fps, fks, rounds = [], [], []
    for seed in range(n):
        rng = random.Random(seed)
        sample = {"bad": rng.sample(sorted(bad), min(2, len(bad))),
                  "good": rng.sample(sorted(good), min(8, len(good)))}
        cons = synth_candidates(candidates(), sample, U)
        if cons:
            _, pred, _ = min(cons, key=lambda x: (x[2], len(x[0])))
            fp, fk = evaluate_candidate(pred, U, bad, good)
            fps.append(fp)
            fks.append(fk)
        else:
            fps.append(None)
            fks.append(None)
        rep, _ = cegis(U, bad, good, random.Random(1000 + seed))
        rounds.append(rep["rounds"] if rep else None)
    def dist(xs):
        return {str(x): xs.count(x) for x in sorted(set(xs), key=str)}
    return {
        "n": n,
        "sample_only_false_pass": dist(fps),
        "sample_only_false_kill": dist(fks),
        "cegis_rounds": dist(rounds),
        "sample_only_leak_seeds": sum(1 for x in fps if x),
    }


def main() -> None:
    table = load_table(TABLE_PATH)
    U = states()
    base = {i: table.evaluate({**PRE, **s}) for i, s in enumerate(U)}
    bad = {i for i in range(len(U)) if base[i].verdict == "pass" and hidden(U[i])}
    good = {i for i in range(len(U)) if base[i].verdict == "pass" and not hidden(U[i])}
    print(f"states={len(U)} bad(false pass)={len(bad)} good={len(good)}")

    # baselines
    reject_all = {"guard": "reject-all", "false_pass": 0, "false_kill": len(good)}
    no_repair = {"guard": "none", "false_pass": len(bad), "false_kill": 0}

    # sample-only: pick the candidate that fits a 30-state sample, no verification
    rng = random.Random(20261030)
    sample = {"bad": rng.sample(sorted(bad), min(2, len(bad))),
              "good": rng.sample(sorted(good), min(8, len(good)))}
    consistent = synth_candidates(candidates(), sample, U)
    if consistent:
        name, pred, size = min(consistent, key=lambda x: (x[2], len(x[0])))
        fp, fk = evaluate_candidate(pred, U, bad, good)
        sample_only = {"guard": name, "size": size, "false_pass": fp, "false_kill": fk}
    else:
        sample_only = {"guard": None}

    t0 = time.time()
    repaired, history = cegis(U, bad, good, random.Random(20261031))
    if repaired:
        repaired["time_s"] = round(time.time() - t0, 3)
        repaired["cegis"] = history
    else:
        repaired = {"guard": None, "cegis": history}

    out = {
        "domain": {"states": len(U), "bad": len(bad), "good": len(good)},
        "hidden_policy": "lel > 15 AND o2 < 20.5",
        "baselines": {"no_repair": no_repair, "reject_all": reject_all,
                      "sample_only": sample_only},
        "cegis": repaired,
        "sweep": sweep(U, bad, good),
    }
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
