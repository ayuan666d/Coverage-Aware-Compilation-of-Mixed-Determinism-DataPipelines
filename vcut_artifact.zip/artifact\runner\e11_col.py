"""E11-COL: column-level coverage operator (task #20, Paper B).

The diagnosis in E11_semantic_zoom.md sec 2.7 says the remaining 7.0 points live in
hub neighbourhoods: 46 test questions whose rarest anchor inside the gold table has
catalogue df 6-20 (city / country / name).  There the table-level rerank (39.1% R@5)
is *below* plain BM25 (47.8%).  The stated cause: projecting diffusion onto table
nodes flattens "which column carries the evidence and how many columns are hit".

This tests that cause directly.  Everything else is held fixed -- same catalogue,
same identifier split, same BM25 recall stage (top 30), same rank-space rerank.  Only
the rerank key changes, and every alternative is defined on the column level.

Pre-registered protocol (written before any test reading was taken):
  * variants are compared on the TRAIN questions only (132 databases);
  * a variant survives only if its train R@5 >= V0 - 0.5 point AND the frozen
    certificate's accepted-subset R@5 (k>=3 & rarest df<=2, e11_support2.py) is
    >= V0 - 0.5 point  -- that second guard is task #20's acceptance condition;
  * among survivors the winner is the one with the best TRAIN hub-bucket (df 6-20)
    R@5;
  * the winner's test reading is then taken untouched.  Existing archive rows stay
    as reported: this script adds rows, it does not rewrite them.

Protocol correction made publicly after the first run.  With --history the guard
selects V0 on train while every column variant beats it on test, which cannot both
be true.  The cause is in the implementation, not in the operator: the co-query edges
of the union graph are mined from the train gold table pairs, so a train question's
gold pair is joined by an edge that was built from that question's own answer, and the
table-level operator reads mass straight across it (column nodes do not carry that
edge).  Selection therefore happens on the COLD catalogue (coquery=None), which is
also the setting the paper claims; --history is kept only to size the leak.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_run_spider import coquery_map, fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
OUT = REPO / "06_结果" / "e11_col.json"
EPS, ALPHA, ITERS, TOPK = 1e-6, 0.85, 20, 30
K_FROZEN, M_FROZEN = 3, 2
GRAPH_V = ["v0_table_gm", "c1_sum_max", "c2_sum_top2", "c3_tokmaxpool_gm",
           "c4_tokmaxpool_sum", "c5_colgm_max", "c6_sum_max_width"]
LEX_V = ["l1_bm25col_max", "l2_bm25col_top2", "l3_bm25col_sum"]
VARIANTS = GRAPH_V + LEX_V + ["bm25_only"]


def col_index(cat):
    """Column documents plus the table -> column span they came from."""
    nodes, docs, starts, ends = [], [], [], []
    for t in cat.tables:
        starts.append(len(nodes))
        for c in t["columns"]:
            nodes.append(cat.col_node[(t["tid"], c["name"])])
            d = toks(c["name"])
            for v in c.get("values", [])[:6]:
                d += toks(v)[:3]
            docs.append(d)
        ends.append(len(nodes))
    return np.array(nodes), docs, np.array(starts), np.array(ends)


def col_bm25_scores(docs, query, k1=1.2, b=0.75):
    tf = [Counter(d) for d in docs]
    df = Counter()
    for d in tf:
        df.update(set(d))
    n = len(docs)
    avgdl = sum(len(d) for d in docs) / max(1, n)
    out = np.zeros(n, dtype=np.float32)
    qs = set(query)
    for i, t in enumerate(tf):
        dl = len(docs[i])
        s = 0.0
        for w in qs:
            f = t.get(w, 0)
            if not f:
                continue
            idf = math.log(1 + (n - df[w] + 0.5) / (df[w] + 0.5))
            s += idf * f * (k1 + 1) / (f + k1 * (1 - b + b * dl / avgdl))
        out[i] = s
    return out


def seg_top12(vals, starts, ends):
    m1 = np.zeros(len(starts), dtype=np.float32)
    m2 = np.zeros(len(starts), dtype=np.float32)
    for i in range(len(starts)):
        seg = np.atleast_1d(np.asarray(vals[starts[i]:ends[i]]).ravel())
        if seg.size == 1:
            m1[i] = float(seg[0])
        elif seg.size:
            a, b = np.partition(seg, -2)[-2:]
            m1[i] = float(max(float(a), float(b)))
            m2[i] = float(min(float(a), float(b)))
    return m1, m2


def gm(M, iw):
    """idf-weighted geometric mean over tokens; M is (n_tokens, n_units)."""
    if M.shape[0] == 0:
        return np.zeros(M.shape[1], dtype=np.float32)
    w = np.asarray(iw).reshape(-1, 1)
    return np.exp((w * np.log(M + EPS)).sum(axis=0) / w.sum())


def bucket(m):
    if m >= 10 ** 9:
        return "df0"
    if m <= 1:
        return "df1"
    if m <= 5:
        return "df2_5"
    if m <= 20:
        return "df6_20"
    return "df20p"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--history", action="store_true",
                    help="keep co-query edges mined from the train gold tables. "
                         "That leaks the answer into the graph on the train half: the "
                         "table-level operator reads mass across exactly the edge built "
                         "from the question's own gold pair, column nodes do not.  Used "
                         "only to size the leak, never to select.")
    args = ap.parse_args()
    g.SPLIT_IDENT = True
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    train = [c for c in data["spider"] if c["split"] == "train"]
    test = [c for c in data["spider"] if c["split"] == "test"]
    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    coq = coquery_map(train, prefix=True) if args.history else None
    cat = g.Catalog(tabs, fks, coquery=coq, prefix_db=True)
    N = len(cat.tables)
    z = np.load(EMB, allow_pickle=True)
    ids = list(z["ids"])
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}
    assert ids == cat.table_ids

    colnodes, cdocs, starts, ends = col_index(cat)
    ncol = (ends - starts).astype(np.float32)
    ncol = np.maximum(ncol, 1.0)
    print(f"catalogue {N} tables / {len(cdocs)} columns / "
          f"{sum(1 for k in cat.idx if k[0] == 'token')} tokens", flush=True)

    t0 = time.time()
    tok_tab, tok_col = {}, {}
    for w in sorted({w for c in train + test for w in toks(c["question"])}):
        k = ("token", w)
        if k not in cat.idx:
            continue
        x = g.ppr(cat.union, {cat.idx[k]: 1.0}, ALPHA, ITERS)
        st = cat.table_scores(x)
        mx = float(st.max())
        if mx <= 0:
            continue
        tok_tab[w] = (st / mx).astype(np.float32)
        cv = np.asarray(x)[colnodes].astype(np.float32)
        cmx = float(cv.max())
        tok_col[w] = cv / cmx if cmx > 0 else cv
    print(f"per-token diffusion cache: {len(tok_tab)} tokens in {time.time()-t0:.0f}s",
          flush=True)

    idf_of = {w: math.log(1 + (N - cat.token_df.get(w, 0) + 0.5)
                          / (cat.token_df.get(w, 0) + 0.5)) for w in tok_tab}

    def run(cases, use_dense):
        rows = []
        for c in cases:
            q = toks(c["question"])
            gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
            ws = sorted({w for w in q if w in tok_tab})
            b = g.bm25(cat, q)
            top = np.argsort(-b)[:TOPK]
            base = float(b[top[-1]])
            keys = {}
            if ws:
                iw = np.array([idf_of[w] for w in ws], dtype=np.float32)[:, None]
                Mt = np.stack([tok_tab[w] for w in ws])
                Mc = np.stack([tok_col[w] for w in ws])
                keys["v0_table_gm"] = gm(Mt, iw)
                S = (iw * Mc).sum(axis=0)                 # idf-weighted column mean
                m1, m2 = seg_top12(S, starts, ends)
                keys["c1_sum_max"] = m1
                keys["c2_sum_top2"] = m1 + 0.5 * m2
                keys["c6_sum_max_width"] = m1 / (1.0 + np.log(ncol))
                Tt = np.maximum.reduceat(Mc, starts, axis=1)   # each token, best column
                keys["c3_tokmaxpool_gm"] = gm(Tt, iw)
                keys["c4_tokmaxpool_sum"] = (iw * Tt).sum(axis=0) / iw.sum()
                Cg = gm(Mc, iw)                           # conjunction inside one column
                keys["c5_colgm_max"], _ = seg_top12(Cg, starts, ends)
            if not ws:
                # no catalogue-visible anchor at all: every operator degenerates to
                # the BM25 order, exactly as in e11_support2.py.  Dropping these rows
                # instead would silently change the denominator of the arm we are
                # supposed to be reproducing.
                for v in GRAPH_V:
                    keys[v] = np.zeros(N, dtype=np.float32)
            L = col_bm25_scores(cdocs, q)
            l1, l2 = seg_top12(L, starts, ends)
            keys["l1_bm25col_max"] = l1
            keys["l2_bm25col_top2"] = l1 + 0.5 * l2
            keys["l3_bm25col_sum"] = np.add.reduceat(L, starts)
            rec = {"qid": c["qid"], "db": c["db_id"], "n_gold": len(gold)}
            rarest = min([cat.token_df.get(w, 10 ** 9) for w in ws], default=10 ** 9)
            rec["m_q"] = int(rarest)
            gold_tokens = set()
            for tid in gold:
                if tid in cat.table_pos:
                    gold_tokens |= set(q) & set(g.table_doc(cat.tables[cat.table_pos[tid]]))
            mg = min([cat.token_df.get(w, 10 ** 9) for w in gold_tokens], default=10 ** 9)
            rec["bucket"] = bucket(mg)
            for name, sc in keys.items():
                sc = np.asarray(sc, dtype=np.float32).ravel()
                if sc.size != N:
                    raise RuntimeError(f"{name} has size {sc.size} (qid {c['qid']})")
                mixed = b.copy()
                order = top[np.argsort(-sc[top])]
                for i, idx in enumerate(order):
                    mixed[idx] = base + (TOPK - i) * 1e-6
                r = g.rank(mixed, cat)
                mm = g.metrics(r, gold)
                t1 = r[0]
                rec[name] = {"r1": round(mm["recall@1"], 4), "r5": round(mm["recall@5"], 4),
                             "mrr": round(mm["mrr"], 4),
                             "k": int(len(set(q) & set(g.table_doc(
                                 cat.tables[cat.table_pos[t1]]))))}
            r = g.rank(b, cat)
            mm = g.metrics(r, gold)
            rec["bm25_only"] = {"r1": round(mm["recall@1"], 4), "r5": round(mm["recall@5"], 4),
                                "mrr": round(mm["mrr"], 4),
                                "k": int(len(set(q) & set(g.table_doc(
                                    cat.tables[cat.table_pos[r[0]]]))))}
            if use_dense and c["qid"] in qpos:
                d = Dm @ Qm[qpos[c["qid"]]]
                md = g.metrics([ids[i] for i in np.argsort(-d)], gold)
                rec["dense"] = {"r1": round(md["recall@1"], 4), "r5": round(md["recall@5"], 4)}
            rows.append(rec)
        return rows

    tr = run(train, use_dense=False)
    te = run(test, use_dense=True)
    print(f"train {len(tr)} / test {len(te)} rows", flush=True)

    def summarize(rows):
        out = {}
        for v in VARIANTS:
            sub = [r for r in rows if v in r]
            hub = [r for r in sub if r["bucket"] == "df6_20"]
            acc = [r for r in sub if r[v]["k"] >= K_FROZEN and r["m_q"] <= M_FROZEN]
            rej = [r for r in sub if not (r[v]["k"] >= K_FROZEN and r["m_q"] <= M_FROZEN)]
            m = lambda rs, key: round(float(np.mean([r[v][key] for r in rs])), 4) if rs else None  # noqa: E731
            d = {"n": len(sub), "r1": m(sub, "r1"), "r5": m(sub, "r5"), "mrr": m(sub, "mrr"),
                 "hub_n": len(hub), "hub_r5": m(hub, "r5"), "hub_r1": m(hub, "r1"),
                 "acc_cov": round(len(acc) / max(1, len(sub)), 4),
                 "acc_r5": m(acc, "r5"), "acc_r1": m(acc, "r1")}
            if all("dense" in r for r in sub):
                d["hybrid_r5"] = round((sum(r[v]["r5"] for r in acc)
                                        + sum(r["dense"]["r5"] for r in rej)) / len(sub), 4)
                d["hybrid_r1"] = round((sum(r[v]["r1"] for r in acc)
                                        + sum(r["dense"]["r1"] for r in rej)) / len(sub), 4)
                d["acc_dense_r5"] = (round(float(np.mean([r["dense"]["r5"] for r in acc])), 4)
                                     if acc else None)
                d["acc_dense_r1"] = (round(float(np.mean([r["dense"]["r1"] for r in acc])), 4)
                                     if acc else None)
            for bk in ("df0", "df1", "df2_5", "df6_20", "df20p"):
                bsub = [r for r in sub if r["bucket"] == bk]
                d[f"{bk}_n"] = len(bsub)
                d[f"{bk}_r5"] = m(bsub, "r5")
            out[v] = d
        return out

    st_tr, st_te = summarize(tr), summarize(te)
    v0 = st_tr["v0_table_gm"]
    guard = {"v0_train_r5": v0["r5"], "v0_train_acc_r5": v0["acc_r5"]}
    survivors = [v for v in GRAPH_V + LEX_V
                 if st_tr[v]["r5"] is not None and st_tr[v]["r5"] >= v0["r5"] - 0.005
                 and (st_tr[v]["acc_r5"] is None or st_tr[v]["acc_r5"] >= (v0["acc_r5"] or 0) - 0.005)]
    winner = max(survivors, key=lambda v: (st_tr[v]["hub_r5"] or -1)) if survivors else None
    out = {"n_train": len(tr), "n_test": len(te), "guard": guard,
           "history": bool(args.history),
           "survivors": survivors, "selected_on_train": winner,
           "train_summary": st_tr, "test_summary": st_te,
           "test_rows": te, "train_rows": tr}
    out_path = OUT if not args.history else str(OUT).replace(".json", "_history.json")
    json.dump(out, open(out_path, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({"guard": guard, "survivors": survivors, "winner": winner,
                      "train": {v: {k: st_tr[v][k] for k in
                                    ("n", "r1", "r5", "hub_n", "hub_r5", "acc_cov", "acc_r5")}
                                for v in VARIANTS},
                      "test": {v: {k: st_te[v][k] for k in
                                   ("n", "r1", "r5", "hub_r5", "acc_cov", "acc_r5", "acc_r1",
                                    "hybrid_r5", "hybrid_r1")} for v in VARIANTS}},
                     indent=1, ensure_ascii=False))
    print("wrote", out_path)


if __name__ == "__main__":
    main()
