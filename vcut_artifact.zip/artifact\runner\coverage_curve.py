# -*- coding: utf-8 -*-
"""Coverage curve: with k authoritative post fields, how much can the DB decide?

The point is the asymmetry:
  * a violation can be rejected as soon as the fields of its rule are known;
  * a pass can only be certified when *all* post fields are known
    (missing -> review, by the table's semantics).

So reject coverage grows with k, pass coverage stays 0 until k = |F|.
This is a structural property of violation-only rules + missing->review,
not a property of a particular model.

Usage:
    python runner/coverage_curve.py --docs ../04_数据/permits/documents_web.jsonl
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from pathlib import Path
from typing import Dict, List, Tuple

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "05_代码"))

from checker.decision_table import DecisionTable, load_table  # noqa: E402

TABLE_PATH = REPO / "04_数据" / "gb30871" / "decision_table_v0.2.yaml"


def curve(docs: List[dict], table: DecisionTable) -> List[dict]:
    reached = [d for d in docs if table.pre_decision(d["pre"]) is None]
    fields = list(table.post_fields)
    rows = []
    for k in range(len(fields) + 1):
        best = None
        for sub in itertools.combinations(fields, k):
            caught = false_reject = certified = review = 0
            for d in reached:
                known = {f: d["post_true"][f] for f in sub if f in d["post_true"]}
                if len(known) < len(sub):
                    review += 1
                    continue
                dec = table.partial_post_decision(known)
                if dec.rule_id:
                    if d["true_verdict"] == "reject":
                        caught += 1
                    else:
                        false_reject += 1
                elif dec.verdict == "pass":
                    certified += 1
                else:
                    review += 1
            score = (caught, certified, -false_reject, -review)
            if best is None or score > best[0]:
                best = (score, sub, caught, certified, review, false_reject)
        _, sub, caught, certified, review, false_reject = best
        rows.append({
            "k": k,
            "fields": list(sub),
            "caught_reject": caught,
            "certified_pass": certified,
            "review": review,
            "false_reject": false_reject,
            "model_calls_saved": caught,
        })
    return rows


def write_report(rows: List[dict], n_docs: int, n_reached: int, out: Path) -> None:
    lines = [
        "# E2 覆盖曲线：部分求值下，拒绝与通过的不对称",
        "",
        "> 30 份混合语料；只有 3 个真 reject、16 个真 pass 进入模型，**这是形状演示，不是比例估计**。",
        "",
        f"- 文档：{n_docs} 份；pre 表判掉 {n_docs - n_reached} 份；进入模型 {n_reached} 份。",
        "- `caught_reject`：真 reject 中，仅凭 k 个已知字段就被规则拒绝的份数。",
        "- `certified_pass`：真 pass 中，能凭已知字段认证为通过的份数。",
        "- `review`：字段不足，不能下结论的份数。",
        "",
        "| k | 已知字段 | 抓住 reject | 认证 pass | 仍 review | 误拒 | 省掉模型调用 |",
        "|---|---|---|---|---|---|---|",
    ]
    for r in rows:
        fs = ", ".join(r["fields"]) if r["fields"] else "—"
        lines.append(
            f"| {r['k']} | {fs} | {r['caught_reject']} | {r['certified_pass']} "
            f"| {r['review']} | {r['false_reject']} | {r['model_calls_saved']} |"
        )
    lines += [
        "",
        "**读法：拒绝覆盖随 k 增长，通过覆盖在 k < |F| 时恒为 0。**",
        "",
        "原因不是数据，而是规则语义：违规规则是“存在一条为真就 reject”；"
        "pass 是“所有规则都不为真”，而缺失字段不能当成“规则不为真”，所以 pass 必须等全覆盖。"
        "换句话说，**数据库的部分覆盖能抓不合理，但不能证明合理**；后者要么补全字段，要么交给模型，"
        "要么显式 review——不能默认 pass。",
        "",
        "这也给出一个可证的上界：在 violation-only 规则 + missing→review 下，"
        "任何 k < |F| 的模型前判决只能是 reject 或 review，不可能是 pass。"
        "`certified_default=true` 正是试图绕过这个上界，把“没覆盖”写成“合规”。",
        "",
    ]
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--docs", default=str(TABLE_PATH.parents[1] / "permits" / "documents_web.jsonl"))
    ap.add_argument("--out", default=str(TABLE_PATH.parents[2] / "06_结果" / "E2_覆盖曲线.md"))
    args = ap.parse_args()
    table = load_table(TABLE_PATH)
    docs = [json.loads(l) for l in Path(args.docs).read_text(encoding="utf-8").splitlines() if l.strip()]
    rows = curve(docs, table)
    reached = sum(1 for d in docs if table.pre_decision(d["pre"]) is None)
    write_report(rows, len(docs), reached, Path(args.out))
    print(json.dumps({"rows": rows, "n_docs": len(docs), "n_reached": reached},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
