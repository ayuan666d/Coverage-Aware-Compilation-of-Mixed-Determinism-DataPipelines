"""E27：A 类基线（零模型、零预训练、零额外标注）在同一 876 表平铺目录上的读数。

口径与 z_split341 / z_cv 完全一致：
- 目录：Spider 166 库 876 表，doc_ids 顺序取自 z_all_feats.npz
- 冷启动：341 问 / 6 库（e11_dense_spider.json 的 qid 集合），其余 693 问 / 14 库
- 指标：R@1 / R@5 为多金标部分分口径，top1 为首位是否命中
- 计时：建索引（不含公共表解析）+ 全量 1034 问打分均值

基线全部不使用任何标签，不使用预训练模型：
  bm25_all / bm25_schema / tfidf_cos / jaccard / levenshtein / value_overlap / schema_graph
"""
from __future__ import annotations

import json
import math
import re
import time
from collections import Counter, defaultdict

import numpy as np
from rapidfuzz import fuzz, process

W = r"D:\vldb2027_e11"
CASES = r"E:\vldb2027_pipeline_safety\06_结果\e11_cases.json"
SCHEMA = W + r"\schema_cache.json"
FEATS = W + r"\z_all_feats.npz"
DENSE = W + r"\e11_dense_spider.json"
FOLDS = W + r"\z_folds.json"
OUT = W + r"\e27_a_baselines.json"

WORD = re.compile(r"[a-z0-9]+")
CAMEL = re.compile(r"[A-Z]+(?![a-z])|[A-Z][a-z]+|[a-z]+|[0-9]+")
STOP = set("""a an the of to in for and or on by with what which how many much is are was were
does do that this from at as per than then their its it who whom whose when where why not
all any each other such only also into over under between during before after above below
more most less least few several can could should would may might will shall has have had
there here we you they he she i me my our your his her them us list show give find return
number names name""".split())


def stem(w):
    return w[:-1] if len(w) > 3 and w.endswith("s") else w


def qtoks(s):
    out = []
    for w in WORD.findall(s):
        if w in STOP:
            continue
        out.append(stem(w))
    for w in CAMEL.findall(s):
        lw = w.lower()
        if lw not in STOP and len(lw) > 1:
            out.append(stem(lw))
    return out


def ev(S, qs, gold, doc_ids):
    r1 = r5 = top1 = 0.0
    for qi, q in enumerate(qs):
        order = np.argsort(-S[qi])
        top = [doc_ids[order[0]]]
        top5 = [doc_ids[i] for i in order[:5]]
        g = gold[q]
        r1 += len(set(top) & g) / len(g)
        r5 += len(set(top5) & g) / len(g)
        top1 += 1.0 if (top[0] in g) else 0.0
    n = len(qs)
    return dict(R1=r1 / n, R5=r5 / n, top1=top1 / n)


def main():
    z = np.load(FEATS, allow_pickle=True)
    doc_ids = [str(x) for x in z["doc_ids"]]
    qids = [str(x) for x in z["qids"]]
    idx_of = {q: i for i, q in enumerate(qids)}
    N, D = len(qids), len(doc_ids)

    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    qtext = {c["qid"]: c["question"] for c in cases}
    gold = {c["qid"]: {f"{c['db_id']}::{g.lower()}" for g in c["gold"]} for c in cases}
    didx = {d: j for j, d in enumerate(doc_ids)}

    cache = json.load(open(SCHEMA, encoding="utf-8"))["spider"]

    # ---------- 公共表解析（不计入各方法建索引） ----------
    name_t, col_t, val_t, all_t, db_t = {}, {}, {}, {}, {}
    fk_edges = defaultdict(list)          # db -> [(t1, t2), ...] 无向
    for db, s in cache.items():
        for t in s["tables"]:
            fid = f"{db}::{t['name'].lower()}"
            if fid not in didx:
                continue
            nm, cl, vl = set(qtoks(t["name"])) or {t["name"].lower()}, set(), set()
            for c in t["columns"]:
                cl |= set(qtoks(str(c["name"])))
                for v in (c.get("values") or [])[:12]:
                    vl |= set(qtoks(str(v)))
            name_t[fid], col_t[fid], val_t[fid] = nm, cl, vl
            all_t[fid] = nm | cl | vl
            db_t[fid] = db
        for fk in s.get("fks", []):
            t1, t2 = f"{db}::{fk[0].lower()}", f"{db}::{fk[2].lower()}"
            if t1 in didx and t2 in didx and t1 != t2:
                fk_edges[db].append((t1, t2))
                fk_edges[db].append((t2, t1))

    dj = [didx[d] for d in doc_ids]
    nset = [name_t[d] for d in doc_ids]
    cset = [col_t[d] for d in doc_ids]
    vset = [val_t[d] for d in doc_ids]
    aset = [all_t[d] for d in doc_ids]
    sset = [name_t[d] | col_t[d] for d in doc_ids]      # 仅 schema，不含值

    df_all, df_sch = Counter(), Counter()
    for a in aset:
        df_all.update(a)
    for s_ in sset:
        df_sch.update(s_)
    idf_all = {t: math.log(1 + (D - c + 0.5) / (c + 0.5)) for t, c in df_all.items()}
    idf_sch = {t: math.log(1 + (D - c + 0.5) / (c + 0.5)) for t, c in df_sch.items()}
    dl = np.array([len(a) for a in aset], dtype=np.float32)
    avgdl = float(dl.mean())

    # ---------- 方法实现 ----------
    def make_bm25(use_schema: bool):
        t0 = time.perf_counter()
        df = df_sch if use_schema else df_all
        idf = idf_sch if use_schema else idf_all
        inv = defaultdict(list)                  # token -> [(doc, tf)]
        for j, s_ in enumerate(sset if use_schema else aset):
            for t in s_:
                inv[t].append(j)
        built = time.perf_counter() - t0
        k1, b = 1.2, 0.75

        def score(toks):
            out = np.zeros(D, dtype=np.float32)
            qc = Counter(toks)
            for t, c in qc.items():
                posts = inv.get(t)
                if not posts:
                    continue
                w = idf.get(t, 0.0) * c
                for j in posts:
                    out[j] += w * (2.2) / (1.0 + 1.2 * (0.25 + 0.75 * dl[j] / avgdl))
            return out
        return score, built

    def make_tfidf():
        t0 = time.perf_counter()
        vocab = {t: i for i, t in enumerate(sorted(df_all))}
        M = np.zeros((D, len(vocab)), dtype=np.float32)
        for j, a in enumerate(aset):
            for t in a:
                M[j, vocab[t]] = idf_all[t]
        M /= np.linalg.norm(M, axis=1, keepdims=True) + 1e-9
        built = time.perf_counter() - t0

        def score(toks):
            q = np.zeros(len(vocab), dtype=np.float32)
            for t in toks:
                i = vocab.get(t)
                if i is not None:
                    q[i] = idf_all[t]
            q /= np.linalg.norm(q) + 1e-9
            return M @ q
        return score, built

    def make_jaccard():
        built = 0.0

        def score(toks):
            q = set(toks)
            if not q:
                return np.zeros(D, dtype=np.float32)
            return np.array([len(q & s_) / max(len(q | s_), 1) for s_ in sset],
                            dtype=np.float32)
        return score, built

    def make_lev():
        """token 级最佳编辑相似度：每个问句 token 与表名 token 逐一比对后取最大。

        整串编辑距离会被长问句稀释，不是该基线在 schema matching 里的标准用法。
        """
        t0 = time.perf_counter()
        vocab = sorted({t for s_ in nset for t in s_} |
                       {t for toks in (qtoks(qtext[q]) for q in qids) for t in toks})
        vidx = {t: i for i, t in enumerate(vocab)}
        K = len(vocab)
        sim = np.array(process.cdist(vocab, vocab, scorer=fuzz.ratio, workers=-1),
                       dtype=np.float32) / 100.0
        tab_tok_ids = [np.array([vidx[t] for t in sorted(s_)], dtype=np.int32) for s_ in nset]
        built = time.perf_counter() - t0

        def score(toks):
            qid = np.array([vidx[t] for t in toks if t in vidx], dtype=np.int32)
            if qid.size == 0:
                return np.zeros(D, dtype=np.float32)
            # 每张表：所有 (q token, 表名 token) 相似度里的最大值
            return np.array([sim[np.ix_(qid, ids)].max() for ids in tab_tok_ids],
                            dtype=np.float32)
        return score, built

    def make_value():
        t0 = time.perf_counter()
        inv = defaultdict(list)
        for j, v in enumerate(vset):
            for t in v:
                inv[t].append(j)
        built = time.perf_counter() - t0

        def score(toks):
            qc = Counter(toks)
            out = np.zeros(D, dtype=np.float32)
            qw = sum(idf_all.get(t, 0.0) for t in qc)
            for t, c in qc.items():
                for j in inv.get(t, ()):
                    out[j] += idf_all.get(t, 0.0)
            if qw > 0:
                out /= qw
            return out
        return score, built

    def make_graph():
        """词法种子（name+col Jaccard）+ 沿主外键一步扩散，alpha=0.3，两步。"""
        t0 = time.perf_counter()
        edges = defaultdict(list)
        for db, es in fk_edges.items():
            for a, b in es:
                edges[didx[a]].append(didx[b])
        built = time.perf_counter() - t0
        alpha = 0.3

        def score(toks):
            q = set(toks)
            if not q:
                return np.zeros(D, dtype=np.float32)
            seed = np.array([len(q & s_) / max(len(q | s_), 1) for s_ in sset],
                            dtype=np.float32)
            s = seed.copy()
            for _ in range(2):
                nb = np.zeros(D, dtype=np.float32)
                for a, bs in edges.items():
                    if s[a] > 0:
                        for b in bs:
                            nb[b] = max(nb[b], s[a])
                s = seed + alpha * nb
            return s
        return score, built

    methods = {
        "bm25_all": make_bm25(False),
        "bm25_schema": make_bm25(True),
        "tfidf_cos": make_tfidf(),
        "jaccard": make_jaccard(),
        "levenshtein": make_lev(),
        "value_overlap": make_value(),
        "schema_graph": make_graph(),
    }

    # ---------- 打分（全量 1034，冷启动取子集） ----------
    rows = json.load(open(DENSE, encoding="utf-8"))["rows"]
    te = [r["qid"] for r in rows]
    te_set = set(te)
    te_db = {r["db"] for r in rows}
    folds = json.load(open(FOLDS, encoding="utf-8"))

    qtok_all = {}
    t_tok = time.perf_counter()
    for q in qids:
        qtok_all[q] = qtoks(qtext[q])
    tok_ms = (time.perf_counter() - t_tok) / N * 1000

    res = {}
    for name, (score, built) in methods.items():
        t0 = time.perf_counter()
        S = np.empty((N, D), dtype=np.float32)
        for i, q in enumerate(qids):
            S[i] = score(qtok_all[q])
        sec = time.perf_counter() - t0

        tei = [idx_of[q] for q in te]
        m_te = ev(S[tei], te, gold, doc_ids)
        m_all = ev(S, qids, gold, doc_ids)
        per_fold = []
        for f in folds:
            fi = [idx_of[q] for q in f]
            per_fold.append(ev(S[fi], f, gold, doc_ids))
        res[name] = dict(
            cold=dict(m_te, n=len(te), n_db=len(te_db)),
            all=dict(m_all, n=N),
            folds=dict(
                R1=float(np.mean([x["R1"] for x in per_fold])),
                R1_sd=float(np.std([x["R1"] for x in per_fold], ddof=1)),
                R5=float(np.mean([x["R5"] for x in per_fold])),
                R5_sd=float(np.std([x["R5"] for x in per_fold], ddof=1)),
                top1=float(np.mean([x["top1"] for x in per_fold])),
            ),
            index_build_ms=built * 1000,
            query_ms=sec / N * 1000,
        )
        print(f"{name:14s} cold R@1={m_te['R1']*100:.2f} R@5={m_te['R5']*100:.2f} "
              f"top1={m_te['top1']*100:.2f} | all R@1={m_all['R1']*100:.2f} "
              f"R@5={m_all['R5']*100:.2f} | {res[name]['query_ms']:.2f} ms/q")

    ref = {}
    for p, tag in ((W + r"\z_split341.json", "forge_cold"),
                   (W + r"\z_cv_results.json", "forge_cv")):
        try:
            ref[tag] = json.load(open(p, encoding="utf-8"))
        except Exception as e:                     # noqa: BLE001
            ref[tag] = str(e)

    out = dict(
        protocol=dict(n_questions=N, n_tables=D, cold_n=len(te), cold_dbs=sorted(te_db),
                      metric="R@1/R@5 partial-credit over gold tables; top1 exact"),
        tokenize_ms_per_q=tok_ms,
        methods=res,
        forge_reference=ref,
    )
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("\nwrote", OUT)


if __name__ == "__main__":
    main()
