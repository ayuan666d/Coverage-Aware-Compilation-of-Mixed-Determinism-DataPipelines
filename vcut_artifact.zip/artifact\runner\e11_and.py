"""E11-DIAG2: turn the diagnosis into an operator and see if it moves.

Diagnosis (e11_diag.py) says the loss is concentrated in two places:
  * 62/341 questions have no lexical anchor at all -> nothing a catalogue-only
    operator can do (BM25 and the graph both score the gold table exactly 0).
  * when the anchor exists but is a hub (token df >= 2) the graph is WORSE than
    BM25, and idf-weighting the edges does not repair it (0.4746 -> 0.4702),
    because idf scales every neighbour of the hub by the same factor: the
    confusion happens *inside* one token's neighbourhood, not between tokens.

What the current operator throws away is conjunction: a table supported by
"flight" AND "name" should beat one supported by "name" alone, but summing the
seed masses (OR semantics) cannot express that.  So compute a per-token
reachability vector and fuse tokens with AND-like aggregation instead of a sum.
Gradient-free, and it is the same object a path certificate needs (every query
token must be explained).

Variants scored here:
  sum        : the current operator (union PPR + band), for reference
  count      : |query tokens in doc|  (pure conjunction, no weights)
  and_min    : min over query tokens of that token's normalised table score
  geom       : geometric mean over query tokens
  harm       : harmonic mean
  cov_min    : sum x (fraction of query tokens that reach the table)
"""
from __future__ import annotations

import json
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
from e11_data import toks  # noqa: E402
from e11_run_spider import band_fn, coquery_map, fks_of, tables_of  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
CACHE = Path("D:/vldb2027_e11/schema_cache.json")
CASES = REPO / "06_结果" / "e11_cases.json"
DIAG = REPO / "06_结果" / "e11_diag.json"
EMB = Path("D:/vldb2027_e11/e11_emb_spider.npz")
OUT = REPO / "06_结果" / "e11_and.json"
EPS = 1e-6


def main():
    cache = json.load(open(CACHE, encoding="utf-8"))
    data = json.load(open(CASES, encoding="utf-8"))
    dg = json.load(open(DIAG, encoding="utf-8"))
    bucket = {r["qid"]: r["bridge_bucket"] for r in dg["rows"]}
    test = [c for c in data["spider"] if c["split"] == "test"]

    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += tables_of(cache, db, prefix=True)
        fks += fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    coq = coquery_map([c for c in data["spider"] if c["split"] == "train"], prefix=True)
    cat = g.Catalog(tabs, fks, coquery=coq, prefix_db=True)
    bf, _ = band_fn(test)
    nt = len(cat.tables)

    z = np.load(EMB, allow_pickle=True)
    Dm, Qm = z["D"].astype(np.float32), z["Q"].astype(np.float32)
    qpos = {q: i for i, q in enumerate(list(z["qids"]))}

    # ---- per-token reachability, cached (the expensive part is paid once)
    t0 = time.time()
    qv_tokens = set()
    for c in test:
        qv_tokens |= set(toks(c["question"]))
    known = sorted(w for w in qv_tokens if ("token", w) in cat.idx)
    tok_scores: dict[str, np.ndarray] = {}
    for k, w in enumerate(known):
        x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, alpha=0.85, iters=20)
        s = cat.table_scores(x)
        mx = float(s.max())
        tok_scores[w] = s / mx if mx > 0 else s
        if (k + 1) % 150 == 0:
            print(f"tokens {k+1}/{len(known)} {time.time()-t0:.0f}s", flush=True)
    print(f"per-token PPR cached for {len(tok_scores)} tokens in {time.time()-t0:.1f}s", flush=True)

    docsets = [set(g.table_doc(t)) for t in cat.tables]

    def and_aggregate(q: list[str], mode: str) -> np.ndarray:
        ws = [w for w in set(q) if w in tok_scores]
        if not ws:
            return np.zeros(nt, dtype=np.float32)
        M = np.stack([tok_scores[w] for w in ws])          # (|q|, n_tables)
        if mode == "and_min":
            return M.min(axis=0)
        if mode == "geom":
            return np.exp(np.log(M + EPS).mean(axis=0))
        if mode == "harm":
            return len(ws) / (1.0 / (M + EPS)).sum(axis=0)
        if mode == "count":
            return np.array([sum(1 for w in set(q) if w in d) for d in docsets], dtype=np.float32)
        if mode == "sum":
            return M.sum(axis=0)
        raise ValueError(mode)

    rows = []
    for n, c in enumerate(test):
        q = toks(c["question"])
        gold = {f"{c['db_id']}::{t}" for t in c["gold"]}
        bw = bf(q)
        methods = {
            "bm25": g.bm25(cat, q),
            "sum_band": g.single_ppr(cat, q, band_weight=bw),
            "typed_band": g.fuse(cat, q, band_weight=bw),
            "sum": and_aggregate(q, "sum"),
            "count": and_aggregate(q, "count"),
            "and_min": and_aggregate(q, "and_min"),
            "geom": and_aggregate(q, "geom"),
            "harm": and_aggregate(q, "harm"),
        }
        ws = [w for w in set(q) if w in tok_scores]
        cov = and_aggregate(q, "sum") * (len(ws) / max(1, len(set(q))))
        methods["cov_min"] = cov
        s_dense = Dm @ Qm[qpos[c["qid"]]]
        methods["dense"] = s_dense
        rec = {"qid": c["qid"], "bucket": bucket[c["qid"]], "gold": sorted(gold)}
        for name, s in methods.items():
            r = g.rank(s, cat)
            m = g.metrics(r, gold)
            rec[f"{name}_r5"] = round(m["recall@5"], 4)
            rec[f"{name}_r1"] = round(m["recall@1"], 4)
            rec[f"{name}_rank"] = next((i for i, t in enumerate(r, 1) if t in gold), 999)
        rows.append(rec)
        if (n + 1) % 60 == 0:
            print(f"{n+1}/{len(test)}", flush=True)

    names = [k for k in rows[0] if k.endswith("_r5")]
    names = [x[:-3] for x in names]

    def agg(sel):
        s = [r for r in rows if sel(r)]
        if not s:
            return {"n": 0}
        return {"n": len(s), **{m: round(float(np.mean([r[f"{m}_r5"] for r in s])), 4) for m in names},
                **{f"{m}@1": round(float(np.mean([r[f"{m}_r1"] for r in s])), 4) for m in names}}

    buckets = sorted({r["bucket"] for r in rows})
    out = {"n": len(rows), "tokens_cached": len(tok_scores),
           "overall": agg(lambda r: True),
           "by_bucket": {b: agg(lambda r, b=b: r["bucket"] == b) for b in buckets},
           "gold_rank_le20": {m: sum(1 for r in rows if r[f"{m}_rank"] <= 20) for m in names},
           "names": names, "rows": rows}
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=2))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
