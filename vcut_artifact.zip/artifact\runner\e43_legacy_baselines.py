"""E43：把基线搬到 legacy 目录上——同一 10k 目录、同一 1034 问。

背景：E40/E41 的 57.32 / 77.91 没有任何同目录基线可对。E28/E29 的 bm25 42.72、
dense 80.11 全部建立在旧合成干扰集（db_size AUC 0.9997、表名长度 AUC 0.9239）上，
不能与 legacy 读数并列。本实验只做一件事：**目录构造与 E41 逐字一致**，把
BM25 / fuse / dense 三个基线放上去，给出同目录同问集的对照。

目录构造（必须与 e32_scale_forge.py 的 LEGACY 分支完全一致）：
  base   = spider 876（tables_of）+ bird 75
  donors = 排除 20 个 dev20 测试库的 spider 表 + 全部 bird
  place  = 全部 176 库的真实表数（含测试库，否则"没被塞的库"= 含答案的库）
  extra  = legacy_tables(donors, 10000-951, place=place, seed=40)
嵌套保证：951 点无 extra，10k 点的前 951 张就是 951 点的目录，因此只编码一次
10k 文档，前 n 行即 n 表目录，规模曲线是同一条目录的生长。

dense 协议与 E29 完全一致（`db :: name | columns | values(每列 12 值)`，
Qwen3-Embedding-0.6B，max_seq_length=128，normalize），以便与 E29 的旧合成读数
做"只换干扰集"的差分。

用法（ssptrain 环境）：
  $env:E43_SIZE="951,10000"
  python e43_legacy_baselines.py
输出：D:\\vldb2027_e11\\e43_legacy_baselines.json + e43_legacy_{tag}_perq.jsonl
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import e11_graph as g  # noqa: E402
import e28_scale as s28  # noqa: E402
from e40_legacy import legacy_tables  # noqa: E402

WORK = Path(r"D:\vldb2027_e11")
REPO = Path(__file__).resolve().parents[2]
CASES = Path(os.environ.get("E43_CASES", str(REPO / "06_结果" / "e35_dev20_cases.json")))
OUT = Path(os.environ.get("E43_OUT", str(WORK / "e43_legacy_baselines.json")))
SIZES = sorted(int(x) for x in os.environ.get("E43_SIZE", "951,10000").split(","))
EPS = 1e-6


def fid(db, name):
    """与 e32 的 fid 同一实现：库名与表名同时小写。"""
    return f"{str(db).lower()}::{str(name).lower()}"


def doc_text(t):
    """与 E29 的 doc_text 逐字相同（每列 12 值），只换目录。"""
    parts = [f"{t['db']} :: {t['name']}"]
    cols, vals = [], []
    for c in t["columns"]:
        cols.append(c["name"])
        vals += [str(v) for v in (c.get("values") or [])[:12]]
    parts.append("columns: " + ", ".join(cols))
    if vals:
        parts.append("values: " + ", ".join(vals))
    return " | ".join(parts)


def ev(ranked, gold):
    return dict(R1=len(set(ranked[:1]) & gold) / len(gold),
                R5=len(set(ranked[:5]) & gold) / len(gold),
                top1=1.0 if ranked[0] in gold else 0.0,
                hit20=len(set(ranked[:20]) & gold) / len(gold))


def build_catalog():
    """复刻 e32 LEGACY 分支的目录构造；返回 (all_tabs, fks, n_real, cases, test)。"""
    g.SPLIT_IDENT = True
    cache = json.load(open(WORK / "schema_cache.json", encoding="utf-8"))
    cases = json.load(open(CASES, encoding="utf-8"))["spider"]
    test = [c for c in cases if c["split"] == "test"]
    test_dbs = {c["db_id"] for c in test}

    tabs, fks = [], []
    for db in cache["spider"]:
        tabs += s28.tables_of(cache, db, prefix=True)
        fks += s28.fks_of(cache, db, cache["spider"][db]["tables"], prefix=True)
    bird = []
    for db, s in cache["bird"].items():
        bird += [dict(t, db=db) for t in s["tables"]]

    base = tabs + bird
    n_real = len(base)
    donors = [t for t in tabs if t["db"] not in test_dbs] + bird
    place = {db: len(cache["spider"][db]["tables"]) for db in cache["spider"]}
    place.update({db: len(s["tables"]) for db, s in cache["bird"].items()})

    need = max(SIZES) - n_real
    extra = legacy_tables(donors, need, place=place,
                          seed=int(os.environ.get("LEGACY_SEED", "40"))) if need > 0 else []
    all_tabs = base + extra
    print(f"[catalog] N={len(all_tabs)} 真实={n_real} 干扰={len(extra)} "
          f"donors={len(donors)} 库={len(place)}", flush=True)
    return all_tabs, fks, n_real, cases, test


def main():
    all_tabs, fks, n_real, cases, test = build_catalog()
    doc_ids = [fid(t["db"], t["name"]) for t in all_tabs]
    h = hashlib.sha1()
    for i, t in enumerate(all_tabs):
        h.update(f"{doc_ids[i]}|{len(t['columns'])}|".encode())
    doc_hash = h.hexdigest()[:16]
    print(f"[catalog] doc_hash={doc_hash}", flush=True)

    qsets = [set(g.toks(c["question"])) for c in test]
    golds = [{fid(c["db_id"], x) for x in c["gold"]} for c in test]
    res = json.load(open(OUT, encoding="utf-8")) if OUT.exists() else {}

    # ---------- dense：只编码一次最大目录 ----------
    from sentence_transformers import SentenceTransformer
    t_enc = time.perf_counter()
    model = SentenceTransformer(str(WORK / "models" / "Qwen3-Embedding-0.6B"),
                                device="cuda")
    model.max_seq_length = 128
    Q = model.encode([c["question"] for c in test], batch_size=32,
                     convert_to_numpy=True, normalize_embeddings=True,
                     prompt_name="query", show_progress_bar=False)
    D = model.encode([doc_text(t) for t in all_tabs], batch_size=32,
                     convert_to_numpy=True, normalize_embeddings=True,
                     show_progress_bar=False)
    enc_s = time.perf_counter() - t_enc
    print(f"[dense] 编码完成 {enc_s:.0f}s  docs={D.shape[0]}x{D.shape[1]}", flush=True)

    for n in SIZES:
        tag = "951" if n == 951 else f"{n // 1000}k-syn"
        t0 = time.perf_counter()
        sub = all_tabs[:n]
        sub_ids = doc_ids[:n]

        # ---- BM25 / fuse：与 e28_scale.py 同一实现 ----
        cat = g.Catalog(sub, fks, coquery=None, prefix_db=True)
        N = len(cat.tables)
        toks = sorted({w for qs in qsets for w in qs if ("token", w) in cat.idx})
        tok = {}
        for w in toks:
            x = g.ppr(cat.union, {cat.idx[("token", w)]: 1.0}, 0.85, 20)
            s = cat.table_scores(x)
            mx = float(s.max())
            tok[w] = s / mx if mx > 0 else s
        idf = {w: math.log(1 + (N - cat.token_df.get(w, 0) + 0.5) /
                           (cat.token_df.get(w, 0) + 0.5)) for w in tok}

        # 一次算完 1034 × n 的余弦矩阵（41 MB @10k），避免逐问重复做矩阵乘
        S_all = Q @ D[:n].T
        rows_b, rows_f, rows_d, pq = [], [], [], []
        for qi, (c, qs, gold) in enumerate(zip(test, qsets, golds)):
            b = g.bm25(cat, qs)
            b_order = np.argsort(-b)
            b_rank = [cat.table_ids[i].lower() for i in b_order]
            rb = ev(b_rank, gold)

            ws = [w for w in qs if w in tok]
            if ws:
                M = np.stack([tok[w] for w in ws])
                iw = np.array([idf[w] for w in ws])[:, None]
                graph = np.exp((iw * np.log(M + EPS)).sum(axis=0) / iw.sum())
            else:
                graph = np.zeros(N, dtype=np.float32)
            top = b_order[:30]
            mixed = b.copy()
            basev = float(b[top[-1]])
            for k, idx in enumerate(top[np.argsort(-graph[top])]):
                mixed[idx] = basev + (30 - k) * 1e-6
            f_rank = [cat.table_ids[i].lower() for i in np.argsort(-mixed)]
            rf = ev(f_rank, gold)

            S = S_all[qi]
            order = np.argsort(-S)[:20]
            d_rank = [sub_ids[i] for i in order]
            rd = ev(d_rank, gold)

            rows_b.append(rb)
            rows_f.append(rf)
            rows_d.append(rd)
            pq.append({"tag": tag, "qid": c["qid"], "db": c["db_id"],
                       "n_gold": len(gold), "src": c.get("src", "dev"),
                       "bm25": rb, "fuse": rf, "dense": rd})

        agg = {}
        for name, rows in (("bm25", rows_b), ("fuse", rows_f), ("dense", rows_d)):
            agg[name] = {k: float(np.mean([r[k] for r in rows]))
                         for k in ("R1", "R5", "top1", "hit20")}
        res[tag] = dict(N=n, n_real=n_real, n_synth=n - n_real, doc_hash=doc_hash,
                        encode_s=enc_s, sec=time.perf_counter() - t0, **agg)
        res.setdefault("_meta", {})["cases"] = str(CASES)
        res["_meta"]["doc_hash"] = doc_hash
        json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

        print(f"[{tag}] N={n:6d} | bm25 {agg['bm25']['R1']*100:5.2f}/"
              f"{agg['bm25']['R5']*100:5.2f} | fuse {agg['fuse']['R1']*100:5.2f}/"
              f"{agg['fuse']['R5']*100:5.2f} | dense {agg['dense']['R1']*100:5.2f}/"
              f"{agg['dense']['R5']*100:5.2f} ({time.perf_counter()-t0:.0f}s)",
              flush=True)

        pq_path = OUT.with_name(f"{OUT.stem}_{tag}_perq.jsonl")
        with open(pq_path, "w", encoding="utf-8") as f:
            for rec in pq:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        del cat
        import gc
        gc.collect()


if __name__ == "__main__":
    main()
