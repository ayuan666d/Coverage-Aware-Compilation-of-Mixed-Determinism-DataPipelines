# -*- coding: utf-8 -*-
"""构造性修复器 —— 定理 2（v0.3 边插入模型）的可执行化

语义出处（01_理论/sec3_4_formalization_v0.3.md）：
    定理 1 违反 = 存在 entry→sink 路径完全避开 V_eff。
    修复 = 边割插入：在 G \\ V_eff 的最小边割的每条边上串入一个新判决
    节点。插入节点按保守兜底编码（∀t judged ⟹ eff 恒真）并入 V_eff。
    Menger 对偶：每出口的插入数 = 该出口在残余图上的最小边割宽度
    （= 最大边不相交路径数）。多出口按排序逐个处理，先前插入的判决
    进入后续出口的 blocked 集（残余贪心：共享割自动复用）。

工程动作（五纪律 #4/#5 的落实）：
    · 修复模型是**边割**（不是顶点割）：插入落在边上；源出边与汇入边
      同为合法修复位置；源与汇节点本身不可割（超级源弧容量 INF）。
    · 插入节点的**表**由调用方负责，必须取保守兜底（fallback ∈
      {reject, review}）——本模块是结构层，不替调用方默认；胶水层
      （runner/e4b_repair.py 的 repair_pipe）固定 fallback="reject"。

正确性主张分两层，缺一不可：
    1. 构造层：割边替换后，避开全部判决的 entry→sink 路径不存在——
       否则它 lifts 成 G\\V_eff 中避开割边的 sources→sink 路径，与割
       定义矛盾。
    2. 验证层：修复结果必须经独立重验。本模块内置 B 组可达性重验；
       小图的 A 组枚举对拍在 runner/tests 层做（axioms 不 import
       graphutil 的纪律不变）。重验失败按 bug 处理，不进统计。

与 E4 的关系：e4.py 的五类操作是**攻击侧**（随机变异测重写必要性）；
本模块是**构造侧**（给定不安全管线，产出修复后管线）。E4 报告 L2
声明两者不可互相冒充：insert=0% 只验证割单调性，不验证定理 4。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from time import perf_counter
from typing import Collection, Dict, List, Mapping, Sequence, Set, Tuple

from . import graphutil as GU

CONSERVATIVE_FALLBACKS = frozenset({"reject", "review"})


@dataclass(frozen=True)
class Insertion:
    """一次边割插入：把 replaced 边替换为 (a, node) 与 (node, b)。"""

    sink: str                      # 为哪个出口的割而插入
    replaced: Tuple[str, str]      # 被替换的原始边（割边）
    node: str                      # 新判决节点 id


@dataclass
class SinkRepair:
    """单个出口的修复记录（证书的最小单元）。"""

    sink: str
    cut_edges: List[Tuple[str, str]]     # 该出口残余图上的最小边割
    insertions: List[Insertion]
    width: int                           # 割宽 = 插入数
    menger: int                          # 最大边不相交路径数（对偶校验值）


@dataclass
class RepairOutcome:
    """repair_edge_insertion 的返回值。

    status:
        already_safe  输入即安全，零插入（幂等性的形式）
        repaired      完成插入且 B 组重验通过
        unrepairable  存在边插入模型无法修复的出口（见 unrepairable_reasons）
    verified_safe: 最终结构重验结果（unrepairable 时可为 False）
    new_nodes / new_edges: 结构补丁——new_nodes 是新增判决 id → kind，
        new_edges 是修复后的完整边表（未变时为输入的拷贝）。
    """

    status: str
    verified_safe: bool
    per_sink: List[SinkRepair] = field(default_factory=list)
    unrepairable_reasons: Dict[str, str] = field(default_factory=dict)
    new_nodes: Dict[str, str] = field(default_factory=dict)
    new_edges: List[Tuple[str, str]] = field(default_factory=list)
    stats: Dict[str, float] = field(default_factory=dict)

    @property
    def insertions(self) -> List[Insertion]:
        return [ins for sr in self.per_sink for ins in sr.insertions]


def _succ_of(nodes: Collection[str], edges: Sequence[Tuple[str, str]]) -> Dict[str, List[str]]:
    """邻接表。必须以全部节点为键：孤立节点（源即汇）的空路径也参与语义。"""
    s: Dict[str, List[str]] = {n: [] for n in nodes}
    for a, b in edges:
        s.setdefault(a, []).append(b)
        s.setdefault(b, [])
    return s


def _reachable_avoiding(
    sources: Sequence[str],
    targets: Set[str],
    succ: Mapping[str, Sequence[str]],
    blocked: FrozenSet[str],
) -> Set[str]:
    """sources 中任一源避开 blocked 能到达的 targets 子集。

    空路径也算路径：src 本身是 target 时即命中（与 e4.struct_safe 的
    reachable_set 含起点一致；这正是"源即汇不可用边插入修复"的根据）。
    """
    hit: Set[str] = set()
    tset = set(targets)
    for src in sources:
        if src in blocked:
            continue
        if src in tset:
            hit.add(src)
        reach = GU.reachable_set(src, succ, blocked)
        hit |= reach & tset
        if len(hit) == len(tset):
            break
    return hit


def repair_edge_insertion(
    nodes: Mapping[str, str],
    edges: Sequence[Tuple[str, str]],
    verdicts: Collection[str],
    sources: Sequence[str],
    sinks: Sequence[str],
    *,
    node_prefix: str = "v_fix",
) -> RepairOutcome:
    """构造性修复：最小边割插入判决，恢复定理 1（结构层，p_miss=0 语义）。

    参数全部是纯数据（与 Pipe 解耦）；调用方负责把 new_nodes 编码成
    判决节点并挂保守兜底的表。
    """
    t0 = perf_counter()

    all_nodes = list(nodes)
    srcs = list(sources)
    snks = sorted(set(sinks))
    verdict_set: Set[str] = set(verdicts)

    edges_cur = list(edges)
    succ = _succ_of(all_nodes, edges_cur)
    if GU.has_cycle(all_nodes, succ):
        raise ValueError("输入图有环：修复模型只对 DAG 定义（调用前须自检）")

    # 每出口逐步修复；已插入判决进入后续出口的 blocked（残余贪心）
    per_sink: List[SinkRepair] = []
    unrepairable: Dict[str, str] = {}
    n_inserted = 0
    t_cut = 0.0

    for s in snks:
        blocked = frozenset(verdict_set)
        cur_succ = _succ_of(all_nodes, edges_cur)
        hit = _reachable_avoiding(srcs, {s}, cur_succ, blocked)
        if s not in hit:
            per_sink.append(SinkRepair(sink=s, cut_edges=[], insertions=[],
                                       width=0, menger=0))
            continue
        if s in set(srcs):
            unrepairable[s] = (
                "sink 即 source：空路径不存在可割边，边插入模型不可修复"
                "（工程动作：在输出端强制串判决，属拓扑变更，超出本模型）"
            )
            continue

        t1 = perf_counter()
        cut = GU.min_edge_cut_multi(srcs, s, all_nodes, cur_succ, blocked)
        menger = GU.max_edge_disjoint_paths_multi(
            srcs, s, all_nodes, cur_succ, blocked
        )
        t_cut += perf_counter() - t1
        if not cut or menger >= GU.INF or menger != len(cut):
            unrepairable[s] = (
                f"割计算异常（cut={cut!r}, menger={menger}）："
                "可达但无有限割与 Menger 对偶矛盾，按 bug 处理"
            )
            continue

        acts: List[Insertion] = []
        for (a, b) in cut:
            v = f"{node_prefix}{n_inserted}"
            n_inserted += 1
            edges_cur.remove((a, b))
            edges_cur.append((a, v))
            edges_cur.append((v, b))
            all_nodes.append(v)
            verdict_set.add(v)
            acts.append(Insertion(sink=s, replaced=(a, b), node=v))
        per_sink.append(SinkRepair(sink=s, cut_edges=list(cut),
                                   insertions=acts, width=len(cut),
                                   menger=menger))

    # B 组独立重验（checker 语义：每出口从所有源避开全部判决不可达）
    final_succ = _succ_of(all_nodes, edges_cur)
    final_blocked = frozenset(verdict_set)
    residual = _reachable_avoiding(srcs, set(snks), final_succ, final_blocked)
    verified_safe = not residual

    t_total = perf_counter() - t0
    if unrepairable:
        status = "unrepairable"
    elif n_inserted == 0:
        status = "already_safe"
    else:
        status = "repaired"
    if unrepairable and not residual and n_inserted > 0:
        # 可修复出口已修好、不可修复出口另计
        status = "unrepairable"

    return RepairOutcome(
        status=status,
        verified_safe=verified_safe,
        per_sink=per_sink,
        unrepairable_reasons=unrepairable,
        new_nodes={ins.node: "rule" for sr in per_sink for ins in sr.insertions},
        new_edges=list(edges_cur),
        stats={
            "cut_ms": round(t_cut * 1000, 3),
            "total_ms": round(t_total * 1000, 3),
            "n_cut_calls": sum(1 for sr in per_sink if sr.cut_edges),
            "n_insertions": n_inserted,
        },
    )
