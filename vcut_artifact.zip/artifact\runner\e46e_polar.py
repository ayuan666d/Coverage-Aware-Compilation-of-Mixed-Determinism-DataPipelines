"""E46e 极化度：编译式评分 vs 相似度评分的分布形状差异。"""
import json
import numpy as np
from scipy import stats

D = "D:/vldb2027_e11"
N_REAL, M10 = 951, 9049


def L(p):
    return [json.loads(l) for l in open(f"{D}/{p}", encoding="utf-8")]


def forge(p):
    return [(q["qid"], q["n_gold"], q["gpos_real"], q["gpos"]) for q in L(p)]


def base(p, m):
    return [(q["qid"], q["n_gold"], q[m]["gpos_real"], q[m]["gpos"]) for q in L(p)]


SETS = [
    ("FORGE", forge("e44_forge_rich_10k-syn-leg_perq.jsonl")),
    ("dense", base("e44_legacy_rich_10k-syn_perq.jsonl", "dense")),
    ("fuse", base("e44_legacy_rich_10k-syn_perq.jsonl", "fuse")),
    ("bm25", base("e44_legacy_rich_10k-syn_perq.jsonl", "bm25")),
]

print("=" * 84)
print("【1】r（真实表内 rank）的分布形状：编译是离散的，相似度是连续的")
print("=" * 84)
print(f"  {'方法':7s} {'r=0':>7} {'r=1':>7} {'r=2-4':>7} {'r=5-19':>7} "
      f"{'r>=20':>7} {'Gini':>7} {'CV':>7}")
for name, recs in SETS:
    r = np.array([a for qid, ng, rr, gg in recs for a in rr], float)
    b = [np.mean(r == 0), np.mean(r == 1), np.mean((r >= 2) & (r < 5)),
         np.mean((r >= 5) & (r < 20)), np.mean(r >= 20)]
    # Gini
    s = np.sort(r)
    n = len(s)
    gini = (2 * np.sum((np.arange(1, n + 1)) * s) / (n * s.sum()) - (n + 1) / n)
    print(f"  {name:7s} " + "".join(f"{x*100:6.1f}%" for x in b)
          + f" {gini:7.3f} {r.std()/max(r.mean(),1e-9):7.2f}")

print("\n" + "=" * 84)
print("【2】X（金标前干扰表数）的四段分布：极化 vs 中庸")
print("=" * 84)
print(f"  {'方法':7s} {'X=0':>7} {'1-4':>7} {'5-19':>7} {'20-99':>7} "
      f"{'100-999':>8} {'>=1000':>8}")
for name, recs in SETS:
    X = np.array([g - a for qid, ng, rr, gg in recs for a, g in zip(rr, gg)], float)
    seg = [np.mean(X == 0), np.mean((X >= 1) & (X < 5)), np.mean((X >= 5) & (X < 20)),
           np.mean((X >= 20) & (X < 100)), np.mean((X >= 100) & (X < 1000)),
           np.mean(X >= 1000)]
    print(f"  {name:7s} " + "".join(f"{x*100:6.1f}%" for x in seg[:3])
          + f" {seg[3]*100:7.1f}% {seg[4]*100:7.1f}% {seg[5]*100:7.1f}%")

print("\n  极化度 P_pol = P(X=0) + P(X>=100)  （两端），中间度 P_mid = P(0<X<100)")
print(f"  {'方法':7s} {'P_pol':>8} {'P_mid':>8} {'比值':>8}")
for name, recs in SETS:
    X = np.array([g - a for qid, ng, rr, gg in recs for a, g in zip(rr, gg)], float)
    pol = np.mean(X == 0) + np.mean(X >= 100)
    mid = 1 - pol
    print(f"  {name:7s} {pol*100:7.1f}% {mid*100:7.1f}% {pol/mid:8.2f}")

print("\n" + "=" * 84)
print("【3】双模态检验：log10(X+1) 的核密度峰数（Sarle 双峰系数）")
print("=" * 84)
for name, recs in SETS:
    X = np.array([g - a for qid, ng, rr, gg in recs for a, g in zip(rr, gg)], float)
    y = np.log10(X + 1)
    n = len(y)
    m2 = stats.moment(y, 2)
    m3 = stats.moment(y, 3)
    m4 = stats.moment(y, 4)
    sarle = (m3 ** 2 + 1) / (m4 + 3 * (n - 1) ** 2 / ((n - 2) * (n - 3)))
    skew = stats.skew(y)
    kurt = stats.kurtosis(y)
    print(f"  {name:7s} log10(X+1): 偏度={skew:+.3f} 峰度={kurt:+7.2f} "
          f"Sarle={sarle:.4f} {'（双峰）' if sarle < 0.555 else '（单峰）'}")

print("\n" + "=" * 84)
print("【4】把 r 与 X 合起来：金标在分数轴上的位置分布")
print("=" * 84)
print("  若评分是「求值」（离散约束命中），金标应成簇落在少数几个名次；")
print("  若评分是「相似」（连续内积），金标名次应平滑铺开。")
print(f"  {'方法':7s} {'top1 质量':>10} {'top5 质量':>10} {'top5外质量':>11} {'集中度':>8}")
for name, recs in SETS:
    gg = np.array([p for qid, ng, rr, g in recs for p in g], float)
    t1 = np.mean(gg == 0)
    t5 = np.mean(gg < 5)
    t5o = np.mean(gg >= 5)
    # 集中度：top1 占 top5 的比例
    print(f"  {name:7s} {t1*100:9.1f}% {t5*100:9.1f}% {t5o*100:10.1f}% "
          f"{t1/max(t5,1e-9)*100:7.1f}%")
