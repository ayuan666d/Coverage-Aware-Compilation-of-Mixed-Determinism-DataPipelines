"""E7n: CORD held-out test split with a second, local model.

DeepSeek-chat was the model under test on the 800-receipt train split.  The
held-out split is scored with qwen3:4b served by Ollama, reusing the *identical*
prompt and checker.  The point is not the model's accuracy but that the
certification decision is model-independent.
"""
from __future__ import annotations

import json
import sys
import time
import urllib.request
from collections import Counter
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from e7_receipts import (  # noqa: E402
    SYSTEM, judge, gold_of, parse_model, tokens_text,
)

REPO = Path(__file__).resolve().parents[2]
DATA = REPO / "04_数据" / "external" / "cord" / "test_adapted.parquet"
OUT = REPO / "06_结果" / "e7n_test_qwen3.json"
HOST = "http://127.0.0.1:11434/api/chat"


def call_ollama(model: str, text: str, timeout: int = 180) -> dict:
    body = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": "OCR tokens:\n" + text + "\n\nReturn the JSON object now."},
        ],
        "stream": False,
        "think": False,
        "format": "json",
        "options": {"temperature": 0, "num_predict": 900, "num_ctx": 8192},
    }).encode("utf-8")
    req = urllib.request.Request(HOST, data=body, headers={"Content-Type": "application/json"},
                                 method="POST")
    last = None
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = json.loads(r.read().decode("utf-8"))
            return {"raw": (data.get("message") or {}).get("content", ""),
                    "usage": {"total_tokens": data.get("eval_count", 0)}}
        except Exception as e:  # noqa: BLE001
            last = f"{type(e).__name__}: {e}"
            time.sleep(3 * (attempt + 1))
    return {"raw": "", "error": last, "usage": {}}


def main():
    model = sys.argv[1] if len(sys.argv) > 1 else "qwen3:4b"
    df = pd.read_parquet(DATA)
    rows = []
    t0 = time.perf_counter()
    for i, (_, r) in enumerate(df.iterrows()):
        text = tokens_text(r["ocr_text"])
        raw = call_ollama(model, text)
        gold = gold_of(r["ocr_kie"])
        m = parse_model(raw.get("raw", ""))
        j = judge(m, gold, text)
        rows.append({"file": r["file_name"], "text": text[:2000], "gold": gold,
                     "model": m, "raw": raw.get("raw", "")[:4000],
                     "usage": raw.get("usage", {}), "error": raw.get("error"), **j})
        if (i + 1) % 10 == 0:
            print(f"{i+1}/{len(df)} {time.perf_counter()-t0:.0f}s", flush=True)
            json.dump({"rows": rows}, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)

    n = len(rows)
    verdicts = Counter(r["verdict"] for r in rows)
    known = [r for r in rows if r["model_total_correct"] is not None]
    acc = sum(r["model_total_correct"] for r in known) / max(1, len(known))
    accepted = [r for r in rows if r["verdict"] in ("accept", "fill")]
    fp = sum(1 for r in accepted if r["total_correct"] is False)
    summary = {
        "model": model, "n": n, "verdicts": dict(verdicts),
        "model_total_accuracy": round(acc, 4),
        "accepted": len(accepted), "automation": round(len(accepted) / n, 4),
        "false_pass": fp, "false_pass_rate": round(fp / n, 4),
        "accepted_precision": round((len(accepted) - fp) / len(accepted), 4) if accepted else None,
        "errors": sum(1 for r in rows if r["error"]),
        "seconds": round(time.perf_counter() - t0, 1),
    }
    json.dump({"summary": summary, "rows": rows}, open(OUT, "w", encoding="utf-8"),
              ensure_ascii=False)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
